package com.nexus.gamelibrary

import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val Green = Color(0xFF3DDC6A)
private const val WEEK_MS = 7L * 24 * 60 * 60 * 1000

private fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "à l'instant"
        m < 60 -> "il y a $m min"
        m < 1440 -> "il y a ${m / 60} h"
        else -> "il y a ${m / 1440} j"
    }
}

@Composable
fun NexusGamesApp(resume: Int, openCrosshair: Int, onLaunch: (String, String) -> Unit) {
    val context = LocalContext.current
    val store = remember { Store(context) }

    var themeIndex by remember { mutableIntStateOf(store.themeIndex.coerceIn(0, themes.lastIndex)) }
    var columns by remember { mutableIntStateOf(store.columns.coerceIn(2, 4)) }
    var sortRecent by remember { mutableStateOf(store.sortRecent) }
    var assistant by remember { mutableStateOf(store.assistant) }
    var pinned by remember { mutableStateOf(store.pinned) }
    var hidden by remember { mutableStateOf(store.hidden) }
    var favorites by remember { mutableStateOf(store.favorites) }
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var filter by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<AppEntry?>(null) }
    var crosshairScreen by remember { mutableStateOf(false) }
    var crosshairOn by remember { mutableStateOf(store.crosshairOn) }
    var bgVersion by remember { mutableIntStateOf(0) }
    var bgBlur by remember { mutableIntStateOf(store.bgBlur.coerceIn(0, 100)) }
    var bgBlurUi by remember { mutableIntStateOf(bgBlur) }
    val scope = rememberCoroutineScope()
    val baseTheme = themes[themeIndex]

    // Photo de fond (floue) : rechargée quand on change la photo ou le niveau de flou
    val bg by produceState<ImageBitmap?>(null, bgVersion, bgBlur) {
        value = withContext(Dispatchers.Default) { loadBackground(context, bgBlur) }
    }
    val bgImage = bg
    // Avec une photo, les boutons et cartes deviennent translucides (effet verre)
    val theme = if (bgImage != null) baseTheme.copy(tile = baseTheme.tile.copy(alpha = 0.42f)) else baseTheme

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { saveBackground(context, uri) }
                if (ok) bgVersion++
                else Toast.makeText(context, "Impossible de charger cette photo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Le bouton flottant peut demander d'ouvrir directement les réglages du viseur
    LaunchedEffect(openCrosshair) {
        if (openCrosshair > 0) crosshairScreen = true
    }

    // Icônes de la barre d'état lisibles selon le thème
    (context as? ComponentActivity)?.let { act ->
        SideEffect {
            WindowCompat.getInsetsController(act.window, act.window.decorView).isAppearanceLightStatusBars = theme.light
        }
    }

    LaunchedEffect(resume) {
        apps = withContext(Dispatchers.Default) { loadApps(context) }
    }

    fun inLibrary(a: AppEntry) = (a.autoGame || a.packageName in pinned) && a.packageName !in hidden

    fun setInLibrary(pkg: String, on: Boolean) {
        pinned = if (on) pinned + pkg else pinned - pkg
        hidden = if (on) hidden - pkg else hidden + pkg
        store.pinned = pinned
        store.hidden = hidden
    }

    fun toggleFavorite(pkg: String) {
        favorites = if (pkg in favorites) favorites - pkg else favorites + pkg
        store.favorites = favorites
    }

    val library = remember(apps, pinned, hidden, sortRecent, resume) {
        val list = apps.filter { inLibrary(it) }
        if (sortRecent) list.sortedByDescending { store.lastLaunch(it.packageName) } else list
    }

    val shown = remember(library, filter, favorites, query) {
        var l = library
        if (filter == 1) l = l.filter { it.packageName in favorites }
        if (filter == 2) {
            l = l.filter { store.lastLaunch(it.packageName) > 0L }
                .sortedByDescending { store.lastLaunch(it.packageName) }
        }
        if (query.isNotBlank()) l = l.filter { it.label.contains(query.trim(), ignoreCase = true) }
        l
    }

    val lastGame = remember(library, resume) {
        library.filter { store.lastLaunch(it.packageName) > 0L }
            .maxByOrNull { store.lastLaunch(it.packageName) }
    }

    MaterialTheme(
        colorScheme = if (theme.light) lightColorScheme(primary = theme.accent)
        else darkColorScheme(primary = theme.accent)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(theme.bgTop, theme.bgBottom)))
        ) {
            if (bgImage != null) {
                Image(
                    bitmap = bgImage,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            if (baseTheme.light) Color.White.copy(alpha = 0.35f)
                            else Color.Black.copy(alpha = 0.45f)
                        )
                )
            }
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = {
                    NavigationBar(
                        containerColor = if (bgImage != null) theme.bgBottom.copy(alpha = 0.35f) else theme.bgBottom
                    ) {
                        listOf(
                            "Bibliothèque" to Icons.Filled.SportsEsports,
                            "Applis" to Icons.Filled.ShoppingBag,
                            "Helper" to Icons.Filled.QuestionAnswer,
                            "Activité" to Icons.Filled.BarChart,
                            "Paramètres" to Icons.Filled.Settings
                        ).forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 11.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = Color.Transparent,
                                    selectedIconColor = theme.accent,
                                    selectedTextColor = theme.accent,
                                    unselectedIconColor = theme.onBg.copy(alpha = 0.5f),
                                    unselectedTextColor = theme.onBg.copy(alpha = 0.5f)
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Column(
                    Modifier
                        .padding(padding)
                        .fillMaxSize()
                ) {
                    when (tab) {
                        // ───────────── Bibliothèque ─────────────
                        0 -> {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Bibliothèque",
                                    color = theme.onBg,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f)
                                )
                                RoundIcon(
                                    if (searching) Icons.Filled.Close else Icons.Filled.Search,
                                    theme, 44.dp
                                ) {
                                    searching = !searching
                                    if (!searching) query = ""
                                }
                                Spacer(Modifier.width(10.dp))
                                Box(
                                    Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(theme.tile)
                                        .clickable { tab = 4 },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("G", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                }
                            }

                            if (searching) {
                                BasicTextField(
                                    value = query,
                                    onValueChange = { query = it },
                                    singleLine = true,
                                    textStyle = TextStyle(color = theme.onBg, fontSize = 16.sp),
                                    cursorBrush = SolidColor(theme.accent),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 6.dp),
                                    decorationBox = { inner ->
                                        Box(
                                            Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(16.dp))
                                                .background(theme.tile)
                                                .padding(horizontal = 16.dp, vertical = 14.dp),
                                            contentAlignment = Alignment.CenterStart
                                        ) {
                                            if (query.isEmpty()) {
                                                Text("Rechercher un jeu", color = theme.onBg.copy(alpha = 0.5f))
                                            }
                                            inner()
                                        }
                                    }
                                )
                            }

                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(horizontal = 20.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Chip("Tous les jeux", Icons.Filled.Apps, filter == 0, theme) { filter = 0 }
                                Chip("Favoris", Icons.Filled.Star, filter == 1, theme) { filter = 1 }
                                Chip("Récents", Icons.Filled.Schedule, filter == 2, theme) { filter = 2 }
                            }

                            if (shown.isEmpty()) {
                                Text(
                                    when {
                                        library.isEmpty() -> "Aucun jeu détecté. Va dans « Applis » pour en ajouter."
                                        filter == 1 -> "Aucun favori. Touche le ♥ d'un jeu pour l'ajouter ici."
                                        filter == 2 -> "Tu n'as encore lancé aucun jeu."
                                        else -> "Aucun résultat."
                                    },
                                    color = theme.onBg.copy(alpha = 0.7f),
                                    modifier = Modifier.padding(20.dp)
                                )
                            }

                            LazyVerticalGrid(
                                columns = GridCells.Fixed(columns),
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalArrangement = Arrangement.spacedBy(20.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(shown, key = { it.packageName }) { app ->
                                    GameCard(
                                        app = app,
                                        theme = theme,
                                        favorite = app.packageName in favorites,
                                        lastPlayed = store.lastLaunch(app.packageName),
                                        onClick = { onLaunch(app.packageName, app.label) },
                                        onFav = { toggleFavorite(app.packageName) },
                                        onMenu = { menuFor = app }
                                    )
                                }
                            }

                            if (lastGame != null && query.isEmpty()) {
                                ContinueBar(lastGame, theme) { onLaunch(lastGame.packageName, lastGame.label) }
                            }
                        }

                        // ───────────── Applis (ajouter des jeux) ─────────────
                        1 -> LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
                            item {
                                Text(
                                    "Applis",
                                    color = theme.onBg,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Active l'interrupteur pour ajouter une appli à ta bibliothèque.",
                                    color = theme.onBg.copy(alpha = 0.7f),
                                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                                )
                            }
                            items(apps, key = { it.packageName }) { a ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Image(
                                        bitmap = a.icon,
                                        contentDescription = a.label,
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Text(
                                        a.label,
                                        color = theme.onBg,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = inLibrary(a),
                                        onCheckedChange = { setInLibrary(a.packageName, it) },
                                        colors = SwitchDefaults.colors(checkedTrackColor = theme.accent)
                                    )
                                }
                            }
                        }

                        // ───────────── Helper (question → ChatGPT → réponse collée) ─────────────
                        2 -> HelperScreen(theme, store)

                        // ───────────── Activité ─────────────
                        3 -> {
                            val played = library.filter { store.lastLaunch(it.packageName) > 0L }
                                .sortedByDescending { store.lastLaunch(it.packageName) }
                            LazyColumn(
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                item {
                                    Text(
                                        "Activité",
                                        color = theme.onBg,
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        "${library.size} jeux · ${played.size} déjà lancés · ${favorites.size} favoris",
                                        color = theme.onBg.copy(alpha = 0.7f),
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                                if (played.isEmpty()) {
                                    item {
                                        Text(
                                            "Rien pour l'instant. Lance un jeu depuis la bibliothèque.",
                                            color = theme.onBg.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                                items(played, key = { it.packageName }) { a ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(18.dp))
                                            .background(theme.tile)
                                            .clickable { onLaunch(a.packageName, a.label) }
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Image(
                                            bitmap = a.icon,
                                            contentDescription = a.label,
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                        )
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                a.label,
                                                color = theme.onBg,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                "Dernier lancement : ${ago(store.lastLaunch(a.packageName))}",
                                                color = theme.onBg.copy(alpha = 0.6f),
                                                fontSize = 13.sp
                                            )
                                        }
                                        Icon(
                                            Icons.Filled.PlayArrow,
                                            contentDescription = null,
                                            tint = theme.accent
                                        )
                                    }
                                }
                            }
                        }

                        // ───────────── Paramètres ─────────────
                        else -> LazyColumn(
                            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Text(
                                    "Paramètres",
                                    color = theme.onBg,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            item {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(18.dp))
                                        .background(theme.tile)
                                        .clickable { crosshairScreen = true }
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.GpsFixed, contentDescription = null, tint = theme.accent)
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Viseur", color = theme.onBg, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "Couleur, contours, point central, lignes · aperçu en direct",
                                            color = theme.onBg.copy(alpha = 0.6f),
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Afficher le viseur dans les jeux",
                                        color = theme.onBg,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = crosshairOn,
                                        onCheckedChange = {
                                            crosshairOn = it
                                            store.crosshairOn = it
                                            OverlayService.refresh(context)
                                        },
                                        colors = SwitchDefaults.colors(checkedTrackColor = theme.accent)
                                    )
                                }
                            }
                            item {
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(18.dp))
                                        .background(theme.tile)
                                        .padding(16.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Image, contentDescription = null, tint = theme.accent)
                                        Spacer(Modifier.width(12.dp))
                                        Text("Photo de fond", color = theme.onBg, fontWeight = FontWeight.SemiBold)
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        ActionButton("Choisir une photo", theme, Modifier.weight(1f)) {
                                            photoPicker.launch("image/*")
                                        }
                                        if (bgImage != null) {
                                            ActionButton("Retirer", theme, Modifier.weight(1f), primary = false) {
                                                removeBackground(context)
                                                bgVersion++
                                            }
                                        }
                                    }
                                    if (bgImage != null) {
                                        Spacer(Modifier.height(8.dp))
                                        SliderRow("Flou", bgBlurUi, 0, 100, theme) { bgBlurUi = it }
                                        // on applique le flou quand on lâche le curseur (le calcul prend un instant)
                                        LaunchedEffect(bgBlurUi) {
                                            kotlinx.coroutines.delay(350)
                                            if (bgBlurUi != bgBlur) {
                                                bgBlur = bgBlurUi
                                                store.bgBlur = bgBlurUi
                                            }
                                        }
                                    }
                                }
                            }
                            items(themes.size) { i ->
                                ThemeCard(themes[i], selected = i == themeIndex) {
                                    themeIndex = i
                                    store.themeIndex = i
                                }
                            }
                            item {
                                Text("Colonnes : $columns", color = theme.onBg)
                                Slider(
                                    value = columns.toFloat(),
                                    onValueChange = {
                                        columns = it.roundToInt()
                                        store.columns = columns
                                    },
                                    valueRange = 2f..4f,
                                    steps = 1,
                                    colors = SliderDefaults.colors(
                                        thumbColor = theme.accent,
                                        activeTrackColor = theme.accent
                                    )
                                )
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Bouton flottant Gaming Soul dans les jeux",
                                        color = theme.onBg,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = assistant,
                                        onCheckedChange = {
                                            assistant = it
                                            store.assistant = it
                                        },
                                        colors = SwitchDefaults.colors(checkedTrackColor = theme.accent)
                                    )
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Derniers lancés en premier",
                                        color = theme.onBg,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = sortRecent,
                                        onCheckedChange = {
                                            sortRecent = it
                                            store.sortRecent = it
                                        },
                                        colors = SwitchDefaults.colors(checkedTrackColor = theme.accent)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (crosshairScreen) {
            CrosshairScreen(theme = theme, store = store, onBack = { crosshairScreen = false })
        }

        menuFor?.let { app ->
            AlertDialog(
                onDismissRequest = { menuFor = null },
                title = { Text(app.label) },
                text = { Text("Retirer de la bibliothèque ?") },
                confirmButton = {
                    TextButton(onClick = {
                        setInLibrary(app.packageName, false)
                        menuFor = null
                    }) { Text("Retirer") }
                },
                dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Annuler") } }
            )
        }
    }
}

@Composable
fun RoundIcon(icon: ImageVector, theme: GameTheme, size: Dp, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(theme.tile)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = theme.onBg, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun Chip(text: String, icon: ImageVector, selected: Boolean, theme: GameTheme, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    val tint = if (selected) theme.onBg else theme.onBg.copy(alpha = 0.7f)
    Row(
        Modifier
            .clip(shape)
            .background(if (selected) theme.accent.copy(alpha = 0.25f) else theme.tile)
            .then(if (selected) Modifier.border(1.5.dp, theme.accent, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = tint, fontWeight = FontWeight.Medium, fontSize = 15.sp, maxLines = 1)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameCard(
    app: AppEntry,
    theme: GameTheme,
    favorite: Boolean,
    lastPlayed: Long,
    onClick: () -> Unit,
    onFav: () -> Unit,
    onMenu: () -> Unit
) {
    val recent = lastPlayed > 0L && System.currentTimeMillis() - lastPlayed < WEEK_MS
    val gray = theme.onBg.copy(alpha = 0.55f)
    val cardAlpha = if (theme.tile.alpha < 1f) 0.82f else 1f
    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1.2f)
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            app.color.copy(alpha = cardAlpha),
                            lerp(app.color, Color.Black, 0.65f).copy(alpha = cardAlpha)
                        )
                    )
                )
                .combinedClickable(onClick = onClick, onLongClick = onMenu)
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(84.dp)
                    .clip(RoundedCornerShape(20.dp))
            )
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.35f))
                    .clickable(onClick = onFav),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favori",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    app.label,
                    color = theme.onBg,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                if (recent) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Green)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text("Joué récemment", color = Green, fontSize = 13.sp, maxLines = 1)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Download,
                            contentDescription = null,
                            tint = gray,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text("Installé", color = gray, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
            RoundIcon(Icons.Filled.MoreHoriz, theme, 34.dp, onMenu)
        }
    }
}

@Composable
fun ContinueBar(app: AppEntry, theme: GameTheme, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(theme.tile, lerp(theme.tile, app.color, 0.55f))))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "Continuez votre partie",
                color = theme.onBg,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                maxLines = 1
            )
            Text(
                app.label,
                color = theme.onBg.copy(alpha = 0.7f),
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(theme.accent),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = "Jouer", tint = Color.White)
        }
    }
}

@Composable
fun ThemeCard(t: GameTheme, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(t.bgTop, t.tile)))
            .then(if (selected) Modifier.border(3.dp, t.accent, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(t.accent)
        )
        Spacer(Modifier.width(12.dp))
        Text(t.name, color = t.onBg, fontWeight = FontWeight.Medium)
    }
}
