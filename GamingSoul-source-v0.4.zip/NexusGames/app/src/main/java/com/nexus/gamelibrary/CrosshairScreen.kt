package com.nexus.gamelibrary

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Écran de réglage du viseur, avec aperçu en direct en haut. */
@Composable
fun CrosshairScreen(theme: GameTheme, store: Store, onBack: () -> Unit) {
    val context = LocalContext.current
    var cfg by remember { mutableStateOf(store.crosshair) }
    var on by remember { mutableStateOf(store.crosshairOn) }
    var zoom by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    fun update(n: Crosshair) {
        cfg = n
        store.crosshair = n
        OverlayService.refresh(context)
    }

    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } } // bloque les touches vers l'écran du dessous
            .background(theme.bgBottom)
            .statusBarsPadding()
            .imePadding()
    ) {
        // ── en-tête
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(theme.onBg.copy(alpha = 0.10f))
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour", tint = theme.onBg)
            }
            Spacer(Modifier.size(12.dp))
            Text("Viseur", color = theme.onBg, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }

        // ── aperçu en direct (fond clair + fond sombre pour juger la visibilité)
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(180.dp)
                .clip(RoundedCornerShape(20.dp))
        ) {
            Row(Modifier.fillMaxSize()) {
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .background(Color(0xFF1B2230))
                )
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .background(Color(0xFFC9D3E3))
                )
            }
            Canvas(Modifier.fillMaxSize()) {
                val s = density * (if (zoom) 3f else 1f)
                drawIntoCanvas { c ->
                    drawCrosshair(c.nativeCanvas, cfg, size.width / 2f, size.height / 2f + cfg.offsetY * s, s)
                }
            }
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(10.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable { zoom = !zoom }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(if (zoom) "Zoom ×3" else "Zoom ×1", color = Color.White, fontSize = 12.sp)
            }
        }

        // ── réglages
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            GlassCard(theme) {
                SwitchRow("Afficher le viseur dans les jeux", on, theme) {
                    on = it
                    store.crosshairOn = it
                    OverlayService.refresh(context)
                }
                Text(
                    "Il apparaît au centre de l'écran quand tu lances un jeu depuis Gaming Soul. " +
                        "Tu peux aussi l'afficher ou le masquer avec le bouton flottant (onglet Viseur).",
                    color = theme.onBg.copy(alpha = 0.6f),
                    fontSize = 12.sp
                )
            }

            GlassCard(theme) {
                Text("Couleur", color = theme.onBg, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    crosshairColors.forEach { (_, col) ->
                        val selected = (cfg.color or 0xFF000000.toInt()) == col
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(col))
                                .border(
                                    if (selected) 3.dp else 1.dp,
                                    if (selected) theme.accent else theme.onBg.copy(alpha = 0.25f),
                                    CircleShape
                                )
                                .clickable { update(cfg.copy(color = col)) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                HexField(cfg.color, theme) { update(cfg.copy(color = it)) }
            }

            GlassCard(theme) {
                SwitchRow("Contours", cfg.outline, theme) { update(cfg.copy(outline = it)) }
                if (cfg.outline) {
                    SliderRow("Opacité", cfg.outlineOpacity, 0, 100, theme, " %") { update(cfg.copy(outlineOpacity = it)) }
                    SliderRow("Épaisseur", cfg.outlineThick, 1, 6, theme) { update(cfg.copy(outlineThick = it)) }
                }
            }

            GlassCard(theme) {
                SwitchRow("Point central", cfg.dot, theme) { update(cfg.copy(dot = it)) }
                if (cfg.dot) {
                    SliderRow("Opacité", cfg.dotOpacity, 0, 100, theme, " %") { update(cfg.copy(dotOpacity = it)) }
                    SliderRow("Taille", cfg.dotSize, 1, 10, theme) { update(cfg.copy(dotSize = it)) }
                }
            }

            GlassCard(theme) {
                SwitchRow("Lignes intérieures", cfg.innerOn, theme) { update(cfg.copy(innerOn = it)) }
                if (cfg.innerOn) {
                    SliderRow("Opacité", cfg.innerOpacity, 0, 100, theme, " %") { update(cfg.copy(innerOpacity = it)) }
                    SliderRow("Longueur", cfg.innerLen, 0, 20, theme) { update(cfg.copy(innerLen = it)) }
                    SliderRow("Épaisseur", cfg.innerThick, 1, 10, theme) { update(cfg.copy(innerThick = it)) }
                    SliderRow("Décalage", cfg.innerOffset, 0, 20, theme) { update(cfg.copy(innerOffset = it)) }
                }
            }

            GlassCard(theme) {
                SwitchRow("Lignes extérieures", cfg.outerOn, theme) { update(cfg.copy(outerOn = it)) }
                if (cfg.outerOn) {
                    SliderRow("Opacité", cfg.outerOpacity, 0, 100, theme, " %") { update(cfg.copy(outerOpacity = it)) }
                    SliderRow("Longueur", cfg.outerLen, 0, 20, theme) { update(cfg.copy(outerLen = it)) }
                    SliderRow("Épaisseur", cfg.outerThick, 1, 10, theme) { update(cfg.copy(outerThick = it)) }
                    SliderRow("Décalage", cfg.outerOffset, 0, 40, theme) { update(cfg.copy(outerOffset = it)) }
                }
            }

            GlassCard(theme) {
                Text("Position", color = theme.onBg, fontWeight = FontWeight.SemiBold)
                SliderRow("Décalage vertical", cfg.offsetY, -100, 100, theme, " dp") { update(cfg.copy(offsetY = it)) }
            }

            ActionButton("Réinitialiser le viseur", theme, Modifier.fillMaxWidth(), primary = false) {
                update(Crosshair())
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** Champ pour saisir une couleur personnalisée au format #RRGGBB. */
@Composable
private fun HexField(color: Int, theme: GameTheme, onColor: (Int) -> Unit) {
    var text by remember(color) { mutableStateOf(String.format("#%06X", color and 0xFFFFFF)) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Couleur perso", color = theme.onBg.copy(alpha = 0.85f), fontSize = 14.sp, modifier = Modifier.weight(1f))
        BasicTextField(
            value = text,
            onValueChange = { v ->
                text = v
                val hex = v.trim().removePrefix("#")
                if (hex.length == 6 && hex.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
                    onColor(0xFF000000.toInt() or hex.toInt(16))
                }
            },
            singleLine = true,
            textStyle = TextStyle(color = theme.onBg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
            cursorBrush = SolidColor(theme.accent),
            decorationBox = { inner ->
                Box(
                    Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(theme.onBg.copy(alpha = 0.08f))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) { inner() }
            },
            modifier = Modifier.size(width = 120.dp, height = 44.dp)
        )
    }
}
