package com.nexus.gamelibrary

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.roundToInt

/** Réglages du viseur, façon Valorant. Les opacités sont en % (0..100), les tailles en dp. */
data class Crosshair(
    val color: Int = 0xFF00FFFF.toInt(),
    val outline: Boolean = true,
    val outlineOpacity: Int = 50,
    val outlineThick: Int = 1,
    val dot: Boolean = false,
    val dotOpacity: Int = 100,
    val dotSize: Int = 2,
    val innerOn: Boolean = true,
    val innerOpacity: Int = 80,
    val innerLen: Int = 6,
    val innerThick: Int = 2,
    val innerOffset: Int = 3,
    val outerOn: Boolean = false,
    val outerOpacity: Int = 35,
    val outerLen: Int = 2,
    val outerThick: Int = 2,
    val outerOffset: Int = 10,
    val offsetY: Int = 0
)

/** Couleurs proposées (les mêmes que dans Valorant). */
val crosshairColors: List<Pair<String, Int>> = listOf(
    "Blanc" to 0xFFFFFFFF.toInt(),
    "Vert" to 0xFF00FF00.toInt(),
    "Vert-jaune" to 0xFF7FFF00.toInt(),
    "Jaune clair" to 0xFFDFFF00.toInt(),
    "Jaune" to 0xFFFFFF00.toInt(),
    "Cyan" to 0xFF00FFFF.toInt(),
    "Rose" to 0xFFFF00FF.toInt(),
    "Rouge" to 0xFFFF0000.toInt()
)

private class El(val r: RectF, val opacity: Int)

/**
 * Dessine le viseur centré en (cx, cy). scale = pixels par dp.
 * Utilisé à la fois par l'aperçu dans l'appli et par la fenêtre flottante : le rendu est identique.
 */
fun drawCrosshair(canvas: Canvas, cfg: Crosshair, cx: Float, cy: Float, scale: Float) {
    val ox = cx.roundToInt().toFloat()
    val oy = cy.roundToInt().toFloat()

    fun thick(v: Int): Float = maxOf(1f, (v * scale).roundToInt().toFloat())
    fun dist(v: Int): Float = maxOf(0f, (v * scale).roundToInt().toFloat())

    val els = ArrayList<El>()

    if (cfg.dot) {
        val d = thick(cfg.dotSize)
        els.add(El(RectF(ox - d / 2f, oy - d / 2f, ox + d / 2f, oy + d / 2f), cfg.dotOpacity))
    }

    fun lines(lenDp: Int, thickDp: Int, offDp: Int, opacity: Int) {
        val len = dist(lenDp)
        if (len <= 0f) return
        val t = thick(thickDp)
        val off = dist(offDp)
        els.add(El(RectF(ox - t / 2f, oy - off - len, ox + t / 2f, oy - off), opacity))
        els.add(El(RectF(ox - t / 2f, oy + off, ox + t / 2f, oy + off + len), opacity))
        els.add(El(RectF(ox - off - len, oy - t / 2f, ox - off, oy + t / 2f), opacity))
        els.add(El(RectF(ox + off, oy - t / 2f, ox + off + len, oy + t / 2f), opacity))
    }

    if (cfg.innerOn) lines(cfg.innerLen, cfg.innerThick, cfg.innerOffset, cfg.innerOpacity)
    if (cfg.outerOn) lines(cfg.outerLen, cfg.outerThick, cfg.outerOffset, cfg.outerOpacity)

    // 1) contours noirs (anneau autour de chaque élément, sans recouvrir l'intérieur)
    if (cfg.outline && cfg.outlineOpacity > 0) {
        val ot = thick(cfg.outlineThick)
        val edge = Paint().apply {
            style = Paint.Style.FILL
            isAntiAlias = false
            color = 0xFF000000.toInt()
            alpha = (cfg.outlineOpacity.coerceIn(0, 100) * 255) / 100
        }
        for (e in els) {
            val p = Path()
            p.fillType = Path.FillType.EVEN_ODD
            p.addRect(
                RectF(e.r.left - ot, e.r.top - ot, e.r.right + ot, e.r.bottom + ot),
                Path.Direction.CW
            )
            p.addRect(e.r, Path.Direction.CW)
            canvas.drawPath(p, edge)
        }
    }

    // 2) éléments colorés
    val fill = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = false
    }
    for (e in els) {
        fill.color = cfg.color or 0xFF000000.toInt()
        fill.alpha = (e.opacity.coerceIn(0, 100) * 255) / 100
        canvas.drawRect(e.r, fill)
    }
}

/** Vue transparente affichée au centre de l'écran par-dessus le jeu (non tactile). */
class CrosshairView(context: Context) : View(context) {
    var config: Crosshair = Crosshair()
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawCrosshair(canvas, config, width / 2f, height / 2f, resources.displayMetrics.density)
    }
}
