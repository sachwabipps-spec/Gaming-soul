package com.nexus.gamelibrary

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.widget.Toast
import android.widget.HorizontalScrollView
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Bouton flottant Gaming Soul : bulle "G" + panneau à 3 onglets
 *  - Capture : capture d'écran + texte proposé, envoyés à ChatGPT
 *  - Helper : écrire une question pour ChatGPT, puis coller la réponse
 *  - Viseur : afficher / masquer le viseur
 * Le viseur lui-même est une vue transparente au centre de l'écran.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_PROJECTION = "nexus.PROJECTION"
        const val ACTION_CANCELLED = "nexus.CANCELLED"
        const val ACTION_STOP = "nexus.STOP"
        const val ACTION_REFRESH = "nexus.REFRESH"
        const val CHATGPT = CHATGPT_PACKAGE
        const val DEFAULT_QUESTION =
            "Je ne comprends pas ce qui se passe dans ce jeu. Explique-moi ce que je vois sur cette capture et ce que je dois faire."

        /** Textes proposés dans l'onglet Capture. */
        val SUGGESTIONS = listOf(
            "Explique cette capture" to "Explique-moi ce que je vois sur cette capture d'écran de jeu.",
            "Que dois-je faire ?" to "Que dois-je faire maintenant dans ce jeu ? Donne-moi les prochaines étapes.",
            "Cet ennemi / boss ?" to "Quel est cet ennemi ou ce boss, et comment le battre ?",
            "Aide ce niveau" to "Je suis bloqué dans ce niveau. Explique-moi comment le réussir."
        )

        @Volatile
        var running = false

        /** Demande au service (s'il tourne) de relire les réglages du viseur. */
        fun refresh(context: Context) {
            if (!running) return
            ContextCompat.startForegroundService(
                context,
                Intent(context, OverlayService::class.java).setAction(ACTION_REFRESH)
            )
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var density = 1f

    private var bubble: TextView? = null
    private var panel: FrameLayout? = null
    private var panelOpen = false
    private var chat: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var input: EditText? = null
    private var gameLabel: TextView? = null

    private val store by lazy { Store(this) }
    private var crossView: CrosshairView? = null
    private var crossLp: WindowManager.LayoutParams? = null
    private val tabViews = ArrayList<TextView>()
    private val pages = ArrayList<View>()
    private var crossToggle: TextView? = null
    private var helperQ: EditText? = null
    private var helperA: EditText? = null

    private var game = ""
    private var question = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val action = intent.action
        if (action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground(action == ACTION_PROJECTION)
        when (action) {
            ACTION_PROJECTION -> {
                val code = intent.getIntExtra("code", 0)
                val data = readData(intent)
                if (data != null) startCapture(code, data) else finishCapture()
            }
            ACTION_CANCELLED -> {
                note("Capture annulée", "err")
                finishCapture()
            }
            ACTION_REFRESH -> {
                applyCrosshair()
                refreshCrossPage()
            }
            else -> {
                game = intent.getStringExtra("game") ?: game
                gameLabel?.text = game.ifBlank { "Jeu" }
                if (intent.getBooleanExtra("bubble", true)) ensureBubble()
                applyCrosshair()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        removeCrosshair()
        try { bubble?.let { wm.removeView(it) } } catch (e: Exception) { }
        if (panelOpen) {
            try { panel?.let { wm.removeView(it) } } catch (e: Exception) { }
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------ service au premier plan
    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra("data")

    private fun goForeground(projection: Boolean) {
        val n = notification()
        if (Build.VERSION.SDK_INT >= 34) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (projection) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            startForeground(1, n, t)
        } else if (Build.VERSION.SDK_INT >= 29 && projection) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun notification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("nexus", "Gaming Soul", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        return Notification.Builder(this, "nexus")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Gaming Soul est actif")
            .setContentText("Touche la bulle G dans ton jeu")
            .setOngoing(true)
            .addAction(0, "Fermer", stop)
            .build()
    }

    // ------------------------------------------------------------ helpers visuels
    private fun dp(v: Int) = (v * density).toInt()
    private fun dpf(v: Int) = v * density
    private fun c(hex: String) = Color.parseColor(hex)

    private fun bounds(): Rect =
        if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds
        else resources.displayMetrics.let { Rect(0, 0, it.widthPixels, it.heightPixels) }

    private fun screenW() = bounds().width()
    private fun screenH() = bounds().height()

    private fun box(fill: String, radius: Int, stroke: String? = null) = GradientDrawable().apply {
        setColor(c(fill))
        cornerRadius = dpf(radius)
        if (stroke != null) setStroke(dp(1), c(stroke))
    }

    private fun grad(a: String, b: String, radius: Int, stroke: String? = null, horizontal: Boolean = false) =
        GradientDrawable(
            if (horizontal) GradientDrawable.Orientation.LEFT_RIGHT else GradientDrawable.Orientation.TL_BR,
            intArrayOf(c(a), c(b))
        ).apply {
            cornerRadius = dpf(radius)
            if (stroke != null) setStroke(dp(1), c(stroke))
        }

    private fun label(text: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(c(color))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun winButton(t: String, onClick: () -> Unit) = label(t, 14f, "#8B93AE", true).apply {
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
        setOnClickListener { onClick() }
    }

    private fun chip(t: String, onClick: () -> Unit) = label(t, 11f, "#C7CCE0", true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(10), dp(6), dp(10))
        background = box("#12151F", 15, "#252A3D")
        setOnClickListener { onClick() }
    }

    private fun chipLp() = LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }

    // ------------------------------------------------------------ bulle flottante
    private fun ensureBubble() {
        if (bubble != null) {
            if (!panelOpen) bubble?.visibility = View.VISIBLE
            return
        }
        val b = TextView(this).apply {
            text = "G"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(c("#3B82F6"), c("#8B5CF6"))
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), Color.argb(110, 255, 255, 255))
            }
        }
        val size = dp(56)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW() - size - dp(8)
            y = screenH() / 3
        }

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        wm.updateViewLayout(b, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) openPanel()
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    // ------------------------------------------------------------ panneau Nexus
    private fun openPanel() {
        val p = panel ?: buildPanel().also { panel = it }
        if (!panelOpen) {
            val lp = WindowManager.LayoutParams(
                MP, (screenH() * 0.62).toInt(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            }
            wm.addView(p, lp)
            panelOpen = true
        }
        bubble?.visibility = View.GONE
    }

    private fun closePanel() {
        if (panelOpen) {
            try { panel?.let { wm.removeView(it) } } catch (e: Exception) { }
            panelOpen = false
        }
        bubble?.visibility = View.VISIBLE
    }

    private fun pill(text: String, primary: Boolean, onClick: () -> Unit) = label(text, 13f, "#FFFFFF", true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = if (primary) grad("#3B82F6", "#8B5CF6", 16) else box("#12151F", 16, "#252A3D")
        setOnClickListener { onClick() }
    }

    private fun field(placeholder: String, lines: Int) = EditText(this).apply {
        setHint(placeholder)
        setHintTextColor(c("#4A5170"))
        setTextColor(Color.WHITE)
        textSize = 14f
        background = box("#12151F", 14, "#252A3D")
        setPadding(dp(12), dp(10), dp(12), dp(10))
        gravity = Gravity.TOP or Gravity.START
        minLines = 1
        maxLines = lines
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun buildPanel(): FrameLayout {
        tabViews.clear()
        pages.clear()
        val root = FrameLayout(this).apply { setPadding(dp(10), dp(10), dp(10), dp(10)) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = grad("#0E111B", "#090B12", 22, "#252A3D")
        }
        root.addView(card, FrameLayout.LayoutParams(MP, MP))

        // --- en-tête : logo G, GAMING SOUL, réduire, fermer
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(8), 0)
        }
        val logo = label("G", 17f, "#FFFFFF", true).apply {
            gravity = Gravity.CENTER
            background = grad("#3B82F6", "#8B5CF6", 12)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        titles.addView(label("GAMING SOUL", 14f, "#F1F3FA", true).apply { letterSpacing = 0.18f })
        gameLabel = label(game.ifBlank { "Jeu" }, 11f, "#6F7896").apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        titles.addView(gameLabel)
        header.addView(titles, LinearLayout.LayoutParams(0, WC, 1f))
        header.addView(winButton("—") { closePanel() })
        header.addView(winButton("✕") { stopSelf() })
        card.addView(header, LinearLayout.LayoutParams(MP, dp(60)))
        card.addView(View(this).apply { setBackgroundColor(c("#1B2030")) }, LinearLayout.LayoutParams(MP, dp(1)))

        // --- onglets
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(6))
        }
        listOf("📸 Capture", "💬 Helper", "◎ Viseur").forEachIndexed { i, t ->
            val tv = label(t, 12f, "#8B93AE", true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener { showTab(i) }
            }
            tabViews.add(tv)
            tabs.addView(tv, LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        card.addView(tabs, LinearLayout.LayoutParams(MP, WC))

        // --- pages
        val holder = FrameLayout(this)
        pages.add(buildCapturePage())
        pages.add(buildHelperPage())
        pages.add(buildCrosshairPage())
        pages.forEach { holder.addView(it, FrameLayout.LayoutParams(MP, MP)) }
        card.addView(holder, LinearLayout.LayoutParams(MP, 0, 1f))

        showTab(0)
        return root
    }

    private fun showTab(i: Int) {
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabViews.forEachIndexed { k, t ->
            t.background = if (k == i) grad("#3B82F6", "#8B5CF6", 14) else box("#12151F", 14, "#252A3D")
            t.setTextColor(c(if (k == i) "#FFFFFF" else "#8B93AE"))
        }
        if (i == 2) refreshCrossPage()
    }

    // ------------------------------------------------------------ onglet Capture
    private fun buildCapturePage(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val zone = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        sv.addView(zone)
        scroll = sv
        chat = zone
        page.addView(sv, LinearLayout.LayoutParams(MP, 0, 1f))
        addBubble(
            "Je prends une capture de ton écran et je l'envoie à ChatGPT avec le texte ci-dessous. " +
                "Tu peux le modifier ou toucher une suggestion.",
            false
        )

        // suggestions de texte
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(4), dp(14), dp(6))
        }
        SUGGESTIONS.forEach { (title, text) ->
            chips.addView(chip(title) { input?.setText(text) }, LinearLayout.LayoutParams(WC, WC).apply {
                setMargins(0, 0, dp(6), 0)
            })
        }
        hs.addView(chips)
        page.addView(hs, LinearLayout.LayoutParams(MP, WC))

        // barre de saisie avec le texte proposé déjà rempli
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = box("#12151F", 24, "#252A3D")
            setPadding(dp(16), dp(4), dp(6), dp(4))
        }
        val et = EditText(this).apply {
            setText(DEFAULT_QUESTION)
            setHintTextColor(c("#4A5170"))
            setTextColor(Color.WHITE)
            textSize = 13f
            background = null
            minLines = 1
            maxLines = 3
        }
        input = et
        bar.addView(et, LinearLayout.LayoutParams(0, WC, 1f))
        val send = label("📸", 16f, "#FFFFFF", true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(c("#3B82F6"), c("#8B5CF6"))
            ).apply { shape = GradientDrawable.OVAL }
            setOnClickListener { sendFromInput() }
        }
        bar.addView(send, LinearLayout.LayoutParams(dp(44), dp(44)))
        page.addView(bar, LinearLayout.LayoutParams(MP, WC).apply { setMargins(dp(14), 0, dp(14), dp(10)) })
        return page
    }

    // ------------------------------------------------------------ onglet Helper
    private fun buildHelperPage(): View {
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(12))
        }
        sv.addView(col)

        col.addView(label("1 · Ta question", 12f, "#8B93AE", true))
        val q = field("ex : comment battre ce boss ?", 4)
        helperQ = q
        col.addView(q, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })
        col.addView(
            pill("Envoyer à ChatGPT", true) {
                val text = q.text.toString().trim()
                if (text.isEmpty()) {
                    toast("Écris d'abord ta question")
                } else if (sendToChatGpt(this, text)) {
                    toast("Question copiée et envoyée. Reviens coller la réponse.")
                    closePanel()
                } else {
                    toast("Impossible d'ouvrir ChatGPT")
                }
            },
            LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) }
        )

        col.addView(label("2 · La réponse de ChatGPT", 12f, "#8B93AE", true).apply { setPadding(0, dp(16), 0, 0) })
        val a = field("Colle la réponse ici", 6)
        helperA = a
        col.addView(a, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pill("📋 Coller", false) {
            val t = readClipboard(this)
            if (t.isBlank()) toast("Le presse-papiers est vide") else a.setText(t)
        }, LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(0, 0, dp(4), 0) })
        row.addView(pill("💾 Enregistrer", true) {
            val ans = a.text.toString().trim()
            if (ans.isEmpty()) {
                toast("Colle d'abord la réponse")
            } else {
                val e = HelperEntry(q.text.toString().trim(), ans, System.currentTimeMillis())
                store.helperLog = listOf(e) + store.helperLog
                a.setText("")
                toast("Réponse enregistrée (onglet Helper de l'appli)")
            }
        }, LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(dp(4), 0, 0, 0) })
        col.addView(row, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) })
        return sv
    }

    // ------------------------------------------------------------ onglet Viseur
    private fun buildCrosshairPage(): View {
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(12))
        }
        sv.addView(col)

        val toggle = label("", 15f, "#FFFFFF", true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(18))
            setOnClickListener {
                store.crosshairOn = !store.crosshairOn
                applyCrosshair()
                refreshCrossPage()
            }
        }
        crossToggle = toggle
        col.addView(toggle, LinearLayout.LayoutParams(MP, WC))

        col.addView(label("Couleur rapide", 12f, "#8B93AE", true).apply { setPadding(0, dp(16), 0, dp(8)) })
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        crosshairColors.forEach { (_, swatch) ->
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(swatch)
                    setStroke(dp(1), Color.argb(90, 255, 255, 255))
                }
                setOnClickListener {
                    store.crosshair = store.crosshair.copy(color = swatch)
                    applyCrosshair()
                }
            }
            colors.addView(dot, LinearLayout.LayoutParams(0, dp(30), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        col.addView(colors, LinearLayout.LayoutParams(MP, WC))

        col.addView(
            pill("⚙ Tous les réglages (dans l'appli)", false) { openApp("crosshair") },
            LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(16) }
        )
        return sv
    }

    private fun refreshCrossPage() {
        val on = store.crosshairOn
        crossToggle?.apply {
            text = if (on) "◎  Viseur affiché · toucher pour masquer" else "◎  Viseur masqué · toucher pour afficher"
            background = if (on) grad("#0F766E", "#10B981", 18) else box("#12151F", 18, "#252A3D")
        }
    }

    // ------------------------------------------------------------ viseur à l'écran
    private fun applyCrosshair() {
        if (!store.crosshairOn) {
            removeCrosshair()
            return
        }
        val conf = store.crosshair
        val existing = crossView
        if (existing == null) {
            val size = dp(220)
            val lp = WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
                y = dp(conf.offsetY)
            }
            val v = CrosshairView(this)
            v.config = conf
            try {
                wm.addView(v, lp)
                crossView = v
                crossLp = lp
            } catch (e: Exception) {
                toast("Autorise « Afficher par-dessus les autres applis » pour voir le viseur")
            }
        } else {
            existing.config = conf
            crossLp?.let {
                it.y = dp(conf.offsetY)
                try { wm.updateViewLayout(existing, it) } catch (e: Exception) { }
            }
        }
    }

    private fun removeCrosshair() {
        crossView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        crossView = null
        crossLp = null
    }

    private fun openApp(target: String) {
        val i = packageManager.getLaunchIntentForPackage(packageName) ?: return
        closePanel()
        startActivity(i.putExtra("open", target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun addBubble(text: String, user: Boolean) {
        val zone = chat ?: return
        val maxW = (screenW() * 0.72).toInt()
        val r = dpf(18)
        val s = dpf(5)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (user) Gravity.END else Gravity.START
        }
        if (!user) {
            val av = label("✦", 14f, "#8B5CF6").apply {
                gravity = Gravity.CENTER
                background = box("#161A28", 15, "#252A3D")
            }
            row.addView(av, LinearLayout.LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(8) })
        }
        val tv = label(text, 14f, if (user) "#FFFFFF" else "#E6E9F2").apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            maxWidth = maxW
            background = if (user) {
                GradientDrawable(
                    GradientDrawable.Orientation.TL_BR, intArrayOf(c("#2F6BFF"), c("#7C4DFF"))
                ).apply { cornerRadii = floatArrayOf(r, r, r, r, s, s, r, r) }
            } else {
                GradientDrawable().apply {
                    setColor(c("#151927"))
                    setStroke(dp(1), c("#252A3D"))
                    cornerRadii = floatArrayOf(s, s, r, r, r, r, r, r)
                }
            }
        }
        row.addView(tv)
        zone.addView(row, LinearLayout.LayoutParams(MP, WC).apply { bottomMargin = dp(10) })
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun note(text: String, kind: String) {
        val zone = chat ?: return
        val (bg, st, fg) = when (kind) {
            "ok" -> Triple("#0F2A24", "#14513F", "#6EE7B7")
            "err" -> Triple("#2A1216", "#5B1F27", "#FCA5A5")
            else -> Triple("#12151F", "#252A3D", "#6F7896")
        }
        val tv = label(text, 11f, fg).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = box(bg, 11, st)
        }
        zone.addView(tv, LinearLayout.LayoutParams(WC, WC).apply {
            leftMargin = dp(38)
            bottomMargin = dp(10)
        })
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------ actions
    private fun sendFromInput() {
        val q = input?.text?.toString().orEmpty().trim()
        captureFlow(q)
    }

    // ------------------------------------------------------------ capture d'écran -> ChatGPT
    private fun captureFlow(q: String) {
        question = q.ifBlank { DEFAULT_QUESTION }
        addBubble(if (q.isBlank()) "📸 Capture avec la question par défaut" else q, true)
        // La question est aussi copiée : on peut la coller dans ChatGPT si elle n'est pas pré-remplie
        copyToClipboard(this, question)
        // On lance d'abord la demande d'autorisation (le geste vient d'une fenêtre visible), puis on cache Nexus
        startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        closePanel()
        bubble?.visibility = View.GONE
        crossView?.visibility = View.GONE // le viseur ne doit pas apparaître sur la capture
    }

    private fun finishCapture() {
        goForeground(false)
        bubble?.visibility = View.VISIBLE
        crossView?.visibility = View.VISIBLE
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = try { mpm.getMediaProjection(code, data) } catch (e: Exception) { null }
        if (projection == null) {
            note("Capture impossible", "err")
            finishCapture()
            return
        }
        projection.registerCallback(object : MediaProjection.Callback() {}, ui)
        // petit délai : le temps que la fenêtre d'autorisation disparaisse de l'écran
        ui.postDelayed({ grab(projection) }, 800)
    }

    private fun grab(projection: MediaProjection) {
        val dm = resources.displayMetrics
        val b = bounds()
        val w = b.width()
        val h = b.height()
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        var vd: VirtualDisplay? = null
        var done = false

        fun cleanup() {
            try { vd?.release() } catch (e: Exception) { }
            try { reader.close() } catch (e: Exception) { }
            try { projection.stop() } catch (e: Exception) { }
            finishCapture()
        }

        vd = projection.createVirtualDisplay(
            "nexus-capture", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, ui
        )
        reader.setOnImageAvailableListener({ r ->
            if (done) return@setOnImageAvailableListener
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            done = true
            var shot: Bitmap? = null
            try {
                val plane = img.planes[0]
                val rowPad = plane.rowStride - plane.pixelStride * w
                val full = Bitmap.createBitmap(w + rowPad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(plane.buffer)
                shot = Bitmap.createBitmap(full, 0, 0, w, h)
            } catch (e: Exception) {
                shot = null
            } finally {
                img.close()
            }
            cleanup()
            val s = shot
            if (s == null) note("Capture ratée, réessaie", "err") else saveAndShare(s)
        }, ui)

        ui.postDelayed({
            if (!done) {
                done = true
                cleanup()
                note("Aucune image reçue, réessaie", "err")
            }
        }, 4000)
    }

    private fun saveAndShare(bmp: Bitmap) {
        Thread {
            try {
                val dir = File(cacheDir, "shots").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val f = File(dir, "capture_${System.currentTimeMillis()}.jpg")
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                ui.post { share(uri) }
            } catch (e: Exception) {
                ui.post { note("Impossible d'enregistrer la capture", "err") }
            }
        }.start()
    }

    private fun share(uri: Uri) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, question)
            clipData = ClipData.newRawUri("capture", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(Intent(send).setPackage(CHATGPT))
            note("📸 Capture envoyée à ChatGPT : appuie sur « envoyer » là-bas (question copiée aussi)", "ok")
        } catch (e: Exception) {
            try {
                startActivity(Intent.createChooser(send, "Envoyer la capture à…").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                note("ChatGPT introuvable : choisis une autre appli", "info")
            } catch (e2: Exception) {
                note("Impossible de partager la capture", "err")
            }
        }
    }
}
