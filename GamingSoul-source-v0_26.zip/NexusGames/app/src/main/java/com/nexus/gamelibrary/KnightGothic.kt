package com.nexus.gamelibrary

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import kotlin.math.sin

// ════════════════════════════════════════════════════════════════
//  Éléments gothiques : lampadaire en fer forgé, pont suspendu,
//  plateformes suspendues par des chaînes.
// ════════════════════════════════════════════════════════════════

private val IRON = Color(0xFF0D0D1A)
private val IRON_LIT = Color(0xFF3B4068)
private val STONE_DK = Color(0xFF14142A)

/** Courbe de Bézier quadratique tracée en petits segments. */
private fun KCam.curve(
    x0: Float, y0: Float, x1: Float, y1: Float, x2: Float, y2: Float,
    c: Color, w: Float, steps: Int = 10
) {
    var px = x0
    var py = y0
    for (i in 1..steps) {
        val t = i / steps.toFloat()
        val u = 1f - t
        val nx = u * u * x0 + 2f * u * t * x1 + t * t * x2
        val ny = u * u * y0 + 2f * u * t * y1 + t * t * y2
        line(px, py, nx, ny, c, w)
        px = nx
        py = ny
    }
}

/** Lanterne en forme de goutte, avec capuchon et pointe. */
private fun KCam.teardrop(x: Float, y: Float, glowCol: Color, fl: Float) {
    glow(x, y + 0.1f, 2.8f, glowCol, 0.34f * fl)
    // capuchon + anneau d'attache
    tri(x - 0.15f, y - 0.14f, x, y - 0.34f, x + 0.15f, y - 0.14f, IRON)
    circ(x, y - 0.36f, 0.04f, IRON)
    // verre (contour puis lueur)
    oval(x - 0.17f, y - 0.16f, 0.34f, 0.4f, IRON)
    tri(x - 0.13f, y + 0.12f, x, y + 0.42f, x + 0.13f, y + 0.12f, IRON)
    val lit = lerp(glowCol, Color.White, 0.65f)
    oval(x - 0.12f, y - 0.11f, 0.24f, 0.3f, lit.copy(alpha = 0.95f * fl))
    tri(x - 0.09f, y + 0.12f, x, y + 0.34f, x + 0.09f, y + 0.12f, lit.copy(alpha = 0.9f * fl))
    circ(x, y + 0.04f, 0.05f, Color.White.copy(alpha = 0.85f * fl))
    // meneaux du verre
    line(x, y - 0.14f, x, y + 0.26f, IRON, 0.025f)
}

/** Lampadaire gothique à deux bras : socle étagé, fût à bagues, volutes, pointe en lance. */
internal fun KCam.gothicLamp(x: Float, groundY: Float, glowCol: Color, frame: Int, seed: Int) {
    val h = 3.0f
    val top = groundY - h
    val fl = 0.85f + 0.15f * sin(frame * 0.07f + seed)

    // socle étagé
    rect(x - 0.24f, groundY - 0.12f, 0.48f, 0.12f, IRON)
    rect(x - 0.17f, groundY - 0.26f, 0.34f, 0.14f, IRON)
    rect(x - 0.11f, groundY - 0.4f, 0.22f, 0.14f, IRON)
    rect(x - 0.2f, groundY - 0.14f, 0.05f, 0.03f, IRON_LIT)
    // fût
    rect(x - 0.045f, top + 0.2f, 0.09f, h - 0.5f, IRON)
    rect(x - 0.045f, top + 0.2f, 0.025f, h - 0.5f, IRON_LIT)
    // bagues
    for (by in floatArrayOf(0.75f, 1.55f, 2.3f)) {
        oval(x - 0.11f, groundY - by - 0.05f, 0.22f, 0.1f, IRON)
        oval(x - 0.07f, groundY - by - 0.03f, 0.08f, 0.04f, IRON_LIT)
    }
    // renflement central
    circ(x, groundY - 1.15f, 0.1f, IRON)

    // pointe en lance
    tri(x - 0.075f, top + 0.3f, x, top - 0.12f, x + 0.075f, top + 0.3f, IRON)
    tri(x - 0.1f, top + 0.3f, x, top + 0.22f, x + 0.1f, top + 0.3f, IRON)
    poly(IRON, x, top + 0.18f, x + 0.1f, top + 0.3f, x, top + 0.42f, x - 0.1f, top + 0.3f)

    // bras en col de cygne avec volute, et lanterne
    for (sd in intArrayOf(-1, 1)) {
        val d = sd.toFloat()
        val ay = top + 0.8f
        curve(x, ay + 0.15f, x + d * 0.75f, ay + 0.1f, x + d * 0.68f, ay - 0.35f, IRON, 0.06f, 12)
        // volute décorative près du fût
        curve(x + d * 0.05f, ay + 0.28f, x + d * 0.38f, ay + 0.3f, x + d * 0.34f, ay + 0.02f, IRON, 0.04f, 8)
        ringLine(x + d * 0.3f, ay - 0.02f, 0.07f, IRON, 0.04f * s)
        // crochet et lanterne
        circ(x + d * 0.68f, ay - 0.35f, 0.05f, IRON)
        line(x + d * 0.68f, ay - 0.35f, x + d * 0.68f, ay - 0.16f, IRON, 0.03f)
        teardrop(x + d * 0.68f, ay - 0.0f, glowCol, fl)
    }
}

/**
 * Pont suspendu gothique : tablier de pierre, arcs en ogive dessous avec pendentifs,
 * chaîne en arc entre deux lampadaires, suspentes et garde-corps à balustres.
 * [has] dit si la planche à la colonne donnée existe (trous possibles).
 */
internal fun KCam.gothicBridge(
    x0: Int, y: Int, len: Int, has: (Int) -> Boolean,
    glowCol: Color, ground: Color, frame: Int, seed: Int
) {
    val fy = y.toFloat()
    val stone = lerp(ground, Color(0xFF2A2A48), 0.55f)
    val stoneLit = lerp(stone, Color.White, 0.14f)
    val xa = x0 - 0.5f              // lampadaire côté départ (posé sur le sol voisin)
    val xb = x0 + len + 0.5f        // lampadaire côté arrivée

    // arcs en ogive sous le tablier
    for (i in 0 until len) {
        val tx = x0 + i
        if (!has(tx)) continue
        val fx = tx.toFloat()
        val ty = fy + 0.3f
        curve(fx - 0.02f, ty, fx + 0.04f, ty + 0.55f, fx + 0.5f, ty + 0.78f, IRON, 0.075f, 8)
        curve(fx + 1.02f, ty, fx + 0.96f, ty + 0.55f, fx + 0.5f, ty + 0.78f, IRON, 0.075f, 8)
        tri(fx + 0.43f, ty + 0.74f, fx + 0.5f, ty + 1.12f, fx + 0.57f, ty + 0.74f, IRON)   // pendentif
        circ(fx + 0.5f, ty + 0.4f, 0.07f, IRON)                                          // rosace
        circ(fx + 0.5f, ty + 0.4f, 0.035f, IRON_LIT.copy(alpha = 0.7f))
    }

    // tablier
    for (i in 0 until len) {
        val tx = x0 + i
        if (!has(tx)) continue
        val fx = tx.toFloat()
        rect(fx - 0.02f, fy - 0.02f, 1.06f, 0.36f, IRON)
        rect(fx, fy, 1.02f, 0.3f, stone)
        rect(fx, fy, 1.02f, 0.06f, stoneLit)
        // joints de dalles
        rect(fx + 0.97f, fy + 0.06f, 0.04f, 0.24f, IRON.copy(alpha = 0.8f))
        // petit quatre-feuilles gravé
        circ(fx + 0.5f, fy + 0.18f, 0.045f, STONE_DK)
        circ(fx + 0.38f, fy + 0.18f, 0.03f, STONE_DK)
        circ(fx + 0.62f, fy + 0.18f, 0.03f, STONE_DK)
    }

    // garde-corps : lisse + balustres en fer
    val railY = fy - 0.8f
    line(xa, railY, xb, railY, IRON, 0.07f)
    line(xa, railY + 0.14f, xb, railY + 0.14f, IRON, 0.035f)
    var bx = xa + 0.25f
    while (bx < xb - 0.1f) {
        line(bx, railY, bx, fy, IRON, 0.035f)
        val bi = ((bx - xa) * 2f).toInt()
        circ(bx, railY + 0.07f, 0.045f, IRON)
        if (bi % 2 == 0) ringLine(bx, railY + 0.42f, 0.07f, IRON, 0.03f * s)
        bx += 0.5f
    }

    // chaîne principale en arc + suspentes
    val sag = 0.9f + 0.05f * sin(frame * 0.03f + seed)
    val ay = fy - 2.2f
    var px = xa
    var py = ay
    val n = 16
    for (i in 1..n) {
        val t = i / n.toFloat()
        val nx = xa + (xb - xa) * t
        val ny = ay + sag * 4f * t * (1f - t)
        line(px, py, nx, ny, IRON, 0.055f)
        if (i % 2 == 0) circ(nx, ny, 0.05f, IRON_LIT.copy(alpha = 0.8f))
        px = nx
        py = ny
    }
    var hx = xa + 1f
    while (hx < xb - 0.4f) {
        val t = (hx - xa) / (xb - xa)
        val cy = ay + sag * 4f * t * (1f - t)
        line(hx, cy, hx, railY, IRON, 0.03f)
        circ(hx, cy, 0.04f, IRON)
        hx += 1f
    }

    // lampadaires aux deux extrémités
    gothicLamp(xa, fy, glowCol, frame, seed)
    gothicLamp(xb, fy, glowCol, frame, seed + 1)
}

/** Plateforme suspendue par deux chaînes, avec pendentif et lanterne dessous. */
internal fun KCam.hangingPlatform(
    x0: Int, y: Int, len: Int, ground: Color, glowCol: Color, frame: Int, seed: Int
) {
    val fx = x0.toFloat()
    val fy = y.toFloat()
    val w = len.toFloat()
    val stone = lerp(ground, Color(0xFF2A2A48), 0.5f)
    val lit = lerp(stone, Color.White, 0.16f)
    val fl = 0.85f + 0.15f * sin(frame * 0.07f + seed)
    val sw = sin(frame * 0.02f + seed) * 0.03f

    // chaînes montant dans l'obscurité
    for (cxp in floatArrayOf(fx + 0.3f, fx + w - 0.3f)) {
        val top = cy - 1f
        var yy = fy
        while (yy > top) {
            line(cxp + sw * (fy - yy) * 0.1f, yy, cxp + sw * (fy - yy - 0.34f) * 0.1f, yy - 0.34f, IRON, 0.05f)
            oval(cxp - 0.05f, yy - 0.22f, 0.1f, 0.16f, IRON_LIT.copy(alpha = 0.55f))
            yy -= 0.34f
        }
        circ(cxp, fy - 0.02f, 0.07f, IRON)
    }

    // pendentif et lanterne sous la dalle
    tri(fx + w / 2f - 0.22f, fy + 0.6f, fx + w / 2f, fy + 1.1f, fx + w / 2f + 0.22f, fy + 0.6f, IRON)

    // dalle : contour encré, pierre, pavés
    rect(fx - 0.06f, fy - 0.04f, w + 0.12f, 0.7f, IRON)
    rect(fx, fy, w, 0.6f, stone)
    rect(fx, fy, w, 0.07f, lit)
    for (i in 0 until len * 2) {
        val ox = fx + i * 0.5f
        oval(ox + 0.04f, fy + 0.14f, 0.42f, 0.22f, if (hsh(x0 + i, y) > 0.5f) lerp(stone, Color.Black, 0.25f) else lerp(stone, Color.White, 0.06f))
    }
    for (i in 0 until len) {
        tri(fx + i + 0.2f, fy + 0.58f, fx + i + 0.5f, fy + 0.58f + 0.3f + 0.25f * hsh(x0 + i, y + 9), fx + i + 0.8f, fy + 0.58f, lerp(stone, Color.Black, 0.4f))
    }
    rect(fx - 0.06f, fy + 0.58f, w + 0.12f, 0.07f, IRON)
    teardrop(fx + w / 2f, fy + 1.45f, glowCol, fl)
}
