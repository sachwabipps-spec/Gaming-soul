package com.nexus.gamelibrary

import java.util.Random
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

open class KBody(var x: Float, var y: Float, val w: Float, val h: Float) {
    var vx = 0f
    var vy = 0f
    var ground = false
    var wall = false
}

class KFoe(
    val type: Int, x: Float, y: Float, w: Float, h: Float,
    var hp: Float, val maxHp: Float, val dmg: Float, val spd: Float,
    val coins: Int, val elite: Boolean, val boss: Boolean, val bossIdx: Int
) : KBody(x, y, w, h) {
    val fly = type == 1 || type == 5 || type == 6
    var dir = -1
    var t = 0f
    var t2 = 1.5f
    var charge = 0f
    var flash = 0f
    var dead = false
    var swing = -1
    val homeX = x
    val homeY = y
}

class KChest(val x: Float, val y: Float, val tier: Int) { var open = false }

class KProj(var x: Float, var y: Float, var vx: Float, var vy: Float, val dmg: Float, val mine: Boolean, val color: Long, var life: Float) {
    var pierce = false
    val hit = HashSet<KFoe>()
}

class KFx(val x: Float, val y: Float, var t: Float, val max: Float, val color: Long, val ring: Float)

class KIn {
    var left = false
    var right = false
    var jumpHeld = false
    var jumpLatch = false
    var atkLatch = false
    var dashLatch = false
    val pw = BooleanArray(3)
}

class KnightGame(val lv: Int, val st: KStats, val loadout: IntArray, val powers: Map<Int, Int>, val capeCol: Long = 0xFF7FB0FF, val skin: KSkin = KSkin.default()) {
    companion object {
        const val H = 16
        val FW = floatArrayOf(0.9f, 0.8f, 0.8f, 0.8f, 1.3f, 0.8f, 0.9f)
        val FH = floatArrayOf(0.7f, 0.6f, 1.4f, 1.4f, 1.7f, 1.2f, 1.4f)
        val FHP = floatArrayOf(20f, 14f, 30f, 24f, 80f, 30f, 45f)
        val FDM = floatArrayOf(8f, 7f, 11f, 10f, 18f, 14f, 16f)
        val FSP = floatArrayOf(1.5f, 3f, 2f, 0f, 1.4f, 2f, 2.5f)
        val FCO = intArrayOf(3, 3, 5, 5, 12, 8, 10)
        val UNL = intArrayOf(1, 6, 15, 30, 50, 80, 120)
        val FNAME = listOf("Gelée", "Chauve-souris", "Squelette", "Archer", "Brute", "Mage", "Spectre")
        const val PW = 0.7f
        const val PH = 1.4f
    }

    val world = KN.worlds[KN.worldOf(lv)]
    val boss = lv % 10 == 0
    val W = 72 + lv / 6
    val tiles = ByteArray(W * H)
    /** Ponts et plateformes suspendues : (x, y, longueur, type) — type 0 = pont gothique, 1 = plateforme à chaînes. */
    val spans = ArrayList<IntArray>()
    val foes = ArrayList<KFoe>()
    val chests = ArrayList<KChest>()
    val projs = ArrayList<KProj>()
    val fx = ArrayList<KFx>()
    val inp = KIn()
    val bossName = KN.bossName(lv / 10 - 1)
    var bossDead = false
    val sfx = ArrayDeque<Int>()
    var safeBossArena = 0

    // Joueur
    val p = KBody(2f, 9.6f, PW, PH)
    var hp = st.maxHp.toFloat()
    var face = 1
    var inv = 0f
    var atkT = 0f
    var swingT = 0f
    var swingId = 0
    var dashT = 0f
    var dashCd = 0f
    var dashStrike = 0f
    var shield = 0f
    var rage = 0f
    var coyote = 0f
    var jbuf = 0f
    var jumps = 0
    val pcd = FloatArray(3)
    var safeX = 2f
    var safeY = 9.6f
    var safeT = 0f
    var time = 0f

    // Résultats
    var over = false
    var won = false
    var coinsGained = 0
    val foundItems = ArrayList<KItem>()
    val foundPowers = ArrayList<Int>()
    var msg = ""
    var msgT = 0f
    var kills = 0
    var chestsOpened = 0
    val gateX: Float
    var gateY = 8f
    var bossAlive = false
    val rnd = Random(System.nanoTime())

    init {
        val r = Random(lv * 7919L + 17)
        val d = lv / KN.LEVELS.toFloat()
        val g = IntArray(W) { 11 }
        var gy = 11
        var x = 8
        val flats = ArrayList<IntArray>()
        val spikes = ArrayList<IntArray>()
        val plats = ArrayList<IntArray>()
        val spots = ArrayList<FloatArray>()
        val bridgeTiles = ArrayList<IntArray>()
        fun fill(from: Int, len: Int, y: Int) { for (i in 0 until len) g[from + i] = y }
        while (x < W - 18) {
            when (r.nextInt(12)) {
                0, 1, 2, 3 -> { val len = 4 + r.nextInt(6); fill(x, len, gy); flats.add(intArrayOf(x, x + len, gy)); x += len }
                4 -> {
                    gy = (gy + (if (r.nextBoolean()) -1 else 1) * (1 + r.nextInt(2))).coerceIn(8, 13)
                    val len = 3 + r.nextInt(3); fill(x, len, gy); x += len
                }
                5, 6 -> {
                    val gw = 2 + r.nextInt(if (d > 0.25f) 3 else 2)
                    for (i in 0 until gw) g[x + i] = -1
                    x += gw
                    val len = 3 + r.nextInt(3); fill(x, len, gy); flats.add(intArrayOf(x, x + len, gy)); x += len
                }
                7 -> {
                    fill(x, 6, gy)
                    spikes.add(intArrayOf(x + 2, gy))
                    if (d > 0.2f && r.nextBoolean()) spikes.add(intArrayOf(x + 3, gy))
                    x += 6
                }
                8 -> {
                    for (i in 0 until 8) g[x + i] = -1
                    plats.add(intArrayOf(x + 3, gy - 1, 2))
                    if (r.nextInt(3) == 0) spots.add(floatArrayOf(x + 3.5f, (gy - 1).toFloat()))
                    x += 8
                    val len = 4; fill(x, len, gy); flats.add(intArrayOf(x, x + len, gy)); x += len
                }
                10 -> { // pont suspendu gothique (trous et pointes quand le niveau avance)
                    val bl = 7 + r.nextInt(4)
                    for (i in 0 until bl) g[x + i] = -1
                    val hole = if (d > 0.15f && r.nextInt(3) != 0) x + bl / 2 else -1
                    val hole2 = if (hole >= 0 && d > 0.5f && r.nextBoolean()) hole + 1 else -1
                    bridgeTiles.add(intArrayOf(x, gy, bl, hole, hole2))
                    spans.add(intArrayOf(x, gy, bl, 0))
                    if (hole < 0 && d > 0.25f && r.nextBoolean()) spikes.add(intArrayOf(x + bl / 2, gy))
                    x += bl
                    val len = 4; fill(x, len, gy); flats.add(intArrayOf(x, x + len, gy)); x += len
                }
                11 -> { // plateformes suspendues par des chaînes (style « saute de plateforme en plateforme »)
                    val gap = if (d > 0.3f) 3 else 2
                    val k = 2 + (if (d > 0.3f && r.nextBoolean()) 1 else 0)
                    val total = gap + k * (3 + gap)
                    if (x + total + 4 > W - 2) {
                        val len = 6; fill(x, len, gy); flats.add(intArrayOf(x, x + len, gy)); x += len
                    } else {
                        for (i in 0 until total) g[x + i] = -1
                        var px = x + gap
                        var yy = gy - 1
                        for (j in 0 until k) {
                            bridgeTiles.add(intArrayOf(px, yy, 3, -1, -1))
                            spans.add(intArrayOf(px, yy, 3, 1))
                            if (j == 0 && r.nextInt(3) == 0) spots.add(floatArrayOf(px + 1.5f, yy.toFloat()))
                            px += 3 + gap
                            yy = if (j % 2 == 0) gy - 2 else gy - 1
                        }
                        x += total
                        val len = 4; fill(x, len, gy); flats.add(intArrayOf(x, x + len, gy)); x += len
                    }
                }
                else -> {
                    val len = 6; fill(x, len, gy); flats.add(intArrayOf(x, x + len, gy))
                    plats.add(intArrayOf(x + 2, gy - 3, 3))
                    spots.add(floatArrayOf(x + 3.5f, (gy - 3).toFloat()))
                    x += len
                }
            }
        }
        val arenaStart = x
        while (x < W) { g[x] = gy; x++ }
        for (cx in 0 until W) if (g[cx] >= 0) for (cy in g[cx] until H) tiles[cy * W + cx] = 1
        for (pl in plats) for (i in 0 until pl[2]) tiles[pl[1] * W + pl[0] + i] = 1
        for (b in bridgeTiles) for (i in 0 until b[2]) { val tx = b[0] + i; if (tx != b[3] && tx != b[4]) tiles[b[1] * W + tx] = 3 }
        for (s in spikes) tiles[(s[1] - 1) * W + s[0]] = 2
        gateX = (W - 3).toFloat()
        gateY = (gy - 3).toFloat()

        val hs = 1f + lv * 0.022f
        val ds = 1f + lv * 0.012f
        val cs = 1f + lv * 0.03f
        val allowed = (0..6).filter { UNL[it] <= lv }
        val eliteP = min(0.5f, lv / 900f)
        fun mk(type: Int, fxp: Float, gyF: Float): KFoe {
            val elite = r.nextFloat() < eliteP
            val w = FW[type]; val h = FH[type]
            val fly = type == 1 || type == 5 || type == 6
            val yy = if (fly) gyF - 3f else gyF - h
            return KFoe(
                type, fxp, yy, w, h,
                FHP[type] * hs * (if (elite) 2f else 1f), FHP[type] * hs * (if (elite) 2f else 1f),
                FDM[type] * ds * (if (elite) 1.3f else 1f), FSP[type],
                (FCO[type] * cs * (if (elite) 3f else 1f)).toInt(), elite, false, 0
            )
        }
        for (f in flats) {
            if (f[0] < 12 || f[1] - f[0] < 5) continue
            if (r.nextFloat() > 0.45f + 0.35f * d) continue
            val n = 1 + (if (d > 0.4f && r.nextBoolean()) 1 else 0)
            for (k in 0 until n) {
                val t = if (r.nextFloat() < 0.45f) allowed[max(0, allowed.size - 1 - r.nextInt(2))] else allowed[r.nextInt(allowed.size)]
                foes.add(mk(t, f[0] + 1f + r.nextFloat() * (f[1] - f[0] - 2), f[2].toFloat()))
            }
        }
        // coffres
        fun tier(): Int {
            val u = r.nextFloat()
            return if (u < 0.05f + 0.25f * d) 2 else if (u < 0.30f + 0.25f * d) 1 else 0
        }
        for (s in spots) chests.add(KChest(s[0], s[1] - 0.7f, tier()))
        val extra = ArrayList(flats.filter { it[1] - it[0] >= 4 && it[0] > 10 })
        var guard = 0
        while (chests.size < 3 && extra.isNotEmpty() && guard++ < 20) {
            val f = extra[r.nextInt(extra.size)]
            chests.add(KChest(f[0] + 1.5f + r.nextFloat() * (f[1] - f[0] - 3).coerceAtLeast(0), f[2] - 0.7f, tier()))
        }
        if (r.nextFloat() < 0.5f && extra.isNotEmpty()) {
            val f = extra[r.nextInt(extra.size)]
            chests.add(KChest(f[0] + 2f, f[2] - 0.7f, tier()))
        }
        // boss
        if (boss) {
            val bi = lv / 10 - 1
            val type = bi % 7
            val bw = 2.2f; val bh = 2.6f
            val bf = KFoe(
                type, (W - 9).toFloat(), gy - bh, bw, bh,
                (350f + 60f * (bi % 7)) * hs * 1.6f, (350f + 60f * (bi % 7)) * hs * 1.6f,
                (16f + type * 2f) * ds, 2.2f, (60 * cs).toInt(), false, true, bi
            )
            foes.add(bf)
            bossAlive = true
            safeBossArena = arenaStart
        }
        p.y = 11f - PH
        safeY = p.y
    }

    // ── Collisions
    fun solid(tx: Int, ty: Int): Boolean {
        if (tx < 0 || tx >= W) return true
        if (ty < 0 || ty >= H) return false
        val t = tiles[ty * W + tx]
        return t == 1.toByte() || t == 3.toByte()
    }

    fun hitBox(x: Float, y: Float, w: Float, h: Float): Boolean {
        val x0 = floor(x).toInt(); val x1 = floor(x + w - 0.001f).toInt()
        val y0 = floor(y).toInt(); val y1 = floor(y + h - 0.001f).toInt()
        for (ty in y0..y1) for (tx in x0..x1) if (solid(tx, ty)) return true
        return false
    }

    fun move(b: KBody, dt: Float) {
        b.wall = false
        val nx = b.x + b.vx * dt
        if (!hitBox(nx, b.y, b.w, b.h)) b.x = nx
        else {
            b.wall = true
            b.x = if (b.vx > 0) floor(nx + b.w) - b.w - 0.001f else floor(nx) + 1.001f
            b.vx = 0f
        }
        b.ground = false
        val ny = b.y + b.vy * dt
        if (!hitBox(b.x, ny, b.w, b.h)) b.y = ny
        else {
            if (b.vy > 0) { b.y = floor(ny + b.h) - b.h - 0.001f; b.ground = true } else b.y = floor(ny) + 1.001f
            b.vy = 0f
        }
    }

    private fun overlap(ax: Float, ay: Float, aw: Float, ah: Float, bx: Float, by: Float, bw: Float, bh: Float) =
        ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by

    private fun say(s: String) { msg = s; msgT = 2.5f }
    private fun ring(x: Float, y: Float, color: Long, r: Float, t: Float = 0.35f) { fx.add(KFx(x, y, 0f, t, color, r)) }

    // ── Dégâts
    fun hurt(dmg: Float, srcX: Float) {
        if (over || inv > 0f || dashT > 0f || shield > 0f) return
        hp -= max(1f, dmg)
        inv = 1f
        sfx.add(4)
        p.vy = -8f
        p.vx = if (p.x < srcX) -6f else 6f
        ring(p.x + PW / 2, p.y + PH / 2, 0xFFFF4040, 0.8f, 0.25f)
        if (hp <= 0f) { hp = 0f; over = true; won = false; sfx.add(10) }
    }

    fun hitFoe(f: KFoe, dmg0: Float, kx: Float, canCrit: Boolean = true) {
        if (f.dead) return
        var dmg = dmg0
        if (canCrit && rnd.nextInt(100) < st.crit) { dmg *= 2f; ring(f.x + f.w / 2, f.y, 0xFFFFE94D, 0.5f, 0.25f) }
        f.hp -= dmg
        f.flash = 0.12f
        sfx.add(3)
        if (!f.boss && !hitBox(f.x + kx * 0.35f, f.y, f.w, f.h)) f.x += kx * 0.35f
        if (st.lifesteal > 0) hp = min(st.maxHp.toFloat(), hp + dmg * st.lifesteal / 100f)
        if (f.hp <= 0f) {
            f.dead = true
            kills++
            sfx.add(if (f.boss) 11 else 5)
            val c = (f.coins * (1f + st.coinPct / 100f)).toInt()
            coinsGained += c
            ring(f.x + f.w / 2, f.y + f.h / 2, 0xFFFFC83D, 1f, 0.4f)
            if (f.boss) {
                bossDead = true
                bossAlive = false
                chests.add(KChest(f.x + f.w / 2, f.y + f.h - 0.7f, 2))
                say("BOSS VAINCU ! Ouvre le coffre, puis franchis la porte")
            }
        }
    }

    // ── Pouvoirs
    private fun cast(slot: Int) {
        val id = loadout.getOrNull(slot) ?: -1
        if (id < 0 || pcd[slot] > 0f || dashT > 0f) return
        val lvl = powers[id] ?: return
        val pw = KPower(id)
        val m = pw.mul(lvl) * st.powMul
        val cx = p.x + PW / 2; val cy = p.y + PH / 2
        val col = pw.color
        pcd[slot] = pw.cooldown * st.pcd
        sfx.add(if (pw.kind == 3) 13 else 7)
        val base = st.atk
        when (pw.kind) {
            0 -> projs.add(KProj(cx, cy, face * 11f, 0f, base * 1.6f * m, true, col, 1.4f))
            1 -> {
                ring(cx, cy, col, 3.5f, 0.45f)
                for (f in foes) if (!f.dead && abs(f.x + f.w / 2 - cx) < 3.6f && abs(f.y + f.h / 2 - cy) < 3.2f) hitFoe(f, base * 2.2f * m, if (f.x > cx) 1f else -1f)
            }
            2 -> { dashT = 0.28f; dashStrike = base * 2.2f * m; swingId++; inv = max(inv, 0.3f) }
            3 -> { hp = min(st.maxHp.toFloat(), hp + st.maxHp * 0.25f * m); ring(cx, cy, 0xFF7CFF8A, 1.2f, 0.5f); say("Soin !") }
            4 -> { shield = 2.5f + 0.5f * m; ring(cx, cy, col, 1.2f, 0.4f) }
            5 -> {
                projs.add(KProj(cx, p.y + PH - 0.3f, 9f, 0f, base * 2f * m, true, col, 1.1f).also { it.pierce = true })
                projs.add(KProj(cx, p.y + PH - 0.3f, -9f, 0f, base * 2f * m, true, col, 1.1f).also { it.pierce = true })
            }
            6 -> for (a in -1..1) projs.add(KProj(cx, cy, face * 10f * cos(a * 0.3f), 10f * sin(a * 0.3f), base * 1.2f * m, true, col, 1.2f))
            7 -> { rage = 6f + m; ring(cx, cy, 0xFFFF4040, 1.2f, 0.5f) }
            8 -> {
                var d = 0f
                while (d < 5f && !hitBox(p.x + face * (d + 0.25f), p.y, PW, PH)) d += 0.25f
                p.x += face * d
                inv = max(inv, 0.6f)
                ring(cx, cy, col, 1f, 0.3f); ring(p.x + PW / 2, cy, col, 1f, 0.3f)
            }
            9 -> {
                ring(cx, cy, col, 7f, 0.5f)
                for (f in foes) if (!f.dead && abs(f.x - cx) < 9f) hitFoe(f, base * 2.6f * m, if (f.x > cx) 1f else -1f)
            }
        }
    }

    private fun shootAt(f: KFoe, speed: Float, dmgMul: Float, color: Long) {
        val fx0 = f.x + f.w / 2; val fy0 = f.y + f.h / 2
        val dx = p.x + PW / 2 - fx0; val dy = p.y + PH / 2 - fy0
        val l = max(0.1f, sqrt(dx * dx + dy * dy))
        projs.add(KProj(fx0, fy0, dx / l * speed, dy / l * speed, f.dmg * dmgMul, false, color, 3f))
    }

    // ── Boucle
    fun step(dt: Float) {
        if (over) return
        time += dt
        atkT -= dt; swingT -= dt; dashCd -= dt; inv -= dt; shield -= dt; rage -= dt; msgT -= dt
        for (i in 0..2) pcd[i] -= dt
        if (msgT <= 0f) msg = ""

        val dir = (if (inp.right) 1 else 0) - (if (inp.left) 1 else 0)
        if (dashT > 0f) {
            dashT -= dt
            p.vx = face * 16f
            p.vy = 0f
            if (dashT <= 0f) dashStrike = 0f
        } else {
            p.vx += (dir * st.speed - p.vx) * min(1f, 14f * dt)
            if (dir != 0) face = dir
            p.vy = min(22f, p.vy + 38f * dt)
        }
        if (p.ground) { coyote = 0.1f; jumps = 0 } else coyote -= dt
        jbuf -= dt
        if (inp.jumpLatch) { jbuf = 0.12f; inp.jumpLatch = false }
        if (jbuf > 0f && dashT <= 0f) {
            if (coyote > 0f) { sfx.add(1); p.vy = -16f; jumps = 1; coyote = 0f; jbuf = 0f; p.ground = false }
            else if (st.dbl && jumps < 2) { sfx.add(12); p.vy = -15f; jumps = 2; jbuf = 0f; ring(p.x + PW / 2, p.y + PH, 0xFFFFFFFF, 0.5f, 0.2f) }
        }
        if (!inp.jumpHeld && p.vy < -7f && dashT <= 0f) p.vy = -7f

        if (inp.atkLatch) {
            inp.atkLatch = false
            if (atkT <= 0f && dashT <= 0f) { atkT = st.cd; swingT = 0.16f; swingId++; sfx.add(2) }
        }
        if (inp.dashLatch) {
            inp.dashLatch = false
            if (dashCd <= 0f && dashT <= 0f) { dashT = 0.2f; dashCd = 0.9f; inv = max(inv, 0.25f); dashStrike = 0f; sfx.add(8) }
        }
        for (i in 0..2) if (inp.pw[i]) { inp.pw[i] = false; cast(i) }

        move(p, dt)

        // chute
        if (p.y > H + 2) {
            hp -= st.maxHp * 0.15f
            sfx.add(4)
            if (hp <= 0f) { hp = 0f; over = true; won = false; sfx.add(10); return }
            p.x = safeX; p.y = safeY; p.vx = 0f; p.vy = 0f; inv = 1.5f
        }
        safeT -= dt
        if (p.ground && safeT <= 0f && solid(floor(p.x - 0.8f).toInt(), floor(p.y + PH + 0.2f).toInt()) &&
            solid(floor(p.x + PW + 0.8f).toInt(), floor(p.y + PH + 0.2f).toInt())) {
            safeX = p.x; safeY = p.y; safeT = 0.4f
        }
        // pics
        val tx0 = floor(p.x).toInt(); val tx1 = floor(p.x + PW).toInt()
        val ty0 = floor(p.y + 0.3f).toInt(); val ty1 = floor(p.y + PH - 0.01f).toInt()
        loop@ for (ty in ty0..ty1) for (tx in tx0..tx1) {
            if (tx in 0 until W && ty in 0 until H && tiles[ty * W + tx] == 2.toByte()) {
                if (inv <= 0f && dashT <= 0f && shield <= 0f) {
                    hurt(st.maxHp * 0.12f, tx.toFloat())
                    p.x = safeX; p.y = safeY; p.vx = 0f; p.vy = 0f
                }
                break@loop
            }
        }

        // frappe d'épée
        val dmgMul = if (rage > 0f) 1.8f else 1f
        if (swingT > 0f) {
            val rx = if (face > 0) p.x + PW else p.x - st.reach
            for (f in foes) if (!f.dead && f.swing != swingId && overlap(rx, p.y - 0.1f, st.reach, PH + 0.2f, f.x, f.y, f.w, f.h)) {
                f.swing = swingId
                hitFoe(f, st.atk * dmgMul, face.toFloat())
            }
        }
        if (dashT > 0f && dashStrike > 0f) {
            for (f in foes) if (!f.dead && f.swing != swingId && overlap(p.x, p.y, PW, PH, f.x, f.y, f.w, f.h)) {
                f.swing = swingId
                hitFoe(f, dashStrike * dmgMul, face.toFloat())
            }
        }

        for (f in foes) if (!f.dead) updFoe(f, dt)
        foes.removeAll { it.dead }

        // projectiles
        val pit = projs.iterator()
        while (pit.hasNext()) {
            val pr = pit.next()
            pr.x += pr.vx * dt; pr.y += pr.vy * dt; pr.life -= dt
            var remove = pr.life <= 0f || solid(floor(pr.x).toInt(), floor(pr.y).toInt())
            if (!remove) {
                if (pr.mine) {
                    for (f in foes) if (!f.dead && !pr.hit.contains(f) && overlap(pr.x - 0.25f, pr.y - 0.25f, 0.5f, 0.5f, f.x, f.y, f.w, f.h)) {
                        pr.hit.add(f)
                        hitFoe(f, pr.dmg * dmgMul, if (pr.vx >= 0) 1f else -1f, false)
                        if (!pr.pierce) { remove = true; break }
                    }
                } else if (overlap(pr.x - 0.25f, pr.y - 0.25f, 0.5f, 0.5f, p.x, p.y, PW, PH)) {
                    hurt(pr.dmg, pr.x); remove = true
                }
            }
            if (remove) pit.remove()
        }
        foes.removeAll { it.dead }

        // contact ennemis
        for (f in foes) if (!f.dead && overlap(p.x, p.y, PW, PH, f.x + 0.1f, f.y + 0.1f, f.w - 0.2f, f.h - 0.2f)) hurt(f.dmg, f.x + f.w / 2)

        // coffres
        for (c in chests) if (!c.open && overlap(p.x, p.y, PW, PH, c.x - 0.45f, c.y, 0.9f, 0.7f)) openChest(c)

        // porte
        if (overlap(p.x, p.y, PW, PH, gateX, gateY, 1.2f, 3f)) {
            if (bossAlive) say("Vaincs d'abord le boss !")
            else { won = true; over = true; sfx.add(9) }
        }

        val fi = fx.iterator()
        while (fi.hasNext()) { val e = fi.next(); e.t += dt; if (e.t >= e.max) fi.remove() }
    }

    private fun openChest(c: KChest) {
        c.open = true
        chestsOpened++
        sfx.add(6)
        ring(c.x, c.y, 0xFFFFC83D, 1.2f, 0.5f)
        val u = rnd.nextFloat()
        val r = rnd
        when {
            u < 0.30f -> {
                val amt = ((15f + lv * 1.5f) * (1f + c.tier * 0.8f) * (0.8f + r.nextFloat() * 0.6f)).toInt()
                coinsGained += amt; say("Coffre : +$amt pièces")
            }
            u < 0.42f -> { hp = min(st.maxHp.toFloat(), hp + st.maxHp * 0.4f); say("Coffre : potion de soin !") }
            u < 0.42f + 0.05f + 0.05f * c.tier -> {
                val id = KN.rollPower(r, c.tier)
                foundPowers.add(id)
                say("Coffre : POUVOIR ${KPower(id).name} !")
            }
            else -> {
                val item = KN.rollItem(lv, c.tier, r)
                foundItems.add(item)
                say("Coffre : ${item.name} (${KN.rarNames[item.rar]})")
            }
        }
    }

    fun stars(): Int {
        val ratio = hp / st.maxHp
        return if (ratio >= 0.7f) 3 else if (ratio >= 0.35f) 2 else 1
    }

    // ── IA
    private fun gravityMove(f: KFoe, dt: Float) {
        f.vy = min(22f, f.vy + 38f * dt)
        move(f, dt)
    }

    private fun updFoe(f: KFoe, dt: Float) {
        f.t += dt; f.t2 -= dt; f.flash -= dt
        val px = p.x + PW / 2; val py = p.y + PH / 2
        val fx0 = f.x + f.w / 2; val fy0 = f.y + f.h / 2
        val dist = abs(px - fx0)
        val near = dist < 9f && abs(py - fy0) < 5f
        if (f.boss) { updBoss(f, dt, px, fx0, near); return }
        when (f.type) {
            0, 2, 4 -> {
                val sp = f.spd * (if (f.type == 2 && near && dist < 6f) 2f else 1f)
                if (f.type != 0 && near && dist < 6f) f.dir = if (px > fx0) 1 else -1
                f.vx = f.dir * sp
                gravityMove(f, dt)
                val ax = if (f.dir > 0) f.x + f.w + 0.1f else f.x - 0.1f
                val feet = floor(f.y + f.h + 0.1f).toInt()
                if (f.wall || (f.ground && !solid(floor(ax).toInt(), feet))) f.dir = -f.dir
            }
            3 -> {
                f.dir = if (px > fx0) 1 else -1
                f.vx = 0f
                gravityMove(f, dt)
                if (near && dist < 10f && f.t2 <= 0f) {
                    f.t2 = 2.2f
                    projs.add(KProj(fx0, fy0 - 0.2f, f.dir * 8f, 0f, f.dmg, false, 0xFFC9A66B, 2f))
                }
            }
            1 -> {
                if (near) {
                    val dx = px - fx0; val dy = py - fy0
                    val l = max(0.1f, sqrt(dx * dx + dy * dy))
                    f.x += dx / l * f.spd * dt
                    f.y += dy / l * f.spd * dt + sin(f.t * 6f) * 0.03f
                } else {
                    f.x = f.homeX + sin(f.t) * 2f
                    f.y = f.homeY + sin(f.t * 2f) * 0.5f
                }
                f.dir = if (px > fx0) 1 else -1
            }
            5 -> {
                f.dir = if (px > fx0) 1 else -1
                if (near) {
                    if (dist < 4f) f.x -= f.dir * f.spd * dt else if (dist > 7f) f.x += f.dir * f.spd * dt
                }
                f.y = f.homeY + sin(f.t * 2f) * 0.4f
                if (near && f.t2 <= 0f) { f.t2 = 2.5f; shootAt(f, 6f, 1f, 0xFFD36BFF) }
            }
            6 -> {
                f.dir = if (px > fx0) 1 else -1
                if (dist < 12f) {
                    val dx = px - fx0; val dy = py - fy0
                    val l = max(0.1f, sqrt(dx * dx + dy * dy))
                    f.x += dx / l * f.spd * dt
                    f.y += dy / l * f.spd * dt
                }
            }
        }
        if (f.y > H + 1f) f.dead = true
        if (f.y < 0f) f.y = 0f
    }

    private fun updBoss(f: KFoe, dt: Float, px: Float, fx0: Float, near: Boolean) {
        f.dir = if (px > fx0) 1 else -1
        val enraged = f.hp < f.maxHp * 0.5f
        if (f.charge > 0f) { f.charge -= dt; f.vx = f.dir * 9f }
        else f.vx = if (near) f.dir * f.spd else 0f
        if (near && f.t2 <= 0f) {
            f.t2 = 2.4f - (if (enraged) 0.8f else 0f)
            when ((f.bossIdx + (f.t / 2.4f).toInt()) % 3) {
                0 -> f.charge = 0.7f
                1 -> { if (f.ground) f.vy = -15f; for (a in -1..1) projs.add(KProj(fx0, f.y + 0.5f, f.dir * 6f, a * 2.5f, f.dmg * 0.7f, false, 0xFFFF7A2A, 3f)) }
                else -> { shootAt(f, 7f, 0.8f, 0xFFD36BFF); if (enraged) for (a in listOf(-0.5f, 0.5f)) projs.add(KProj(fx0, f.y + 0.8f, f.dir * 7f, a * 4f, f.dmg * 0.6f, false, 0xFFD36BFF, 3f)) }
            }
        }
        gravityMove(f, dt)
        // reste dans l'arène
        val minX = safeBossArena.toFloat() + 1f
        if (f.x < minX) f.x = minX
    }
}
