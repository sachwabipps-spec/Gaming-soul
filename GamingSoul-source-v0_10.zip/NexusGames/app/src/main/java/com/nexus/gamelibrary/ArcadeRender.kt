package com.nexus.gamelibrary

import androidx.compose.ui.graphics.Color
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * Rendu haute définition : les joueurs, ballons et effets sont dessinés sur une grille
 * 2 fois plus fine que le terrain (demi-pixels), soit 4 fois plus de pixels par sprite.
 */

internal fun Px.h(x: Int, y: Int, w: Int, hh: Int, c: Color) = r(x / 2f, y / 2f, w / 2f, hh / 2f, c)

internal class Look(
    val skin: Color, val skinSh: Color, val hair: Color, val hairHi: Color, val hairStyle: Int,
    val jersey: Color, val jerseyDark: Color, val stripe: Color, val pattern: Int,
    val shorts: Color, val sock: Color, val sleeve: Color, val number: Int, val accessory: Int
)

private val oppKitsHd = listOf(0xFFE23B3B, 0xFFFF8A00, 0xFF9A3BE2, 0xFF16A085, 0xFFD4AF37)
private val oppKitsDarkHd = listOf(0xFFA82424, 0xFFC26A00, 0xFF7026A8, 0xFF0E7A64, 0xFFA88A1E)
private val Ink = Color(0xFF14141C)

internal fun skinLook(s: Skin): Look {
    val k = Cosmetics.kitColors[s.kitColor]
    val k2 = Cosmetics.kitColors[s.kit2Color]
    val sh = Cosmetics.kitColors[s.shortsColor]
    val hc = Cosmetics.hairColors[s.hairColor]
    val st = Cosmetics.skinTones[s.skinTone]
    return Look(
        Color(st.color), Color(st.color2), Color(hc.color), Color(hc.color2), s.hairStyle,
        Color(k.color), Color(k.color2), Color(k2.color), s.kitPattern,
        Color(sh.color), Color(k.color), Color(k.color), s.number, s.accessory
    )
}

/** Apparence d'un joueur du match (toi : ton skin ; coéquipiers : même maillot ; adversaires : couleurs de la division). */
private fun lookOf(m: Match, p: Player, skin: Skin): Look {
    val keeper = m.sport == Sport.FOOT && p.slot == 0
    val mateHair = Cosmetics.hairColors
    if (p.team == 0) {
        val base = skinLook(skin)
        val me = p.slot == 1
        val hs = if (me) skin.hairStyle else (p.slot + 1) % 3
        val hcI = if (me) skin.hairColor else (p.slot * 2 + 1) % 4
        val skI = if (me) skin.skinTone else (p.slot * 2 + 1) % 4
        val sk = Cosmetics.skinTones[skI]
        val hc = mateHair[hcI]
        val jersey = if (keeper) Color(0xFFFFB300) else base.jersey
        val dark = if (keeper) Color(0xFFC98400) else base.jerseyDark
        return Look(
            Color(sk.color), Color(sk.color2), Color(hc.color), Color(hc.color2), hs,
            jersey, dark, if (keeper) Color(0xFFFFD66B) else base.stripe, if (keeper) 0 else skin.kitPattern,
            if (keeper) Ink else base.shorts, if (m.sport == Sport.BASKET) Color(0xFFF2F2F2) else jersey,
            if (keeper) Color.White else if (m.sport == Sport.BASKET) Color(sk.color) else jersey,
            if (me) skin.number else (p.slot * 7 + 3) % 99, if (me) skin.accessory else 0
        )
    }
    val d = m.level.division.coerceIn(0, 4)
    val sk = Cosmetics.skinTones[(p.slot * 2 + 3) % 4]
    val hc = mateHair[(p.slot + 2) % 4]
    val jersey = if (keeper) Color(0xFF3DDC84) else Color(oppKitsHd[d])
    val dark = if (keeper) Color(0xFF22A35E) else Color(oppKitsDarkHd[d])
    return Look(
        Color(sk.color), Color(sk.color2), Color(hc.color), Color(hc.color2), (p.slot + 2) % 3,
        jersey, dark, Color(0xFFF4F4F8), 0, if (keeper) Ink else Color(0xFF2B2B33),
        if (m.sport == Sport.BASKET) Color(0xFFF2F2F2) else jersey,
        if (keeper) Color.White else if (m.sport == Sport.BASKET) Color(sk.color) else jersey, (p.slot * 5 + 4) % 99, 0
    )
}

private val digits = listOf(
    "111101101101111", "010110010010111", "111001111100111", "111001111001111", "101101111001001",
    "111100111001111", "111100111101111", "111001001001001", "111101111101111", "111101111001111"
)

private fun Px.drawNumber(n: Int, cx: Int, y: Int, c: Color) {
    val s = n.coerceIn(0, 99).toString()
    val w = s.length * 4 - 1
    var x0 = cx - w / 2
    for (ch in s) {
        val g = digits[ch - '0']
        for (j in 0 until 5) for (i in 0 until 3) if (g[j * 3 + i] == '1') h(x0 + i, y + j, 1, 1, c)
        x0 += 4
    }
}

private fun lum(c: Color) = 0.3f * c.red + 0.59f * c.green + 0.11f * c.blue

/** Dessine un joueur en haute définition. (px, py) = pieds en unités du terrain. */
internal fun Px.drawLook(
    px: Float, py: Float, lk: Look, fx: Float, fy: Float, step: Int, lift: Int, keeperDive: Boolean = false
) {
    val cx = (px * 2f).roundToInt()
    val base = (py * 2f).roundToInt() - lift * 2
    val side = abs(fy) <= abs(fx) + 0.05f
    val back = !side && fy < 0f
    val sg = if (side && fx < 0f) -1 else 1
    fun box(dx: Int, y: Int, w: Int, hh: Int, c: Color) = h(if (sg > 0) cx + dx else cx - dx - w, base + y, w, hh, c)

    val lo = if (step == 1) 2 else 0
    val ro = if (step == 2) 2 else 0
    val shoe = Color(0xFFF2F2F2)
    val sole = Color(0xFF30303A)

    // jambes + chaussures
    if (!side) {
        box(-4, -9, 3, 7 - lo, lk.sock); box(1, -9, 3, 7 - ro, lk.sock)
        box(-5, -2 - lo, 4, 2, shoe); box(1, -2 - ro, 4, 2, shoe)
        box(-5, -1 - lo, 4, 1, sole); box(1, -1 - ro, 4, 1, sole)
    } else {
        val a = if (step == 1) -4 else if (step == 2) 1 else -2
        val b = if (step == 1) 1 else if (step == 2) -4 else -1
        box(a, -9, 3, 7, lk.sock); box(b, -9, 3, 7, lk.sock)
        box(a, -2, 4, 2, shoe); box(b, -2, 4, 2, shoe)
        box(a, -1, 4, 1, sole); box(b, -1, 4, 1, sole)
    }

    // cheveux placés derrière la tête
    when (lk.hairStyle) {
        1 -> if (!side) { box(-5, -33, 2, 9, lk.hair); box(3, -33, 2, 9, lk.hair) } else box(-5, -33, 3, 9, lk.hair)
        3 -> if (!side) box(4, -34, 2, 7, lk.hair) else box(-7, -34, 3, 7, lk.hair)
        5 -> box(-7, -41, 14, 11, lk.hair)
    }

    // short + maillot
    val wS = if (side) 8 else 12
    val left = -wS / 2
    box(if (side) -4 else -5, -14, if (side) 8 else 10, 6, lk.shorts)
    box(left, -25, wS, 11, lk.jersey)
    box(left, -25, 1, 11, lk.jerseyDark); box(left + wS - 1, -25, 1, 11, lk.jerseyDark)
    box(left, -15, wS, 1, lk.jerseyDark)
    when (lk.pattern) {
        1 -> { var x = left + 2; while (x < left + wS - 1) { box(x, -25, 2, 11, lk.stripe); x += 4 } }
        2 -> box(left, -21, wS, 3, lk.stripe)
        3 -> box(left, -25, wS / 2, 11, lk.stripe)
        4 -> for (yy in 0 until 5) for (xx in 0 until wS / 2) if ((xx + yy) % 2 == 0) box(left + xx * 2, -25 + yy * 2, 2, 2, lk.stripe)
    }
    if (back) drawNumber(lk.number, cx, base - 22, if (lum(lk.jersey) > 0.6f) Ink else Color.White)
    else if (!side) box(-1, -24, 2, 1, lk.jerseyDark) // col

    // bras
    if (!side) {
        val la = if (step == 1) 2 else 0
        val ra = if (step == 2) 2 else 0
        box(-8, -24 + la, 2, 6, lk.sleeve); box(-8, -18 + la, 2, 2, lk.skin)
        box(6, -24 + ra, 2, 6, lk.sleeve); box(6, -18 + ra, 2, 2, lk.skin)
        if (keeperDive) { box(-10, -30, 2, 6, lk.sleeve); box(8, -30, 2, 6, lk.sleeve) }
        if (lk.accessory == 3) box(-8, -22 + la, 2, 2, Color(0xFFFFD24A))
    } else {
        val sw = if (step == 1) -2 else if (step == 2) 2 else 0
        box(-1 + sw, -24, 2, 6, lk.sleeve); box(-1 + sw, -18, 2, 2, lk.skin)
        if (lk.accessory == 3) box(-1 + sw, -22, 2, 2, Color(0xFFFFD24A))
    }

    // tête
    box(-4, -34, 8, 9, lk.skin)
    if (!side) { box(-5, -31, 1, 3, lk.skinSh); box(4, -31, 1, 3, lk.skinSh) } else box(4, -30, 1, 2, lk.skinSh)

    // cheveux devant / dessus
    if (back) {
        box(-4, -35, 8, 9, lk.hair); box(-2, -34, 3, 1, lk.hairHi)
    } else {
        when (lk.hairStyle) {
            2 -> box(-2, -35, 2, 1, lk.skinSh)
            4 -> { box(-1, -40, 2, 6, lk.hair); box(-4, -35, 8, 1, lk.hair) }
            else -> {
                if (!side) {
                    box(-5, -36, 10, 3, lk.hair); box(-5, -34, 2, 3, lk.hair); box(3, -34, 2, 3, lk.hair)
                } else {
                    box(-5, -36, 9, 3, lk.hair); box(-5, -34, 3, 5, lk.hair)
                }
                box(-2, -36, 3, 1, lk.hairHi)
            }
        }
        // visage
        if (!side) {
            box(-3, -30, 2, 2, Ink); box(1, -30, 2, 2, Ink); box(-1, -27, 2, 1, Color(0xFF9A4A3A))
        } else {
            box(1, -30, 2, 2, Ink); box(2, -27, 2, 1, Color(0xFF9A4A3A))
        }
    }

    // accessoires
    when (lk.accessory) {
        1 -> box(-5, -34, 10, 2, lk.stripe)
        2 -> if (!back) {
            if (!side) { box(-4, -31, 8, 2, Ink); box(-3, -31, 2, 1, Color(0xFF7FD6FF)); box(1, -31, 2, 1, Color(0xFF7FD6FF)) }
            else { box(0, -31, 5, 2, Ink); box(1, -31, 2, 1, Color(0xFF7FD6FF)) }
        }
        4 -> {
            box(-5, -37, 10, 3, lk.jersey); box(-5, -35, 10, 1, lk.jerseyDark)
            if (side) box(4, -35, 4, 1, lk.jerseyDark)
        }
        5 -> {
            val g = Color(0xFFFFD24A)
            box(-4, -40, 8, 3, g); box(-4, -42, 2, 2, g); box(-1, -43, 2, 3, g); box(2, -42, 2, 2, g)
            box(-1, -39, 2, 1, Color(0xFFFF4A6A))
        }
    }
}

internal fun Px.drawPlayerHi(m: Match, p: Player, tick: Int, isCtrl: Boolean, skin: Skin) {
    val lk = lookOf(m, p, skin)
    val px = p.x.roundToInt()
    val py = p.y.roundToInt()
    r(px - 5, py - 1, 10, 3, Color.Black.copy(alpha = 0.28f))
    if (isCtrl) {
        val ringCol = Gold.copy(alpha = 0.9f)
        r(px - 6, py, 12, 1, ringCol)
        r(px - 5, py + 1, 10, 1, ringCol)
        r(px - 5, py - 1, 1, 1, ringCol); r(px + 4, py - 1, 1, 1, ringCol)
    }
    val lift = if (p.jumpT > 0f) (sin(min(1f, p.jumpT / 0.45f) * 3.14159f) * 7f).roundToInt() else 0
    val step = if (p.runT > 0f) 1 + (p.runT.toInt() and 1) else 0
    val keeper = m.sport == Sport.FOOT && p.slot == 0
    val sliding = p.tackT > 0f
    var dvy = 0
    if (keeper && p.diveT > 0f) {
        val k = sin(min(1f, p.diveT / 0.45f) * 3.14159f)
        dvy = (p.diveDir * k * 7f).roundToInt()
    }
    val oy = dvy + (if (sliding) 4 else 0)
    drawLook(p.x, p.y + oy, lk, p.fx, p.fy, step, lift, keeper && p.diveT > 0f)
    if (sliding) {
        val ddx = -(p.tdx * 7f).roundToInt()
        val ddy = -(p.tdy * 5f).roundToInt()
        r(px + ddx - 2, py + ddy - 2, 3, 2, Color(0xAAE8D9B0))
        r(px + ddx * 2 - 1, py + ddy * 2 - 1, 2, 2, Color(0x88E8D9B0))
    }
    if (p.actT > 0f) {
        r(px + (p.fx * 9f).roundToInt() - 1, py - 7 + (p.fy * 6f).roundToInt() - lift, 3, 3, Color.White.copy(alpha = 0.75f))
    }
    if (isCtrl) drawMarker(px, py - 24 - lift - (if (lk.accessory == 5) 3 else 0), tick, skin.marker)
}

/** Marqueur au-dessus du joueur piloté (cosmétique). */
internal fun Px.drawMarker(px: Int, y: Int, tick: Int, type: Int) {
    val bob = if ((tick / 10) % 2 == 0) 0 else 1
    val cx = px * 2
    val by = (y + bob) * 2
    val col = when (type) {
        1 -> Color(0xFF35F0FF); 2 -> Color(0xFFFF5FB0); 3 -> Color(0xFF7FE8FF); 4 -> Color(0xFFFFE04A)
        5 -> Color(0xFFFFD24A); else -> Gold
    }
    when (type) {
        3 -> { h(cx - 1, by, 2, 2, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 1, by + 4, 2, 2, col) }
        4 -> { h(cx - 1, by, 2, 6, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 2, by + 1, 4, 4, col.copy(alpha = 0.6f)) }
        5 -> { h(cx - 4, by + 2, 8, 3, col); h(cx - 4, by, 2, 2, col); h(cx - 1, by - 1, 2, 3, col); h(cx + 2, by, 2, 2, col) }
        else -> { h(cx - 4, by, 8, 2, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 1, by + 4, 2, 2, col); h(cx - 2, by + 2, 4, 1, Color.White.copy(alpha = 0.4f)) }
    }
}

private fun hash(i: Int, j: Int, s: Int): Int = lcg(i * 73856093 xor j * 19349663 xor s * 83492791)

private fun ballColor(sport: Sport, skinIdx: Int, i: Int, j: Int, spin: Float): Color {
    val dx = i - 6.5f
    val dy = j - 6.5f
    val t = (dx + dy) / 13.6f // -0.5 (clair) .. +0.5 (ombre)
    val shade = when { t > 0.28f -> 2; t > -0.05f -> 1; else -> 0 }
    val skinOpt = Cosmetics.balls[skinIdx]
    val a = spin * 0.5f
    val ph = floor(abs(spin)).toInt() and 3
    // motif : true = zone d'accent (taches, bandes, coutures)
    val accent: Boolean = when (sport) {
        Sport.FOOT -> (0 until 3).any { k ->
            val ang = a + k * 2.0944f
            val cx = 6.5f + cos(ang) * 3.6f
            val cy = 6.5f + sin(ang) * 3.6f
            (i - cx) * (i - cx) + (j - cy) * (j - cy) < 3.4f
        } || (dx * dx + dy * dy < 2.2f && (ph and 1) == 0)
        Sport.VOLLEY -> ((j + (a * 2f).toInt() + 40) / 3) % 3 == 1
        Sport.BASKET -> (i == 6 || i == 7 || j == 6 || j == 7) || (((ph and 1) == 0) && abs(i - j) <= 0) || (((ph and 1) == 1) && abs(i + j - 13) <= 0)
    }
    if (skinIdx == 0) {
        return when (sport) {
            Sport.FOOT -> if (accent) Color(0xFF1B1B22) else listOf(Color(0xFFFFFFFF), Color(0xFFE4E7EE), Color(0xFFB9BFCC))[shade]
            Sport.VOLLEY -> {
                val band = ((j + (a * 2f).toInt() + 40) / 3) % 3
                when (band) {
                    1 -> listOf(Color(0xFFFFDC4A), Color(0xFFF2C230), Color(0xFFC49A1A))[shade]
                    2 -> listOf(Color(0xFF5A8CFF), Color(0xFF2F6BFF), Color(0xFF1E4ACF))[shade]
                    else -> listOf(Color(0xFFFFFFFF), Color(0xFFE4E7EE), Color(0xFFB9BFCC))[shade]
                }
            }
            Sport.BASKET -> if (accent) Color(0xFF3B1E0C) else listOf(Color(0xFFFF9140), Color(0xFFEE7A1F), Color(0xFFC95E10))[shade]
        }
    }
    if (skinIdx == 5) { // arc-en-ciel
        val hue = ((i + j) * 14f + spin * 25f) % 360f
        return Color.hsv(if (hue < 0) hue + 360f else hue, if (shade == 2) 0.9f else 0.7f, if (shade == 2) 0.75f else 1f)
    }
    val b = Color(skinOpt.color)
    val c = Color(skinOpt.color2)
    if (skinIdx == 3 && hash(i, j, 3) % 6 == 0) return c // galaxie : étoiles
    val lit = when (shade) { 0 -> 1.15f; 1 -> 1f; else -> 0.72f }
    val base = if (accent) c else b
    return Color(min(1f, base.red * lit), min(1f, base.green * lit), min(1f, base.blue * lit), 1f)
}

internal fun Px.drawBallHi(m: Match, skin: Skin) {
    val bz = m.bz
    val shw = max(6, 14 - (bz / 5f).toInt())
    val cx = (m.bx * 2f).roundToInt()
    r(cx / 2f - shw / 4f, m.by + 1f, shw / 2f, 1.5f, Color.Black.copy(alpha = 0.3f))
    val x0 = cx - 7
    val y0 = ((m.by - bz * 0.6f) * 2f).roundToInt() - 7
    for (j in 0 until 14) {
        for (i in 0 until 14) {
            val dx = i - 6.5f
            val dy = j - 6.5f
            if (dx * dx + dy * dy > 45f) continue
            val edge = dx * dx + dy * dy > 36f
            val c = ballColor(m.sport, skin.ball, i, j, m.ballSpin)
            h(x0 + i, y0 + j, 1, 1, if (edge) Color(c.red * 0.7f, c.green * 0.7f, c.blue * 0.7f, 1f) else c)
        }
    }
}

internal fun Px.drawTrail(m: Match, skin: Skin) {
    if (skin.trail == 0 || m.phase != Phase.PLAY) return
    for (i in 2 until m.trailX.size) {
        val tx = m.trailX[i]
        val ty = m.trailY[i] - m.trailZ[i] * 0.6f
        if (tx == 0f && ty == 0f) continue
        val d = abs(tx - m.bx) + abs(ty - (m.by - m.bz * 0.6f))
        if (d < 3f || d > 90f) continue
        val f = 1f - i / m.trailX.size.toFloat()
        val sz = max(2, (9 * f).roundToInt())
        val x = (tx * 2f).roundToInt()
        val y = (ty * 2f).roundToInt()
        when (skin.trail) {
            1 -> h(x - sz / 2, y - sz / 2, sz, sz, Color.White.copy(alpha = 0.55f * f))
            2 -> {
                val c = if (i % 2 == 0) Color(0xFFFFE04A) else Color.White
                h(x + ((hash(i, 1, tick(m)) % 9) - 4), y + ((hash(i, 2, tick(m)) % 9) - 4), 2, 2, c.copy(alpha = f))
            }
            3 -> h(x - sz / 2, y - sz / 2, sz, sz, Color(1f, 0.25f + 0.55f * f, 0.05f, 0.85f * f))
            else -> h(x - sz / 2, y - sz / 2, sz, sz, Color.hsv((i * 32f) % 360f, 0.85f, 1f).copy(alpha = 0.85f * f))
        }
    }
}

private fun tick(m: Match) = (m.simTime * 30f).toInt()

internal fun Px.drawConfetti(m: Match) {
    if (m.phase != Phase.SCORED) return
    val age = m.scoredAge
    val cols = listOf(0xFFFFC83D, 0xFF3DDC84, 0xFF2F6BFF, 0xFFFF5A4A, 0xFFFF5FB0, 0xFFFFFFFF)
    for (i in 0 until 46) {
        val hh = hash(i, 7, 5)
        val x = (hh % 320) + sin(age * 3f + i) * 6f
        val y = -8f + age * (50f + (hh / 7) % 70) - ((hh / 13) % 30)
        if (y < 0f || y > 180f) continue
        h((x * 2f).roundToInt(), (y * 2f).roundToInt(), 3, 3, Color(cols[hh % cols.size]))
    }
}

/** Repère au sol de l'endroit où le ballon va tomber (volley). */
internal fun Px.drawLanding(m: Match, tick: Int) {
    if (m.sport != Sport.VOLLEY || m.phase != Phase.PLAY || m.serveHeld() || m.bz < 4f) return
    val l = m.landing()
    if (l[0] < Court.VX0 - 10f || l[0] > Court.NET_X + 2f) return
    val pulse = 5f + (tick / 6 % 3)
    ring(l[0], l[1], pulse, Color(0xCCFFFFFF))
    ring(l[0], l[1], pulse - 2f, Color(0x88FFC83D))
    h((l[0] * 2f).roundToInt() - 1, (l[1] * 2f).roundToInt() - 1, 2, 2, Color(0xFFFFC83D))
}

/** Ballon dessiné seul (aperçu du skin) : (cx, cy) = centre en unités du terrain. */
internal fun Px.drawBallRaw(cx: Float, cy: Float, sport: Sport, skinIdx: Int, spin: Float) {
    val x0 = (cx * 2f).roundToInt() - 7
    val y0 = (cy * 2f).roundToInt() - 7
    for (j in 0 until 14) for (i in 0 until 14) {
        val dx = i - 6.5f
        val dy = j - 6.5f
        if (dx * dx + dy * dy > 45f) continue
        val c = ballColor(sport, skinIdx, i, j, spin)
        h(x0 + i, y0 + j, 1, 1, if (dx * dx + dy * dy > 36f) Color(c.red * 0.7f, c.green * 0.7f, c.blue * 0.7f, 1f) else c)
    }
}

/** Aperçu de la traînée : le ballon va vers la droite. */
internal fun Px.drawTrailPreview(cx: Float, cy: Float, trail: Int, tick: Int) {
    if (trail == 0) return
    for (i in 2 until 12) {
        val f = 1f - i / 12f
        val sz = max(2, (9 * f).roundToInt())
        val x = ((cx - i * 2.2f) * 2f).roundToInt()
        val y = (cy * 2f).roundToInt()
        when (trail) {
            1 -> h(x - sz / 2, y - sz / 2, sz, sz, Color.White.copy(alpha = 0.55f * f))
            2 -> h(x + ((hash(i, 1, tick / 4) % 7) - 3), y + ((hash(i, 2, tick / 4) % 9) - 4), 2, 2,
                (if (i % 2 == 0) Color(0xFFFFE04A) else Color.White).copy(alpha = f))
            3 -> h(x - sz / 2, y - sz / 2, sz, sz, Color(1f, 0.25f + 0.55f * f, 0.05f, 0.85f * f))
            else -> h(x - sz / 2, y - sz / 2, sz, sz, Color.hsv((i * 32f) % 360f, 0.85f, 1f).copy(alpha = 0.85f * f))
        }
    }
}
