# Nexus Games (v0.2)

Bibliothèque de jeux pour Android + bouton flottant Nexus.

## Nouveautés v0.2
- Quand tu lances un jeu depuis la bibliothèque, une bulle « N » flotte par-dessus.
- Touche la bulle : le panneau Nexus s'ouvre (même look que assistant_ia.py : en-tête NEXUS OS, heure/date, bulle de discussion, boutons rapides, barre de saisie).
- 📸 / ➤ : capture de l'écran, puis envoi de l'image + ta question à l'appli ChatGPT.
- Réglages : l'interrupteur « Bouton flottant Nexus dans les jeux » l'active ou le coupe.

## Premier lancement
1. Android demande « Afficher par-dessus les autres applis » : autorise Nexus Games.
2. À chaque capture, Android affiche sa fenêtre « Commencer l'enregistrement ou la diffusion ? » : appuie sur Commencer.

## Mise à jour
Cette version est signée avec une clé fixe : les prochaines versions s'installent par-dessus sans rien désinstaller.
(La v1 avait une autre clé : désinstalle-la une fois avant d'installer la v2.)
