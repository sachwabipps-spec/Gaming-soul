package com.nexus.gamelibrary

import android.content.Context

/** Sauvegarde locale des réglages (thème, colonnes, jeux ajoutés/retirés, derniers lancés). */
class Store(context: Context) {
    private val sp = context.getSharedPreferences("nexus_games", Context.MODE_PRIVATE)

    var themeIndex: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    var columns: Int
        get() = sp.getInt("columns", 3)
        set(v) = sp.edit().putInt("columns", v).apply()

    var sortRecent: Boolean
        get() = sp.getBoolean("sortRecent", true)
        set(v) = sp.edit().putBoolean("sortRecent", v).apply()

    /** Bouton flottant Nexus affiché au lancement d'un jeu. */
    var assistant: Boolean
        get() = sp.getBoolean("assistant", true)
        set(v) = sp.edit().putBoolean("assistant", v).apply()

    /** Applis ajoutées à la main à la bibliothèque. */
    var pinned: Set<String>
        get() = HashSet(sp.getStringSet("pinned", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("pinned", HashSet(v)).apply()

    /** Jeux retirés de la bibliothèque. */
    var hidden: Set<String>
        get() = HashSet(sp.getStringSet("hidden", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("hidden", HashSet(v)).apply()

    fun lastLaunch(pkg: String): Long = sp.getLong("last_$pkg", 0L)

    fun markLaunched(pkg: String) {
        sp.edit().putLong("last_$pkg", System.currentTimeMillis()).apply()
    }
}
