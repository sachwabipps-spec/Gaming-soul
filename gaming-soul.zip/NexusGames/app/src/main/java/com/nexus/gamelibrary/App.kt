package com.nexus.gamelibrary

import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NexusGamesApp(resume: Int, onLaunch: (String, String) -> Unit) {
    val context = LocalContext.current
    val store = remember { Store(context) }

    var themeIndex by remember { mutableIntStateOf(store.themeIndex.coerceIn(0, themes.lastIndex)) }
    var columns by remember { mutableIntStateOf(store.columns.coerceIn(2, 5)) }
    var sortRecent by remember { mutableStateOf(store.sortRecent) }
    var assistant by remember { mutableStateOf(store.assistant) }
    var pinned by remember { mutableStateOf(store.pinned) }
    var hidden by remember { mutableStateOf(store.hidden) }
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var menuFor by remember { mutableStateOf<AppEntry?>(null) }
    val theme = themes[themeIndex]

    // Icônes de la barre d'état lisibles selon le thème
    (context as? ComponentActivity)?.let { act ->
        SideEffect {
            WindowCompat.getInsetsController(act.window, act.window.decorView).isAppearanceLightStatusBars = theme.light
        }
    }

    LaunchedEffect(resume) {
        apps = withContext(Dispatchers.Default) { loadApps(context) }
    }

    fun inLibrary(a: AppEntry) = (a.autoGame || a.packageName in pinned) && a.packageName !in hidden

    fun setInLibrary(pkg: String, on: Boolean) {
        pinned = if (on) pinned + pkg else pinned - pkg
        hidden = if (on) hidden - pkg else hidden + pkg
        store.pinned = pinned
        store.hidden = hidden
    }

    val library = remember(apps, pinned, hidden, sortRecent, resume) {
        val list = apps.filter { inLibrary(it) }
        if (sortRecent) list.sortedByDescending { store.lastLaunch(it.packageName) } else list
    }

    MaterialTheme(
        colorScheme = if (theme.light) lightColorScheme(primary = theme.accent)
        else darkColorScheme(primary = theme.accent)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(theme.bgTop, theme.bgBottom)))
        ) {
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = {
                    NavigationBar(containerColor = theme.tile) {
                        listOf(
                            "Jeux" to Icons.Filled.SportsEsports,
                            "Applis" to Icons.Filled.Apps,
                            "Réglages" to Icons.Filled.Palette
                        ).forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = theme.accent,
                                    selectedIconColor = if (theme.light) Color.White else Color.Black,
                                    selectedTextColor = theme.onBg,
                                    unselectedIconColor = theme.onBg.copy(alpha = 0.7f),
                                    unselectedTextColor = theme.onBg.copy(alpha = 0.7f)
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                Column(
                    Modifier
                        .padding(padding)
                        .fillMaxSize()
                ) {
                    when (tab) {
                        0 -> {
                            Text(
                                "Ma bibliothèque · ${library.size}",
                                color = theme.onBg,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(16.dp)
                            )
                            if (library.isEmpty()) {
                                Text(
                                    "Aucun jeu détecté. Va dans l'onglet Applis pour en ajouter.",
                                    color = theme.onBg.copy(alpha = 0.7f),
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(columns),
                                contentPadding = PaddingValues(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(library, key = { it.packageName }) { app ->
                                    Tile(
                                        app = app,
                                        theme = theme,
                                        onClick = { onLaunch(app.packageName, app.label) },
                                        onLongClick = { menuFor = app }
                                    )
                                }
                            }
                        }

                        1 -> LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                            item {
                                Text(
                                    "Toutes les applis",
                                    color = theme.onBg,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Active l'interrupteur pour mettre une appli dans ta bibliothèque.",
                                    color = theme.onBg.copy(alpha = 0.7f),
                                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                                )
                            }
                            items(apps, key = { it.packageName }) { a ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Image(
                                        bitmap = a.icon,
                                        contentDescription = a.label,
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Text(
                                        a.label,
                                        color = theme.onBg,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = inLibrary(a),
                                        onCheckedChange = { setInLibrary(a.packageName, it) },
                                        colors = SwitchDefaults.colors(checkedTrackColor = theme.accent)
                                    )
                                }
                            }
                        }

                        else -> LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Text(
                                    "Personnalisation",
                                    color = theme.onBg,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            items(themes.size) { i ->
                                ThemeCard(themes[i], selected = i == themeIndex) {
                                    themeIndex = i
                                    store.themeIndex = i
                                }
                            }
                            item {
                                Text("Colonnes : $columns", color = theme.onBg)
                                Slider(
                                    value = columns.toFloat(),
                                    onValueChange = {
                                        columns = it.roundToInt()
                                        store.columns = columns
                                    },
                                    valueRange = 2f..5f,
                                    steps = 2,
                                    colors = SliderDefaults.colors(
                                        thumbColor = theme.accent,
                                        activeTrackColor = theme.accent
                                    )
                                )
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Bouton flottant Nexus dans les jeux",
                                        color = theme.onBg,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = assistant,
                                        onCheckedChange = {
                                            assistant = it
                                            store.assistant = it
                                        },
                                        colors = SwitchDefaults.colors(checkedTrackColor = theme.accent)
                                    )
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Derniers lancés en premier",
                                        color = theme.onBg,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = sortRecent,
                                        onCheckedChange = {
                                            sortRecent = it
                                            store.sortRecent = it
                                        },
                                        colors = SwitchDefaults.colors(checkedTrackColor = theme.accent)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        menuFor?.let { app ->
            AlertDialog(
                onDismissRequest = { menuFor = null },
                title = { Text(app.label) },
                text = { Text("Retirer de la bibliothèque ?") },
                confirmButton = {
                    TextButton(onClick = {
                        setInLibrary(app.packageName, false)
                        menuFor = null
                    }) { Text("Retirer") }
                },
                dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Annuler") } }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Tile(app: AppEntry, theme: GameTheme, onClick: () -> Unit, onLongClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(theme.tile)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.height(8.dp))
        Text(
            app.label,
            color = theme.onBg,
            fontSize = 12.sp,
            minLines = 2,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ThemeCard(t: GameTheme, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(t.bgTop, t.tile)))
            .then(if (selected) Modifier.border(3.dp, t.accent, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(t.accent)
        )
        Spacer(Modifier.width(12.dp))
        Text(t.name, color = t.onBg, fontWeight = FontWeight.Medium)
    }
}
