package com.nexus.gamelibrary

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap,
    /** Android a classé cette appli comme "jeu" (selon les infos du Play Store). */
    val autoGame: Boolean
)

/** Liste toutes les applis lançables du téléphone (sauf celle-ci). À appeler hors du thread principal. */
fun loadApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { it.activityInfo.applicationInfo }
        .distinctBy { it.packageName }
        .filter { it.packageName != context.packageName }
        .map { ai ->
            AppEntry(
                label = pm.getApplicationLabel(ai).toString(),
                packageName = ai.packageName,
                icon = pm.getApplicationIcon(ai).toBitmap(128, 128).asImageBitmap(),
                autoGame = ai.category == ApplicationInfo.CATEGORY_GAME
            )
        }
        .sortedBy { it.label.lowercase() }
}
