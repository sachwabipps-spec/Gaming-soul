package com.nexus.gamelibrary

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ════════════════════════════════════════════════════════════════
//  Navigation Arcade : hub → menu du mode → carrière / match rapide / tutoriel / style
// ════════════════════════════════════════════════════════════════

@Composable
fun ArcadeScreen(theme: GameTheme, store: Store, version: Int, onPlay: (Level) -> Unit) {
    var page by remember { mutableStateOf("hub") }
    var sport by remember { mutableStateOf(Sport.FOOT) }
    var tutoSport by remember { mutableStateOf<Sport?>(null) }
    var resetTick by remember { mutableIntStateOf(0) }
    val stack = remember { mutableStateListOf<String>() }
    val st = remember(version, resetTick) { store.arcadeStars() }

    fun go(p: String) { stack.add(page); page = p }
    fun back() { page = if (stack.isEmpty()) "hub" else stack.removeAt(stack.lastIndex) }
    if (page != "hub") BackHandler { back() }

    when (page) {
        "hub" -> Hub(
            theme, st,
            onPick = {
                sport = it
                go("mode")
                if (!store.tutoSeen(it.name)) {
                    store.setTutoSeen(it.name)
                    tutoSport = it
                    go("tuto")
                }
            },
            onSkin = { go("skin") },
            onTuto = { tutoSport = null; go("tuto") }
        )
        "mode" -> ModeMenu(
            theme, sport, st, ::back,
            onCareer = { go("career") }, onQuick = { go("quick") },
            onTuto = { tutoSport = sport; go("tuto") }, onSkin = { go("skin") },
            onReset = { store.resetArcade(sport); resetTick++ }
        )
        "career" -> CareerList(theme, sport, st, ::back, onPlay)
        "quick" -> QuickMatch(theme, sport, ::back, onPlay)
        "skin" -> SkinEditor(theme, store, st.sum(), sport, ::back)
        "tuto" -> Tutorial(theme, tutoSport, ::back)
    }
}

@Composable
private fun Back(theme: GameTheme, label: String, onBack: () -> Unit) {
    TextButton(onClick = onBack) { Text("‹ $label", color = theme.accent, fontSize = 16.sp) }
}

@Composable
private fun Tile(theme: GameTheme, icon: String, title: String, sub: String, onClick: () -> Unit) {
    GlassCard(theme, Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 36.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(sub, color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp)
            }
            Text("›", color = theme.onBg.copy(alpha = 0.6f), fontSize = 28.sp)
        }
    }
}

@Composable
private fun Hub(theme: GameTheme, st: IntArray, onPick: (Sport) -> Unit, onSkin: () -> Unit, onTuto: () -> Unit) {
    val total = st.sum()
    val next = Cosmetics.nextUnlock(total)
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Arcade", color = theme.onBg, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text(
                "Foot, volley et basket en équipe avec des bots. Gagne des étoiles pour débloquer des cosmétiques. 100 % hors ligne.",
                color = theme.onBg.copy(alpha = 0.7f), modifier = Modifier.padding(top = 4.dp)
            )
        }
        item {
            GlassCard(theme) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⭐", fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("$total / ${st.size * 3} étoiles", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "Cosmétiques : ${Cosmetics.unlockedCount(total)} / ${Cosmetics.totalCount} débloqués" +
                                (if (next != null) " · prochain : ${next.name} à ${next.stars}★" else ""),
                            color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp
                        )
                    }
                }
            }
        }
        items(Sport.values().size) { k ->
            val sport = Sport.values()[k]
            val lvls = Career.of(sport)
            val t = lvls.sumOf { st[it.index] }
            Tile(theme, sport.icon, sport.label, "${sport.blurb}\n$t / ${lvls.size * 3} ★") { onPick(sport) }
        }
        item { Tile(theme, "👕", "Mon style", "Skin, maillot, ballon, marqueur, traînée") { onSkin() } }
        item { Tile(theme, "📖", "Tutoriel", "Commandes, étoiles et astuces") { onTuto() } }
    }
}

@Composable
private fun ModeMenu(
    theme: GameTheme, sport: Sport, st: IntArray, onBack: () -> Unit,
    onCareer: () -> Unit, onQuick: () -> Unit, onTuto: () -> Unit, onSkin: () -> Unit, onReset: () -> Unit
) {
    var confirm by remember { mutableStateOf(false) }
    val lvls = Career.of(sport)
    val total = lvls.sumOf { st[it.index] }
    val done = lvls.count { st[it.index] > 0 }
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Back(theme, "Arcade", onBack)
            Text("${sport.icon} ${sport.label}", color = theme.onBg, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(sport.blurb, color = theme.onBg.copy(alpha = 0.7f), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        }
        item { Tile(theme, "🏆", "Carrière", "$done / ${lvls.size} matchs gagnés · $total / ${lvls.size * 3} ★", onCareer) }
        item { Tile(theme, "⚡", "Match rapide", "Choisis la difficulté et la durée · entraînement avec conseils", onQuick) }
        item { Tile(theme, "📖", "Tutoriel ${sport.label}", "Apprends les commandes en quelques pages", onTuto) }
        item { Tile(theme, "👕", "Mon style", "Personnalise ton joueur et ton ballon", onSkin) }
        item {
            TextButton(onClick = { confirm = true }) {
                Text("Réinitialiser la carrière ${sport.label}", color = theme.onBg.copy(alpha = 0.6f))
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Réinitialiser ?") },
            text = { Text("Les étoiles de la carrière ${sport.label} seront effacées. Des cosmétiques pourront se reverrouiller.") },
            confirmButton = { TextButton(onClick = { onReset(); confirm = false }) { Text("Effacer") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun CareerList(theme: GameTheme, sport: Sport, st: IntArray, onBack: () -> Unit, onPlay: (Level) -> Unit) {
    val lvls = Career.of(sport)
    val total = lvls.sumOf { st[it.index] }
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Back(theme, sport.label, onBack)
            Text("🏆 Carrière ${sport.label}", color = theme.onBg, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("$total / ${lvls.size * 3} étoiles", color = theme.accent, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
        }
        Career.divisions.forEachIndexed { d, name ->
            item {
                Text("Division ${d + 1} · $name", color = theme.accent, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
            }
            val inDiv = lvls.filter { it.division == d }
            items(inDiv.size) { k ->
                val lv = inDiv[k]
                val unlocked = lv.number == 1 || st[lv.index - 1] >= 1
                val shape = RoundedCornerShape(20.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(theme.tile)
                        .border(1.dp, theme.onBg.copy(alpha = 0.08f), shape)
                        .then(if (unlocked) Modifier.clickable { onPlay(lv) } else Modifier)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (unlocked) sport.icon else "🔒", fontSize = 30.sp, modifier = Modifier.width(44.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Match ${lv.number} · vs ${lv.opponent}", color = theme.onBg.copy(alpha = if (unlocked) 1f else 0.45f), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(lv.rule, color = theme.onBg.copy(alpha = if (unlocked) 0.7f else 0.35f), fontSize = 13.sp)
                    }
                    Text(stars(st[lv.index]), color = if (st[lv.index] > 0) Gold else theme.onBg.copy(alpha = 0.3f), fontSize = 20.sp)
                }
            }
        }
        item {
            Text("Étoiles : 1 = victoire · 2 = victoire nette · 3 = victoire écrasante. Chaque étoile rapproche d'un cosmétique.", color = theme.onBg.copy(alpha = 0.55f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun Chip(theme: GameTheme, text: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) theme.accent else theme.onBg.copy(alpha = 0.10f))
            .border(1.dp, if (selected) theme.accent else theme.onBg.copy(alpha = 0.15f), shape)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Text(
            text,
            color = if (selected) Color.White else theme.onBg.copy(alpha = if (enabled) 1f else 0.4f),
            fontWeight = FontWeight.Bold, fontSize = 14.sp
        )
    }
}

@Composable
private fun QuickMatch(theme: GameTheme, sport: Sport, onBack: () -> Unit, onPlay: (Level) -> Unit) {
    var diff by remember { mutableIntStateOf(2) }
    var len by remember { mutableIntStateOf(1) }
    val lv = Career.quick(sport, diff, len)
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Back(theme, sport.label, onBack)
        Text("⚡ Match rapide · ${sport.label}", color = theme.onBg, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Difficulté", color = theme.accent, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Career.quickDifficulties.forEachIndexed { i, n -> Chip(theme, n, diff == i) { diff = i } }
        }
        if (diff != 0) {
            Text("Durée", color = theme.accent, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Career.quickLengths.forEachIndexed { i, n -> Chip(theme, n, len == i) { len = i } }
            }
        }
        GlassCard(theme) {
            Text("vs ${lv.opponent}", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(
                if (lv.training) "Entraînement libre : adversaire très faible, conseils à l'écran, aucune étoile."
                else lv.rule + " · pas d'étoiles en match rapide",
                color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp
            )
        }
        ActionButton("Jouer", theme, Modifier.fillMaxWidth()) { onPlay(lv) }
    }
}

// ════════════════════════════════════════════════════════════════
//  Mon style : skin + cosmétiques débloqués avec les étoiles
// ════════════════════════════════════════════════════════════════

@Composable
private fun OptRow(
    theme: GameTheme, title: String, opts: List<Opt>, selected: Int, stars: Int, swatch: Boolean, onPick: (Int) -> Unit
) {
    Column {
        Text(title, color = theme.accent, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            opts.forEachIndexed { i, o ->
                val ok = o.stars <= stars
                val shape = RoundedCornerShape(14.dp)
                Row(
                    Modifier
                        .clip(shape)
                        .background(if (i == selected) theme.accent.copy(alpha = 0.9f) else theme.onBg.copy(alpha = 0.10f))
                        .border(1.dp, theme.onBg.copy(alpha = 0.15f), shape)
                        .then(if (ok) Modifier.clickable { onPick(i) } else Modifier)
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (swatch && o.color != 0L) {
                        Box(Modifier.size(16.dp).clip(CircleShape).background(Color(o.color)).border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape))
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        if (ok) o.name else "🔒 ${o.name} · ${o.stars}★",
                        color = if (i == selected) Color.White else theme.onBg.copy(alpha = if (ok) 1f else 0.45f),
                        fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SkinEditor(theme: GameTheme, store: Store, stars: Int, sport: Sport, onBack: () -> Unit) {
    var skin by remember { mutableStateOf(store.skin) }
    var tick by remember { mutableIntStateOf(0) }
    fun upd(s: Skin) { skin = s.sanitized(); store.skin = skin }
    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { tick++ }
        }
    }
    val look = skinLook(skin)
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
    ) {
        item {
            Back(theme, "Retour", onBack)
            Text("👕 Mon style", color = theme.onBg, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(
                "⭐ $stars étoiles · ${Cosmetics.unlockedCount(stars)} / ${Cosmetics.totalCount} cosmétiques débloqués. Gagne des étoiles en carrière pour déverrouiller les 🔒.",
                color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF2A8A44))
            ) {
                tick
                val s = size.height / 46f
                val p = Px(this, s, size.width / 2f - 6f * s, size.height * 0.9f)
                for (i in 0 until 8) if (i % 2 == 0) p.r(-30 + i * 8, -20, 8, 40, Color(0x1AFFFFFF))
                val ang = (tick / 70) % 3
                val fx = if (ang == 1) 1f else 0f
                val fy = if (ang == 0) 1f else if (ang == 2) -1f else 0f
                val step = if ((tick / 9) % 4 == 0) 0 else 1 + (tick / 9) % 2
                p.r(-5, -1, 10, 3, Color.Black.copy(alpha = 0.28f))
                p.drawLook(0f, 0f, look, fx, fy, step, 0)
                p.drawMarker(0, -30, tick, skin.marker)
                p.drawTrailPreview(12f, -4f, skin.trail, tick)
                p.drawBallRaw(12f, -4f, sport, skin.ball, tick / 8f)
            }
        }
        item { OptRow(theme, "Coiffure", Cosmetics.hairStyles, skin.hairStyle, stars, false) { upd(skin.copy(hairStyle = it)) } }
        item { OptRow(theme, "Couleur des cheveux", Cosmetics.hairColors, skin.hairColor, stars, true) { upd(skin.copy(hairColor = it)) } }
        item { OptRow(theme, "Peau", Cosmetics.skinTones, skin.skinTone, stars, true) { upd(skin.copy(skinTone = it)) } }
        item { OptRow(theme, "Maillot · couleur", Cosmetics.kitColors, skin.kitColor, stars, true) { upd(skin.copy(kitColor = it)) } }
        item { OptRow(theme, "Maillot · motif", Cosmetics.patterns, skin.kitPattern, stars, false) { upd(skin.copy(kitPattern = it)) } }
        item { OptRow(theme, "Maillot · couleur du motif", Cosmetics.kitColors, skin.kit2Color, stars, true) { upd(skin.copy(kit2Color = it)) } }
        item { OptRow(theme, "Short", Cosmetics.kitColors, skin.shortsColor, stars, true) { upd(skin.copy(shortsColor = it)) } }
        item { OptRow(theme, "Accessoire", Cosmetics.accessories, skin.accessory, stars, false) { upd(skin.copy(accessory = it)) } }
        item {
            Text("Numéro", color = theme.accent, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Chip(theme, "−", false) { upd(skin.copy(number = (skin.number + 99) % 100)) }
                Text("${skin.number}", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 22.sp, textAlign = TextAlign.Center, modifier = Modifier.width(44.dp))
                Chip(theme, "+", false) { upd(skin.copy(number = (skin.number + 1) % 100)) }
            }
        }
        item { OptRow(theme, "Ballon", Cosmetics.balls, skin.ball, stars, true) { upd(skin.copy(ball = it)) } }
        item { OptRow(theme, "Marqueur du joueur piloté", Cosmetics.markers, skin.marker, stars, false) { upd(skin.copy(marker = it)) } }
        item { OptRow(theme, "Traînée du ballon", Cosmetics.trails, skin.trail, stars, false) { upd(skin.copy(trail = it)) } }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

// ════════════════════════════════════════════════════════════════
//  Tutoriel
// ════════════════════════════════════════════════════════════════

private class TutoPage(val emoji: String, val title: String, val lines: List<String>)

private fun tutoPages(sport: Sport?): List<TutoPage> {
    val controls = TutoPage(
        "🎮", "Les commandes",
        listOf(
            "À gauche : le joystick. Glisse ton pouce pour te déplacer.",
            "À droite : les boutons d'action (TIR, PASSE, TACLE, DÉF, FRAPPE selon le sport).",
            "Tu pilotes un joueur marqué d'une flèche. Le jeu change tout seul vers le joueur le plus proche de l'action.",
            "Bouton II en haut à gauche : pause (recommencer, son, quitter)."
        )
    )
    val stars = TutoPage(
        "⭐", "Étoiles et cosmétiques",
        listOf(
            "Chaque victoire en carrière donne 1 étoile, 2 si tu gagnes nettement, 3 si tu écrases l'adversaire.",
            "Le total d'étoiles de tes trois carrières débloque des cosmétiques : coiffures, maillots, ballons, marqueurs, traînées…",
            "Va dans « Mon style » pour tout personnaliser. Les 🔒 indiquent combien d'étoiles il faut.",
            "Les matchs rapides et l'entraînement ne donnent pas d'étoiles."
        )
    )
    return when (sport) {
        null -> listOf(
            TutoPage("🏟️", "Bienvenue en Arcade", listOf(
                "Trois sports en vue du dessus : football 4 contre 4, volley 2 contre 2, basket 3 contre 3.",
                "Chaque sport a son menu : carrière (15 matchs), match rapide, tutoriel et personnalisation.",
                "Tes coéquipiers et tes adversaires sont des bots : tu joues en équipe."
            )), controls, stars
        )
        Sport.FOOT -> listOf(
            controls,
            TutoPage("⚽", "Attaquer", listOf(
                "Approche-toi du ballon : tu le touches en passant dessus puis tu frappes.",
                "TIR : le jeu vise un coin libre du but. Un pointillé doré montre la cible.",
                "PASSE : envoie le ballon au coéquipier le mieux démarqué dans la direction du joystick."
            )),
            TutoPage("🛡️", "Défendre", listOf(
                "TACLE : glissade pour reprendre le ballon. Un tacle raté te laisse au sol un instant.",
                "Ton gardien n'est pas piloté : il se place, plonge et relance tout seul.",
                "Reste démarqué : un joueur seul reçoit plus facilement la passe."
            )),
            TutoPage("🎯", "Entraîne-toi", listOf(
                "Lance « Match rapide → Entraînement » : des conseils s'affichent en haut de l'écran.",
                "Le match se joue contre un adversaire très faible, sans pression."
            )), stars
        )
        Sport.VOLLEY -> listOf(
            controls,
            TutoPage("🏐", "Le service", listOf(
                "Quand c'est à toi de servir, le ballon reste dans ta main : appuie sur FRAPPE.",
                "Si tu attends trop, le service part tout seul (compte à rebours affiché).",
                "Joystick avant de servir : oriente le ballon."
            )),
            TutoPage("🎯", "Réception et passe", listOf(
                "Le cercle au sol blanc/doré montre où le ballon va tomber : place-toi dessus.",
                "Un seul bouton : réception → passe → smash s'enchaînent. 3 touches maximum, jamais le même joueur deux fois de suite.",
                "Appuie un peu trop tôt ? Ton appui est gardé une fraction de seconde."
            )),
            TutoPage("💥", "Le smash", listOf(
                "À la 3ᵉ touche, le jeu ralentit : un cercle se resserre autour du ballon.",
                "Appuie sur FRAPPE quand il touche l'anneau doré : vert = smash parfait.",
                "Joystick = viser : côté, court ou long."
            )), stars
        )
        Sport.BASKET -> listOf(
            controls,
            TutoPage("🏀", "Attaquer", listOf(
                "Tu contrôles le porteur du ballon. TIR : tir assisté, la jauge au-dessus du joueur donne la chance de marquer.",
                "Plus tu es proche du panier et libre, plus la jauge est verte. L'arc extérieur vaut 3 points.",
                "PASSE : vers le coéquipier le mieux démarqué."
            )),
            TutoPage("🛡️", "Défendre", listOf(
                "Maintiens DÉF : défense assistée, tu te places entre ton adversaire et le panier.",
                "TIR près du porteur : tentative de vol. Pendant qu'il arme son tir (il saute), TIR = contre !",
                "Attention aux interceptions sur les passes."
            )), stars
        )
    }
}

@Composable
private fun Tutorial(theme: GameTheme, sport: Sport?, onClose: () -> Unit) {
    val pages = remember(sport) { tutoPages(sport) }
    var i by remember(sport) { mutableIntStateOf(0) }
    val pg = pages[i]
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Back(theme, "Fermer", onClose)
        GlassCard(theme, Modifier.weight(1f)) {
            Text(pg.emoji, fontSize = 52.sp)
            Text(pg.title, color = theme.onBg, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
            for (l in pg.lines) {
                Text("• $l", color = theme.onBg.copy(alpha = 0.85f), fontSize = 15.sp, modifier = Modifier.padding(vertical = 4.dp))
            }
            if (pg.title == "Les commandes") {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(64.dp).clip(CircleShape).background(theme.onBg.copy(alpha = 0.12f)).border(2.dp, theme.onBg.copy(alpha = 0.35f), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(26.dp).clip(CircleShape).background(theme.onBg.copy(alpha = 0.45f)))
                    }
                    Text("joystick", color = theme.onBg.copy(alpha = 0.7f), fontSize = 12.sp)
                    val labels = (sport ?: Sport.FOOT).let { listOfNotNull(it.thirdLabel, it.secondLabel, it.actionLabel) }
                    labels.forEach { lb ->
                        Box(Modifier.size(54.dp).clip(CircleShape).background(Gold.copy(alpha = 0.18f)).border(2.dp, Gold, CircleShape), contentAlignment = Alignment.Center) {
                            Text(lb, color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            pages.indices.forEach { k ->
                Box(Modifier.padding(3.dp).size(if (k == i) 10.dp else 7.dp).clip(CircleShape).background(if (k == i) theme.accent else theme.onBg.copy(alpha = 0.25f)))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            if (i > 0) ActionButton("Précédent", theme, Modifier.weight(1f), primary = false) { i-- }
            if (i < pages.lastIndex) ActionButton("Suivant", theme, Modifier.weight(1f)) { i++ }
            else ActionButton("Terminer", theme, Modifier.weight(1f)) { onClose() }
        }
    }
}
