package com.nexus.gamelibrary

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/*
 * Moteur du mini-jeu « Arcade » v3 : vue du dessus, équipes avec bots.
 *  - Football 4 contre 4 avec gardien (arrêts, sorties, relance) et tacle glissé
 *  - Volley 2 contre 2 en 3 touches (réception, passe, attaque) avec cercle de timing pour le smash
 *  - Basket 3 contre 3 avec vraie défense (individuelle + aide, vol, contre, interception)
 *  - Les bots se démarquent : ils cherchent un espace libre avec une ligne de passe dégagée
 *    au lieu de courir tous vers le ballon (un seul presseur par équipe).
 *  - Tu pilotes un joueur (celui qui est le plus proche de l'action), les bots font le reste.
 *  - Aide à la visée : tirs, passes et frappes sont corrigés automatiquement vers la bonne cible.
 * Kotlin pur : aucune dépendance Android, tout fonctionne hors ligne.
 * Le monde fait 320 x 180 « pixels » ; l'écran les agrandit.
 */

enum class Sport(
    val label: String,
    val icon: String,
    val actionLabel: String,
    val secondLabel: String?,
    val thirdLabel: String?,
    val teamSize: Int,
    val blurb: String,
    val help: String
) {
    FOOT(
        "Football", "⚽", "TIR", "PASSE", "TACLE", 4,
        "4 contre 4 avec gardien · démarquage, tacles, arrêts",
        "Joystick : bouger · TIR : vise le but · PASSE : coéquipier démarqué · TACLE : glissade pour reprendre le ballon"
    ),
    VOLLEY(
        "Volley", "🏐", "FRAPPE", null, null, 2,
        "2 contre 2 · timing au ralenti, passe et smash en 3 touches",
        "Un seul bouton : réception → passe → smash s'enchaînent tout seuls · le jeu ralentit : appuie quand le cercle touche l'anneau doré · joystick = viser le smash"
    ),
    BASKET(
        "Basket", "🏀", "TIR", "PASSE", "DÉF", 3,
        "3 contre 3 · démarquage, contres, vols, interceptions",
        "Joystick : bouger · TIR : panier (en défense : vol ou CONTRE) · PASSE : coéquipier · DÉF (maintenir près du porteur) : vol automatique"
    )
}

data class Level(
    val index: Int,
    val number: Int,
    val division: Int,
    val divisionName: String,
    val sport: Sport,
    val opponent: String,
    val ai: Float,
    /** volley : points à atteindre ; foot / basket : durée du match en secondes */
    val target: Int,
    val margin2: Int,
    val margin3: Int,
    /** Match rapide (hors carrière) : ne donne pas d'étoiles. */
    val quick: Boolean = false,
    /** Entraînement : adversaire très faible, conseils affichés, aucune étoile. */
    val training: Boolean = false
) {
    val title: String get() = "${sport.label} · vs $opponent"
    val rule: String
        get() = when (sport) {
            Sport.VOLLEY -> "Premier à $target points"
            Sport.FOOT -> "${target / 60}:${"%02d".format(target % 60)} · plus de buts"
            Sport.BASKET -> "${target / 60}:${"%02d".format(target % 60)} · plus de points"
        }
}

object Career {
    val divisions = listOf("Quartier", "Ville", "Région", "Pro", "Légende")

    private val teams: Map<Sport, List<String>> = mapOf(
        Sport.FOOT to listOf(
            "Les Pitchous", "FC Quartier", "Les Rapides",
            "Union Ville", "AS Béton", "Étoile Sud",
            "Racing Pixel", "Olympique Nord", "Real Régio",
            "Atlético Néon", "Dragons FC", "Titans United",
            "Pixel City", "Les Galactiques", "Légende FC"
        ),
        Sport.VOLLEY to listOf(
            "Les Smasheurs", "Volley Club", "Les Sablés",
            "Filet Express", "Team Plage", "Les Bloqueurs",
            "Ace Ville", "Smash Nord", "Les Faucons",
            "Tempête", "Les Spikers", "Volcan VB",
            "Néon Spike", "Les Titans", "Légende VB"
        ),
        Sport.BASKET to listOf(
            "Les Dunkers", "Street Ball", "Les Paniers",
            "Ville Hoops", "Les Rebonds", "Bitume BC",
            "Pro Hoops", "Les Meneurs", "Blocs Nord",
            "Les Aigles", "Skyline", "Triple Double",
            "Pixel Hoops", "Les Légendes", "Dream Team"
        )
    )

    private val baseAi = floatArrayOf(0.12f, 0.30f, 0.48f, 0.66f, 0.82f)

    val levels: List<Level> = Sport.values().toList().flatMapIndexed { si, sport ->
        List(15) { i ->
            val div = i / 3
            val k = i % 3
            val ai = min(0.95f, baseAi[div] + 0.05f * k)
            val t = when (sport) {
                Sport.VOLLEY -> Triple(if (div < 3) 5 else 7, 2, 4)
                Sport.FOOT -> Triple(75, 2, 3)
                Sport.BASKET -> Triple(75, 8, 16)
            }
            Level(si * 15 + i, i + 1, div, divisions[div], sport, teams.getValue(sport)[i], ai, t.first, t.second, t.third)
        }
    }

    fun of(sport: Sport): List<Level> = levels.filter { it.sport == sport }

    fun next(lv: Level): Level? {
        if (lv.quick || lv.index < 0) return null
        return levels.getOrNull(lv.index + 1)?.takeIf { it.sport == lv.sport }
    }

    val quickDifficulties = listOf("Entraînement", "Facile", "Normal", "Difficile", "Expert")
    private val quickAi = floatArrayOf(0.04f, 0.25f, 0.5f, 0.74f, 0.93f)
    val quickLengths = listOf("Court", "Normal", "Long")

    /** Match rapide : difficulté 0..4 (0 = entraînement), durée 0..2. */
    fun quick(sport: Sport, difficulty: Int, length: Int): Level {
        val d = difficulty.coerceIn(0, 4)
        val l = length.coerceIn(0, 2)
        val target = when (sport) {
            Sport.VOLLEY -> intArrayOf(5, 7, 11)[l]
            else -> intArrayOf(45, 75, 120)[l]
        }
        val training = d == 0
        val name = if (training) "Le Coach" else teams.getValue(sport)[min(14, d * 3 + l)]
        return Level(
            index = -1, number = 0, division = d.coerceIn(0, 4), divisionName = quickDifficulties[d],
            sport = sport, opponent = name, ai = quickAi[d],
            target = if (training) (if (sport == Sport.VOLLEY) 15 else 300) else target,
            margin2 = 99, margin3 = 99, quick = true, training = training
        )
    }
}

/** Touches du joueur : le moteur lit ces valeurs à chaque pas. */
class ArcadeInput {
    @Volatile var mx = 0f
    @Volatile var my = 0f
    @Volatile var action = false
    @Volatile var actionLatch = false
    @Volatile var pass = false
    @Volatile var passLatch = false
    /** Troisième bouton : TACLE (foot) ou DÉF (basket). */
    @Volatile var third = false
    @Volatile var thirdLatch = false
}

object Court {
    const val W = 320f
    const val H = 180f

    // aire de jeu (foot et basket)
    const val X0 = 16f
    const val X1 = 304f
    const val Y0 = 16f
    const val Y1 = 164f
    const val CY = 90f

    // foot
    const val GOAL_Y0 = 68f
    const val GOAL_Y1 = 112f
    const val GOAL_D = 12f

    // basket
    const val HOOP_X = 30f
    const val ARC = 74f

    // volley
    const val VX0 = 44f
    const val VX1 = 276f
    const val VY0 = 32f
    const val VY1 = 148f
    const val NET_X = 160f
    const val NET_H = 20f

    const val BALL_R = 3f
}

class Player(val team: Int, val slot: Int) {
    var x = 0f
    var y = 0f
    var vx = 0f
    var vy = 0f
    var fx = 1f
    var fy = 0f
    var runT = 0f
    var cool = 0f
    var actT = 0f
    var jumpT = 0f
    var tx = 0f
    var ty = 0f
    var aiT = 0f
    var aiGo = false
    var aiGo2 = false
    var mx = 0f
    var my = 0f
    var act = false
    var pass = false
    var third = false

    /** Défense assistée (basket) : le joueur piloté se place tout seul entre son adversaire et le panier. */
    var def = false

    /** Temps restant avant de rechoisir un espace libre (démarquage). */
    var spotT = 0f

    /** Volley : hauteur du ballon à laquelle un bot déclenche son smash. */
    var trigZ = 28f

    // foot : tacle glissé
    var tackT = 0f
    var tdx = 1f
    var tdy = 0f
    var stunT = 0f

    // foot : gardien
    var holdT = 0f
    var diveT = 0f
    var diveDir = 0f
    var reactT = 0f
    var shotSeen = false
    var shotY = 90f

    // basket : armé du tir (le défenseur peut contrer pendant ce temps)
    var windT = 0f
}

enum class Phase { INTRO, PLAY, SCORED, OVER }

data class Hud(
    val scoreA: Int,
    val scoreB: Int,
    val seconds: Int,
    val message: String,
    val overtime: Boolean,
    val over: Boolean,
    /** Volley : touches déjà faites par l'équipe qui a le ballon (-1 = rien à afficher). */
    val touches: Int = -1,
    val touchSide: Int = 0,
    /** Volley : secondes avant le service automatique quand c'est à toi de servir (-1 = rien). */
    val serveWait: Int = -1
)

private fun hyp(a: Float, b: Float): Float = sqrt(a * a + b * b)

// volley : type de touche
private const val PLAN_BUMP = 0
private const val PLAN_SET = 1
private const val PLAN_SMASH = 2
private const val PLAN_OVER = 3
private const val PLAN_SERVE = 4

/** Hauteur du ballon pour un smash parfait, et hauteur maximale à laquelle on peut toucher le ballon. */
private const val SMASH_Z = 28f
private const val REACH_Z = 34f

/** Hauteur idéale du ballon pour une réception / une passe (cercle de timing). */
private const val PASS_Z = 18f

/** Vitesse du jeu pendant le cercle de timing (ralenti). */
private const val SLOW = 0.4f

class Match(
    val level: Level,
    seed: Long = System.nanoTime()
) {
    val sport = level.sport
    private val n = sport.teamSize
    private val rnd = Random(seed)
    val ps: List<Player> = List(n * 2) { Player(it / n, it % n) }
    val input = ArcadeInput()

    /** Indice (dans ps) du joueur que tu pilotes. */
    var ctrl = 1
    private var switchT = 0f

    // ballon
    var bx = 160f
    var by = 90f
    var bz = 0f
    var bvx = 0f
    var bvy = 0f
    var bvz = 0f
    var ballSpin = 0f

    // basket : qui tient le ballon (foot : gardien qui a capté), et vol (passe / tir)
    var holder: Player? = null
    var flKind = 0 // 0 aucun, 1 passe, 2 tir
    private var flT = 0f
    private var flDur = 0.5f
    private var fsx = 0f
    private var fsy = 0f
    private var fex = 0f
    private var fey = 0f
    private var flTarget: Player? = null
    private var flGood = false
    private var flPts = 2
    private var flTeam = 0
    private val flRolled = HashSet<Player>()
    private var noGrabT = 0f

    // foot : dernier joueur à avoir touché le ballon
    private var footOwner: Player? = null
    private var footOwnerT = 0f

    // volley
    var lastTouch = 0
    private var vTouches = 0
    private var vLast: Player? = null
    private var vServe = false
    private var vServeTeam = 0

    /** Volley : le ballon reste dans la main du serveur jusqu'au service (toi : bouton FRAPPE ; bot : petit délai). */
    private var vHold = false
    private var vHoldT = 0f

    /** Volley : appui un peu trop tôt mémorisé (0,2 s) pour ne pas perdre un point à cause d'un doigt pressé. */
    private var vBuf = 0f

    /** Temps écoulé depuis le dernier point (confettis, effets). */
    var scoredAge = 0f

    /** Traînée du ballon (anciennes positions), pour l'effet cosmétique. */
    val trailX = FloatArray(12)
    val trailY = FloatArray(12)
    val trailZ = FloatArray(12)
    private var trailT = 0f

    /** Vrai juste après un service, jusqu'à la réception : l'équipe qui reçoit est aidée. */
    private var vServeRecv = false

    /** Facteur de ralenti courant (1 = normal). */
    private var slowK = 1f

    val score = intArrayOf(0, 0)
    var timeLeft = level.target.toFloat()
    var overtime = false
    var phase = Phase.INTRO
    private var phaseT = 1.8f
    private var pendingOver = false
    var message = ""
    private var messageT = 0f
    var won = false
    var simTime = 0f
    private var lastScorer = 0

    /** Sons à jouer : 1 = frappe, 2 = point, 3 = victoire, 4 = défaite. */
    val sfx = ArrayDeque<Int>()

    init {
        setMessage("${level.sport.label} · vs ${level.opponent}", 1.8f)
        resetPositions(0)
    }

    fun hud(): Hud = Hud(
        score[0], score[1],
        if (sport == Sport.VOLLEY) -1 else max(0, timeLeft.toInt() + if (timeLeft > timeLeft.toInt()) 1 else 0),
        message, overtime, phase == Phase.OVER,
        if (sport == Sport.VOLLEY && phase == Phase.PLAY && !vServe) vTouches else -1,
        if (bx < Court.NET_X) 0 else 1,
        if (waitingServe()) max(0, vHoldT.toInt() + 1) else -1
    )

    fun stars(): Int {
        if (!won) return 0
        val diff = score[0] - score[1]
        return 1 + (if (diff >= level.margin2) 1 else 0) + (if (diff >= level.margin3) 1 else 0)
    }

    private fun setMessage(m: String, t: Float) {
        message = m
        messageT = t
    }

    private fun aiOf(p: Player): Float = if (p.team == 1) level.ai else 0.7f

    private fun isHuman(p: Player) = p === ps[ctrl]

    private fun isKeeper(p: Player) = sport == Sport.FOOT && p.slot == 0

    private fun dir(team: Int): Float = if (team == 0) 1f else -1f

    /** Panier que vise cette équipe (x). L'équipe 0 attaque à droite. */
    private fun hoopX(team: Int): Float = if (team == 0) Court.W - Court.HOOP_X else Court.HOOP_X

    private fun goalLineX(team: Int): Float = if (team == 0) Court.X1 else Court.X0

    // ───────────────────────── mise en place ─────────────────────────

    private fun resetPositions(serve: Int) {
        for (p in ps) {
            p.vx = 0f; p.vy = 0f; p.cool = 0f; p.actT = 0f; p.jumpT = 0f
            p.aiT = 0f; p.aiGo = false; p.aiGo2 = false
            p.mx = 0f; p.my = 0f; p.act = false; p.pass = false; p.third = false; p.def = false
            p.spotT = 0f; p.tackT = 0f; p.stunT = 0f
            p.holdT = 0f; p.diveT = 0f; p.reactT = 0f; p.shotSeen = false
            p.windT = 0f
            p.fx = dir(p.team); p.fy = 0f
        }
        holder = null
        flKind = 0
        flRolled.clear()
        noGrabT = 0f
        footOwner = null
        footOwnerT = 0f
        bz = 0f; bvx = 0f; bvy = 0f; bvz = 0f
        switchT = 0f

        when (sport) {
            Sport.FOOT -> {
                for (p in ps) {
                    val d = dir(p.team)
                    when (p.slot) {
                        0 -> { p.x = goalLineX(1 - p.team) + d * 8f; p.y = Court.CY }
                        1 -> { p.x = 160f - d * (if (p.team == serve) 14f else 46f); p.y = Court.CY }
                        2 -> { p.x = 160f - d * 62f; p.y = Court.CY - 40f }
                        else -> { p.x = 160f - d * 62f; p.y = Court.CY + 40f }
                    }
                }
                bx = 160f; by = 90f
                ctrl = 1
            }
            Sport.BASKET -> {
                val d = dir(serve)
                for (p in ps) {
                    if (p.team == serve) {
                        p.x = 160f - d * (if (p.slot == 1) 52f else 74f)
                        p.y = Court.CY + (p.slot - 1) * 34f
                    } else {
                        p.x = 160f - d * (if (p.slot == 1) 30f else 42f)
                        p.y = Court.CY + (p.slot - 1) * 30f
                    }
                }
                holder = ps[serve * n + 1]
                val h = holder
                if (h != null) { bx = h.x; by = h.y }
                ctrl = 1
            }
            Sport.VOLLEY -> {
                for (p in ps) {
                    val d = dir(p.team)
                    if (p.slot == 0) { p.x = Court.NET_X - d * 54f; p.y = Court.CY - 28f }
                    else { p.x = Court.NET_X - d * 104f; p.y = Court.CY + 28f }
                }
                val server = ps[serve * n + 1]
                bx = server.x + dir(serve) * 6f
                by = server.y
                bz = 14f
                bvz = 0f
                lastTouch = serve
                vHold = true
                vHoldT = if (serve == 0) 7f else 0.9f + rnd.nextFloat() * 0.7f
                vBuf = 0f
                vServe = true
                vServeRecv = false
                slowK = 1f
                vServeTeam = serve
                vTouches = 0
                vLast = null
                ctrl = 1
            }
        }
    }

    // ───────────────────────── pas de simulation ─────────────────────────

    fun step(dt: Float) {
        if (phase == Phase.OVER) return
        simTime += dt
        messageT -= dt
        if (messageT <= 0f) message = ""
        ballSpin += (bvx + bvy) * dt * 0.1f

        when (phase) {
            Phase.INTRO -> {
                phaseT -= dt
                idle(dt)
                clearLatches()
                if (phaseT <= 0f) {
                    phase = Phase.PLAY
                    if (message.isNotEmpty() && messageT < 0.6f) message = ""
                }
            }
            Phase.SCORED -> {
                phaseT -= dt
                scoredAge += dt
                idle(dt)
                clearLatches()
                moveBall(dt, false)
                if (phaseT <= 0f) {
                    if (pendingOver) finish() else nextPoint()
                }
            }
            Phase.PLAY -> {
                // volley : ralenti pendant le cercle de timing
                val slowTarget = if (humanTiming()) SLOW else 1f
                slowK += (slowTarget - slowK) * min(1f, 12f * dt)
                val sdt = dt * slowK
                chooseControlled(sdt)
                for (p in ps) control(p, sdt)
                for (p in ps) movePlayer(p, sdt, speedOf(p))
                separate()
                for (p in ps) doAction(p)
                updateSpecials(sdt)
                clearLatches()
                moveBall(sdt, true)
                updateTrail(dt)
                if (sport != Sport.VOLLEY && phase == Phase.PLAY && !overtime && flKind == 0) {
                    timeLeft -= dt
                    if (timeLeft <= 0f) {
                        timeLeft = 0f
                        if (score[0] != score[1]) {
                            pendingOver = true
                            phase = Phase.SCORED
                            phaseT = 1.3f
                            setMessage("FIN DU MATCH", 2f)
                        } else {
                            overtime = true
                            setMessage("PROLONGATION · prochain point gagne", 2.5f)
                        }
                    }
                }
            }
            Phase.OVER -> {}
        }
    }

    private fun idle(dt: Float) {
        for (p in ps) {
            p.mx = 0f; p.my = 0f; p.act = false; p.pass = false; p.third = false
            movePlayer(p, dt, 0f)
        }
    }

    private fun clearLatches() {
        input.actionLatch = false
        input.passLatch = false
        input.thirdLatch = false
    }

    private fun nextPoint() {
        val serve = if (sport == Sport.VOLLEY) lastScorer else 1 - lastScorer
        resetPositions(serve)
        phase = Phase.INTRO
        phaseT = 0.9f
    }

    private fun finish() {
        phase = Phase.OVER
        won = score[0] > score[1]
        sfx.addLast(if (won) 3 else 4)
        message = ""
    }

    private fun scoreFor(side: Int, pts: Int) {
        if (phase != Phase.PLAY) return
        score[side] += pts
        lastScorer = side
        phase = Phase.SCORED
        phaseT = 1.5f
        scoredAge = 0f
        sfx.addLast(2)
        val who = if (side == 0) "TOI" else level.opponent.uppercase()
        when (sport) {
            Sport.FOOT -> setMessage("BUT ! · $who", 1.5f)
            Sport.BASKET -> setMessage("PANIER +$pts · $who", 1.5f)
            Sport.VOLLEY -> setMessage("POINT · $who", 1.5f)
        }
        pendingOver = when (sport) {
            Sport.VOLLEY -> score[side] >= level.target
            else -> overtime
        }
        flKind = 0
    }

    // ───────────────────────── outils de géométrie ─────────────────────────

    private fun dist2(p: Player, x: Float, y: Float): Float {
        val dx = p.x - x
        val dy = p.y - y
        return dx * dx + dy * dy
    }

    private fun nearestOpp(p: Player): Player {
        var best = ps.first { it.team != p.team }
        var bd = 1e9f
        for (q in ps) {
            if (q.team == p.team) continue
            val d = dist2(q, p.x, p.y)
            if (d < bd) { bd = d; best = q }
        }
        return best
    }

    private fun nearestOppDist(x: Float, y: Float, team: Int): Float {
        var m = 999f
        for (q in ps) if (q.team != team) m = min(m, hyp(q.x - x, q.y - y))
        return m
    }

    /** Distance entre la ligne de passe (a → b) et l'adversaire le plus proche de cette ligne. */
    private fun laneClear(ax: Float, ay: Float, cx: Float, cy: Float, team: Int): Float {
        val dx = cx - ax
        val dy = cy - ay
        val l2 = max(1f, dx * dx + dy * dy)
        var m = 999f
        for (q in ps) {
            if (q.team == team) continue
            val t = (((q.x - ax) * dx + (q.y - ay) * dy) / l2).coerceIn(0f, 1f)
            m = min(m, hyp(q.x - (ax + dx * t), q.y - (ay + dy * t)))
        }
        return m
    }

    /**
     * Se démarquer : cherche autour de (cx, cy) le point libre le mieux placé —
     * loin des adversaires, ligne de passe dégagée avec le porteur, pas collé aux coéquipiers.
     */
    private fun openSpot(
        p: Player,
        carrierX: Float, carrierY: Float,
        cx: Float, cy: Float,
        radius: Float, forward: Float
    ): FloatArray {
        val d = dir(p.team)
        var bestX = cx.coerceIn(Court.X0 + 12f, Court.X1 - 12f)
        var bestY = cy.coerceIn(Court.Y0 + 10f, Court.Y1 - 10f)
        var bs = -1e9f
        for (k in 0 until 17) {
            val ring = if (k == 16) 0 else k / 8
            val ang = (k % 8) * 0.7854f + ring * 0.39f
            val rr = if (k == 16) 0f else radius * (0.55f + 0.45f * ring)
            val x = (cx + cos(ang) * rr).coerceIn(Court.X0 + 12f, Court.X1 - 12f)
            val y = (cy + sin(ang) * rr).coerceIn(Court.Y0 + 10f, Court.Y1 - 10f)
            val free = min(nearestOppDist(x, y, p.team), 45f)
            val lane = min(laneClear(carrierX, carrierY, x, y, p.team), 30f)
            var sc = free + lane * 1.3f
            sc += (x - carrierX) * d * 0.05f * forward
            for (q in ps) {
                if (q.team != p.team || q === p) continue
                val dq = hyp(q.x - x, q.y - y)
                if (dq < 30f) sc -= (30f - dq) * 0.9f
            }
            val dc = hyp(x - carrierX, y - carrierY)
            if (dc < 28f) sc -= (28f - dc) * 0.8f
            if (dc > 130f) sc -= (dc - 130f) * 0.15f
            sc -= hyp(x - p.x, y - p.y) * 0.04f
            if (sc > bs) { bs = sc; bestX = x; bestY = y }
        }
        return floatArrayOf(bestX, bestY)
    }

    /** Démarquage avec mémoire : garde son espace libre ~0,5 s avant d'en rechoisir un. */
    private fun demarque(
        p: Player,
        carrierX: Float, carrierY: Float,
        baseX: Float, baseY: Float,
        radius: Float, forward: Float
    ) {
        if (p.spotT > 0f && nearestOppDist(p.tx, p.ty, p.team) > 12f) return
        val s = openSpot(p, carrierX, carrierY, baseX, baseY, radius, forward)
        p.tx = s[0]
        p.ty = s[1]
        p.spotT = 0.55f + rnd.nextFloat() * 0.35f
    }

    // ───────────────────────── joueur piloté ─────────────────────────

    private fun chooseControlled(dt: Float) {
        switchT -= dt
        if (sport == Sport.VOLLEY) {
            chooseVolley()
            return
        }
        if (switchT > 0f) return
        val h = holder
        if (sport == Sport.BASKET && h != null && h.team == 0) {
            val idx = ps.indexOf(h)
            if (idx != ctrl) { ctrl = idx; switchT = 0.2f }
            return
        }
        var rx = bx
        var ry = by
        if (sport == Sport.BASKET && h != null) { rx = h.x; ry = h.y }
        val first = if (sport == Sport.FOOT) 1 else 0 // le gardien n'est jamais piloté
        var best = ctrl
        var bd = dist2(ps[ctrl], rx, ry) - 80f
        for (i in first until n) {
            val d = dist2(ps[i], rx, ry)
            if (d < bd) { bd = d; best = i }
        }
        if (best != ctrl) { ctrl = best; switchT = 0.3f }
    }

    private fun speedOf(p: Player): Float {
        if (p.tackT > 0f) return 190f
        if (p.stunT > 0f) return 0f
        if (p.windT > 0f) return 16f
        if (isKeeper(p)) return if (p.shotSeen && p.reactT <= 0f) 150f else 62f + 30f * aiOf(p)
        if (isHuman(p)) {
            var s = if (sport == Sport.BASKET && holder === p) 92f else 100f
            if (p.def) s *= 0.92f
            return s
        }
        val base = if (p.team == 0) 86f else 64f + 32f * level.ai
        // volley : à la réception du service, les bots courent plus vite pour rattraper la balle
        return if (sport == Sport.VOLLEY && vServeRecv && p.team != lastTouch) base * 1.45f else base
    }

    // ───────────────────────── commandes (joueur / IA) ─────────────────────────

    private fun control(p: Player, dt: Float) {
        p.act = false
        p.pass = false
        p.third = false
        p.def = false
        if (p.stunT > 0f) { p.mx = 0f; p.my = 0f; return }
        if (p.tackT > 0f) { p.mx = p.tdx; p.my = p.tdy; return }
        if (isKeeper(p)) { controlKeeper(p, dt); return }
        if (isHuman(p)) {
            p.mx = input.mx.coerceIn(-1f, 1f)
            p.my = input.my.coerceIn(-1f, 1f)
            p.act = input.action || input.actionLatch ||
                (sport == Sport.VOLLEY && vHold && vHoldT <= 0f && vServeTeam == 0 && p.slot == 1)
            p.pass = input.pass || input.passLatch
            p.third = input.third || input.thirdLatch
            if (sport == Sport.BASKET && input.third && holder?.team != p.team) {
                p.def = true
                applyDefAssist(p)
                val hh = holder
                if (hh != null && p.cool <= 0f && hyp(p.x - hh.x, p.y - hh.y) < 20f) p.act = true
            }
            return
        }
        p.spotT -= dt
        val a = aiOf(p)
        if (sport == Sport.VOLLEY && vServeRecv && p.team != lastTouch) p.aiT = 0f
        p.aiT -= dt
        if (p.aiT <= 0f) {
            p.aiT = 0.05f + (1f - a) * 0.2f
            p.aiGo = rnd.nextFloat() < 0.5f + 0.5f * a
            p.aiGo2 = rnd.nextFloat() < 0.10f + 0.20f * a
            when (sport) {
                Sport.FOOT -> thinkFoot(p, a)
                Sport.BASKET -> thinkBasket(p, a)
                Sport.VOLLEY -> thinkVolley(p, a)
            }
        }
        steer(p)
        when (sport) {
            Sport.FOOT -> actFootAi(p, a)
            Sport.BASKET -> actBasketAi(p, a)
            Sport.VOLLEY -> actVolleyAi(p)
        }
    }

    private fun steer(p: Player) {
        val dx = p.tx - p.x
        val dy = p.ty - p.y
        val d = hyp(dx, dy)
        if (d < 2f) {
            p.mx = 0f; p.my = 0f
        } else {
            val k = min(1f, d / 10f)
            p.mx = dx / d * k
            p.my = dy / d * k
        }
    }

    private fun movePlayer(p: Player, dt: Float, speed: Float) {
        var mx = p.mx
        var my = p.my
        val len = hyp(mx, my)
        if (len > 1f) { mx /= len; my /= len }
        val k = min(1f, 14f * dt)
        p.vx += (mx * speed - p.vx) * k
        p.vy += (my * speed - p.vy) * k
        p.x += p.vx * dt
        p.y += p.vy * dt
        clampPlayer(p)
        if (len > 0.15f) {
            val l = max(len, 0.001f)
            p.fx = p.mx / l
            p.fy = p.my / l
        }
        val sp = hyp(p.vx, p.vy)
        if (sp > 8f) p.runT += dt * 9f else p.runT = 0f
        p.cool -= dt
        p.actT -= dt
        p.jumpT -= dt
        p.diveT -= dt
        p.stunT -= dt
    }

    private fun clampPlayer(p: Player) {
        if (isKeeper(p)) {
            val lo = if (p.team == 0) Court.X0 + 3f else Court.X1 - 38f
            val hi = if (p.team == 0) Court.X0 + 38f else Court.X1 - 3f
            p.x = p.x.coerceIn(lo, hi)
            p.y = p.y.coerceIn(Court.GOAL_Y0 - 14f, Court.GOAL_Y1 + 14f)
            return
        }
        if (sport == Sport.VOLLEY) {
            val lo = if (p.team == 0) Court.VX0 - 16f else Court.NET_X + 8f
            val hi = if (p.team == 0) Court.NET_X - 8f else Court.VX1 + 16f
            p.x = p.x.coerceIn(lo, hi)
            p.y = p.y.coerceIn(Court.VY0 - 14f, Court.VY1 + 14f)
        } else {
            p.x = p.x.coerceIn(Court.X0 + 4f, Court.X1 - 4f)
            p.y = p.y.coerceIn(Court.Y0 + 4f, Court.Y1 - 4f)
        }
    }

    private fun separate() {
        for (i in ps.indices) {
            for (j in i + 1 until ps.size) {
                val a = ps[i]
                val b = ps[j]
                val dx = b.x - a.x
                val dy = b.y - a.y
                val d2 = dx * dx + dy * dy
                if (d2 < 64f && d2 > 0.0001f) {
                    val d = sqrt(d2)
                    val push = (8f - d) / 2f
                    val nx = dx / d
                    val ny = dy / d
                    a.x -= nx * push; a.y -= ny * push
                    b.x += nx * push; b.y += ny * push
                }
            }
        }
    }

    private fun doAction(p: Player) {
        if (p.stunT > 0f || p.tackT > 0f || isKeeper(p) || p.cool > 0f) return
        when (sport) {
            Sport.FOOT -> {
                if (p.third) { startTackle(p); return }
                if (!p.act && !p.pass) return
                p.actT = 0.2f
                if (holder == null && hyp(bx - p.x, by - p.y) < 11f) kickFoot(p, p.act) else p.cool = 0.12f
            }
            Sport.BASKET -> {
                if (p.act || p.pass) actBasket(p)
            }
            Sport.VOLLEY -> {
                if (p.act || p.pass) actVolley(p)
            }
        }
    }

    /** Choisit un coéquipier pour la passe : le plus aligné avec la direction (humain) ou le mieux démarqué (bot). */
    private fun passTarget(p: Player, human: Boolean): Player? {
        var best: Player? = null
        var bs = -9f
        val d = dir(p.team)
        for (q in ps) {
            if (q.team != p.team || q === p || isKeeper(q)) continue
            val ex = q.x - p.x
            val ey = q.y - p.y
            val dl = hyp(ex, ey)
            if (dl < 18f) continue
            val sc = if (human) {
                (p.fx * ex + p.fy * ey) / dl - dl * 0.0012f
            } else {
                val lane = min(laneClear(p.x, p.y, q.x, q.y, p.team), 30f)
                val free = min(nearestOppDist(q.x, q.y, p.team), 40f)
                ex * d / 100f + lane * 0.03f + free * 0.015f - dl * 0.003f + rnd.nextFloat() * 0.15f
            }
            if (sc > bs) { bs = sc; best = q }
        }
        if (human && bs < 0.15f) return null
        return best
    }

    private fun updateSpecials(dt: Float) {
        if (footOwnerT > 0f) footOwnerT -= dt
        if (noGrabT > 0f) noGrabT -= dt
        when (sport) {
            Sport.FOOT -> {
                resolveTackles()
                for (p in ps) {
                    updateTackle(p, dt)
                    if (isKeeper(p)) keeperSave(p)
                }
            }
            Sport.BASKET -> updateWindups(dt)
            Sport.VOLLEY -> {
                if (vHold) vHoldT -= dt
                if (vBuf > 0f) {
                    vBuf -= dt
                    val h = ps[ctrl]
                    if (h.stunT <= 0f && volleyReach(h)) {
                        vBuf = 0f
                        hitVolley(h)
                    }
                }
            }
        }
    }

    private fun updateTrail(dt: Float) {
        trailT -= dt
        if (trailT > 0f) return
        trailT = 0.022f
        for (i in trailX.size - 1 downTo 1) {
            trailX[i] = trailX[i - 1]; trailY[i] = trailY[i - 1]; trailZ[i] = trailZ[i - 1]
        }
        trailX[0] = bx; trailY[0] = by; trailZ[0] = bz
    }

    /** Volley : c'est à toi de servir et le ballon attend dans ta main. */
    fun serveHeld(): Boolean = vHold

    fun waitingServe(): Boolean = sport == Sport.VOLLEY && phase == Phase.PLAY && vHold && vServeTeam == 0

    /** Entraînement : petit conseil selon la situation (null hors entraînement). */
    fun coach(): String? {
        if (!level.training || phase != Phase.PLAY) return null
        val p = ps[ctrl]
        val dBall = hyp(bx - p.x, by - p.y)
        return when (sport) {
            Sport.FOOT -> when {
                holder != null -> "Le gardien a le ballon : replace-toi"
                dBall > 24f -> "Cours vers le ballon avec le joystick"
                else -> "TIR : vise le but · PASSE : coéquipier · TACLE : reprendre le ballon"
            }
            Sport.BASKET -> {
                val h = holder
                when {
                    h == null -> "Ramasse le ballon libre"
                    h === p -> "TIR : panier (jauge verte = bonne chance) · PASSE : coéquipier"
                    h.team == 0 -> "Démarque-toi pour recevoir une passe"
                    else -> "Défends : maintiens DÉF près de lui = vol automatique · TIR = vol / contre"
                }
            }
            Sport.VOLLEY -> when {
                waitingServe() -> "Appuie sur FRAPPE pour servir"
                sideOfBall() != 0 -> "Replace-toi, le ballon revient"
                !canTouch(p) -> "Laisse ton coéquipier jouer · déplace-toi"
                dBall > 40f -> "Va sous le ballon : l'ombre au sol montre où il tombe"
                vTouches == 0 -> "Réception : FRAPPE quand le cercle touche l'anneau doré"
                vTouches == 1 -> "Passe : FRAPPE au bon moment pour armer le smash"
                else -> "SMASH ! Joystick = viser · FRAPPE quand le cercle touche l'anneau"
            }
        }
    }

    // ───────────────────────── FOOT ─────────────────────────

    /** Équipe qui a la possession (0 / 1) ou -1 si le ballon est libre. */
    private fun footPossession(): Int {
        val h = holder
        if (h != null) return h.team
        val o = footOwner
        if (o != null && footOwnerT > 0f) return o.team
        return -1
    }

    /** Cible d'un tir : [x, y, assisté (1) ou non (0)]. */
    fun footShotTarget(p: Player, human: Boolean): FloatArray {
        val a = if (human) 1f else aiOf(p)
        val goalX = if (p.team == 0) Court.X1 + 4f else Court.X0 - 4f
        val tgx = goalX - bx
        val tgy = Court.CY - by
        val gl = max(1f, hyp(tgx, tgy))
        val cosA = (p.fx * tgx + p.fy * tgy) / gl
        if (cosA > 0.6f && gl < 190f) {
            val keeper = ps[(1 - p.team) * n]
            var ty = if (keeper.y < Court.CY) Court.GOAL_Y1 - 9f else Court.GOAL_Y0 + 9f
            if (!human) ty += (rnd.nextFloat() - 0.5f) * 2f * (1f - a) * 34f
            return floatArrayOf(goalX, ty, 1f)
        }
        return floatArrayOf(bx + p.fx * 60f, by + p.fy * 60f, 0f)
    }

    private fun kickFoot(p: Player, shot: Boolean) {
        val human = isHuman(p)
        var dx = p.fx
        var dy = p.fy
        var speed: Float
        if (shot) {
            val t = footShotTarget(p, human)
            dx = t[0] - bx
            dy = t[1] - by
            speed = 255f
        } else {
            val q = passTarget(p, human)
            if (q != null) {
                dx = q.x + q.vx * 0.35f - bx
                dy = q.y + q.vy * 0.35f - by
                val dl = hyp(dx, dy)
                speed = min(235f, 95f + dl * 1.25f)
            } else {
                speed = 175f
            }
        }
        val l = max(0.001f, hyp(dx, dy))
        bvx = dx / l * speed
        bvy = dy / l * speed
        p.cool = 0.35f
        footOwner = p
        footOwnerT = 1.2f
        sfx.addLast(1)
    }

    // ----- tacle glissé -----

    private fun startTackle(p: Player) {
        var dx = p.fx
        var dy = p.fy
        // aide : on glisse vers l'adversaire qui a le ballon, s'il y en a un tout près
        var best: Player? = null
        var bd = 900f
        for (q in ps) {
            if (q.team == p.team || isKeeper(q)) continue
            val dd = dist2(q, p.x, p.y)
            if (dd < bd && hyp(q.x - bx, q.y - by) < 16f) { bd = dd; best = q }
        }
        if (best != null) {
            dx = best.x - p.x
            dy = best.y - p.y
        }
        val l = hyp(dx, dy)
        if (l < 0.01f) { dx = dir(p.team); dy = 0f } else { dx /= l; dy /= l }
        p.tdx = dx
        p.tdy = dy
        p.tackT = 0.34f
        p.actT = 0.3f
        p.cool = 1.1f
        sfx.addLast(1)
    }

    private fun updateTackle(p: Player, dt: Float) {
        if (p.tackT <= 0f) return
        p.tackT -= dt
        if (p.tackT <= 0f) {
            p.tackT = 0f
            p.stunT = max(p.stunT, 0.4f) // le temps de se relever
        }
    }

    private fun resolveTackles() {
        for (p in ps) {
            if (p.tackT <= 0f) continue
            for (q in ps) {
                if (q.team == p.team || isKeeper(q)) continue
                if (hyp(q.x - p.x, q.y - p.y) > 9f) continue
                val ballNear = hyp(bx - q.x, by - q.y) < 13f && holder == null
                if (ballNear) {
                    val chance = if (isHuman(p)) 0.8f else 0.28f + 0.4f * aiOf(p)
                    if (rnd.nextFloat() < chance) {
                        // ballon récupéré : il roule devant le tacleur
                        bvx = p.tdx * 120f + (rnd.nextFloat() - 0.5f) * 30f
                        bvy = p.tdy * 120f + (rnd.nextFloat() - 0.5f) * 30f
                        footOwner = p
                        footOwnerT = 1.2f
                        q.stunT = 0.5f
                        q.vx *= 0.2f; q.vy *= 0.2f
                        p.tackT = 0f
                        p.stunT = 0.12f
                        setMessage("TACLE !", 0.6f)
                    } else {
                        // tacle raté : le tacleur reste au sol un moment
                        p.tackT = 0f
                        p.stunT = 0.55f
                    }
                } else {
                    // pas de ballon : tacle dans le vide, il perd du temps
                    p.tackT = 0f
                    p.stunT = 0.7f
                    q.stunT = max(q.stunT, 0.25f)
                }
                break
            }
        }
    }

    // ----- gardien -----

    private fun keeperClosest(k: Player): Boolean {
        val dk = dist2(k, bx, by)
        for (q in ps) {
            if (q === k) continue
            if (dist2(q, bx, by) < dk) return false
        }
        return true
    }

    private fun controlKeeper(p: Player, dt: Float) {
        val a = aiOf(p)
        val inward = if (p.team == 0) 1f else -1f
        val lineX = if (p.team == 0) Court.X0 else Court.X1
        val hk = holder
        if (hk === p) {
            // il tient le ballon puis relance
            p.mx = 0f; p.my = 0f
            p.holdT -= dt
            if (p.holdT <= 0f) throwKeeper(p)
            return
        }
        val sp = hyp(bvx, bvy)
        val toward = hk == null && bvx * inward < -40f && sp > 110f && hyp(bx - lineX, by - Court.CY) < 210f
        if (toward) {
            // lecture du tir : il se place là où le ballon va passer (avec un temps de réaction)
            if (!p.shotSeen) {
                p.shotSeen = true
                p.reactT = 0.08f + (1f - a) * 0.30f
                val t = (lineX - bx) / bvx
                p.shotY = by + bvy * t + (rnd.nextFloat() - 0.5f) * 2f * (1f - a) * 24f
            }
            p.reactT -= dt
            p.tx = lineX + inward * 6f
            p.ty = if (p.reactT > 0f) p.y else p.shotY.coerceIn(Court.GOAL_Y0 - 6f, Court.GOAL_Y1 + 6f)
        } else {
            p.shotSeen = false
            // placement : sur la ligne ballon → centre du but, un peu plus loin quand le ballon est loin
            val dx = bx - lineX
            val dy = by - Court.CY
            val dl = max(1f, hyp(dx, dy))
            val rr = 8f + min(14f, dl * 0.07f)
            p.tx = lineX + dx / dl * rr
            p.ty = (Court.CY + dy / dl * rr).coerceIn(Court.GOAL_Y0 + 5f, Court.GOAL_Y1 - 5f)
            // sortie : ballon lent et proche, personne n'est mieux placé
            if (hk == null && dl < 50f && sp < 80f && keeperClosest(p)) {
                p.tx = bx
                p.ty = by
            }
        }
        steer(p)
    }

    private fun keeperSave(p: Player) {
        if (holder != null) return
        if (p.cool > 0f || p.stunT > 0f || p.diveT > 0f) return
        val d = hyp(bx - p.x, by - p.y)
        val sp = hyp(bvx, bvy)
        val reach = if (p.shotSeen) 15f else 11f
        if (d > reach) return
        if (sp < 60f) {
            // ballon lent : il le ramasse s'il est tout près
            if (d < 10f) catchBall(p)
            return
        }
        val a = aiOf(p)
        val seen = p.shotSeen && p.reactT <= 0f
        val chance = (0.30f + 0.58f * a - sp * 0.0009f + (if (seen) 0.10f else 0f)).coerceIn(0.15f, 0.93f)
        p.diveT = 0.45f
        p.diveDir = if (by >= p.y) 1f else -1f
        p.cool = 0.7f
        if (rnd.nextFloat() < chance) {
            if (sp < 170f || rnd.nextFloat() < 0.5f) catchBall(p) else parryBall(p)
        }
    }

    private fun catchBall(p: Player) {
        holder = p
        bvx = 0f; bvy = 0f
        p.holdT = 0.8f + rnd.nextFloat() * 0.6f
        footOwner = p
        footOwnerT = 1.2f
        setMessage("ARRÊT !", 0.7f)
        sfx.addLast(1)
    }

    private fun parryBall(p: Player) {
        val inw = if (p.team == 0) 1f else -1f
        bvx = inw * (80f + rnd.nextFloat() * 60f)
        bvy = (if (rnd.nextBoolean()) 1f else -1f) * (50f + rnd.nextFloat() * 60f)
        footOwner = null
        footOwnerT = 0f
        setMessage("ARRÊT !", 0.7f)
        sfx.addLast(1)
    }

    private fun throwKeeper(p: Player) {
        val inw = if (p.team == 0) 1f else -1f
        val q = passTarget(p, false)
        var dx = inw
        var dy = (rnd.nextFloat() - 0.5f) * 0.8f
        var spd = 170f
        if (q != null) {
            dx = q.x - p.x
            dy = q.y - p.y
            spd = min(200f, 110f + hyp(dx, dy) * 0.9f)
        }
        val l = max(0.001f, hyp(dx, dy))
        holder = null
        bz = 0f
        bx = p.x + inw * 7f
        by = p.y
        bvx = dx / l * spd
        bvy = dy / l * spd
        p.cool = 0.6f
        footOwner = p
        footOwnerT = 1.2f
        sfx.addLast(1)
    }

    // ----- IA des joueurs de champ -----

    private fun thinkFoot(p: Player, a: Float) {
        val d = dir(p.team)
        val ownX = goalLineX(1 - p.team)
        val oppX = goalLineX(p.team)
        val h = holder
        val poss = footPossession()

        // rang du joueur parmi les joueurs de champ de son équipe (0 = le plus proche du ballon)
        var rank = 0
        val myD = dist2(p, bx, by)
        for (q in ps) {
            if (q.team != p.team || q === p || isKeeper(q)) continue
            if (dist2(q, bx, by) < myD) rank++
        }

        if (h != null) {
            // un gardien tient le ballon
            if (h.team == p.team) demarqueFoot(p, d, oppX, h.x, h.y) else markFoot(p, ownX)
            return
        }
        if (poss == p.team) {
            val o = footOwner
            if (o === p && hyp(bx - p.x, by - p.y) < 16f) {
                // porteur : il file vers le but en évitant l'adversaire qui se présente
                p.spotT = 0f
                p.tx = oppX
                p.ty = Court.CY + (by - Court.CY) * 0.35f
                val op = nearestOpp(p)
                if (hyp(op.x - p.x, op.y - p.y) < 22f && (op.x - p.x) * d > -4f) {
                    p.tx = p.x + d * 24f
                    p.ty = p.y + (if (op.y >= p.y) -36f else 36f)
                }
            } else {
                // coéquipier : il se démarque
                demarqueFoot(p, d, oppX, o?.x ?: bx, o?.y ?: by)
            }
            return
        }
        if (poss == -1 && rank > 0) {
            // ballon libre : un seul va le chercher, les autres s'écartent pour être disponibles
            demarqueFoot(p, d, oppX, bx, by)
            return
        }
        // ballon à l'adversaire (ou libre et je suis le plus proche)
        p.spotT = 0f
        when (rank) {
            0 -> {
                p.tx = bx + bvx * 0.25f
                p.ty = by + bvy * 0.25f
            }
            1 -> {
                p.tx = bx + (ownX - bx) * 0.3f
                p.ty = by + (Court.CY - by) * 0.3f
            }
            else -> markFoot(p, ownX)
        }
    }

    private fun demarqueFoot(p: Player, d: Float, oppX: Float, carrierX: Float, carrierY: Float) {
        // ballon qui arrive vers moi : je vais le chercher
        val db = hyp(bx - p.x, by - p.y)
        if (db < 40f && hyp(bvx, bvy) > 30f && (bvx * (p.x - bx) + bvy * (p.y - by)) > 0f) {
            p.tx = bx + bvx * 0.2f
            p.ty = by + bvy * 0.2f
            p.spotT = 0f
            return
        }
        val base = when (p.slot) {
            1 -> floatArrayOf(carrierX + d * 34f, Court.CY - 42f + (carrierY - Court.CY) * 0.3f)
            2 -> floatArrayOf(carrierX + d * 28f, Court.CY + 42f + (carrierY - Court.CY) * 0.3f)
            else -> floatArrayOf(oppX - d * 56f, Court.CY + (carrierY - Court.CY) * 0.3f)
        }
        demarque(p, carrierX, carrierY, base[0].coerceIn(48f, 272f), base[1].coerceIn(30f, 150f), 28f, 1f)
    }

    /** Marquage : se place côté but, entre son adversaire et sa propre cage. */
    private fun markFoot(p: Player, ownX: Float) {
        val opp = ps[(1 - p.team) * n + p.slot]
        p.spotT = 0f
        p.tx = opp.x + (ownX - opp.x) * 0.22f
        p.ty = opp.y + (Court.CY - opp.y) * 0.15f
    }

    private fun actFootAi(p: Player, a: Float) {
        if (p.cool > 0f) return
        if (holder != null) return
        val dball = hyp(bx - p.x, by - p.y)

        // tacle : le ballon est collé à un adversaire, face à moi
        if (p.aiGo2 && dball > 6f && dball < 24f && footPossession() != p.team) {
            for (q in ps) {
                if (q.team == p.team || isKeeper(q)) continue
                if (hyp(q.x - bx, q.y - by) < 11f && hyp(q.x - p.x, q.y - p.y) < 16f) {
                    p.third = true
                    return
                }
            }
        }
        if (dball > 10f) return
        val d = dir(p.team)
        val dg = abs(p.x - goalLineX(p.team))
        if (dg < 105f && p.aiGo && p.fx * d > 0.3f) {
            p.act = true
        } else if (p.aiGo2) {
            val near = nearestOppDist(p.x, p.y, p.team)
            if (near < 26f) p.pass = true
        }
    }

    private fun moveBallFoot(dt: Float, scoring: Boolean) {
        val r = Court.BALL_R
        val hk = holder
        if (hk != null) {
            // le gardien tient le ballon dans les mains
            val inw = if (hk.team == 0) 1f else -1f
            bx = hk.x + inw * 5f
            by = hk.y
            bz = 5f
            bvx = 0f; bvy = 0f
            return
        }
        bz = 0f
        val f = max(0f, 1f - 1.15f * dt)
        bvx *= f
        bvy *= f
        bx += bvx * dt
        by += bvy * dt

        // joueurs : poussent et conduisent le ballon
        for (p in ps) {
            // le gardien n'arrête pas les tirs « en dur » : ça passe par le jet d'arrêt
            if (isKeeper(p) && (hyp(bvx, bvy) > 60f || p.diveT > 0f)) continue
            val dx = bx - p.x
            val dy = by - p.y
            val d = hyp(dx, dy)
            if (d < 8f && d > 0.01f) {
                val nx = dx / d
                val ny = dy / d
                bx = p.x + nx * 8f
                by = p.y + ny * 8f
                val rel = (bvx - p.vx) * nx + (bvy - p.vy) * ny
                if (rel < 0f) {
                    bvx -= rel * nx * 1.45f
                    bvy -= rel * ny * 1.45f
                }
                bvx += p.vx * 0.1f
                bvy += p.vy * 0.1f
                if (p.tackT > 0f) {
                    bvx = p.tdx * 150f
                    bvy = p.tdy * 150f
                }
                footOwner = p
                footOwnerT = 1.2f
            }
        }

        // murs et filets
        val inMouth = by > Court.GOAL_Y0 && by < Court.GOAL_Y1
        if (by < Court.Y0 + r) { by = Court.Y0 + r; bvy = abs(bvy) * 0.8f }
        if (by > Court.Y1 - r) { by = Court.Y1 - r; bvy = -abs(bvy) * 0.8f }
        if (!inMouth) {
            if (bx < Court.X0 + r) { bx = Court.X0 + r; bvx = abs(bvx) * 0.8f }
            if (bx > Court.X1 - r) { bx = Court.X1 - r; bvx = -abs(bvx) * 0.8f }
        } else {
            if (bx < Court.X0 - Court.GOAL_D + r) { bx = Court.X0 - Court.GOAL_D + r; bvx = abs(bvx) * 0.2f }
            if (bx > Court.X1 + Court.GOAL_D - r) { bx = Court.X1 + Court.GOAL_D - r; bvx = -abs(bvx) * 0.2f }
        }
        if (bx < Court.X0 || bx > Court.X1) by = by.coerceIn(Court.GOAL_Y0 + r, Court.GOAL_Y1 - r)

        val sp = hyp(bvx, bvy)
        if (sp > 300f) { bvx *= 300f / sp; bvy *= 300f / sp }

        if (!scoring) return
        if (bx < Court.X0 - r) scoreFor(1, 1)
        else if (bx > Court.X1 + r) scoreFor(0, 1)
    }

    // ───────────────────────── BASKET ─────────────────────────

    private fun grab(q: Player) {
        holder = q
        flKind = 0
        flRolled.clear()
        q.cool = 0.3f
        sfx.addLast(1)
    }

    private fun actBasket(p: Player) {
        val h = holder
        p.actT = 0.25f
        if (p.pass) {
            if (h === p && p.windT <= 0f) passBasket(p) else p.cool = 0.12f
            return
        }
        if (h === p) {
            startShot(p)
            return
        }
        if (h != null && h.team != p.team) {
            val reach = if (isHuman(p)) (if (h.windT > 0f) 28f else if (p.def) 26f else 22f) else (if (h.windT > 0f) 16f else if (p.def) 14f else 11f)
            if (hyp(p.x - h.x, p.y - h.y) < reach) {
                if (h.windT > 0f) blockShot(p, h) else stealBall(p, h)
                return
            }
        }
        p.cool = 0.15f
    }

    /** Armé du tir : le tireur saute, le défenseur a un court instant pour le contrer. */
    private fun startShot(p: Player) {
        p.windT = 0.3f
        p.jumpT = 0.34f
        p.cool = 0.9f
        p.vx *= 0.3f
        p.vy *= 0.3f
    }

    private fun updateWindups(dt: Float) {
        for (p in ps) {
            if (p.windT <= 0f) continue
            if (holder !== p) { p.windT = 0f; continue }
            p.windT -= dt
            if (p.windT <= 0f) {
                p.windT = 0f
                shootBasket(p)
            }
        }
    }

    private fun stealBall(p: Player, h: Player) {
        var chance = if (isHuman(p)) 0.72f else 0.10f + 0.28f * aiOf(p)
        if (p.def) chance += 0.15f
        // par derrière (le porteur te tourne le dos) : bien plus facile
        val behind = (h.fx * (p.x - h.x) + h.fy * (p.y - h.y)) < 0f
        if (behind && isHuman(p)) chance += 0.15f
        p.cool = if (isHuman(p)) 0.3f else 0.7f
        if (rnd.nextFloat() < chance.coerceIn(0f, 0.95f)) {
            grab(p)
            setMessage("VOL !", 0.6f)
        }
    }

    private fun blockShot(p: Player, h: Player) {
        val dist = hyp(p.x - h.x, p.y - h.y)
        var chance = (if (isHuman(p)) 0.85f else 0.10f + 0.32f * aiOf(p)) * (1.2f - dist / 30f)
        if (p.def) chance += 0.12f
        p.cool = if (isHuman(p)) 0.35f else 0.7f
        p.jumpT = 0.3f
        if (rnd.nextFloat() < chance.coerceIn(0.05f, 0.95f)) {
            val dl = max(1f, dist)
            val nx = (p.x - h.x) / dl
            val ny = (p.y - h.y) / dl
            holder = null
            h.windT = 0f
            flKind = 0
            bvx = nx * 70f + (rnd.nextFloat() - 0.5f) * 60f
            bvy = ny * 70f + (rnd.nextFloat() - 0.5f) * 60f
            bz = 12f
            noGrabT = 0.3f
            setMessage("CONTRE !", 0.7f)
            sfx.addLast(1)
        }
    }

    /** Chance de marquer si p tire maintenant (0..1). */
    fun shotChance(p: Player): Float {
        val human = isHuman(p)
        val hx = hoopX(p.team)
        val dist = hyp(hx - p.x, Court.CY - p.y)
        var chance = 0.95f - 0.0058f * dist
        if (human) chance += 0.12f else chance *= 0.72f + 0.35f * aiOf(p)
        var near = 999f
        var nd: Player? = null
        for (q in ps) {
            if (q.team == p.team) continue
            val dd = hyp(q.x - p.x, q.y - p.y)
            if (dd < near) { near = dd; nd = q }
        }
        if (near < 12f) chance -= 0.22f else if (near < 20f) chance -= 0.10f
        if (nd != null && nd.def && near < 22f) chance -= 0.08f
        return chance.coerceIn(0.06f, 0.95f)
    }

    private fun shootBasket(p: Player) {
        val hx = hoopX(p.team)
        val dist = hyp(hx - p.x, Court.CY - p.y)
        val chance = shotChance(p)
        holder = null
        flKind = 2
        flT = 0f
        flDur = 0.5f + dist / 360f
        fsx = p.x; fsy = p.y
        fex = hx; fey = Court.CY
        flGood = rnd.nextFloat() < chance
        flPts = if (dist > Court.ARC) 3 else 2
        flTeam = p.team
        flTarget = null
        p.cool = 0.5f
        sfx.addLast(1)
    }

    private fun passBasket(p: Player) {
        val q = passTarget(p, isHuman(p))
        p.cool = 0.4f
        if (q == null) return
        val tx = q.x + q.vx * 0.2f
        val ty = q.y + q.vy * 0.2f
        val dl = hyp(tx - p.x, ty - p.y)
        holder = null
        flKind = 1
        flT = 0f
        flDur = 0.22f + dl / 520f
        fsx = p.x; fsy = p.y
        fex = tx; fey = ty
        flTarget = q
        flTeam = p.team
        flRolled.clear()
        sfx.addLast(1)
    }

    /** Meilleure place défensive : entre l'adversaire à garder et son panier. [x, y] */
    private fun defSpot(p: Player): FloatArray {
        val h = holder
        val own = hoopX(1 - p.team) // le panier que p défend
        val onBall = h != null && h.team != p.team
        val tgt: Player = if (onBall && h != null) h else nearestOpp(p)
        val gap = if (onBall) 9f else 15f
        val dx = own - tgt.x
        val dy = Court.CY - tgt.y
        val dl = max(1f, hyp(dx, dy))
        return floatArrayOf(tgt.x + dx / dl * gap, tgt.y + dy / dl * gap)
    }

    /** Défense assistée (bouton DÉF) : le joystick reste prioritaire en partie, le reste te place tout seul. */
    private fun applyDefAssist(p: Player) {
        val s = defSpot(p)
        val dx = s[0] - p.x
        val dy = s[1] - p.y
        val d = hyp(dx, dy)
        var ax = 0f
        var ay = 0f
        if (d > 2f) {
            val k = min(1f, d / 12f)
            ax = dx / d * k
            ay = dy / d * k
        }
        p.mx = (ax * 0.7f + p.mx * 0.5f).coerceIn(-1f, 1f)
        p.my = (ay * 0.7f + p.my * 0.5f).coerceIn(-1f, 1f)
    }

    private fun thinkBasket(p: Player, a: Float) {
        val h = holder
        val d = dir(p.team)
        val atkX = hoopX(p.team)
        val ownX = hoopX(1 - p.team)
        if (h == null) {
            // ballon libre ou en l'air
            if (flKind == 1 && flTarget === p) {
                p.spotT = 0f
                p.tx = fex
                p.ty = fey
                return
            }
            var rank = 0
            val myD = dist2(p, bx, by)
            for (q in ps) {
                if (q.team == p.team && q !== p && dist2(q, bx, by) < myD) rank++
            }
            if (rank == 0) {
                p.spotT = 0f
                p.tx = bx
                p.ty = by
            } else {
                val ref = ps.firstOrNull { it.team == p.team && it !== p } ?: p
                demarqueBasket(p, d, atkX, ref.x, ref.y)
            }
            return
        }
        if (h.team == p.team) {
            if (p === h) {
                p.spotT = 0f
                p.tx = atkX - d * 30f
                p.ty = Court.CY + (by - Court.CY) * 0.2f
            } else {
                demarqueBasket(p, d, atkX, h.x, h.y)
            }
            return
        }
        // défense : un presseur sur le porteur, les autres gardent un homme côté panier avec de l'aide
        p.spotT = 0f
        var presser: Player? = null
        var pd = 1e9f
        for (q in ps) {
            if (q.team != p.team) continue
            val dd = dist2(q, h.x, h.y)
            if (dd < pd) { pd = dd; presser = q }
        }
        if (p === presser) {
            val dx = ownX - h.x
            val dy = Court.CY - h.y
            val dl = max(1f, hyp(dx, dy))
            p.tx = h.x + dx / dl * 9f
            p.ty = h.y + dy / dl * 9f
        } else {
            var opp = ps[(1 - p.team) * n + p.slot]
            if (opp === h) opp = ps[(1 - p.team) * n + (p.slot + 1) % n]
            val dx = ownX - opp.x
            val dy = Court.CY - opp.y
            val dl = max(1f, hyp(dx, dy))
            var tx = opp.x + dx / dl * 14f
            var ty = opp.y + dy / dl * 14f
            if (hyp(opp.x - h.x, opp.y - h.y) > 70f) {
                // aide : son joueur est loin du ballon, on se rapproche de la raquette
                tx += (ownX - tx) * 0.18f
                ty += (Court.CY - ty) * 0.25f
            }
            p.tx = tx
            p.ty = ty
        }
    }

    private fun demarqueBasket(p: Player, d: Float, atkX: Float, carrierX: Float, carrierY: Float) {
        val side = when (p.slot) {
            0 -> -1f
            1 -> 0f
            else -> 1f
        }
        val bxx = atkX - d * (if (p.slot == 1) 52f else 70f)
        val byy = Court.CY + side * 46f + (carrierY - Court.CY) * 0.25f
        demarque(p, carrierX, carrierY, bxx, byy, 24f, 0.6f)
    }

    private fun actBasketAi(p: Player, a: Float) {
        if (p.cool > 0f) return
        val h = holder
        if (h === p) {
            if (p.windT > 0f) return
            val dist = hyp(hoopX(p.team) - p.x, Court.CY - p.y)
            val near = nearestOppDist(p.x, p.y, p.team)
            if (dist < 48f + 40f * a && p.aiGo && !(near < 13f && p.aiGo2)) p.act = true
            else if (near < 15f && p.aiGo2) p.pass = true
        } else if (h != null && h.team != p.team) {
            val dd = hyp(p.x - h.x, p.y - h.y)
            if (h.windT > 0f && dd < 16f && p.aiGo2) p.act = true // tentative de contre
            else if (dd < 10f && p.aiGo2) p.act = true // tentative de vol
        }
    }

    private fun moveBallBasket(dt: Float, scoring: Boolean) {
        val h = holder
        if (h != null) {
            bx = h.x + h.fx * 6f
            by = h.y + h.fy * 6f
            bz = if (h.windT > 0f) 14f + (0.3f - h.windT) * 50f else 3f + abs(sin(simTime * 9f)) * 7f
            bvx = 0f; bvy = 0f; bvz = 0f
            return
        }
        if (flKind != 0) {
            flT += dt
            val t = min(1f, flT / flDur)
            bx = fsx + (fex - fsx) * t
            by = fsy + (fey - fsy) * t
            bz = (if (flKind == 2) 30f else 7f) * sin(t * 3.14159f) + 6f
            if (flKind == 1 && scoring) {
                for (q in ps) {
                    if (q.team == flTeam) continue
                    if (t > 0.12f && t < 0.92f && hyp(q.x - bx, q.y - by) < 9f && flRolled.add(q)) {
                        val chance = if (isHuman(q)) 0.55f + (if (q.def) 0.2f else 0f) else 0.18f + 0.4f * aiOf(q)
                        if (rnd.nextFloat() < chance) {
                            grab(q)
                            setMessage("INTERCEPTÉ !", 0.7f)
                            return
                        }
                    }
                }
            }
            if (t >= 1f) arrive(scoring)
            return
        }
        // ballon libre
        val f = max(0f, 1f - 2.2f * dt)
        bvx *= f
        bvy *= f
        bx += bvx * dt
        by += bvy * dt
        bz = max(0f, bz - 30f * dt)
        val r = Court.BALL_R
        if (bx < Court.X0 + r) { bx = Court.X0 + r; bvx = abs(bvx) * 0.6f }
        if (bx > Court.X1 - r) { bx = Court.X1 - r; bvx = -abs(bvx) * 0.6f }
        if (by < Court.Y0 + r) { by = Court.Y0 + r; bvy = abs(bvy) * 0.6f }
        if (by > Court.Y1 - r) { by = Court.Y1 - r; bvy = -abs(bvy) * 0.6f }
        if (scoring && noGrabT <= 0f) {
            var best: Player? = null
            var bd = 49f
            for (q in ps) {
                val dd = dist2(q, bx, by)
                if (dd < bd) { bd = dd; best = q }
            }
            if (best != null) grab(best)
        }
    }

    private fun arrive(scoring: Boolean) {
        val kind = flKind
        flKind = 0
        if (kind == 1) {
            val q = flTarget
            if (q != null && hyp(q.x - bx, q.y - by) < 16f) {
                grab(q)
            } else {
                bvx = 0f; bvy = 0f
            }
            return
        }
        // tir
        if (flGood && scoring) {
            scoreFor(flTeam, flPts)
            bz = 0f
        } else {
            val away = if (fex < 160f) 1f else -1f
            bvx = away * (40f + rnd.nextFloat() * 50f)
            bvy = (rnd.nextFloat() - 0.5f) * 90f
            bz = 6f
            noGrabT = 0.25f
            sfx.addLast(1)
        }
    }

    // ───────────────────────── VOLLEY (3 touches) ─────────────────────────

    private fun sideOfBall(): Int = if (bx < Court.NET_X) 0 else 1

    private fun mateOf(p: Player): Player? = ps.firstOrNull { it.team == p.team && it !== p }

    /** Peut-il toucher le ballon maintenant ? (3 touches max, pas deux fois de suite le même joueur) */
    private fun canTouch(p: Player): Boolean {
        if (vServe) return p.team == vServeTeam && p.slot == 1
        if (sideOfBall() != p.team) return false
        if (vTouches >= 3) return false
        if (vTouches > 0 && p === vLast) return false
        return true
    }

    /** Pourra-t-il toucher le ballon quand il arrivera (utile pour anticiper, ballon encore de l'autre côté) ? */
    private fun eligibleNext(q: Player): Boolean {
        if (vServe) return q.team == vServeTeam && q.slot == 1
        if (sideOfBall() != q.team) return true // le compteur sera remis à zéro au passage du filet
        return vTouches < 3 && !(vTouches > 0 && q === vLast)
    }

    /** Point de l'espace où le ballon passera à portée de main (z <= REACH_Z) : [x, y]. */
    private fun meet(): FloatArray {
        val g = 150f
        val groundT = (bvz + sqrt(bvz * bvz + 2f * g * max(0f, bz))) / g
        val disc = bvz * bvz + 2f * g * (bz - REACH_Z)
        val t = when {
            bz <= REACH_Z && bvz <= 0f -> min(groundT, 0.18f)
            disc >= 0f -> (bvz + sqrt(disc)) / g
            else -> groundT
        }
        val tt = max(0f, t)
        return floatArrayOf(bx + bvx * tt, by + bvy * tt)
    }

    /** Point d'atterrissage prévu du ballon : [x, y]. */
    fun landing(): FloatArray {
        val g = 150f
        val disc = bvz * bvz + 2f * g * max(0f, bz)
        val t = (bvz + sqrt(disc)) / g
        return floatArrayOf(bx + bvx * max(0f, t), by + bvy * max(0f, t))
    }

    private fun volleyReach(p: Player): Boolean {
        if (!canTouch(p)) return false
        val rr = when {
            vServeRecv && p.team != lastTouch -> 30f // réception du service : grande portée
            vTouches == 0 && !vServe && hyp(bvx, bvy) > 150f -> 22f
            else -> 18f
        }
        return hyp(bx - p.x, by - p.y) < rr && bz < REACH_Z
    }

    private fun chooseVolley() {
        val m = meet()
        val side = if (vServe) vServeTeam else if (m[0] < Court.NET_X) 0 else 1
        if (side != 0) return
        var best = -1
        var bd = 1e9f
        for (i in 0 until n) {
            if (!eligibleNext(ps[i])) continue
            val d = dist2(ps[i], m[0], m[1])
            if (d < bd) { bd = d; best = i }
        }
        if (best < 0 || best == ctrl) return
        val cur = ps[ctrl]
        if (!eligibleNext(cur) || (switchT <= 0f && dist2(cur, m[0], m[1]) - 80f > bd)) {
            ctrl = best
            switchT = 0.3f
        }
    }

    /** Type de touche que le joueur va faire. */
    private fun volleyPlan(p: Player, human: Boolean): Int {
        if (vServe) return PLAN_SERVE
        if (vTouches >= 2) return PLAN_SMASH
        // un seul bouton : l'enchaînement est automatique (réception → passe → smash)
        if (human) return if (vTouches == 0) PLAN_BUMP else PLAN_SET
        // les bots reçoivent toujours le service proprement vers leur coéquipier
        if (vServeRecv && p.team != lastTouch) return PLAN_BUMP
        val mate = mateOf(p)
        val over = if (mate == null) true else {
            val s = setSpot(p, mate, if (vTouches == 0) PLAN_BUMP else PLAN_SET)
            hyp(mate.x - s[0], mate.y - s[1]) > 75f // le coéquipier est trop loin : on renvoie
        }
        if (over) return PLAN_OVER
        return if (vTouches == 0) PLAN_BUMP else PLAN_SET
    }

    /** Où envoyer la passe (réception → passeur, passe → attaquant) : près du filet, à la hauteur du coéquipier. */
    private fun setSpot(p: Player, mate: Player, stage: Int): FloatArray {
        val d = dir(p.team)
        val sx = Court.NET_X - d * (if (stage == PLAN_BUMP) 36f else 30f)
        val sy = mate.y.coerceIn(Court.VY0 + 16f, Court.VY1 - 16f)
        return floatArrayOf(sx, sy)
    }

    /** Qualité du smash selon la hauteur du ballon au moment de la frappe (cercle de timing). */
    private fun smashQuality(z: Float): Float {
        if (z < 12f) return 0.1f
        val e = abs(z - SMASH_Z)
        return when {
            e <= 4f -> 1f
            e <= 8f -> 0.6f
            e <= 13f -> 0.3f
            else -> 0.12f
        }
    }

    /** Hauteur idéale du ballon selon le type de touche. */
    private fun idealZ(plan: Int): Float = if (plan == PLAN_SMASH) SMASH_Z else PASS_Z

    /** Qualité de la touche (0..1) selon la hauteur du ballon quand on appuie : cercle de timing. */
    private fun touchQuality(plan: Int, z: Float): Float {
        if (plan == PLAN_SMASH) return smashQuality(z)
        val e = abs(z - PASS_Z)
        return when {
            e <= 4f -> 1f
            e <= 8f -> 0.6f
            e <= 13f -> 0.3f
            else -> 0.15f
        }
    }

    /** Vrai quand le joueur piloté doit viser le bon moment : le jeu passe alors au ralenti. */
    private fun humanTiming(): Boolean {
        if (sport != Sport.VOLLEY || phase != Phase.PLAY || vServe) return false
        val p = ps[ctrl]
        if (p.team != 0 || !canTouch(p)) return false
        return bvz < 0f && bz < 80f && hyp(bx - p.x, by - p.y) < 50f
    }

    private fun actVolley(p: Player) {
        p.actT = 0.25f
        if (volleyReach(p)) {
            hitVolley(p)
        } else {
            // trop tôt : en phase d'attaque, on ne peut pas matraquer le bouton
            val attackWindow = !vServe && vTouches >= 2 && canTouch(p)
            if (!attackWindow && !vServe && isHuman(p) && canTouch(p)) {
                vBuf = 0.2f
                p.cool = 0.03f
            } else {
                p.cool = if (attackWindow) 0.5f else 0.2f
            }
            p.jumpT = 0.3f
        }
    }

    /** Cible conseillée d'une frappe de volley : [x, y]. Le joystick oriente (côté, court / long). */
    fun volleyTarget(p: Player): FloatArray {
        val d = dir(p.team)
        val x0 = if (p.team == 0) Court.NET_X + 22f else Court.VX0 + 8f
        val x1 = if (p.team == 0) Court.VX1 - 8f else Court.NET_X - 22f
        val y0 = Court.VY0 + 8f
        val y1 = Court.VY1 - 8f
        val human = isHuman(p)
        var tx = (x0 + x1) / 2f
        var ty = Court.CY
        var bs = -1e9f
        for (a in 0..5) {
            for (b in 0..5) {
                val cx = x0 + (x1 - x0) * a / 5f
                val cy = y0 + (y1 - y0) * b / 5f
                var sc = 1e9f
                for (q in ps) if (q.team != p.team) sc = min(sc, hyp(q.x - cx, q.y - cy))
                if (human) {
                    if (hyp(p.mx, p.my) > 0.3f) sc -= abs(cy - (Court.CY + p.my * 50f)) * 1.2f
                    if (p.mx * d > 0.5f) sc -= abs(cx - (Court.NET_X + d * 32f)) * 0.9f
                    else if (p.mx * d < -0.5f) sc -= abs(cx - (if (p.team == 0) x1 else x0)) * 0.9f
                }
                if (sc > bs) { bs = sc; tx = cx; ty = cy }
            }
        }
        return floatArrayOf(tx, ty)
    }

    private fun hitVolley(p: Player) {
        val human = isHuman(p)
        val a = if (human) 1f else aiOf(p)
        val plan = volleyPlan(p, human)
        val g = 150f
        var tx: Float
        var ty: Float
        var t: Float
        var zt = 0f
        var margin = 5f
        var crosses = true
        var smash = false

        when (plan) {
            PLAN_BUMP, PLAN_SET -> {
                val mate = mateOf(p)
                val spot = if (mate != null) setSpot(p, mate, plan)
                else floatArrayOf(Court.NET_X - dir(p.team) * 34f, Court.CY)
                // cercle de timing : bon timing = passe précise, mauvais timing = passe qui dérive
                val q = if (human) touchQuality(plan, bz) else 1f
                val base = when {
                    human -> 2f + (1f - q) * 22f
                    vServeRecv -> 3f
                    else -> 4f + (1f - a) * 16f
                }
                val err = base + min(8f, hyp(bvx, bvy) * 0.03f)
                tx = spot[0] + (rnd.nextFloat() - 0.5f) * 2f * err
                ty = spot[1] + (rnd.nextFloat() - 0.5f) * 2f * err
                crosses = false
                if (plan == PLAN_BUMP) { t = 1.0f; zt = 22f } else { t = 0.9f; zt = 30f }
                if (human) {
                    val m = when {
                        q >= 1f -> "PASSE PARFAITE !"
                        q >= 0.6f -> "BONNE PASSE"
                        bz > PASS_Z -> "TROP TÔT"
                        else -> "TROP TARD"
                    }
                    setMessage(m, 0.8f)
                }
            }
            PLAN_SMASH -> {
                val q = smashQuality(bz)
                smash = bz > 18f
                val tg = volleyTarget(p)
                val err = if (human) 3f + (1f - q) * 26f else 4f + (1f - a) * 12f + (1f - q) * 22f
                tx = tg[0] + (rnd.nextFloat() - 0.5f) * 2f * err
                ty = tg[1] + (rnd.nextFloat() - 0.5f) * 2f * err
                if (smash) {
                    t = 0.62f + (1f - q) * 0.30f // smash moins violent
                    margin = 2f
                } else {
                    t = 1.1f
                }
                if (human && smash) {
                    val m = when {
                        q >= 1f -> "SMASH PARFAIT !"
                        q >= 0.6f -> "BON SMASH"
                        bz > SMASH_Z -> "TROP TÔT"
                        else -> "TROP TARD"
                    }
                    setMessage(m, 0.8f)
                }
            }
            else -> {
                val tg = volleyTarget(p)
                val err = if (human) 3f else 4f + (1f - a) * 26f
                tx = tg[0] + (rnd.nextFloat() - 0.5f) * 2f * err
                ty = tg[1] + (rnd.nextFloat() - 0.5f) * 2f * err
                t = if (plan == PLAN_SERVE) 1.25f else 1.15f
            }
        }

        var vx = 0f
        var vy = 0f
        var vz = 0f
        var guard = 0
        while (true) {
            vx = (tx - bx) / t
            vy = (ty - by) / t
            vz = (zt - bz + 0.5f * g * t * t) / t
            var ok = true
            if (crosses && abs(vx) > 1f) {
                val tn = (Court.NET_X - bx) / vx
                if (tn > 0f && tn < t) {
                    val zn = bz + vz * tn - 0.5f * g * tn * tn
                    ok = zn > Court.NET_H + margin
                }
            }
            guard++
            if (ok || guard > 24) break
            t += 0.07f
        }
        bvx = vx
        bvy = vy
        bvz = vz

        lastTouch = p.team
        if (vServe) {
            vServe = false
            vHold = false
            vTouches = 0
            vServeRecv = true // le service est parti : l'équipe adverse est aidée pour le rattraper
        } else {
            vTouches++
            vServeRecv = false
        }
        vLast = p
        p.cool = 0.3f
        p.jumpT = if (smash) 0.45f else if (plan == PLAN_SET) 0.25f else 0.2f
        switchT = 0f
        sfx.addLast(1)
    }

    private fun voHome(p: Player): FloatArray {
        val d = dir(p.team)
        return if (p.slot == 0) floatArrayOf(Court.NET_X - d * 54f, Court.CY - 28f)
        else floatArrayOf(Court.NET_X - d * 104f, Court.CY + 28f)
    }

    private fun thinkVolley(p: Player, a: Float) {
        val home = voHome(p)
        val d = dir(p.team)
        val m = meet()
        val side = if (vServe) vServeTeam else if (m[0] < Court.NET_X) 0 else 1
        if (side != p.team) {
            // le ballon va de l'autre côté : retour en position
            p.tx = home[0]
            p.ty = home[1] + (by - Court.CY) * 0.2f
            return
        }
        // qui prend le ballon ? le joueur éligible qui arrive le premier (toi compris)
        var taker: Player? = null
        var best = 1e9f
        for (q in ps) {
            if (q.team != p.team || !eligibleNext(q)) continue
            val dd = hyp(q.x - m[0], q.y - m[1]) / max(40f, speedOf(q))
            if (dd < best) { best = dd; taker = q }
        }
        if (p === taker) {
            val jit = if (vServeRecv) 0f else (1f - a) * 20f
            p.tx = m[0] + (rnd.nextFloat() - 0.5f) * jit
            p.ty = m[1] + (rnd.nextFloat() - 0.5f) * jit
            if (!vServe && vTouches >= 2) {
                p.trigZ = SMASH_Z + 1f + (rnd.nextFloat() - 0.5f) * 2f * (1f - a) * 18f
            }
        } else if (vLast === p && vTouches == 1 && !vServe) {
            // je viens de réceptionner : je m'élance vers le filet pour attaquer la passe
            p.tx = Court.NET_X - d * 30f
            p.ty = p.y.coerceIn(Court.VY0 + 16f, Court.VY1 - 16f)
        } else if (vLast === p && !vServe) {
            p.tx = home[0]
            p.ty = home[1]
        } else {
            // zone de passe, près du filet
            p.tx = Court.NET_X - d * 36f
            p.ty = Court.CY + (if (p.slot == 0) -26f else 26f)
        }
    }

    private fun actVolleyAi(p: Player) {
        if (p.cool > 0f) return
        if (!volleyReach(p)) return
        when (volleyPlan(p, false)) {
            PLAN_SMASH -> if (bvz < 0f && bz <= p.trigZ) p.act = true
            PLAN_SERVE -> if (vHold && vHoldT <= 0f) p.act = true
            else -> if (bz < 26f && (p.aiGo || bz < 12f || vServeRecv)) p.act = true
        }
    }

    private fun moveBallVolley(dt: Float, scoring: Boolean) {
        if (vHold) {
            // le serveur tient le ballon : il ne tombe pas, aucun point perdu avant le service
            val sv = ps[vServeTeam * n + 1]
            bx = sv.x + dir(vServeTeam) * 6f
            by = sv.y
            bz = 14f
            bvx = 0f; bvy = 0f; bvz = 0f
            return
        }
        val g = 150f
        val px = bx
        bvz -= g * dt
        bx += bvx * dt
        by += bvy * dt
        bz += bvz * dt

        // filet
        if ((px - Court.NET_X) * (bx - Court.NET_X) < 0f) {
            if (by > Court.VY0 - 10f && by < Court.VY1 + 10f && bz < Court.NET_H) {
                bx = if (px < Court.NET_X) Court.NET_X - 2f else Court.NET_X + 2f
                bvx = -bvx * 0.25f
                bvy *= 0.5f
                bvz = min(bvz, 0f)
                if (scoring) {
                    setMessage("FILET !", 1.2f)
                    scoreFor(1 - lastTouch, 1)
                }
            } else {
                // le ballon passe de l'autre côté : le décompte des touches repart à zéro
                vTouches = 0
                vLast = null
            }
        }
        if (bz <= 0f) {
            bz = 0f
            if (scoring) {
                val inb = bx >= Court.VX0 && bx <= Court.VX1 && by >= Court.VY0 && by <= Court.VY1
                val winner = if (inb) (if (bx < Court.NET_X) 1 else 0) else 1 - lastTouch
                scoreFor(winner, 1)
            }
            if (bvz < -25f) bvz = -bvz * 0.35f else bvz = 0f
            bvx *= 0.7f
            bvy *= 0.7f
        }
        if (bx < 4f) { bx = 4f; bvx = abs(bvx) * 0.5f }
        if (bx > Court.W - 4f) { bx = Court.W - 4f; bvx = -abs(bvx) * 0.5f }
        if (by < 4f) { by = 4f; bvy = abs(bvy) * 0.5f }
        if (by > Court.H - 4f) { by = Court.H - 4f; bvy = -abs(bvy) * 0.5f }
    }

    // ───────────────────────── ballon ─────────────────────────

    private fun moveBall(dt: Float, scoring: Boolean) {
        when (sport) {
            Sport.FOOT -> moveBallFoot(dt, scoring)
            Sport.BASKET -> moveBallBasket(dt, scoring)
            Sport.VOLLEY -> moveBallVolley(dt, scoring)
        }
    }

    // ───────────────────────── aide à la visée (affichage) ─────────────────────────

    /** Cible conseillée pour le joueur piloté : [x, y, force 0..1] ou null s'il n'y a rien à viser. */
    fun aimHint(): FloatArray? {
        if (phase != Phase.PLAY) return null
        val p = ps[ctrl]
        return when (sport) {
            Sport.FOOT ->
                if (holder != null || hyp(bx - p.x, by - p.y) > 14f) null else footShotTarget(p, true)
            Sport.BASKET ->
                if (holder !== p) null else floatArrayOf(hoopX(0), Court.CY, shotChance(p))
            Sport.VOLLEY ->
                if (!canTouch(p) || hyp(bx - p.x, by - p.y) > 48f) {
                    null
                } else {
                    val plan = volleyPlan(p, true)
                    val mate = mateOf(p)
                    val tg = if ((plan == PLAN_BUMP || plan == PLAN_SET) && mate != null) {
                        setSpot(p, mate, plan)
                    } else {
                        volleyTarget(p)
                    }
                    floatArrayOf(tg[0], tg[1], 1f)
                }
        }
    }

    /**
     * Cercle de timing du volley (réception, passe et smash) : [x, y, rayon, qualité 0..1] ou null.
     * Le jeu passe au ralenti ; le cercle se resserre autour du ballon : frappe quand il touche l'anneau doré (rayon 5).
     */
    fun smashRing(): FloatArray? {
        if (sport != Sport.VOLLEY || phase != Phase.PLAY || vServe) return null
        val p = ps[ctrl]
        if (p.team != 0 || !canTouch(p)) return null
        if (hyp(bx - p.x, by - p.y) > 70f) return null
        val plan = volleyPlan(p, true)
        val rad = if (bvz > 0f) 35f else (5f + (bz - idealZ(plan)) * 0.9f).coerceIn(1.5f, 35f)
        return floatArrayOf(bx, by - bz * 0.6f, rad, touchQuality(plan, bz))
    }
}
