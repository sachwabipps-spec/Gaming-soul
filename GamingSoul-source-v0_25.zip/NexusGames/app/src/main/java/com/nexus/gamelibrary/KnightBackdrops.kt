package com.nexus.gamelibrary

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import java.util.concurrent.atomic.AtomicReferenceArray
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ════════════════════════════════════════════════════════════════
//  Chevalier : fonds peints (images) par monde, avec profondeur
//  Un monde sans image (null) garde le décor dessiné en code (KnightScenery).
// ════════════════════════════════════════════════════════════════

internal object KnightBg {
    // Plusieurs fonds par monde : on change tous les 10 niveaux (donc à chaque boss).
    // Monde : Prairie, Forêt sombre, Grottes, Marais, Désert, Neige, Cristal, Cimetière, Volcan, Ruines, Cité, Château, Abysses
    private val RES: Array<IntArray> = arrayOf(
        intArrayOf(R.drawable.kbg_w0_0, R.drawable.kbg_w0_1, R.drawable.kbg_w0_2),
        intArrayOf(R.drawable.kbg_w1_0, R.drawable.kbg_w1_1, R.drawable.kbg_w1_2, R.drawable.kbg_w1_3),
        intArrayOf(R.drawable.kbg_w2_0, R.drawable.kbg_w2_1, R.drawable.kbg_w2_2, R.drawable.kbg_w2_3),
        intArrayOf(R.drawable.kbg_w3_0, R.drawable.kbg_w3_1, R.drawable.kbg_w3_2),
        intArrayOf(R.drawable.kbg_w4_0),
        intArrayOf(R.drawable.kbg_w5_0, R.drawable.kbg_w5_1, R.drawable.kbg_w5_2),
        intArrayOf(R.drawable.kbg_w6_0, R.drawable.kbg_w6_1, R.drawable.kbg_w6_2, R.drawable.kbg_w6_3),
        intArrayOf(R.drawable.kbg_w7_0, R.drawable.kbg_w7_1),
        intArrayOf(R.drawable.kbg_w8_0, R.drawable.kbg_w8_1, R.drawable.kbg_w8_2, R.drawable.kbg_w8_3),
        intArrayOf(R.drawable.kbg_w9_0, R.drawable.kbg_w9_1, R.drawable.kbg_w9_2),
        intArrayOf(R.drawable.kbg_w10_0, R.drawable.kbg_w10_1, R.drawable.kbg_w10_2),
        intArrayOf(R.drawable.kbg_w11_0, R.drawable.kbg_w11_1, R.drawable.kbg_w11_2, R.drawable.kbg_w11_3),
        intArrayOf(R.drawable.kbg_w12_0, R.drawable.kbg_w12_1)
    )

    // un emplacement de cache par (monde, variante)
    private val base = IntArray(RES.size).also { var n = 0; for (i in RES.indices) { it[i] = n; n += RES[i].size } }
    private val cache = AtomicReferenceArray<ImageBitmap?>(RES.sumOf { it.size })

    /** Variante du fond pour un niveau : 0..n-1, change tous les 10 niveaux. */
    private fun variantOf(wi: Int, level: Int): Int {
        val n = RES[wi].size
        return ((((level - 1) % KN.PER_WORLD) + KN.PER_WORLD) % KN.PER_WORLD / 10) % n
    }

    /** Charge le fond du niveau [level] (monde [wi]) hors du thread principal. Sans effet si déjà chargé. */
    suspend fun ensure(ctx: Context, wi: Int, level: Int) {
        if (wi !in RES.indices) return
        val v = variantOf(wi, level)
        val slot = base[wi] + v
        if (cache.get(slot) != null) return
        withContext(Dispatchers.Default) {
            try {
                val bmp = BitmapFactory.decodeResource(ctx.resources, RES[wi][v])
                if (bmp != null) cache.set(slot, bmp.asImageBitmap())
            } catch (_: Throwable) {
            }
        }
    }

    fun get(wi: Int, level: Int): ImageBitmap? =
        if (wi in RES.indices) cache.get(base[wi] + variantOf(wi, level)) else null
}

private val NAVY_TOP = Color(0xFF05050E)
private val NAVY_BOT = Color(0xFF0B0B1C)

/** Mondes dont l'image est claire : on les assombrit moins pour garder leurs couleurs. */
private fun isBrightWorld(wi: Int) = wi == 4 || wi == 5 || wi == 8

/**
 * Dessine l'image en bandes répétées (une sur deux inversée pour que les raccords soient invisibles).
 * Elle défile lentement avec la caméra : les lointains bougent moins vite que le terrain.
 */
internal fun DrawScope.drawPhotoBackdrop(img: ImageBitmap, wi: Int, w: KWorld, cx: Float, cy: Float, s: Float, frame: Int) {
    drawRect(Brush.verticalGradient(listOf(NAVY_TOP, NAVY_BOT)), Offset.Zero, size)

    val yb = (11.5f - cy * 0.8f - 0.7f) * s       // bas du décor : suit la caméra comme les décors dessinés
    val dh = size.height * 0.88f
    val dw = dh * img.width / img.height
    val top = yb - dh
    val off = cx * 0.16f * s + frame * 0.04f      // parallaxe + lente dérive
    val first = floor(off / dw).toInt() - 1
    val last = first + (size.width / dw).toInt() + 3
    val src = IntSize(img.width, img.height)
    val dsz = IntSize(ceil(dw).toInt() + 1, ceil(dh).toInt())
    for (i in first..last) {
        val x = i * dw - off
        val dst = IntOffset(floor(x).toInt(), floor(top).toInt())
        if (((i % 2) + 2) % 2 == 1) {
            scale(-1f, 1f, pivot = Offset(x + dw / 2f, 0f)) {
                drawImage(img, IntOffset.Zero, src, dst, dsz)
            }
        } else {
            drawImage(img, IntOffset.Zero, src, dst, dsz)
        }
    }

    // raccord avec le haut et le bas de l'image
    val fadeTop = dh * 0.18f
    drawRect(Brush.verticalGradient(listOf(NAVY_TOP, Color.Transparent), startY = top, endY = top + fadeTop), Offset(0f, top), Size(size.width, fadeTop))
    val fadeBot = dh * 0.22f
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, NAVY_BOT), startY = yb - fadeBot, endY = yb),
        Offset(0f, yb - fadeBot), Size(size.width, fadeBot)
    )
    if (yb < size.height) drawRect(NAVY_BOT, Offset(0f, yb), Size(size.width, max(0f, size.height - yb)))

    // ambiance : teinte du monde + léger assombrissement pour que les ennemis restent lisibles
    val bright = isBrightWorld(wi)
    if (!bright) drawRect(Color(w.sky2).copy(alpha = 0.04f), Offset.Zero, size)
    drawRect(Color(0xFF02020A).copy(alpha = if (bright) 0.04f else 0.10f), Offset.Zero, size)
}
