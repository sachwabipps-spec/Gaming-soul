package com.nexus.gamelibrary

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Sauvegarde locale des réglages (thème, colonnes, jeux ajoutés/retirés, derniers lancés). */
class Store(context: Context) {
    private val sp = context.getSharedPreferences("nexus_games", Context.MODE_PRIVATE)

    var themeIndex: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    var columns: Int
        get() = sp.getInt("columns", 2)
        set(v) = sp.edit().putInt("columns", v).apply()

    var sortRecent: Boolean
        get() = sp.getBoolean("sortRecent", true)
        set(v) = sp.edit().putBoolean("sortRecent", v).apply()

    /** Bouton flottant Nexus affiché au lancement d'un jeu. */
    var assistant: Boolean
        get() = sp.getBoolean("assistant", true)
        set(v) = sp.edit().putBoolean("assistant", v).apply()

    /** Applis ajoutées à la main à la bibliothèque. */
    var pinned: Set<String>
        get() = HashSet(sp.getStringSet("pinned", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("pinned", HashSet(v)).apply()

    /** Jeux retirés de la bibliothèque. */
    var hidden: Set<String>
        get() = HashSet(sp.getStringSet("hidden", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("hidden", HashSet(v)).apply()

    /** Jeux marqués en favoris (cœur). */
    var favorites: Set<String>
        get() = HashSet(sp.getStringSet("favorites", emptySet()) ?: emptySet())
        set(v) = sp.edit().putStringSet("favorites", HashSet(v)).apply()

    fun lastLaunch(pkg: String): Long = sp.getLong("last_$pkg", 0L)

    fun markLaunched(pkg: String) {
        sp.edit().putLong("last_$pkg", System.currentTimeMillis()).apply()
    }

    /** Flou de la photo de fond (0..100). */
    var bgBlur: Int
        get() = sp.getInt("bgBlur", 60)
        set(v) = sp.edit().putInt("bgBlur", v).apply()

    /** Viseur affiché par-dessus les jeux. */
    var crosshairOn: Boolean
        get() = sp.getBoolean("ch_on", false)
        set(v) = sp.edit().putBoolean("ch_on", v).apply()

    var crosshair: Crosshair
        get() {
            val d = Crosshair()
            return Crosshair(
                color = sp.getInt("ch_color", d.color),
                outline = sp.getBoolean("ch_outline", d.outline),
                outlineOpacity = sp.getInt("ch_outlineOpacity", d.outlineOpacity),
                outlineThick = sp.getInt("ch_outlineThick", d.outlineThick),
                dot = sp.getBoolean("ch_dot", d.dot),
                dotOpacity = sp.getInt("ch_dotOpacity", d.dotOpacity),
                dotSize = sp.getInt("ch_dotSize", d.dotSize),
                innerOn = sp.getBoolean("ch_innerOn", d.innerOn),
                innerOpacity = sp.getInt("ch_innerOpacity", d.innerOpacity),
                innerLen = sp.getInt("ch_innerLen", d.innerLen),
                innerThick = sp.getInt("ch_innerThick", d.innerThick),
                innerOffset = sp.getInt("ch_innerOffset", d.innerOffset),
                outerOn = sp.getBoolean("ch_outerOn", d.outerOn),
                outerOpacity = sp.getInt("ch_outerOpacity", d.outerOpacity),
                outerLen = sp.getInt("ch_outerLen", d.outerLen),
                outerThick = sp.getInt("ch_outerThick", d.outerThick),
                outerOffset = sp.getInt("ch_outerOffset", d.outerOffset),
                offsetX = sp.getInt("ch_offsetX", d.offsetX),
                offsetY = sp.getInt("ch_offsetY", d.offsetY)
            )
        }
        set(c) {
            sp.edit()
                .putInt("ch_color", c.color)
                .putBoolean("ch_outline", c.outline)
                .putInt("ch_outlineOpacity", c.outlineOpacity)
                .putInt("ch_outlineThick", c.outlineThick)
                .putBoolean("ch_dot", c.dot)
                .putInt("ch_dotOpacity", c.dotOpacity)
                .putInt("ch_dotSize", c.dotSize)
                .putBoolean("ch_innerOn", c.innerOn)
                .putInt("ch_innerOpacity", c.innerOpacity)
                .putInt("ch_innerLen", c.innerLen)
                .putInt("ch_innerThick", c.innerThick)
                .putInt("ch_innerOffset", c.innerOffset)
                .putBoolean("ch_outerOn", c.outerOn)
                .putInt("ch_outerOpacity", c.outerOpacity)
                .putInt("ch_outerLen", c.outerLen)
                .putInt("ch_outerThick", c.outerThick)
                .putInt("ch_outerOffset", c.outerOffset)
                .putInt("ch_offsetX", c.offsetX)
                .putInt("ch_offsetY", c.offsetY)
                .apply()
        }

    /** Mode Arcade : étoiles (0..3) de chaque niveau des 3 carrières (foot, volley, basket), "0,3,2,...". */
    fun arcadeStars(): IntArray {
        val parts = (sp.getString("arcade2_stars", "") ?: "").split(",")
        return IntArray(Career.levels.size) { parts.getOrNull(it)?.toIntOrNull() ?: 0 }
    }

    fun setArcadeStars(level: Int, stars: Int) {
        val a = arcadeStars()
        if (level !in a.indices || stars <= a[level]) return
        a[level] = stars
        sp.edit().putString("arcade2_stars", a.joinToString(",")).apply()
    }

    /** Remet à zéro la carrière d'un seul sport (les autres carrières restent intactes). */
    fun resetArcade(sport: Sport) {
        val a = arcadeStars()
        for (lv in Career.of(sport)) a[lv.index] = 0
        sp.edit().putString("arcade2_stars", a.joinToString(",")).apply()
    }

    /** Vue 3D (perspective façon FIFA Mobile) pour le foot et le basket. */
    var arcade3d: Boolean
        get() = sp.getBoolean("arcade_3d", true)
        set(v) = sp.edit().putBoolean("arcade_3d", v).apply()

    var arcadeSound: Boolean
        get() = sp.getBoolean("arcade_sound", true)
        set(v) = sp.edit().putBoolean("arcade_sound", v).apply()

    /** Historique du Helper : questions envoyées à ChatGPT + réponses collées. */
    var helperLog: List<HelperEntry>
        get() = try {
            val arr = JSONArray(sp.getString("helper_log", "[]") ?: "[]")
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                HelperEntry(o.optString("q"), o.optString("a"), o.optLong("t"))
            }
        } catch (e: Exception) {
            emptyList()
        }
        set(v) {
            val arr = JSONArray()
            v.take(50).forEach {
                val o = JSONObject()
                o.put("q", it.q)
                o.put("a", it.a)
                o.put("t", it.t)
                arr.put(o)
            }
            sp.edit().putString("helper_log", arr.toString()).apply()
        }

    /** Total d'étoiles de toutes les carrières : débloque les cosmétiques. */
    fun totalStars(): Int = arcadeStars().sum()

    /** Apparence du joueur en Arcade. */
    var skin: Skin
        get() = Skin.decode(sp.getString("arcade_skin", null))
        set(v) = sp.edit().putString("arcade_skin", v.sanitized().encode()).apply()

    /** Sports dont le tutoriel a déjà été vu (ou "general"). */
    fun tutoSeen(key: String): Boolean = sp.getBoolean("tuto_$key", false)

    fun setTutoSeen(key: String) {
        sp.edit().putBoolean("tuto_$key", true).apply()
    }
}
