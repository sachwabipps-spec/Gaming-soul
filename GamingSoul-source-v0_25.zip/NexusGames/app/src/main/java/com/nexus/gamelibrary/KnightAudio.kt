package com.nexus.gamelibrary

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

// ════════════════════════════════════════════════════════════════
//  Chevalier : sons et musique générés par le téléphone (aucun fichier audio)
//  Chaque niveau a sa propre musique (monde = ambiance, niveau = mélodie), les boss sont plus rapides.
// ════════════════════════════════════════════════════════════════

object KMusic {
    const val SR = 22050

    private class Style(val root: Int, val scale: IntArray, val bpm: Int, val wave: Int, val bassWave: Int, val drums: Boolean, val sparse: Float)

    // wave : 0 carré, 1 triangle, 2 scie, 3 sinus
    private val styles = listOf(
        Style(48, intArrayOf(0, 2, 4, 7, 9), 112, 0, 1, true, 0.15f),          // Prairie (pentatonique majeure)
        Style(50, intArrayOf(0, 2, 3, 5, 7, 9, 10), 96, 1, 1, true, 0.25f),     // Forêt (dorien)
        Style(40, intArrayOf(0, 2, 3, 5, 7, 8, 10), 80, 3, 1, false, 0.35f),    // Grottes (mineur)
        Style(42, intArrayOf(0, 1, 3, 5, 7, 8, 10), 76, 1, 3, false, 0.35f),    // Marais (phrygien)
        Style(50, intArrayOf(0, 1, 4, 5, 7, 8, 11), 100, 0, 1, true, 0.2f),     // Désert (phrygien dominant)
        Style(45, intArrayOf(0, 2, 4, 6, 7, 9, 11), 84, 3, 3, false, 0.45f),    // Neige (lydien)
        Style(47, intArrayOf(0, 2, 4, 6, 7, 9, 11), 92, 3, 1, true, 0.3f),      // Cristaux
        Style(48, intArrayOf(0, 2, 3, 5, 7, 8, 11), 70, 1, 3, false, 0.4f),     // Cimetière (mineur harmonique)
        Style(52, intArrayOf(0, 1, 3, 5, 7, 8, 10), 128, 2, 2, true, 0.1f),     // Volcan
        Style(43, intArrayOf(0, 2, 3, 5, 7, 9, 10), 90, 1, 1, true, 0.25f),     // Ruines
        Style(39, intArrayOf(0, 2, 4, 6, 7, 9, 11), 72, 3, 3, false, 0.45f),    // Cité engloutie
        Style(50, intArrayOf(0, 2, 3, 5, 7, 8, 11), 104, 2, 1, true, 0.2f),     // Château
        Style(36, intArrayOf(0, 1, 3, 5, 6, 8, 10), 88, 2, 2, true, 0.3f)       // Abysses (locrien)
    )

    private fun freq(m: Int) = 440f * 2f.pow((m - 69) / 12f)

    private fun osc(wave: Int, ph: Float): Float {
        val x = ph - kotlin.math.floor(ph)
        return when (wave) {
            0 -> if (x < 0.4f) 0.6f else -0.6f
            1 -> (if (x < 0.5f) x * 4f - 1f else 3f - x * 4f) * 0.9f
            2 -> (x * 2f - 1f) * 0.6f
            else -> sin(x * 2f * PI.toFloat())
        }
    }

    private fun note(buf: FloatArray, startSample: Int, dur: Float, f: Float, vol: Float, wave: Int, decay: Float) {
        val n = (dur * SR).toInt()
        var ph = 0f
        val inc = f / SR
        for (i in 0 until n) {
            val t = i / SR.toFloat()
            val att = min(1f, i / (0.006f * SR))
            val rel = min(1f, (n - i) / (0.02f * SR))
            val env = att * rel * exp(-t * decay)
            ph += inc
            val idx = (startSample + i) % buf.size
            buf[idx] += osc(wave, ph) * vol * env
        }
    }

    private fun noise(buf: FloatArray, startSample: Int, dur: Float, vol: Float, decay: Float, r: Random) {
        val n = (dur * SR).toInt()
        for (i in 0 until n) {
            val t = i / SR.toFloat()
            buf[(startSample + i) % buf.size] += (r.nextFloat() * 2f - 1f) * vol * exp(-t * decay)
        }
    }

    private fun kick(buf: FloatArray, startSample: Int, vol: Float) {
        val n = (0.16f * SR).toInt()
        var ph = 0f
        for (i in 0 until n) {
            val t = i / SR.toFloat()
            val f = 40f + 110f * exp(-t * 28f)
            ph += f / SR
            buf[(startSample + i) % buf.size] += sin(ph * 2f * PI.toFloat()) * vol * exp(-t * 14f)
        }
    }

    /** Boucle musicale du niveau (mono 16 bits). */
    fun generate(level: Int): ShortArray {
        val world = KN.worldOf(level)
        val st = styles[world.coerceIn(0, styles.lastIndex)]
        val boss = level % 10 == 0
        val bpm = st.bpm + (level % 40) / 4 + (if (boss) 28 else 0)
        val r = Random(level * 104729L + 7)
        val rn = Random(level * 31L + 5)
        val stepLen = 60f / bpm / 2f // croche
        val steps = 64
        val total = (steps * stepLen * SR).toInt()
        val buf = FloatArray(total)
        val sc = st.scale
        fun degree(d: Int): Int {
            val oct = Math.floorDiv(d, sc.size)
            val k = Math.floorMod(d, sc.size)
            return sc[k] + 12 * oct
        }
        // progression : 4 accords (degrés), chacun 16 croches
        val prog = intArrayOf(0, listOf(2, 3, 4, 5)[r.nextInt(4)], listOf(3, 4, 5)[r.nextInt(3)], listOf(4, 1, 6)[r.nextInt(3)])
        var mel = r.nextInt(sc.size) + sc.size
        for (s in 0 until steps) {
            val chord = prog[s / 16]
            val start = (s * stepLen * SR).toInt()
            // basse
            if (s % 4 == 0 || (boss && s % 2 == 0)) {
                note(buf, start, stepLen * (if (boss) 1.6f else 3.4f), freq(st.root + degree(chord)), 0.33f, st.bassWave, if (boss) 5f else 2.5f)
            }
            // nappe (début de chaque accord)
            if (s % 16 == 0) {
                for (k in intArrayOf(0, 2, 4)) {
                    note(buf, start, stepLen * 15f, freq(st.root + 12 + degree(chord + k)), 0.07f, 3, 0.25f)
                }
            }
            // mélodie / arpège
            if (r.nextFloat() > st.sparse) {
                val move = r.nextInt(5) - 2
                mel = (mel + move).coerceIn(sc.size - 2, sc.size * 2 + 2)
                if (s % 8 == 0) mel = chord + sc.size + listOf(0, 2, 4)[r.nextInt(3)]
                note(buf, start, stepLen * (if (r.nextInt(4) == 0) 2.2f else 1.1f), freq(st.root + 12 + degree(mel)), 0.16f, st.wave, 4f)
            }
            // batterie
            if (st.drums || boss) {
                if (s % 4 == 0) kick(buf, start, 0.45f)
                if (s % 2 == 1) noise(buf, start, 0.04f, 0.07f, 60f, rn)
                if (boss && s % 8 == 4) noise(buf, start, 0.12f, 0.16f, 25f, rn)
            }
        }
        var peak = 0.001f
        for (v in buf) peak = max(peak, kotlin.math.abs(v))
        val g = 0.7f / peak
        return ShortArray(total) { (buf[it] * g * 32767f).toInt().coerceIn(-32767, 32767).toShort() }
    }

    // ── Effets sonores
    private fun tone(f0: Float, f1: Float, dur: Float, wave: Int, vol: Float, decay: Float): FloatArray {
        val n = (dur * SR).toInt()
        val out = FloatArray(n)
        var ph = 0f
        for (i in 0 until n) {
            val k = i / n.toFloat()
            ph += (f0 + (f1 - f0) * k) / SR
            val env = min(1f, i / (0.004f * SR)) * min(1f, (n - i) / (0.01f * SR)) * exp(-k * decay)
            out[i] = osc(wave, ph) * vol * env
        }
        return out
    }

    private fun noiseBurst(dur: Float, vol: Float, decay: Float, lowpass: Float): FloatArray {
        val n = (dur * SR).toInt()
        val r = Random(99)
        val out = FloatArray(n)
        var y = 0f
        for (i in 0 until n) {
            val k = i / n.toFloat()
            y += (r.nextFloat() * 2f - 1f - y) * lowpass
            out[i] = y * vol * exp(-k * decay)
        }
        return out
    }

    private fun cat(vararg parts: FloatArray): FloatArray {
        val out = FloatArray(parts.sumOf { it.size })
        var p = 0
        for (a in parts) { System.arraycopy(a, 0, out, p, a.size); p += a.size }
        return out
    }

    private fun mix(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(max(a.size, b.size))
        for (i in a.indices) out[i] += a[i]
        for (i in b.indices) out[i] += b[i]
        return out
    }

    fun sfx(id: Int): FloatArray = when (id) {
        1 -> tone(300f, 620f, 0.14f, 1, 0.5f, 2f)                                   // saut
        2 -> noiseBurst(0.11f, 0.5f, 4f, 0.5f)                                      // coup d'épée
        3 -> mix(tone(180f, 90f, 0.1f, 0, 0.5f, 3f), noiseBurst(0.08f, 0.4f, 5f, 0.7f)) // coup touché
        4 -> tone(420f, 90f, 0.28f, 2, 0.5f, 2.5f)                                  // joueur blessé
        5 -> cat(tone(880f, 880f, 0.06f, 0, 0.35f, 1f), tone(1320f, 1320f, 0.1f, 0, 0.35f, 3f)) // pièces / ennemi vaincu
        6 -> cat(tone(523f, 523f, 0.08f, 1, 0.5f, 1.5f), tone(659f, 659f, 0.08f, 1, 0.5f, 1.5f), tone(784f, 784f, 0.08f, 1, 0.5f, 1.5f), tone(1047f, 1047f, 0.2f, 1, 0.5f, 3f)) // coffre
        7 -> mix(tone(200f, 1300f, 0.32f, 2, 0.35f, 2f), tone(100f, 650f, 0.32f, 3, 0.4f, 2f)) // pouvoir
        8 -> noiseBurst(0.16f, 0.45f, 3f, 0.25f)                                    // dash
        9 -> cat(tone(523f, 523f, 0.14f, 0, 0.4f, 2f), tone(659f, 659f, 0.14f, 0, 0.4f, 2f), tone(784f, 784f, 0.14f, 0, 0.4f, 2f), tone(1047f, 1047f, 0.5f, 0, 0.4f, 3f)) // victoire
        10 -> cat(tone(392f, 392f, 0.2f, 1, 0.5f, 2f), tone(330f, 330f, 0.2f, 1, 0.5f, 2f), tone(262f, 262f, 0.2f, 1, 0.5f, 2f), tone(196f, 130f, 0.6f, 1, 0.5f, 3f)) // défaite
        11 -> mix(noiseBurst(0.7f, 0.7f, 4f, 0.2f), tone(160f, 40f, 0.7f, 3, 0.7f, 3f)) // boss vaincu
        12 -> tone(500f, 950f, 0.12f, 3, 0.45f, 2f)                                 // double saut
        else -> cat(tone(600f, 600f, 0.1f, 3, 0.4f, 1.5f), tone(900f, 900f, 0.18f, 3, 0.4f, 3f)) // soin
    }

    fun toShorts(f: FloatArray): ShortArray = ShortArray(f.size) { (f[it] * 24000f).toInt().coerceIn(-32767, 32767).toShort() }
}

class KAudio {
    var sfxOn = true
    var musicOn = true
    private var music: AudioTrack? = null
    private val tracks = HashMap<Int, AudioTrack>()
    private var released = false

    private fun build(data: ShortArray): AudioTrack? = try {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(KMusic.SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(data, 0, data.size)
        t
    } catch (e: Throwable) { null }

    fun play(id: Int) {
        if (!sfxOn || released) return
        try {
            val t = tracks.getOrPut(id) { build(KMusic.toShorts(KMusic.sfx(id))) ?: return }
            t.stop()
            t.setPlaybackHeadPosition(0)
            t.play()
        } catch (e: Throwable) { }
    }

    /** À appeler hors du thread principal pour générer, puis start(). */
    fun startMusic(data: ShortArray) {
        if (released) return
        stopMusic()
        try {
            val t = build(data) ?: return
            t.setLoopPoints(0, data.size, -1)
            t.setVolume(if (musicOn) 0.45f else 0f)
            t.play()
            music = t
        } catch (e: Throwable) { }
    }

    fun setMusic(on: Boolean) {
        musicOn = on
        try { music?.setVolume(if (on) 0.45f else 0f) } catch (e: Throwable) { }
    }

    fun pauseMusic() { try { music?.pause() } catch (e: Throwable) { } }
    fun resumeMusic() { try { music?.play() } catch (e: Throwable) { } }

    fun stopMusic() {
        try { music?.stop(); music?.release() } catch (e: Throwable) { }
        music = null
    }

    fun release() {
        released = true
        stopMusic()
        for (t in tracks.values) try { t.stop(); t.release() } catch (e: Throwable) { }
        tracks.clear()
    }
}
