package com.nexus.gamelibrary

/**
 * Caméra « 3D » façon FIFA Mobile : le terrain est vu en perspective depuis le bord du terrain.
 * Le côté lointain est plus étroit et plus petit, le côté proche plus large ; les joueurs et le ballon
 * restent dessinés debout (ils sont mis à l'échelle selon leur profondeur).
 *
 * Coordonnées de jeu (x : 0..320, y : 0..180, y = 0 est le côté lointain).
 */
internal class Persp(val s: Float, val ox: Float, val oy: Float) {
    companion object {
        /** Force de la perspective : plus c'est grand, plus le côté lointain rétrécit. */
        const val C = 0.6f

        /** Les joueurs sont dessinés un peu plus grands qu'en vue du dessus (au premier plan = 1,25×). */
        const val BB = 1.25f

        private fun kOf(y: Float): Float = 1f / (1f + C * (1f - y / Court.H))
        private val KMIN = kOf(0f)
    }

    /** Échelle de profondeur : 1 au bord proche, ~0,62 au bord lointain. */
    fun k(y: Float): Float = kOf(y)

    fun sx(x: Float, y: Float): Float = ox + Court.W * s / 2f + (x - Court.W / 2f) * s * kOf(y)

    fun sy(y: Float): Float = oy + Court.H * s * (kOf(y) - KMIN) / (1f - KMIN)
}
