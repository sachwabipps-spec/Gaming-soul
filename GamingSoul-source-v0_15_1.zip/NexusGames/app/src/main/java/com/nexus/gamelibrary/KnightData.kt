package com.nexus.gamelibrary

import android.content.Context
import java.util.Random

// ════════════════════════════════════════════════════════════════
//  Chevalier : données (mondes, classes, pouvoirs, objets, sauvegarde)
// ════════════════════════════════════════════════════════════════

data class KWorld(val name: String, val sky1: Long, val sky2: Long, val ground: Long, val grass: Long)

data class KClass(
    val name: String, val icon: String, val desc: String, val color: Long,
    val hp: Float, val dmg: Float, val spd: Float, val crit: Int,
    val atkCd: Float, val reach: Float, val pow: Float, val pcd: Float
)

data class KPower(val id: Int) {
    val kind: Int get() = id / 5
    val variant: Int get() = id % 5
    val name: String get() = KN.kindNames[kind] + " · " + KN.elems[variant]
    val icon: String get() = KN.kindIcons[kind]
    val color: Long get() = KN.elemColors[variant]
    val rarity: Int get() = variant
    val cooldown: Float get() = KN.kindCd[kind]
    fun mul(level: Int): Float = KN.varMul[variant] * (1f + 0.15f * (level - 1))
    val desc: String get() = KN.kindDesc[kind]
}

data class KItem(val id: Long, val slot: Int, val rar: Int, val sub: Int, val pw: Int, val sp: Int, val name: String) {
    fun enc() = "$id|$slot|$rar|$sub|$pw|$sp|$name"
    val sell: Int get() = ((10 + pw) * (rar + 1) / 2)
    val desc: String
        get() = when (slot) {
            0 -> "Dégâts +$pw"
            1 -> "PV +$pw"
            2 -> "Vitesse +$pw%"
            else -> "Charme"
        } + (if (sp != 0) " · " + KN.specialDesc(sp, pw) else "")

    companion object {
        fun dec(s: String): KItem? = try {
            val p = s.split("|", limit = 7)
            KItem(p[0].toLong(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt(), p[6])
        } catch (e: Exception) { null }
    }
}

class KStats(
    val maxHp: Int, val atk: Float, val speed: Float, val crit: Int, val cd: Float, val reach: Float,
    val lifesteal: Int, val coinPct: Int, val dbl: Boolean, val powMul: Float, val pcd: Float
)

object KN {
    const val LEVELS = 520
    const val PER_WORLD = 40
    const val PULL_COST = 150

    val worlds = listOf(
        KWorld("Prairie", 0xFF6EC6FF, 0xFFD6F0FF, 0xFF6B4A2B, 0xFF4CAF50),
        KWorld("Forêt sombre", 0xFF1B3A2A, 0xFF4F7F5A, 0xFF4A3524, 0xFF2E7D32),
        KWorld("Grottes", 0xFF1A1426, 0xFF3A2F52, 0xFF3C3550, 0xFF5E5578),
        KWorld("Marais", 0xFF2E3B2A, 0xFF7C8F58, 0xFF4B4A2A, 0xFF7A8F2E),
        KWorld("Désert", 0xFFF2B35A, 0xFFFFE2A8, 0xFFB98B4C, 0xFFE8C77A),
        KWorld("Montagnes de neige", 0xFF8FB8DE, 0xFFE8F4FF, 0xFF6B7A8F, 0xFFFFFFFF),
        KWorld("Mines de cristal", 0xFF14183A, 0xFF3B3F8C, 0xFF2E3157, 0xFF6C7CFF),
        KWorld("Cimetière", 0xFF1E1B2B, 0xFF4B4660, 0xFF3A3A44, 0xFF5B6B4B),
        KWorld("Volcan", 0xFF3A0E0A, 0xFFB3401A, 0xFF3A2A28, 0xFFFF6A2A),
        KWorld("Ruines anciennes", 0xFF47506B, 0xFFB9B3A0, 0xFF6E6A5C, 0xFF9C9884),
        KWorld("Cité engloutie", 0xFF0A2A4A, 0xFF2A7FA8, 0xFF2F4F5F, 0xFF3ED1C0),
        KWorld("Château maudit", 0xFF150F22, 0xFF4A2A55, 0xFF2D2538, 0xFF8A4FFF),
        KWorld("Abysses", 0xFF05050F, 0xFF1A0F2E, 0xFF1C1228, 0xFFFF3D6E)
    )

    val classes = listOf(
        KClass("Chevalier", "🛡️", "Équilibré. Bon partout.", 0xFF7FB0FF, 1f, 1f, 1f, 5, 1f, 1f, 1f, 1f),
        KClass("Berserker", "🪓", "Dégâts énormes, peu de PV.", 0xFFFF5A36, 0.8f, 1.35f, 1f, 8, 1.1f, 1f, 1f, 1f),
        KClass("Paladin", "✨", "Beaucoup de PV, un peu lent.", 0xFFFFD84D, 1.45f, 0.9f, 0.9f, 3, 1f, 1f, 1.1f, 1f),
        KClass("Assassin", "🗡️", "Rapide, critiques, frappe vive.", 0xFFB06CFF, 0.85f, 1f, 1.2f, 20, 0.72f, 0.9f, 1f, 1f),
        KClass("Mage-lame", "🔮", "Pouvoirs +40% et recharge -30%.", 0xFF3DE0E0, 0.9f, 0.95f, 1f, 5, 1f, 1f, 1.4f, 0.7f),
        KClass("Lancier", "🔱", "Allonge longue, attaque sûre.", 0xFF9CFFB0, 1.05f, 1f, 1f, 6, 1f, 1.35f, 1f, 1f)
    )

    val kindNames = listOf("Projectile", "Nova", "Charge", "Soin", "Bouclier", "Séisme", "Éventail", "Rage", "Éclipse", "Foudroiement")
    val kindIcons = listOf("☄️", "💥", "⚡", "💚", "🛡️", "🌋", "🔱", "😡", "🌀", "⛈️")
    val kindCd = floatArrayOf(3f, 6f, 5f, 10f, 12f, 8f, 5f, 14f, 6f, 12f)
    val kindDesc = listOf(
        "Lance une boule d'énergie", "Explosion autour de toi", "Fonce en frappant tout", "Soigne 25% des PV",
        "Invulnérable quelques secondes", "Deux vagues rasantes", "3 projectiles en éventail",
        "Dégâts x1,8 pendant 6 s", "Téléportation vers l'avant", "Foudre sur tous les ennemis proches"
    )
    val elems = listOf("Pierre", "Feu", "Glace", "Foudre", "Astral")
    val elemColors = longArrayOf(0xFFB08A5A, 0xFFFF7A2A, 0xFF6FE3FF, 0xFFFFE94D, 0xFFC27BFF)
    val varMul = floatArrayOf(1f, 1.15f, 1.3f, 1.5f, 1.85f)
    val rarNames = listOf("Commun", "Peu commun", "Rare", "Épique", "Légendaire")
    val rarColors = longArrayOf(0xFFB0B0B0, 0xFF6BD16B, 0xFF5AA0FF, 0xFFC27BFF, 0xFFFFB02E)
    val slotNames = listOf("Arme", "Armure", "Bottes", "Charme")
    val slotIcons = listOf("⚔️", "🛡️", "👢", "📿")

    val wCd = floatArrayOf(0.35f, 0.55f, 0.4f)
    val wMul = floatArrayOf(1f, 1.45f, 0.95f)
    val wReach = floatArrayOf(1.5f, 1.3f, 2.1f)

    fun specialDesc(sp: Int, pw: Int) = when (sp) {
        1 -> "Vol de vie $pw%"
        2 -> "Critique +$pw%"
        3 -> "Pièces +${pw * 2}%"
        4 -> "Double saut"
        5 -> "Recharge pouvoirs -${pw}%"
        else -> ""
    }

    private val bossA = listOf("Gardien", "Roi", "Seigneur", "Colosse", "Spectre", "Dragon", "Tyran")
    private val bossB = listOf("Cendré", "Maudit", "Glacé", "Ardent", "Ténébreux", "Oublié", "Écarlate", "Corrompu")
    fun bossName(b0: Int): String {
        val b = b0.coerceAtLeast(0) // niveaux 1-9 : pas de boss (index -1 faisait planter)
        return bossA[b % bossA.size] + " " + bossB[(b / bossA.size) % bossB.size]
    }

    fun worldOf(level: Int) = ((level - 1) / PER_WORLD).coerceIn(0, worlds.lastIndex)

    // ── Loot
    private val wNames = listOf("Épée", "Hache", "Lance")
    private val aNames = listOf("Cotte", "Plastron", "Cape")
    private val bNames = listOf("Bottes", "Jambières")
    private val cNames = listOf("Amulette", "Talisman", "Anneau")
    private val mats = listOf(
        listOf("de Fer", "de Cuivre", "de Bronze"),
        listOf("d'Acier", "d'Argent", "de Jade"),
        listOf("d'Obsidienne", "de Rubis", "de Saphir"),
        listOf("du Néant", "d'Orichalque", "des Étoiles"),
        listOf("du Dragon", "du Roi Déchu", "de l'Éclipse")
    )

    fun rollRarity(r: Random, tier: Int, lv: Int): Int {
        val f = lv / LEVELS.toFloat()
        val x = r.nextFloat()
        return when {
            x < 0.008f + 0.03f * tier + 0.02f * f -> 4
            x < 0.05f + 0.10f * tier + 0.05f * f -> 3
            x < 0.22f + 0.22f * tier + 0.08f * f -> 2
            x < 0.55f + 0.1f * tier -> 1
            else -> 0
        }
    }

    fun rollItem(lv: Int, tier: Int, r: Random): KItem {
        val rar = rollRarity(r, tier, lv)
        val slot = r.nextInt(4)
        var sub = 0
        val base = when (slot) {
            0 -> { sub = r.nextInt(3); wNames[sub] }
            1 -> { sub = r.nextInt(3); aNames[sub] }
            2 -> { sub = r.nextInt(2); bNames[sub] }
            else -> { sub = r.nextInt(3); cNames[sub] }
        }
        val name = base + " " + mats[rar][r.nextInt(3)]
        var pw = 0
        var sp = 0
        when (slot) {
            0 -> pw = Math.round(6f * (1f + lv * 0.025f) * (1f + rar * 0.5f))
            1 -> pw = Math.round(40f * (1f + lv * 0.03f) * (1f + rar * 0.45f))
            2 -> {
                pw = 3 + rar * 3
                if (rar >= 2 && r.nextFloat() < 0.6f) sp = 4
            }
            else -> {
                sp = intArrayOf(1, 2, 3, 5)[r.nextInt(4)]
                pw = 3 + rar * 3 + lv / 100
            }
        }
        return KItem(r.nextLong() and 0x7fffffffffffL, slot, rar, sub, pw, sp, name)
    }

    /** Tirage de pouvoir (gacha). boost > 0 : meilleures chances. */
    fun rollPower(r: Random, boost: Int = 0): Int {
        val w = intArrayOf(35, 30, 20, 11, 4)
        if (boost > 0) { w[0] -= 10 * boost; w[2] += 4 * boost; w[3] += 4 * boost; w[4] += 2 * boost }
        var x = r.nextInt(w.sum())
        var v = 0
        for (i in w.indices) { if (x < w[i]) { v = i; break }; x -= w[i] }
        return r.nextInt(10) * 5 + v
    }
}

class KnightSave(ctx: Context) {
    private val sp = ctx.getSharedPreferences("knight_save", Context.MODE_PRIVATE)

    var coins: Int
        get() = sp.getInt("coins", 100)
        set(v) = sp.edit().putInt("coins", v).apply()
    var sfxOn: Boolean
        get() = sp.getBoolean("sfxOn", true)
        set(v) = sp.edit().putBoolean("sfxOn", v).apply()
    var musicOn: Boolean
        get() = sp.getBoolean("musicOn", true)
        set(v) = sp.edit().putBoolean("musicOn", v).apply()
    var upgHp: Int
        get() = sp.getInt("upgHp", 0)
        set(v) = sp.edit().putInt("upgHp", v).apply()
    var upgAtk: Int
        get() = sp.getInt("upgAtk", 0)
        set(v) = sp.edit().putInt("upgAtk", v).apply()
    var cls: Int
        get() = sp.getInt("cls", 0).coerceIn(0, KN.classes.lastIndex)
        set(v) = sp.edit().putInt("cls", v).apply()

    fun stars(): IntArray {
        val s = sp.getString("stars", "") ?: ""
        return IntArray(KN.LEVELS) { if (it < s.length) (s[it] - '0').coerceIn(0, 3) else 0 }
    }

    fun setStars(level: Int, n: Int) {
        val a = stars()
        val i = level - 1
        if (i !in a.indices || n <= a[i]) return
        a[i] = n
        sp.edit().putString("stars", a.joinToString("")).apply()
    }

    /** Plus haut niveau jouable (1 = premier). */
    fun maxLevel(): Int {
        val a = stars()
        var last = 0
        for (i in a.indices) if (a[i] > 0) last = i + 1
        return (last + 1).coerceAtMost(KN.LEVELS)
    }

    var powers: Map<Int, Int>
        get() {
            val m = HashMap<Int, Int>()
            (sp.getString("powers", "") ?: "").split(",").forEach {
                val p = it.split(":")
                if (p.size == 2) { val a = p[0].toIntOrNull(); val b = p[1].toIntOrNull(); if (a != null && b != null) m[a] = b }
            }
            return m
        }
        set(v) = sp.edit().putString("powers", v.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()

    var loadout: IntArray
        get() {
            val p = (sp.getString("loadout", "") ?: "").split(",")
            return IntArray(3) { p.getOrNull(it)?.toIntOrNull() ?: -1 }
        }
        set(v) = sp.edit().putString("loadout", v.joinToString(",")).apply()

    var inv: List<KItem>
        get() = (sp.getString("inv", "") ?: "").split("\n").mapNotNull { if (it.isBlank()) null else KItem.dec(it) }
        set(v) = sp.edit().putString("inv", v.joinToString("\n") { it.enc() }).apply()

    var equipped: LongArray
        get() {
            val p = (sp.getString("equipped", "") ?: "").split(",")
            return LongArray(4) { p.getOrNull(it)?.toLongOrNull() ?: -1L }
        }
        set(v) = sp.edit().putString("equipped", v.joinToString(",")).apply()

    fun equippedItems(): List<KItem?> {
        val items = inv
        val eq = equipped
        return List(4) { s -> items.firstOrNull { it.id == eq[s] && it.slot == s } }
    }

    fun addPower(id: Int): Boolean {
        val m = HashMap(powers)
        val isNew = !m.containsKey(id)
        m[id] = ((m[id] ?: 0) + 1).coerceAtMost(5)
        powers = m
        return isNew
    }

    fun stats(): KStats {
        val c = KN.classes[cls]
        val eq = equippedItems()
        val w = eq[0]; val a = eq[1]; val b = eq[2]; val ch = eq[3]
        var crit = c.crit
        var life = 0; var coin = 0; var pcd = c.pcd
        if (ch != null) when (ch.sp) { 1 -> life = ch.pw; 2 -> crit += ch.pw; 3 -> coin = ch.pw * 2; 5 -> pcd *= (1f - ch.pw / 100f).coerceAtLeast(0.4f) }
        val sub = w?.sub ?: 0
        val dmg = (8f + upgAtk * 2f + (w?.pw ?: 0)) * c.dmg * KN.wMul[sub]
        return KStats(
            maxHp = ((100 + upgHp * 12 + (a?.pw ?: 0)) * c.hp).toInt(),
            atk = dmg,
            speed = 6f * c.spd * (1f + (b?.pw ?: 0) / 100f),
            crit = crit,
            cd = KN.wCd[sub] * c.atkCd,
            reach = KN.wReach[sub] * c.reach,
            lifesteal = life, coinPct = coin,
            dbl = b?.sp == 4,
            powMul = c.pow,
            pcd = pcd
        )
    }
}
