package com.nexus.gamelibrary

import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner

private data class KHud(
    val hp: Int, val maxHp: Int, val coins: Int, val msg: String, val over: Boolean, val won: Boolean,
    val bossPct: Int, val cds: List<Int>, val dash: Boolean
)

private const val KSTEP = 1f / 60f

private fun hudOf(g: KnightGame): KHud {
    val boss = g.foes.firstOrNull { it.boss && !it.dead }
    return KHud(
        g.hp.toInt(), g.st.maxHp, g.coinsGained, g.msg, g.over, g.won,
        if (boss != null) (boss.hp / boss.maxHp * 100).toInt().coerceIn(0, 100) else -1,
        List(3) { max(0, ceil(g.pcd[it]).toInt()) },
        g.dashCd <= 0f
    )
}

@Composable
fun KnightGameScreen(level: Int, onExit: () -> Unit, onNext: () -> Unit) {
    val context = LocalContext.current
    val save = remember { KnightSave(context) }
    var attempt by remember(level) { mutableIntStateOf(0) }
    val game = remember(level, attempt) { KnightGame(level, save.stats(), save.loadout, save.powers, KN.classes[save.cls].color) }
    var paused by remember(level, attempt) { mutableStateOf(false) }
    var hud by remember(game) { mutableStateOf(hudOf(game)) }
    var frame by remember(game) { mutableIntStateOf(0) }
    var showHelp by remember(game) { mutableStateOf(true) }
    val committed = remember(game) { booleanArrayOf(false) }
    val loadout = remember(game) { save.loadout }
    val audio = remember { KAudio() }
    var sfxOn by remember { mutableStateOf(save.sfxOn) }
    var musicOn by remember { mutableStateOf(save.musicOn) }
    audio.sfxOn = sfxOn
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(Unit) { onDispose { audio.release() } }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_PAUSE) audio.pauseMusic()
            else if (ev == Lifecycle.Event.ON_RESUME && !paused && !game.over) audio.resumeMusic()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    // Musique propre à chaque niveau (générée sur un autre thread)
    LaunchedEffect(game) {
        audio.stopMusic()
        audio.musicOn = musicOn
        val data = withContext(Dispatchers.Default) { KMusic.generate(level) }
        audio.startMusic(data)
    }
    LaunchedEffect(paused) { if (paused) audio.pauseMusic() else if (!game.over) audio.resumeMusic() }
    LaunchedEffect(hud.over) { if (hud.over) audio.stopMusic() }

    fun commit() {
        if (committed[0]) return
        committed[0] = true
        save.coins += game.coinsGained
        if (game.foundItems.isNotEmpty()) {
            save.inv = save.inv + game.foundItems
            // équipe automatiquement dans un emplacement vide
            val eq = save.equipped
            val inv = save.inv
            for (it in game.foundItems) {
                if (inv.none { x -> x.id == eq[it.slot] }) eq[it.slot] = it.id
            }
            save.equipped = eq
        }
        for (id in game.foundPowers) {
            val isNew = save.addPower(id)
            val l = save.loadout
            if (isNew && !l.contains(id)) { val f = l.indexOf(-1); if (f >= 0) { l[f] = id; save.loadout = l } }
        }
        if (game.won) save.setStars(level, game.stars())
    }

    LaunchedEffect(game) { delay(7000); showHelp = false }

    DisposableEffect(Unit) {
        val act = context.findActivity()
        val window = act?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    LaunchedEffect(game, paused) {
        if (paused) return@LaunchedEffect
        var last = 0L
        var acc = 0f
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) {
                    acc += min(0.05f, (now - last) / 1_000_000_000f)
                    while (acc >= KSTEP) { game.step(KSTEP); acc -= KSTEP }
                }
                last = now
                val h = hudOf(game)
                if (h != hud) hud = h
                if (game.over) commit()
                if (game.sfx.isNotEmpty()) {
                    val seen = HashSet<Int>()
                    while (game.sfx.isNotEmpty()) seen.add(game.sfx.removeFirst())
                    for (id in seen) audio.play(id)
                }
                frame++
            }
        }
    }

    fun exit() { commit(); onExit() }
    BackHandler { if (!hud.over) paused = !paused else exit() }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
            .background(Color.Black)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            frame
            drawKnight(game, frame)
        }

        // ── HUD
        Column(
            Modifier.align(Alignment.TopCenter).safeDrawingPadding().padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("❤", color = Color(0xFFFF6B6B), fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                Box(Modifier.width(140.dp).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color.White.copy(alpha = 0.2f))) {
                    Box(
                        Modifier.fillMaxSize().padding(end = (140f * (1f - hud.hp.toFloat() / hud.maxHp).coerceIn(0f, 1f)).dp)
                            .background(Color(0xFFFF5252))
                    )
                }
                Spacer(Modifier.width(6.dp))
                Text("${hud.hp}/${hud.maxHp}", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                Spacer(Modifier.width(10.dp))
                Text("🪙 ${hud.coins}", color = Gold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Text(
                "Niv. $level · ${game.world.name}" + if (game.boss) " · 👑 BOSS" else "",
                color = Color.White.copy(alpha = 0.85f), fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
            if (hud.bossPct >= 0) {
                Text(game.bossName.uppercase() + "  " + hud.bossPct + "%", color = Color(0xFFFF8A80), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            if (hud.msg.isNotEmpty()) {
                Text(
                    hud.msg, color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }

        if (showHelp && !hud.over) {
            Text(
                "◀ ▶ bouger · SAUT (maintenir = plus haut) · ⚔ attaque · DASH esquive · 3 pouvoirs · ouvre les coffres · atteins la porte",
                color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 10.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).safeDrawingPadding().padding(bottom = 2.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }

        Box(
            Modifier.align(Alignment.TopStart).safeDrawingPadding().padding(8.dp).size(40.dp).clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f)).clickable { if (!hud.over) paused = true },
            contentAlignment = Alignment.Center
        ) { Text("II", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        // ── Commandes
        Row(
            Modifier.align(Alignment.BottomStart).safeDrawingPadding().padding(start = 18.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PadButton("◀", 76.dp, Color.White) { down -> game.inp.left = down }
            PadButton("▶", 76.dp, Color.White) { down -> game.inp.right = down }
        }
        Column(
            Modifier.align(Alignment.BottomEnd).safeDrawingPadding().padding(end = 18.dp, bottom = 16.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (i in 0..2) {
                    val id = loadout[i]
                    val cd = hud.cds[i]
                    val lbl = if (id < 0) "–" else if (cd > 0) "$cd" else KPower(id).icon
                    val col = if (id < 0) Color.Gray else Color(KPower(id).color)
                    PadButton(lbl, 56.dp, col, onPress = { game.inp.pw[i] = true }) { }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Bottom) {
                PadButton("DASH", 56.dp, if (hud.dash) Color(0xFF80D8FF) else Color.Gray, onPress = { game.inp.dashLatch = true }) { }
                PadButton("⚔", 76.dp, Color(0xFFFF8A80), onPress = { game.inp.atkLatch = true }) { }
                PadButton("SAUT", 84.dp, Gold, onPress = { game.inp.jumpLatch = true }) { down -> game.inp.jumpHeld = down }
            }
        }

        if (paused && !hud.over) {
            OverlayCard {
                Text("PAUSE", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                Spacer(Modifier.height(14.dp))
                OverlayButton("Continuer", Gold) { paused = false }
                OverlayButton(if (musicOn) "Musique : oui" else "Musique : non", Color.White) {
                    musicOn = !musicOn; save.musicOn = musicOn; audio.setMusic(musicOn)
                }
                OverlayButton(if (sfxOn) "Sons : oui" else "Sons : non", Color.White) {
                    sfxOn = !sfxOn; save.sfxOn = sfxOn
                }
                OverlayButton("Recommencer", Color.White) { commit(); attempt++ }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { exit() }
            }
        }

        if (hud.over) {
            OverlayCard {
                Text(
                    if (hud.won) "NIVEAU TERMINÉ !" else "DÉFAITE",
                    color = if (hud.won) Gold else Color(0xFFFF8A80), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp
                )
                if (hud.won) Text(stars(game.stars()), color = Gold, fontSize = 30.sp)
                Text("🪙 +${game.coinsGained} · ☠ ${game.kills} · 🎁 ${game.chestsOpened}", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                for (it in game.foundItems.take(4)) {
                    Text("${KN.slotIcons[it.slot]} ${it.name}", color = Color(KN.rarColors[it.rar]), fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                for (id in game.foundPowers.take(3)) {
                    Text("${KPower(id).icon} ${KPower(id).name}", color = Color(KPower(id).color), fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                if (hud.won && level < KN.LEVELS) OverlayButton("Niveau suivant", Gold) { commit(); onNext() }
                OverlayButton("Rejouer", Color.White) { commit(); attempt++ }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { exit() }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════════
//  Dessin
// ════════════════════════════════════════════════════════════════

private class KCam(val ds: DrawScope, val s: Float, val cx: Float, val cy: Float) {
    fun rect(x: Float, y: Float, w: Float, h: Float, c: Color) =
        ds.drawRect(c, Offset((x - cx) * s, (y - cy) * s), Size(w * s, h * s))

    fun oval(x: Float, y: Float, w: Float, h: Float, c: Color) =
        ds.drawOval(c, Offset((x - cx) * s, (y - cy) * s), Size(w * s, h * s))

    fun circ(x: Float, y: Float, r: Float, c: Color) = ds.drawCircle(c, r * s, Offset((x - cx) * s, (y - cy) * s))

    fun ringLine(x: Float, y: Float, r: Float, c: Color, w: Float) =
        ds.drawCircle(c, r * s, Offset((x - cx) * s, (y - cy) * s), style = Stroke(width = w))

    fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, c: Color) {
        val p = Path()
        p.moveTo((x1 - cx) * s, (y1 - cy) * s)
        p.lineTo((x2 - cx) * s, (y2 - cy) * s)
        p.lineTo((x3 - cx) * s, (y3 - cy) * s)
        p.close()
        ds.drawPath(p, c)
    }
}

internal fun DrawScope.drawKnight(g: KnightGame, frame: Int) {
    val viewH = 9.5f
    val s = size.height / viewH
    val viewW = size.width / s
    val cx = (g.p.x + 0.35f - viewW / 2f).coerceIn(0f, max(0f, g.W - viewW))
    val cy = (g.p.y - 5.2f).coerceIn(0f, KnightGame.H - viewH)
    val c = KCam(this, s, cx, cy)
    val w = g.world

    drawRect(Brush.verticalGradient(listOf(Color(w.sky1), Color(w.sky2))), Offset.Zero, size)

    // montagnes en parallaxe
    for (layer in 0..1) {
        val factor = 0.15f + 0.15f * layer
        val off = cx * factor
        val seg = 5f
        val first = floor(off / seg).toInt()
        val col = lerp(Color(w.sky2), Color(w.ground), 0.3f + 0.25f * layer)
        val base = (11.5f - cy) * s
        for (k in first..first + (viewW / seg).toInt() + 2) {
            val xw = k * seg - off
            val hgt = 2.5f + (((k * 37 + layer * 11) % 5 + 5) % 5) * 0.6f + layer
            val p = Path()
            p.moveTo(xw * s, base)
            p.lineTo((xw + seg / 2) * s, base - hgt * s)
            p.lineTo((xw + seg) * s, base)
            p.close()
            drawPath(p, col)
        }
        drawRect(col, Offset(0f, base), Size(size.width, size.height - base))
    }

    // tuiles
    val ground = Color(w.ground)
    val ground2 = lerp(ground, Color.White, 0.07f)
    val grass = Color(w.grass)
    val x0 = floor(cx).toInt().coerceAtLeast(0)
    val x1 = min(g.W - 1, floor(cx + viewW).toInt())
    val y0 = floor(cy).toInt().coerceAtLeast(0)
    val y1 = min(KnightGame.H - 1, floor(cy + viewH).toInt())
    for (ty in y0..y1) for (tx in x0..x1) {
        val t = g.tiles[ty * g.W + tx].toInt()
        if (t == 1) {
            c.rect(tx.toFloat(), ty.toFloat(), 1.02f, 1.02f, if ((tx + ty) % 2 == 0) ground else ground2)
            if (ty == 0 || g.tiles[(ty - 1) * g.W + tx].toInt() != 1) c.rect(tx.toFloat(), ty.toFloat(), 1.02f, 0.22f, grass)
        } else if (t == 2) {
            val sp = Color(0xFFE0E0EA)
            for (k in 0..2) c.tri(tx + k / 3f, ty + 1f, tx + k / 3f + 0.17f, ty + 0.35f, tx + (k + 1) / 3f, ty + 1f, sp)
        }
    }

    // porte
    val open = !g.bossAlive
    val gc = if (open) Color(0xFF7CFF8A) else Color(0xFFFF5252)
    c.rect(g.gateX, g.gateY, 1.2f, 3f, Color(0xFF2A2438))
    c.rect(g.gateX + 0.15f, g.gateY + 0.3f, 0.9f, 2.7f, gc.copy(alpha = 0.55f + 0.25f * sin(frame * 0.1f)))
    c.tri(g.gateX - 0.1f, g.gateY, g.gateX + 0.6f, g.gateY - 0.7f, g.gateX + 1.3f, g.gateY, Color(0xFF2A2438))

    // coffres
    for (ch in g.chests) {
        val body = when (ch.tier) { 2 -> Color(0xFFFFC83D); 1 -> Color(0xFFB8C4D0); else -> Color(0xFF9A6B3A) }
        if (ch.open) {
            c.rect(ch.x - 0.45f, ch.y + 0.3f, 0.9f, 0.4f, body.copy(alpha = 0.6f))
            c.rect(ch.x - 0.45f, ch.y - 0.1f, 0.9f, 0.15f, body.copy(alpha = 0.6f))
        } else {
            c.rect(ch.x - 0.45f, ch.y, 0.9f, 0.7f, body)
            c.rect(ch.x - 0.45f, ch.y + 0.25f, 0.9f, 0.1f, Color(0xFF3A2A1A))
            c.rect(ch.x - 0.1f, ch.y + 0.2f, 0.2f, 0.2f, Color(0xFFFFE9A0))
            if (ch.tier > 0) c.circ(ch.x + sin(frame * 0.1f) * 0.3f, ch.y - 0.2f, 0.06f, Color.White)
        }
    }

    // ennemis
    for (f in g.foes) c.foe(f, frame)

    // projectiles
    for (p in g.projs) {
        val col = Color(p.color)
        c.circ(p.x, p.y, 0.3f, col.copy(alpha = 0.35f))
        c.circ(p.x, p.y, 0.17f, col)
    }

    // joueur
    c.player(g, frame)

    // effets
    for (e in g.fx) {
        val k = e.t / e.max
        c.ringLine(e.x, e.y, e.ring * (0.3f + 0.7f * k), Color(e.color).copy(alpha = 1f - k), 5f)
    }
}

private fun KCam.player(g: KnightGame, frame: Int) {
    val p = g.p
    val f = g.face.toFloat()
    val mid = p.x + 0.35f
    if (g.dashT > 0f) for (k in 1..3) circ(mid - f * k * 0.4f, p.y + 0.8f, 0.3f, Color.White.copy(alpha = 0.2f))
    if (g.inv > 0f && (frame / 3) % 2 == 0 && g.dashT <= 0f) return
    val moving = abs(p.vx) > 1f
    val flutter = sin(frame * 0.3f) * 0.08f
    tri(mid - f * 0.1f, p.y + 0.5f, mid - f * 0.5f - flutter, p.y + 1.25f, mid - f * 0.1f, p.y + 1.2f, g.capeColor())
    val leg = if (moving) sin(frame * 0.5f) * 0.12f else 0f
    rect(p.x + 0.12f + leg, p.y + 1.05f, 0.2f, 0.35f, Color(0xFF30303C))
    rect(p.x + 0.38f - leg, p.y + 1.05f, 0.2f, 0.35f, Color(0xFF30303C))
    rect(p.x + 0.1f, p.y + 0.55f, 0.5f, 0.55f, Color(0xFFE8E8F0))
    rect(p.x + 0.1f, p.y + 0.8f, 0.5f, 0.08f, g.capeColor())
    circ(mid, p.y + 0.35f, 0.3f, Color(0xFFF2F2FA))
    tri(mid - 0.28f, p.y + 0.2f, mid - 0.4f, p.y - 0.15f, mid - 0.08f, p.y + 0.1f, Color(0xFFD0D0DC))
    tri(mid + 0.28f, p.y + 0.2f, mid + 0.4f, p.y - 0.15f, mid + 0.08f, p.y + 0.1f, Color(0xFFD0D0DC))
    rect(mid + f * 0.05f - 0.04f, p.y + 0.3f, 0.07f, 0.12f, Color.Black)
    rect(mid + f * 0.2f - 0.04f, p.y + 0.3f, 0.07f, 0.12f, Color.Black)
    if (g.swingT > 0f) {
        val r = g.st.reach
        val start = if (g.face > 0) -65f else 115f
        ds.drawArc(
            Color.White.copy(alpha = 0.75f), start, 130f, true,
            Offset((mid - r - cx) * s, (p.y + 0.7f - r - cy) * s), Size(2 * r * s, 2 * r * s)
        )
        rect(mid + (if (g.face > 0) 0.2f else -0.2f - r * 0.9f), p.y + 0.65f, r * 0.9f, 0.1f, Color(0xFFCFE8FF))
    } else {
        rect(mid + f * 0.3f - 0.04f, p.y + 0.2f, 0.08f, 0.8f, Color(0xFFCFE8FF))
    }
    if (g.shield > 0f) ringLine(mid, p.y + 0.7f, 1.1f, Color(0xFF6FE3FF).copy(alpha = 0.8f), 4f)
    if (g.rage > 0f) ringLine(mid, p.y + 0.7f, 0.9f + 0.1f * sin(frame * 0.4f), Color(0xFFFF4040).copy(alpha = 0.7f), 3f)
}

private fun KnightGame.capeColor(): Color = Color(capeCol)

private fun KCam.foe(f: KFoe, frame: Int) {
    val flash = f.flash > 0f
    fun col(v: Long) = if (flash) Color.White else Color(v)
    val x = f.x; val y = f.y; val w = f.w; val h = f.h
    val mid = x + w / 2
    val d = f.dir.toFloat()
    when (f.type) {
        0 -> {
            oval(x, y + h * 0.15f, w, h * 0.85f, col(0xFF5BD16B))
            circ(mid + d * 0.15f, y + h * 0.5f, 0.07f * w + 0.04f, Color.Black)
            circ(mid - d * 0.1f, y + h * 0.5f, 0.07f * w + 0.04f, Color.Black)
        }
        1 -> {
            val fl = sin(frame * 0.5f) * 0.25f * h
            tri(x, y + h * 0.4f, x - w * 0.6f, y - fl, x + w * 0.35f, y + h * 0.5f, col(0xFF6B4A8F))
            tri(x + w, y + h * 0.4f, x + w * 1.6f, y - fl, x + w * 0.65f, y + h * 0.5f, col(0xFF6B4A8F))
            oval(x + w * 0.2f, y + h * 0.2f, w * 0.6f, h * 0.8f, col(0xFF3A2A4F))
            circ(mid - 0.1f * w, y + h * 0.45f, 0.05f, Color.Red); circ(mid + 0.1f * w, y + h * 0.45f, 0.05f, Color.Red)
        }
        2 -> {
            rect(x + w * 0.2f, y + h * 0.4f, w * 0.6f, h * 0.45f, col(0xFFE8E4D4))
            circ(mid, y + h * 0.25f, w * 0.38f, col(0xFFF4F0E0))
            rect(x + w * 0.25f, y + h * 0.8f, w * 0.2f, h * 0.2f, col(0xFFD8D4C4)); rect(x + w * 0.55f, y + h * 0.8f, w * 0.2f, h * 0.2f, col(0xFFD8D4C4))
            circ(mid - 0.12f * w, y + h * 0.25f, 0.06f, Color.Black); circ(mid + 0.12f * w, y + h * 0.25f, 0.06f, Color.Black)
            rect(mid + d * w * 0.5f - 0.04f, y + h * 0.3f, 0.08f, h * 0.5f, Color(0xFFB0B0B8))
        }
        3 -> {
            tri(x, y + h, mid, y, x + w, y + h, col(0xFF3F7F4A))
            circ(mid, y + h * 0.28f, w * 0.3f, col(0xFFE0C8A0))
            rect(mid + d * w * 0.45f - 0.03f, y + h * 0.3f, 0.06f, h * 0.6f, Color(0xFF8A5A2A))
        }
        4 -> {
            rect(x, y + h * 0.25f, w, h * 0.75f, col(0xFF6E7480))
            rect(x + w * 0.15f, y, w * 0.7f, h * 0.35f, col(0xFF8C93A0))
            tri(x + w * 0.15f, y + 0.1f, x, y - 0.3f, x + w * 0.3f, y, col(0xFFC8C8D0)); tri(x + w * 0.85f, y + 0.1f, x + w, y - 0.3f, x + w * 0.7f, y, col(0xFFC8C8D0))
            rect(x + w * 0.3f, y + h * 0.15f, w * 0.4f, 0.1f, Color(0xFFFF4040))
        }
        5 -> {
            tri(x, y + h, mid, y + h * 0.15f, x + w, y + h, col(0xFF6B3FA0))
            circ(mid, y + h * 0.25f, w * 0.28f, col(0xFFE0C8A0))
            tri(x + w * 0.1f, y + h * 0.25f, mid, y - h * 0.2f, x + w * 0.9f, y + h * 0.25f, col(0xFF4A2A70))
            circ(mid + d * w * 0.6f, y + h * 0.4f + sin(frame * 0.2f) * 0.05f, 0.15f, Color(0xFFD36BFF))
        }
        else -> {
            val a = 0.65f + 0.2f * sin(frame * 0.2f)
            tri(x, y + h, mid, y, x + w, y + h, (if (flash) Color.White else Color(0xFF9CF0FF)).copy(alpha = a))
            circ(mid, y + h * 0.3f, w * 0.35f, (if (flash) Color.White else Color(0xFFCFFAFF)).copy(alpha = a))
            circ(mid - 0.12f * w, y + h * 0.28f, 0.06f, Color.Black); circ(mid + 0.12f * w, y + h * 0.28f, 0.06f, Color.Black)
        }
    }
    if (f.boss) {
        tri(x + w * 0.2f, y - 0.1f, x + w * 0.3f, y - 0.6f, x + w * 0.4f, y - 0.1f, Color(0xFFFFC83D))
        tri(x + w * 0.4f, y - 0.1f, x + w * 0.5f, y - 0.75f, x + w * 0.6f, y - 0.1f, Color(0xFFFFC83D))
        tri(x + w * 0.6f, y - 0.1f, x + w * 0.7f, y - 0.6f, x + w * 0.8f, y - 0.1f, Color(0xFFFFC83D))
    }
    if (f.elite) ringLine(mid, y + h / 2, max(w, h) * 0.7f, Color(0xFFFF4040).copy(alpha = 0.7f), 3f)
    if (!f.boss && f.hp < f.maxHp) {
        rect(x, y - 0.25f, w, 0.1f, Color.Black.copy(alpha = 0.6f))
        rect(x, y - 0.25f, w * (f.hp / f.maxHp).coerceIn(0f, 1f), 0.1f, Color(0xFFFF5252))
    }
}
