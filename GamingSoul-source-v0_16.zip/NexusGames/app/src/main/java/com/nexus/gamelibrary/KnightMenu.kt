package com.nexus.gamelibrary

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Random

// ════════════════════════════════════════════════════════════════
//  Chevalier : menu (aventure, équipement, classes, invocation, forge)
// ════════════════════════════════════════════════════════════════

@Composable
private fun KChip(theme: GameTheme, text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) theme.accent else theme.onBg.copy(alpha = 0.10f))
            .border(1.dp, if (selected) theme.accent else theme.onBg.copy(alpha = 0.15f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Text(text, color = if (selected) Color.White else theme.onBg, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun KBtn(theme: GameTheme, text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .clip(shape)
            .background(if (enabled) theme.accent else theme.onBg.copy(alpha = 0.12f))
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (enabled) Color.White else theme.onBg.copy(alpha = 0.4f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun KnightMenu(theme: GameTheme, version: Int, onBack: () -> Unit, onPlay: (Int) -> Unit) {
    val ctx = LocalContext.current
    val save = remember { KnightSave(ctx) }
    var tick by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var pulled by remember { mutableStateOf<List<Pair<Int, Boolean>>?>(null) }
    var pickPower by remember { mutableStateOf<Int?>(null) }
    val rev = tick + version

    val coins = save.coins + 0 * rev
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Arcade", color = theme.accent, fontSize = 16.sp) }
            Spacer(Modifier.weight(1f))
            Text("🪙 $coins", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Text(
            "⚔️ Chevalier · ${KN.LEVELS} niveaux",
            color = theme.onBg, fontSize = 26.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 20.dp)
        )
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val names = listOf("🗺️ Aventure", "🎒 Équipement", "🎨 Style", "🎭 Classes", "🎰 Invocation", "🔨 Forge")
            names.forEachIndexed { i, n -> KChip(theme, n, tab == i) { tab = i } }
        }
        when (tab) {
            0 -> AdventureTab(theme, save, rev, onPlay)
            1 -> GearTab(theme, save, rev) { tick++ }
            2 -> SkinTab(theme, save)
            3 -> ClassTab(theme, save, rev) { tick++ }
            4 -> GachaTab(theme, save, rev, { tick++ }, { pulled = it }, { pickPower = it })
            else -> ForgeTab(theme, save, rev) { tick++ }
        }
    }

    val pr = pulled
    if (pr != null) {
        AlertDialog(
            onDismissRequest = { pulled = null },
            title = { Text("Invocation") },
            text = {
                Column {
                    pr.forEach { (id, isNew) ->
                        val p = KPower(id)
                        Text(
                            "${p.icon} ${p.name} — ${KN.rarNames[p.rarity]}" + if (isNew) "  NOUVEAU !" else "  (niveau +1)",
                            color = Color(KN.rarColors[p.rarity]), fontWeight = FontWeight.Bold, fontSize = 14.sp
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pulled = null }) { Text("OK") } }
        )
    }
    val pp = pickPower
    if (pp != null) {
        val p = KPower(pp)
        AlertDialog(
            onDismissRequest = { pickPower = null },
            title = { Text("${p.icon} ${p.name}") },
            text = { Text("${p.desc}\nRecharge ${p.cooldown.toInt()} s · puissance x${"%.2f".format(p.mul(save.powers[pp] ?: 1))}\n\nPlacer dans quel emplacement ?") },
            confirmButton = {
                Row {
                    for (s in 0..2) TextButton(onClick = {
                        val lo = save.loadout
                        for (k in 0..2) if (lo[k] == pp) lo[k] = -1
                        lo[s] = pp
                        save.loadout = lo
                        pickPower = null; tick++
                    }) { Text("Slot ${s + 1}") }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    val lo = save.loadout
                    for (k in 0..2) if (lo[k] == pp) lo[k] = -1
                    save.loadout = lo; pickPower = null; tick++
                }) { Text("Retirer") }
            }
        )
    }
}

@Composable
private fun AdventureTab(theme: GameTheme, save: KnightSave, rev: Int, onPlay: (Int) -> Unit) {
    val st = remember(rev) { save.stars() }
    val maxLv = remember(rev) { save.maxLevel() }
    val startIdx = remember { 1 + KN.worldOf(maxLv) * 9 + 1 + ((maxLv - 1) % KN.PER_WORLD) / 5 }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = startIdx)
    val s = save.stats()
    LazyColumn(
        state = state,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item {
            GlassCard(theme) {
                val c = KN.classes[save.cls]
                Text("${c.icon} ${c.name}  ·  ❤ ${s.maxHp}  ⚔ ${s.atk.toInt()}  👟 ${"%.1f".format(s.speed)}", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    "Progression : niveau ${maxLv} / ${KN.LEVELS} · ${st.sum()} / ${KN.LEVELS * 3} ★",
                    color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp
                )
                Text(
                    "Les ennemis deviennent plus durs à chaque niveau : cherche les coffres 🎁 pour t'équiper. 👑 = boss.",
                    color = theme.onBg.copy(alpha = 0.55f), fontSize = 12.sp
                )
            }
        }
        for (w in KN.worlds.indices) {
            item {
                val wd = KN.worlds[w]
                Text(
                    "Monde ${w + 1} · ${wd.name}  (niv. ${w * KN.PER_WORLD + 1}–${(w + 1) * KN.PER_WORLD})",
                    color = Color(wd.grass).let { if (theme.light) theme.onBg else it }, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
            items((0 until 8).toList()) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (c in 0 until 5) {
                        val n = w * KN.PER_WORLD + row * 5 + c + 1
                        val unlocked = n <= maxLv
                        val shape = RoundedCornerShape(12.dp)
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(shape)
                                .background(if (n == maxLv) theme.accent.copy(alpha = 0.35f) else theme.tile)
                                .border(1.dp, theme.onBg.copy(alpha = 0.1f), shape)
                                .then(if (unlocked) Modifier.clickable { onPlay(n) } else Modifier)
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                if (!unlocked) "🔒" else if (n % 10 == 0) "👑$n" else "$n",
                                color = theme.onBg.copy(alpha = if (unlocked) 1f else 0.4f), fontWeight = FontWeight.Bold, fontSize = 14.sp
                            )
                            Text(stars(st[n - 1]), color = if (st[n - 1] > 0) Gold else theme.onBg.copy(alpha = 0.25f), fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun GearTab(theme: GameTheme, save: KnightSave, rev: Int, refresh: () -> Unit) {
    val inv = remember(rev) { save.inv }
    val eq = remember(rev) { save.equipped }
    val worn = remember(rev) { save.equippedItems() }
    val s = remember(rev) { save.stats() }
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            GlassCard(theme) {
                Text("Stats : ❤ ${s.maxHp} · ⚔ ${s.atk.toInt()} · 👟 ${"%.1f".format(s.speed)} · critique ${s.crit}%", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    "Allonge ${"%.1f".format(s.reach)} · vol de vie ${s.lifesteal}% · pièces +${s.coinPct}%" + if (s.dbl) " · double saut" else "",
                    color = theme.onBg.copy(alpha = 0.7f), fontSize = 12.sp
                )
                Spacer(Modifier.height(6.dp))
                for (sl in 0..3) {
                    val it = worn[sl]
                    Text(
                        "${KN.slotIcons[sl]} " + (if (it == null) "— vide —" else "${it.name} · ${it.desc}"),
                        color = if (it == null) theme.onBg.copy(alpha = 0.5f) else Color(KN.rarColors[it.rar]), fontSize = 13.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Sac : ${inv.size} objets", color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.weight(1f))
                KBtn(theme, "Vendre les communs") {
                    val keep = inv.filter { it.rar > 0 || eq.contains(it.id) }
                    val gain = inv.filter { !(it.rar > 0 || eq.contains(it.id)) }.sumOf { it.sell }
                    save.inv = keep; save.coins += gain; refresh()
                }
            }
        }
        items(inv.sortedWith(compareByDescending<KItem> { it.rar }.thenByDescending { it.pw })) { it ->
            val on = eq[it.slot] == it.id
            val shape = RoundedCornerShape(16.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(theme.tile)
                    .border(if (on) 2.dp else 1.dp, if (on) theme.accent else Color(KN.rarColors[it.rar]).copy(alpha = 0.5f), shape)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(KN.slotIcons[it.slot], fontSize = 28.sp, modifier = Modifier.width(40.dp))
                Column(Modifier.weight(1f)) {
                    Text(it.name, color = Color(KN.rarColors[it.rar]), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("${KN.rarNames[it.rar]} · ${it.desc}", color = theme.onBg.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    if (!on) KBtn(theme, "Équiper") {
                        val e = save.equipped; e[it.slot] = it.id; save.equipped = e; refresh()
                    } else Text("Équipé", color = theme.accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Vendre ${it.sell}🪙", color = theme.onBg.copy(alpha = 0.6f), fontSize = 12.sp, modifier = Modifier.clickable {
                        val e = save.equipped
                        if (e[it.slot] == it.id) { e[it.slot] = -1; save.equipped = e }
                        save.inv = save.inv.filter { x -> x.id != it.id }
                        save.coins += it.sell; refresh()
                    })
                }
            }
        }
        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun KnightPreview(sk: KSkin, ver: Int) {
    var frame by remember { mutableIntStateOf(0) }
    var pose by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { frame++ } } }
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(250.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable { pose = (pose + 1) % 3 }
    ) {
        frame
        ver
        drawKnightPreview(sk, frame, pose)
    }
}

@Composable
private fun SkinOptionRow(theme: GameTheme, label: String, names: List<String>, selected: Int, onPick: (Int) -> Unit) {
    Column {
        Text(label, color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { i, n -> KChip(theme, n, selected == i) { onPick(i) } }
        }
    }
}

@Composable
private fun SkinColorRow(theme: GameTheme, label: String, selected: Int, onPick: (Int) -> Unit) {
    Column {
        Text(
            label + " : " + KN.skinColorNames[selected.coerceIn(0, KN.skinColorNames.lastIndex)],
            color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 15.sp
        )
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KN.skinColors.forEachIndexed { i, c ->
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(if (selected == i) 3.dp else 1.dp, if (selected == i) Color.White else Color.Black.copy(alpha = 0.35f), CircleShape)
                        .clickable { onPick(i) }
                )
            }
        }
    }
}

@Composable
private fun SkinTab(theme: GameTheme, save: KnightSave) {
    val sk = remember { save.skin }
    var ver by remember { mutableIntStateOf(0) }
    fun set(i: Int, value: Int) { sk.v[i] = value; save.skin = sk; ver++ }
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                KnightPreview(sk, ver)
                Text(
                    "Touche l'aperçu : repos → course → attaque",
                    color = theme.onBg.copy(alpha = 0.6f), fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KBtn(theme, "🎲 Aléatoire") {
                    val r = KSkin.random(Random())
                    for (i in r.v.indices) sk.v[i] = r.v[i]
                    save.skin = sk; ver++
                }
                KBtn(theme, "↺ Par défaut") {
                    val d = KSkin.default()
                    for (i in d.v.indices) sk.v[i] = d.v[i]
                    save.skin = sk; ver++
                }
            }
        }
        item { SkinOptionRow(theme, "Casque", KN.helmNames, sk.v[0] + 0 * ver) { set(0, it) } }
        item { SkinOptionRow(theme, "Panache", KN.plumeNames, sk.v[1] + 0 * ver) { set(1, it) } }
        item { SkinOptionRow(theme, "Cape", KN.capeNames, sk.v[2] + 0 * ver) { set(2, it) } }
        item { SkinOptionRow(theme, "Épaulières", KN.shoulderNames, sk.v[3] + 0 * ver) { set(3, it) } }
        item { SkinOptionRow(theme, "Emblème", KN.emblemNames, sk.v[4] + 0 * ver) { set(4, it) } }
        item { SkinColorRow(theme, "Armure", sk.v[5] + 0 * ver) { set(5, it) } }
        item { SkinColorRow(theme, "Liseré", sk.v[6] + 0 * ver) { set(6, it) } }
        item { SkinColorRow(theme, "Cape", sk.v[7] + 0 * ver) { set(7, it) } }
        item { SkinColorRow(theme, "Panache", sk.v[8] + 0 * ver) { set(8, it) } }
        item { SkinColorRow(theme, "Yeux / lueur", sk.v[9] + 0 * ver) { set(9, it) } }
        item { SkinColorRow(theme, "Lame", sk.v[10] + 0 * ver) { set(10, it) } }
        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun ClassTab(theme: GameTheme, save: KnightSave, rev: Int, refresh: () -> Unit) {
    val cur = remember(rev) { save.cls }
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(KN.classes.size) { i ->
            val c = KN.classes[i]
            val shape = RoundedCornerShape(16.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(theme.tile)
                    .border(if (cur == i) 2.dp else 1.dp, if (cur == i) Color(c.color) else theme.onBg.copy(alpha = 0.1f), shape)
                    .clickable { save.cls = i; refresh() }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(c.icon, fontSize = 34.sp, modifier = Modifier.width(48.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name + if (cur == i) "  ✔" else "", color = Color(c.color), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(c.desc, color = theme.onBg.copy(alpha = 0.8f), fontSize = 13.sp)
                    Text(
                        "PV x${c.hp} · dégâts x${c.dmg} · vitesse x${c.spd} · critique ${c.crit}% · attaque x${"%.2f".format(1f / c.atkCd)} · pouvoirs x${c.pow}",
                        color = theme.onBg.copy(alpha = 0.55f), fontSize = 11.sp
                    )
                }
            }
        }
        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun GachaTab(
    theme: GameTheme, save: KnightSave, rev: Int, refresh: () -> Unit,
    onPulled: (List<Pair<Int, Boolean>>) -> Unit, onPick: (Int) -> Unit
) {
    val owned = remember(rev) { save.powers }
    val lo = remember(rev) { save.loadout }
    val coins = save.coins
    fun pull(n: Int) {
        val cost = if (n == 10) KN.PULL_COST * 9 else KN.PULL_COST
        if (save.coins < cost) return
        save.coins -= cost
        val r = Random()
        val res = ArrayList<Pair<Int, Boolean>>()
        repeat(n) {
            val id = KN.rollPower(r)
            val isNew = save.addPower(id)
            res.add(id to isNew)
            val l = save.loadout
            if (isNew && !l.contains(id)) {
                val free = l.indexOf(-1)
                if (free >= 0) { l[free] = id; save.loadout = l }
            }
        }
        onPulled(res)
        refresh()
    }
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            GlassCard(theme) {
                Text("Mon set d'attaque (3 pouvoirs en combat)", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                for (s in 0..2) {
                    val id = lo[s]
                    Text(
                        "Slot ${s + 1} : " + (if (id < 0) "— vide — (touche un pouvoir ci-dessous)" else KPower(id).let { "${it.icon} ${it.name} (niv. ${owned[id] ?: 1})" }),
                        color = if (id < 0) theme.onBg.copy(alpha = 0.5f) else Color(KPower(id).color), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
        }
        item {
            GlassCard(theme) {
                Text("🎰 Invocation de pouvoirs", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "50 pouvoirs : 10 types × 5 éléments. Commun 35% · Peu commun 30% · Rare 20% · Épique 11% · Légendaire 4%. Un doublon augmente le niveau du pouvoir (max 5). Les coffres peuvent aussi en contenir.",
                    color = theme.onBg.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KBtn(theme, "×1 · ${KN.PULL_COST}🪙", coins >= KN.PULL_COST) { pull(1) }
                    KBtn(theme, "×10 · ${KN.PULL_COST * 9}🪙", coins >= KN.PULL_COST * 9) { pull(10) }
                }
            }
        }
        item {
            Text("Collection : ${owned.size} / 50", color = theme.accent, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        items(50) { id ->
            val p = KPower(id)
            val lvl = owned[id] ?: 0
            val shape = RoundedCornerShape(14.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(theme.tile)
                    .border(1.dp, Color(KN.rarColors[p.rarity]).copy(alpha = if (lvl > 0) 0.8f else 0.2f), shape)
                    .then(if (lvl > 0) Modifier.clickable { onPick(id) } else Modifier)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (lvl > 0) p.icon else "❔", fontSize = 26.sp, modifier = Modifier.width(40.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (lvl > 0) p.name else "???",
                        color = if (lvl > 0) Color(p.color) else theme.onBg.copy(alpha = 0.4f), fontWeight = FontWeight.Bold, fontSize = 14.sp
                    )
                    Text(
                        if (lvl > 0) "${KN.rarNames[p.rarity]} · ${p.desc} · ${p.cooldown.toInt()} s" else KN.rarNames[p.rarity],
                        color = theme.onBg.copy(alpha = 0.6f), fontSize = 11.sp
                    )
                }
                if (lvl > 0) Text("Niv. $lvl", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun ForgeTab(theme: GameTheme, save: KnightSave, rev: Int, refresh: () -> Unit) {
    val hp = save.upgHp
    val atk = save.upgAtk
    val costHp = 60 + hp * 40
    val costAtk = 80 + atk * 50
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassCard(theme) {
                Text("❤ Cœur de fer · niveau $hp", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("+12 PV max par niveau", color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                KBtn(theme, "Améliorer · ${costHp}🪙", save.coins >= costHp) { save.coins -= costHp; save.upgHp = hp + 1; refresh() }
            }
        }
        item {
            GlassCard(theme) {
                Text("⚔ Lame affûtée · niveau $atk", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("+2 dégâts par niveau", color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                KBtn(theme, "Améliorer · ${costAtk}🪙", save.coins >= costAtk) { save.coins -= costAtk; save.upgAtk = atk + 1; refresh() }
            }
        }
        item {
            Text("Gagne des pièces en tuant des ennemis et en ouvrant des coffres.", color = theme.onBg.copy(alpha = 0.55f), fontSize = 12.sp)
        }
    }
}
