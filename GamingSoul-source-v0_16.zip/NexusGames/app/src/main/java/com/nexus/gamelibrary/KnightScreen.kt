package com.nexus.gamelibrary

import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner

private data class KHud(
    val hp: Int, val maxHp: Int, val coins: Int, val msg: String, val over: Boolean, val won: Boolean,
    val bossPct: Int, val cds: List<Int>, val dash: Boolean
)

private const val KSTEP = 1f / 60f

private fun hudOf(g: KnightGame): KHud {
    val boss = g.foes.firstOrNull { it.boss && !it.dead }
    return KHud(
        g.hp.toInt(), g.st.maxHp, g.coinsGained, g.msg, g.over, g.won,
        if (boss != null) (boss.hp / boss.maxHp * 100).toInt().coerceIn(0, 100) else -1,
        List(3) { max(0, ceil(g.pcd[it]).toInt()) },
        g.dashCd <= 0f
    )
}

@Composable
fun KnightGameScreen(level: Int, onExit: () -> Unit, onNext: () -> Unit) {
    val context = LocalContext.current
    val save = remember { KnightSave(context) }
    var attempt by remember(level) { mutableIntStateOf(0) }
    val game = remember(level, attempt) { KnightGame(level, save.stats(), save.loadout, save.powers, save.skin.col(7), save.skin) }
    var paused by remember(level, attempt) { mutableStateOf(false) }
    var hud by remember(game) { mutableStateOf(hudOf(game)) }
    var frame by remember(game) { mutableIntStateOf(0) }
    var showHelp by remember(game) { mutableStateOf(true) }
    val committed = remember(game) { booleanArrayOf(false) }
    val loadout = remember(game) { save.loadout }
    val audio = remember { KAudio() }
    var sfxOn by remember { mutableStateOf(save.sfxOn) }
    var musicOn by remember { mutableStateOf(save.musicOn) }
    audio.sfxOn = sfxOn
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(Unit) { onDispose { audio.release() } }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_PAUSE) audio.pauseMusic()
            else if (ev == Lifecycle.Event.ON_RESUME && !paused && !game.over) audio.resumeMusic()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    // Musique propre à chaque niveau (générée sur un autre thread)
    LaunchedEffect(game) {
        audio.stopMusic()
        audio.musicOn = musicOn
        val data = withContext(Dispatchers.Default) { KMusic.generate(level) }
        audio.startMusic(data)
    }
    LaunchedEffect(paused) { if (paused) audio.pauseMusic() else if (!game.over) audio.resumeMusic() }
    LaunchedEffect(hud.over) { if (hud.over) audio.stopMusic() }

    fun commit() {
        if (committed[0]) return
        committed[0] = true
        save.coins += game.coinsGained
        if (game.foundItems.isNotEmpty()) {
            save.inv = save.inv + game.foundItems
            // équipe automatiquement dans un emplacement vide
            val eq = save.equipped
            val inv = save.inv
            for (it in game.foundItems) {
                if (inv.none { x -> x.id == eq[it.slot] }) eq[it.slot] = it.id
            }
            save.equipped = eq
        }
        for (id in game.foundPowers) {
            val isNew = save.addPower(id)
            val l = save.loadout
            if (isNew && !l.contains(id)) { val f = l.indexOf(-1); if (f >= 0) { l[f] = id; save.loadout = l } }
        }
        if (game.won) save.setStars(level, game.stars())
    }

    LaunchedEffect(game) { delay(7000); showHelp = false }

    DisposableEffect(Unit) {
        val act = context.findActivity()
        val window = act?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    LaunchedEffect(game, paused) {
        if (paused) return@LaunchedEffect
        var last = 0L
        var acc = 0f
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) {
                    acc += min(0.05f, (now - last) / 1_000_000_000f)
                    while (acc >= KSTEP) { game.step(KSTEP); acc -= KSTEP }
                }
                last = now
                val h = hudOf(game)
                if (h != hud) hud = h
                if (game.over) commit()
                if (game.sfx.isNotEmpty()) {
                    val seen = HashSet<Int>()
                    while (game.sfx.isNotEmpty()) seen.add(game.sfx.removeFirst())
                    for (id in seen) audio.play(id)
                }
                frame++
            }
        }
    }

    fun exit() { commit(); onExit() }
    BackHandler { if (!hud.over) paused = !paused else exit() }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
            .background(Color.Black)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            frame
            drawKnight(game, frame)
        }

        // ── HUD
        Column(
            Modifier.align(Alignment.TopCenter).safeDrawingPadding().padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("❤", color = Color(0xFFFF6B6B), fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                Box(Modifier.width(140.dp).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color.White.copy(alpha = 0.2f))) {
                    Box(
                        Modifier.fillMaxSize().padding(end = (140f * (1f - hud.hp.toFloat() / hud.maxHp).coerceIn(0f, 1f)).dp)
                            .background(Color(0xFFFF5252))
                    )
                }
                Spacer(Modifier.width(6.dp))
                Text("${hud.hp}/${hud.maxHp}", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                Spacer(Modifier.width(10.dp))
                Text("🪙 ${hud.coins}", color = Gold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Text(
                "Niv. $level · ${game.world.name}" + if (game.boss) " · 👑 BOSS" else "",
                color = Color.White.copy(alpha = 0.85f), fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
            if (hud.bossPct >= 0) {
                Text(game.bossName.uppercase() + "  " + hud.bossPct + "%", color = Color(0xFFFF8A80), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            if (hud.msg.isNotEmpty()) {
                Text(
                    hud.msg, color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }

        if (showHelp && !hud.over) {
            Text(
                "◀ ▶ bouger · SAUT (maintenir = plus haut) · ⚔ attaque · DASH esquive · 3 pouvoirs · ouvre les coffres · atteins la porte",
                color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 10.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).safeDrawingPadding().padding(bottom = 2.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }

        Box(
            Modifier.align(Alignment.TopStart).safeDrawingPadding().padding(8.dp).size(40.dp).clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f)).clickable { if (!hud.over) paused = true },
            contentAlignment = Alignment.Center
        ) { Text("II", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        // ── Commandes
        Row(
            Modifier.align(Alignment.BottomStart).safeDrawingPadding().padding(start = 18.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PadButton("◀", 76.dp, Color.White) { down -> game.inp.left = down }
            PadButton("▶", 76.dp, Color.White) { down -> game.inp.right = down }
        }
        Column(
            Modifier.align(Alignment.BottomEnd).safeDrawingPadding().padding(end = 18.dp, bottom = 16.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (i in 0..2) {
                    val id = loadout[i]
                    val cd = hud.cds[i]
                    val lbl = if (id < 0) "–" else if (cd > 0) "$cd" else KPower(id).icon
                    val col = if (id < 0) Color.Gray else Color(KPower(id).color)
                    PadButton(lbl, 56.dp, col, onPress = { game.inp.pw[i] = true }) { }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Bottom) {
                PadButton("DASH", 56.dp, if (hud.dash) Color(0xFF80D8FF) else Color.Gray, onPress = { game.inp.dashLatch = true }) { }
                PadButton("⚔", 76.dp, Color(0xFFFF8A80), onPress = { game.inp.atkLatch = true }) { }
                PadButton("SAUT", 84.dp, Gold, onPress = { game.inp.jumpLatch = true }) { down -> game.inp.jumpHeld = down }
            }
        }

        if (paused && !hud.over) {
            OverlayCard {
                Text("PAUSE", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                Spacer(Modifier.height(14.dp))
                OverlayButton("Continuer", Gold) { paused = false }
                OverlayButton(if (musicOn) "Musique : oui" else "Musique : non", Color.White) {
                    musicOn = !musicOn; save.musicOn = musicOn; audio.setMusic(musicOn)
                }
                OverlayButton(if (sfxOn) "Sons : oui" else "Sons : non", Color.White) {
                    sfxOn = !sfxOn; save.sfxOn = sfxOn
                }
                OverlayButton("Recommencer", Color.White) { commit(); attempt++ }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { exit() }
            }
        }

        if (hud.over) {
            OverlayCard {
                Text(
                    if (hud.won) "NIVEAU TERMINÉ !" else "DÉFAITE",
                    color = if (hud.won) Gold else Color(0xFFFF8A80), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp
                )
                if (hud.won) Text(stars(game.stars()), color = Gold, fontSize = 30.sp)
                Text("🪙 +${game.coinsGained} · ☠ ${game.kills} · 🎁 ${game.chestsOpened}", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                for (it in game.foundItems.take(4)) {
                    Text("${KN.slotIcons[it.slot]} ${it.name}", color = Color(KN.rarColors[it.rar]), fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                for (id in game.foundPowers.take(3)) {
                    Text("${KPower(id).icon} ${KPower(id).name}", color = Color(KPower(id).color), fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                if (hud.won && level < KN.LEVELS) OverlayButton("Niveau suivant", Gold) { commit(); onNext() }
                OverlayButton("Rejouer", Color.White) { commit(); attempt++ }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { exit() }
            }
        }
    }
}
