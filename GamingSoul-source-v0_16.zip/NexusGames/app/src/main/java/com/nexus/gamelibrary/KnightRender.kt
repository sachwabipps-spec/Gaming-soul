package com.nexus.gamelibrary

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ════════════════════════════════════════════════════════════════
//  Chevalier : rendu (décor gothique en couches, brume, lumières,
//  contours encrés, chevalier personnalisable)
// ════════════════════════════════════════════════════════════════

internal val INK = Color(0xFF07070F)

/** Caméra : convertit les coordonnées du monde (en tuiles) en pixels. Si tint != null, tout est dessiné de cette couleur (contours). */
internal class KCam(val ds: DrawScope, val s: Float, val cx: Float, val cy: Float, val tint: Color? = null) {
    private fun tc(c: Color): Color = tint ?: c
    private fun px(x: Float) = (x - cx) * s
    private fun py(y: Float) = (y - cy) * s

    fun rect(x: Float, y: Float, w: Float, h: Float, c: Color) =
        ds.drawRect(tc(c), Offset(px(x), py(y)), Size(w * s, h * s))

    fun oval(x: Float, y: Float, w: Float, h: Float, c: Color) =
        ds.drawOval(tc(c), Offset(px(x), py(y)), Size(w * s, h * s))

    fun circ(x: Float, y: Float, r: Float, c: Color) = ds.drawCircle(tc(c), r * s, Offset(px(x), py(y)))

    fun ringLine(x: Float, y: Float, r: Float, c: Color, w: Float) =
        ds.drawCircle(tc(c), r * s, Offset(px(x), py(y)), style = Stroke(width = w))

    fun line(x1: Float, y1: Float, x2: Float, y2: Float, c: Color, w: Float) =
        ds.drawLine(tc(c), Offset(px(x1), py(y1)), Offset(px(x2), py(y2)), strokeWidth = max(1f, w * s), cap = StrokeCap.Round)

    fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, c: Color) {
        val p = Path()
        p.moveTo(px(x1), py(y1))
        p.lineTo(px(x2), py(y2))
        p.lineTo(px(x3), py(y3))
        p.close()
        ds.drawPath(p, tc(c))
    }

    /** Polygone : poly(couleur, x1, y1, x2, y2, ...) */
    fun poly(c: Color, vararg pts: Float) {
        if (pts.size < 6) return
        val p = Path()
        p.moveTo(px(pts[0]), py(pts[1]))
        var i = 2
        while (i + 1 < pts.size) {
            p.lineTo(px(pts[i]), py(pts[i + 1]))
            i += 2
        }
        p.close()
        ds.drawPath(p, tc(c))
    }

    /** Halo lumineux doux (ignoré pour les contours). */
    fun glow(x: Float, y: Float, r: Float, c: Color, a: Float) {
        if (tint != null || r <= 0f) return
        val ctr = Offset(px(x), py(y))
        ds.drawCircle(
            Brush.radialGradient(listOf(c.copy(alpha = a), c.copy(alpha = 0f)), center = ctr, radius = r * s),
            r * s, ctr
        )
    }

    fun shifted(dx: Float, dy: Float, t: Color?): KCam = KCam(ds, s, cx - dx, cy - dy, t)
}

private val OUTLINE = floatArrayOf(0.055f, 0f, -0.055f, 0f, 0f, 0.055f, 0f, -0.055f)

private inline fun KCam.inked(draw: KCam.() -> Unit) {
    var i = 0
    while (i < OUTLINE.size) {
        shifted(OUTLINE[i], OUTLINE[i + 1], INK).draw()
        i += 2
    }
    this.draw()
}

private fun hsh(a: Int, b: Int): Float {
    var h = a * 374761393 + b * 668265263
    h = (h xor (h ushr 13)) * 1274126177.toInt()
    h = h xor (h ushr 16)
    return (h and 0xFFFF) / 65535f
}

private fun DrawScope.triPx(c: Color, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
    val p = Path()
    p.moveTo(x1, y1)
    p.lineTo(x2, y2)
    p.lineTo(x3, y3)
    p.close()
    drawPath(p, c)
}

// 0 collines et arbres · 1 cité gothique · 2 montagnes / dunes · 3 grottes
private val WORLD_STYLE = intArrayOf(0, 0, 3, 0, 2, 2, 3, 1, 2, 1, 1, 1, 3)
private val DARK_CEILING = booleanArrayOf(false, true, true, true, false, false, true, true, true, true, true, true, true)

// ════════════════════════════════════════════════════════════════
//  Décor lointain
// ════════════════════════════════════════════════════════════════

private fun DrawScope.drawStructure(
    style: Int, wi: Int, k: Int, salt: Int, xp: Float, base: Float, u: Float, seg: Float,
    col: Color, lit: Color, accent: Color, layer: Int, frame: Int
) {
    val h1 = hsh(k, salt)
    val h2 = hsh(k, salt + 101)
    val h3 = hsh(k, salt + 202)
    val wid = seg * u
    when (style) {
        0 -> { // collines + arbres
            val hh = (1.4f + h1 * 2.2f) * u
            drawOval(col, Offset(xp - wid * 0.1f, base - hh), Size(wid * 1.2f, hh * 2f))
            val n = 1 + (h2 * 3f).toInt()
            for (i in 0 until n) {
                val tx = xp + wid * (0.1f + 0.8f * hsh(k, salt + 10 + i))
                val th = (2.2f + 2.6f * hsh(k, salt + 30 + i)) * u
                val ty = base - hh * 0.6f
                for (j in 0..2) {
                    val top = ty - th * (1f - j * 0.27f)
                    val half = th * 0.2f * (1f + j * 0.55f)
                    triPx(col, tx, top, tx - half, top + th * 0.42f, tx + half, top + th * 0.42f)
                }
                drawRect(col, Offset(tx - 0.08f * u, ty - th * 0.2f), Size(0.16f * u, th * 0.3f))
            }
        }
        1 -> { // cité gothique
            val kind = (h1 * 3f).toInt().coerceIn(0, 2)
            val bx = xp + wid * 0.5f
            when (kind) {
                0 -> {
                    val tw = (1.1f + h2 * 0.9f) * u
                    val th = (3.5f + h3 * 4.5f) * u
                    drawRect(col, Offset(bx - tw / 2f, base - th), Size(tw, th + 2f))
                    triPx(col, bx - tw * 0.62f, base - th, bx, base - th - tw * 2.6f, bx + tw * 0.62f, base - th)
                    val sw = tw * 0.28f
                    for (sd in intArrayOf(-1, 1)) {
                        val sx = bx + sd * tw * 0.62f
                        drawRect(col, Offset(sx - sw / 2f, base - th * 0.6f), Size(sw, th * 0.6f))
                        triPx(col, sx - sw * 0.8f, base - th * 0.6f, sx, base - th * 0.6f - sw * 3f, sx + sw * 0.8f, base - th * 0.6f)
                    }
                    if (layer >= 1) {
                        val a = 0.5f + 0.2f * sin(frame * 0.05f + k)
                        val wy = base - th * 0.75f
                        drawRect(lit.copy(alpha = a), Offset(bx - tw * 0.12f, wy), Size(tw * 0.24f, tw * 0.5f))
                        triPx(lit.copy(alpha = a), bx - tw * 0.12f, wy, bx, wy - tw * 0.2f, bx + tw * 0.12f, wy)
                    }
                }
                1 -> {
                    val bw = 4.6f * u
                    val bh = (2.2f + h2 * 0.8f) * u
                    drawRect(col, Offset(bx - bw / 2f, base - bh), Size(bw, bh + 2f))
                    drawOval(col, Offset(bx - bw * 0.3f, base - bh - bw * 0.22f), Size(bw * 0.6f, bw * 0.44f))
                    val dy = base - bh - bw * 0.2f
                    triPx(col, bx - bw * 0.05f, dy, bx, dy - bw * 0.45f, bx + bw * 0.05f, dy)
                    for (sd in intArrayOf(-1, 1)) {
                        val sx = bx + sd * bw * 0.5f
                        val sw = bw * 0.07f
                        drawRect(col, Offset(sx - sw, base - bh * 1.5f), Size(sw * 2f, bh * 0.5f + 1f))
                        triPx(col, sx - sw * 1.3f, base - bh * 1.5f, sx, base - bh * 1.5f - bw * 0.28f, sx + sw * 1.3f, base - bh * 1.5f)
                    }
                    if (layer >= 1) {
                        val a = 0.5f + 0.2f * sin(frame * 0.04f + k * 2f)
                        drawRect(lit.copy(alpha = a), Offset(bx - bw * 0.05f, base - bh * 0.85f), Size(bw * 0.1f, bh * 0.5f))
                        triPx(lit.copy(alpha = a), bx - bw * 0.05f, base - bh * 0.85f, bx, base - bh * 0.85f - bw * 0.07f, bx + bw * 0.05f, base - bh * 0.85f)
                    }
                }
                else -> {
                    val beamY = base - (2.4f + h2 * 1.5f) * u
                    drawRect(col, Offset(xp - 1f, beamY), Size(wid + 2f, 0.45f * u))
                    for (i in 0..1) drawRect(col, Offset(xp + wid * (0.1f + 0.7f * i), beamY), Size(0.7f * u, base - beamY + 2f))
                    var bxx = xp
                    while (bxx < xp + wid) {
                        drawRect(col, Offset(bxx, beamY - 0.3f * u), Size(0.1f * u, 0.3f * u))
                        bxx += 0.4f * u
                    }
                    if (h3 > 0.4f) {
                        val sx = xp + wid * 0.1f + 0.35f * u
                        triPx(col, sx - 0.35f * u, beamY, sx, beamY - 1.8f * u, sx + 0.35f * u, beamY)
                    }
                }
            }
        }
        2 -> { // montagnes / dunes
            val hh = (2.5f + h1 * 4.5f) * u
            val pk = xp + wid * (0.3f + 0.4f * h2)
            if (wi == 4) {
                drawOval(col, Offset(xp - wid * 0.3f, base - hh * 0.45f), Size(wid * 1.6f, hh * 0.9f))
                if (h3 > 0.65f) {
                    val ox = xp + wid * 0.5f
                    val oy = base - hh * 0.45f
                    drawRect(col, Offset(ox, oy - 2.6f * u), Size(0.5f * u, 2.6f * u))
                    triPx(col, ox - 0.03f * u, oy - 2.6f * u, ox + 0.25f * u, oy - 3.3f * u, ox + 0.53f * u, oy - 2.6f * u)
                }
            } else {
                val lx0 = xp - wid * 0.25f
                val rx0 = xp + wid * 1.25f
                triPx(col, lx0, base, pk, base - hh, rx0, base)
                if (wi == 5) {
                    val cap = Color(0xFFEAF4FF).copy(alpha = 0.35f + 0.1f * layer)
                    val lx = pk + (lx0 - pk) * 0.3f
                    val rx = pk + (rx0 - pk) * 0.3f
                    triPx(cap, lx, base - hh * 0.7f, pk, base - hh, rx, base - hh * 0.7f)
                } else if (wi == 8 && layer >= 1) {
                    val c = Offset(pk, base - hh)
                    val r = 2.6f * u
                    drawCircle(Brush.radialGradient(listOf(Color(0xFFFF7A2A).copy(alpha = 0.5f), Color.Transparent), center = c, radius = r), r, c)
                }
            }
        }
        else -> { // grottes
            val ln = (1.2f + h1 * 2.8f) * u
            val sx = xp + wid * (0.15f + 0.7f * h2)
            triPx(col, sx - 0.6f * u, base, sx, base - ln, sx + 0.6f * u, base)
            val tl = (1.0f + h3 * 2.5f) * u * (0.6f + 0.3f * layer)
            val tx2 = xp + wid * (0.1f + 0.8f * hsh(k, salt + 5))
            triPx(col, tx2 - 0.55f * u, -2f, tx2, tl, tx2 + 0.55f * u, -2f)
            if (hsh(k, salt + 9) < 0.2f) drawRect(col, Offset(tx2 - 0.35f * u, 0f), Size(0.7f * u, base))
            if (wi == 6 || wi == 2) {
                val cs = sx + 1.1f * u
                val a = 0.5f + 0.25f * sin(frame * 0.04f + k)
                triPx(accent.copy(alpha = a), cs - 0.25f * u, base, cs, base - (0.8f + h3) * u * 1.3f, cs + 0.25f * u, base)
                val gc = Offset(cs, base - 0.5f * u)
                drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.22f), Color.Transparent), center = gc, radius = 1.6f * u), 1.6f * u, gc)
            }
            if (wi == 12 && h3 > 0.5f) {
                val on = ((frame / 40 + k) % 3) != 0
                if (on) {
                    val ex = sx + 0.5f * u
                    val ey = base - ln * 0.5f
                    drawCircle(accent.copy(alpha = 0.8f), 0.05f * u, Offset(ex, ey))
                    drawCircle(accent.copy(alpha = 0.8f), 0.05f * u, Offset(ex + 0.25f * u, ey))
                }
            }
        }
    }
}

private fun DrawScope.drawBackdrop(wi: Int, w: KWorld, cx: Float, cy: Float, s: Float, viewW: Float, frame: Int) {
    val sky1 = Color(w.sky1)
    val sky2 = Color(w.sky2)
    drawRect(Brush.verticalGradient(listOf(sky1, sky2)), Offset.Zero, size)
    val halo = lerp(sky2, Color.White, 0.6f)
    val hc = Offset(size.width * 0.68f, size.height * 0.26f)
    val hr = size.height * 0.8f
    drawCircle(Brush.radialGradient(listOf(halo.copy(alpha = 0.55f), halo.copy(alpha = 0f)), center = hc, radius = hr), hr, hc)
    drawCircle(halo.copy(alpha = 0.85f), size.height * 0.06f, hc)

    // faisceaux de lumière
    for (i in 0..2) {
        val x0 = size.width * (0.18f + 0.3f * i) - cx * s * 0.05f
        val sway = sin(frame * 0.008f + i * 2f) * s * 0.4f
        val p = Path()
        p.moveTo(x0, 0f)
        p.lineTo(x0 + s * 1.4f, 0f)
        p.lineTo(x0 + s * 3.6f + sway, size.height * 0.85f)
        p.lineTo(x0 + s * 1.6f + sway, size.height * 0.85f)
        p.close()
        drawPath(p, Brush.verticalGradient(listOf(halo.copy(alpha = 0.13f), Color.Transparent), startY = 0f, endY = size.height * 0.85f))
    }

    val style = WORLD_STYLE[wi.coerceIn(0, WORLD_STYLE.lastIndex)]
    val lit = lerp(halo, Color(0xFFFFE9B0), 0.55f)
    val accent = Color(w.grass)
    val fog = lerp(sky2, Color.White, 0.28f)
    for (layer in 0..2) {
        val factor = 0.10f + 0.12f * layer
        val off = cx * factor
        val seg = 7f - layer
        val first = floor(off / seg).toInt() - 1
        val col = lerp(sky2, Color.Black, 0.38f + 0.2f * layer)
        val base = (11.5f - cy * (0.6f + 0.2f * layer) - (2 - layer) * 0.7f) * s
        for (kk in first..first + (viewW / seg).toInt() + 3) {
            val xp = (kk * seg - off) * s
            drawStructure(style, wi, kk, wi * 7 + layer, xp, base, s, seg, col, lit, accent, layer, frame)
        }
        val fh = 5f * s
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, fog.copy(alpha = 0.30f + 0.05f * layer)), startY = base - fh, endY = base),
            Offset(0f, base - fh), Size(size.width, fh)
        )
        if (base < size.height) drawRect(col, Offset(0f, base), Size(size.width, size.height - base))
    }
}

// ════════════════════════════════════════════════════════════════
//  Terrain, décors, objets
// ════════════════════════════════════════════════════════════════

private fun KCam.lamp(x: Float, groundY: Float, glowCol: Color, frame: Int, seed: Int) {
    val post = Color(0xFF0D0D1A)
    val top = groundY - 2.5f
    rect(x - 0.045f, top, 0.09f, 2.5f, post)
    rect(x - 0.14f, groundY - 0.18f, 0.28f, 0.18f, post)
    rect(x - 0.09f, groundY - 0.45f, 0.18f, 0.1f, post)
    val fl = 0.85f + 0.15f * sin(frame * 0.07f + seed)
    for (sd in intArrayOf(-1, 1)) {
        val lx = x + sd * 0.5f
        line(x, top + 0.1f, x + sd * 0.25f, top - 0.12f, post, 0.06f)
        line(x + sd * 0.25f, top - 0.12f, lx, top + 0.05f, post, 0.06f)
        glow(lx, top + 0.2f, 2.8f, glowCol, 0.32f * fl)
        circ(lx, top + 0.22f, 0.17f, post)
        circ(lx, top + 0.22f, 0.12f, lerp(glowCol, Color.White, 0.6f).copy(alpha = 0.95f))
    }
}

private fun KCam.fern(x: Float, groundY: Float, frame: Int, seed: Int) {
    val ink = Color(0xFF0B0B16)
    val sw = sin(frame * 0.03f + seed) * 0.05f
    for (b in 0..1) {
        val d = if (b == 0) 1f else -1f
        val h = 0.55f + 0.25f * hsh(seed, b)
        line(x, groundY, x + d * 0.06f, groundY - h * 0.5f, ink, 0.05f)
        line(x + d * 0.06f, groundY - h * 0.5f, x + d * (0.2f + sw), groundY - h, ink, 0.045f)
        line(x + d * (0.2f + sw), groundY - h, x + d * (0.38f + sw), groundY - h * 0.85f, ink, 0.04f)
        circ(x + d * (0.38f + sw), groundY - h * 0.85f, 0.065f, ink)
    }
}

private fun KCam.crystalDecor(x: Float, groundY: Float, accent: Color, frame: Int, seed: Int) {
    val a = 0.7f + 0.25f * sin(frame * 0.05f + seed)
    val cc = lerp(accent, Color.White, 0.25f).copy(alpha = a)
    glow(x, groundY - 0.3f, 1.4f, accent, 0.25f)
    for (i in -1..1) {
        val hgt = 0.35f + 0.3f * hsh(seed, i + 5)
        tri(x + i * 0.18f - 0.1f, groundY, x + i * 0.18f, groundY - hgt, x + i * 0.18f + 0.1f, groundY, INK)
        tri(x + i * 0.18f - 0.07f, groundY, x + i * 0.18f, groundY - hgt + 0.06f, x + i * 0.18f + 0.07f, groundY, cc)
    }
}

private fun DrawScope.drawTerrain(g: KnightGame, c: KCam, w: KWorld, wi: Int, cx: Float, cy: Float, viewW: Float, viewH: Float, frame: Int) {
    val ground = Color(w.ground)
    val grass = Color(w.grass)
    val style = WORLD_STYLE[wi.coerceIn(0, WORLD_STYLE.lastIndex)]
    val x0 = floor(cx).toInt().coerceAtLeast(0)
    val x1 = min(g.W - 1, floor(cx + viewW).toInt() + 1)
    val y0 = floor(cy).toInt().coerceAtLeast(0)
    val y1 = min(KnightGame.H - 1, floor(cy + viewH).toInt() + 1)
    val lampCol = lerp(Color(w.sky2), Color(0xFFFFF1C8), 0.75f)

    // décors posés sur la surface
    for (tx in x0..x1) {
        for (ty in 0 until KnightGame.H) {
            if (!g.solid(tx, ty)) continue
            if (g.solid(tx, ty - 1)) break
            if (ty < y0 - 3 || ty > y1 + 2) break
            val hl = hsh(tx, 77)
            val ex = tx + 0.5f
            val flat = g.solid(tx - 1, ty) && g.solid(tx + 1, ty) && !g.solid(tx - 1, ty - 1) && !g.solid(tx + 1, ty - 1)
            if (hl < 0.07f && flat && tx > 4 && tx < g.W - 8) c.lamp(ex, ty.toFloat() + 0.02f, lampCol, frame, tx)
            else if (hl in 0.07f..0.3f && tx > 3 && tx < g.W - 6) {
                if (style == 3) c.crystalDecor(ex, ty.toFloat() + 0.02f, grass, frame, tx)
                else c.fern(ex, ty.toFloat() + 0.02f, frame, tx)
            }
            break
        }
    }

    // tuiles
    for (ty in y0..y1) for (tx in x0..x1) {
        val t = g.tiles[ty * g.W + tx].toInt()
        if (t == 1) {
            val hh = hsh(tx, ty)
            val depth = ((ty - 9) * 0.05f).coerceIn(0f, 0.45f)
            val baseC = lerp(ground, Color.Black, depth + 0.1f)
            val fx = tx.toFloat()
            val fy = ty.toFloat()
            c.rect(fx, fy, 1.02f, 1.02f, baseC)
            val cobble = if (hh > 0.5f) lerp(baseC, Color.Black, 0.2f) else lerp(baseC, Color.White, 0.05f)
            c.oval(fx + 0.07f, fy + 0.08f, 0.86f, 0.84f, cobble)
            if (depth < 0.3f) c.oval(fx + 0.2f, fy + 0.15f, 0.3f, 0.14f, lerp(baseC, Color.White, 0.16f))
            val up = g.solid(tx, ty - 1)
            if (!up) {
                c.rect(fx - 0.01f, fy, 1.04f, 0.2f, grass)
                for (b in 0..2) {
                    val bh = 0.1f + 0.14f * hsh(tx * 3 + b, ty)
                    c.tri(fx + 0.08f + 0.3f * b, fy + 0.02f, fx + 0.2f + 0.3f * b, fy - bh, fx + 0.32f + 0.3f * b, fy + 0.02f, grass)
                }
                c.rect(fx - 0.01f, fy + 0.2f, 1.04f, 0.06f, INK.copy(alpha = 0.7f))
            }
            if (!g.solid(tx - 1, ty)) c.rect(fx - 0.01f, fy, 0.08f, 1.02f, INK)
            if (!g.solid(tx + 1, ty)) c.rect(fx + 0.95f, fy, 0.08f, 1.02f, INK)
            if (ty + 1 < KnightGame.H && !g.solid(tx, ty + 1)) {
                c.rect(fx - 0.01f, fy + 0.94f, 1.04f, 0.09f, INK)
                if (hsh(tx, ty + 50) < 0.4f) {
                    val len = 0.4f + 0.8f * hsh(tx + 9, ty)
                    c.tri(fx + 0.12f, fy + 1f, fx + 0.5f, fy + 1f + len, fx + 0.88f, fy + 1f, lerp(baseC, Color.Black, 0.35f))
                }
            }
        } else if (t == 2) {
            val sp = Color(0xFFD9DCEA)
            val fx = tx.toFloat()
            val fy = ty.toFloat()
            for (k in 0..2) {
                val a = fx + k / 3f
                c.tri(a - 0.03f, fy + 1.02f, a + 0.17f, fy + 0.3f, a + 0.37f, fy + 1.02f, INK)
                c.tri(a + 0.02f, fy + 1f, a + 0.17f, fy + 0.38f, a + 0.31f, fy + 1f, sp)
                c.tri(a + 0.17f, fy + 0.38f, a + 0.31f, fy + 1f, a + 0.17f, fy + 1f, lerp(sp, Color.Black, 0.35f))
            }
        }
    }
}

private fun KCam.gate(g: KnightGame, frame: Int) {
    val open = !g.bossAlive
    val gc = if (open) Color(0xFF7CFF8A) else Color(0xFFFF5252)
    val gx = g.gateX
    val gy = g.gateY
    val stone = Color(0xFF2A2438)
    val pulse = 0.55f + 0.25f * sin(frame * 0.1f)
    glow(gx + 0.6f, gy + 1.3f, 3.6f, gc, 0.28f * pulse)
    // cadre en arche
    rect(gx - 0.12f, gy - 0.1f, 1.44f, 3.12f, INK)
    rect(gx, gy, 1.2f, 3f, stone)
    oval(gx - 0.12f, gy - 0.72f, 1.44f, 1.4f, INK)
    oval(gx, gy - 0.6f, 1.2f, 1.2f, stone)
    // lumière intérieure
    rect(gx + 0.17f, gy + 0.3f, 0.86f, 2.7f, gc.copy(alpha = pulse))
    oval(gx + 0.17f, gy - 0.35f, 0.86f, 1.3f, gc.copy(alpha = pulse))
    // pierres de l'arche
    for (i in 0..4) rect(gx + 0.05f, gy + 0.3f + i * 0.55f, 0.07f, 0.3f, lerp(stone, Color.White, 0.2f))
    rect(gx + 1.08f, gy + 0.3f, 0.07f, 2.7f, lerp(stone, Color.White, 0.12f))
}

private fun KCam.chest(ch: KChest, frame: Int) {
    val body = when (ch.tier) { 2 -> Color(0xFFFFC83D); 1 -> Color(0xFFB8C4D0); else -> Color(0xFF9A6B3A) }
    if (ch.open) {
        rect(ch.x - 0.45f, ch.y + 0.3f, 0.9f, 0.4f, body.copy(alpha = 0.6f))
        rect(ch.x - 0.45f, ch.y - 0.1f, 0.9f, 0.15f, body.copy(alpha = 0.6f))
    } else {
        if (ch.tier > 0) glow(ch.x, ch.y + 0.3f, 1.8f, body, 0.28f + 0.08f * sin(frame * 0.1f))
        rect(ch.x - 0.45f, ch.y, 0.9f, 0.7f, body)
        rect(ch.x - 0.45f, ch.y, 0.9f, 0.14f, lerp(body, Color.White, 0.3f))
        rect(ch.x - 0.45f, ch.y + 0.25f, 0.9f, 0.1f, Color(0xFF3A2A1A))
        rect(ch.x - 0.1f, ch.y + 0.2f, 0.2f, 0.2f, Color(0xFFFFE9A0))
        if (ch.tier > 0) circ(ch.x + sin(frame * 0.1f) * 0.3f, ch.y - 0.2f, 0.06f, Color.White)
    }
}

// ════════════════════════════════════════════════════════════════
//  Atmosphère (devant)
// ════════════════════════════════════════════════════════════════

private fun DrawScope.drawMotes(cx: Float, s: Float, viewW: Float, viewH: Float, frame: Int, tintCol: Color) {
    val span = viewW + 8f
    for (i in 0 until 26) {
        val par = 0.25f + 0.5f * hsh(i, 5)
        var mx = hsh(i, 1) * span - cx * par + sin(frame * 0.01f + i) * 0.6f
        mx = ((mx % span) + span) % span - 4f
        var my = hsh(i, 2) * viewH - frame * 0.006f * (1f + hsh(i, 3))
        my = ((my % viewH) + viewH) % viewH
        val a = 0.22f + 0.35f * (0.5f + 0.5f * sin(frame * 0.03f + i * 1.7f))
        drawCircle(tintCol.copy(alpha = a), (0.02f + 0.03f * hsh(i, 4)) * s, Offset(mx * s, my * s))
    }
}

private fun DrawScope.drawAtmosphere(wi: Int, w: KWorld, cx: Float, s: Float, viewW: Float, viewH: Float, frame: Int) {
    val fog = lerp(Color(w.sky2), Color.White, 0.3f)
    // brume qui dérive
    for (i in 0..2) {
        val period = size.width * 1.7f
        val x = ((frame * 0.25f * (i + 1) + i * 420f) % period) - size.width * 0.5f
        drawOval(fog.copy(alpha = 0.06f), Offset(x, size.height * (0.5f + 0.12f * i)), Size(size.width * 0.75f, s * 1.7f))
    }
    drawMotes(cx, s, viewW, viewH, frame, lerp(fog, Color.White, 0.5f))

    // stalactites au premier plan
    if (DARK_CEILING[wi.coerceIn(0, DARK_CEILING.lastIndex)]) {
        val period = viewW + 6f
        for (k in 0..9) {
            var xx = k * 3.3f - cx * 1.2f + hsh(k, wi) * 1.5f
            xx = ((xx % period) + period) % period - 2f
            val len = 0.7f + 1.8f * hsh(k, wi + 9)
            val ww = 0.45f + 0.7f * hsh(k, wi + 4)
            triPx(INK, (xx - ww / 2f) * s, -2f, xx * s, len * s, (xx + ww / 2f) * s, -2f)
        }
    }

    // ombre en haut + vignette
    val topH = size.height * 0.24f
    drawRect(Brush.verticalGradient(listOf(INK.copy(alpha = 0.55f), Color.Transparent), startY = 0f, endY = topH), Offset.Zero, Size(size.width, topH))
    val diag = sqrt(size.width * size.width + size.height * size.height)
    drawRect(
        Brush.radialGradient(
            0f to Color.Transparent, 0.5f to Color.Transparent, 1f to Color(0xFF02020A).copy(alpha = 0.72f),
            center = Offset(size.width / 2f, size.height / 2f), radius = diag * 0.55f
        ),
        Offset.Zero, size
    )
}

// ════════════════════════════════════════════════════════════════
//  Ennemis
// ════════════════════════════════════════════════════════════════

private fun KCam.foe(f: KFoe, frame: Int) {
    val flash = f.flash > 0f
    fun col(v: Long) = if (flash) Color.White else Color(v)
    val x = f.x; val y = f.y; val w = f.w; val h = f.h
    val mid = x + w / 2
    val d = f.dir.toFloat()
    if (f.boss) glow(mid, y + h / 2, max(w, h) * 1.6f, Color(0xFFFF4A4A), 0.2f + 0.06f * sin(frame * 0.1f))
    when (f.type) {
        0 -> {
            oval(x, y + h * 0.15f, w, h * 0.85f, col(0xFF5BD16B))
            oval(x + w * 0.15f, y + h * 0.25f, w * 0.3f, h * 0.2f, Color.White.copy(alpha = 0.35f))
            circ(mid + d * 0.15f, y + h * 0.5f, 0.07f * w + 0.04f, Color.Black)
            circ(mid - d * 0.1f, y + h * 0.5f, 0.07f * w + 0.04f, Color.Black)
        }
        1 -> {
            val fl = sin(frame * 0.5f) * 0.25f * h
            tri(x, y + h * 0.4f, x - w * 0.6f, y - fl, x + w * 0.35f, y + h * 0.5f, col(0xFF6B4A8F))
            tri(x + w, y + h * 0.4f, x + w * 1.6f, y - fl, x + w * 0.65f, y + h * 0.5f, col(0xFF6B4A8F))
            oval(x + w * 0.2f, y + h * 0.2f, w * 0.6f, h * 0.8f, col(0xFF3A2A4F))
            circ(mid - 0.1f * w, y + h * 0.45f, 0.05f, Color.Red); circ(mid + 0.1f * w, y + h * 0.45f, 0.05f, Color.Red)
        }
        2 -> {
            rect(x + w * 0.2f, y + h * 0.4f, w * 0.6f, h * 0.45f, col(0xFFE8E4D4))
            circ(mid, y + h * 0.25f, w * 0.38f, col(0xFFF4F0E0))
            rect(x + w * 0.25f, y + h * 0.8f, w * 0.2f, h * 0.2f, col(0xFFD8D4C4)); rect(x + w * 0.55f, y + h * 0.8f, w * 0.2f, h * 0.2f, col(0xFFD8D4C4))
            circ(mid - 0.12f * w, y + h * 0.25f, 0.06f, Color.Black); circ(mid + 0.12f * w, y + h * 0.25f, 0.06f, Color.Black)
            rect(mid + d * w * 0.5f - 0.04f, y + h * 0.3f, 0.08f, h * 0.5f, Color(0xFFB0B0B8))
        }
        3 -> {
            tri(x, y + h, mid, y, x + w, y + h, col(0xFF3F7F4A))
            circ(mid, y + h * 0.28f, w * 0.3f, col(0xFFE0C8A0))
            rect(mid + d * w * 0.45f - 0.03f, y + h * 0.3f, 0.06f, h * 0.6f, Color(0xFF8A5A2A))
        }
        4 -> {
            rect(x, y + h * 0.25f, w, h * 0.75f, col(0xFF6E7480))
            rect(x + w * 0.15f, y, w * 0.7f, h * 0.35f, col(0xFF8C93A0))
            tri(x + w * 0.15f, y + 0.1f, x, y - 0.3f, x + w * 0.3f, y, col(0xFFC8C8D0)); tri(x + w * 0.85f, y + 0.1f, x + w, y - 0.3f, x + w * 0.7f, y, col(0xFFC8C8D0))
            rect(x + w * 0.3f, y + h * 0.15f, w * 0.4f, 0.1f, Color(0xFFFF4040))
        }
        5 -> {
            tri(x, y + h, mid, y + h * 0.15f, x + w, y + h, col(0xFF6B3FA0))
            circ(mid, y + h * 0.25f, w * 0.28f, col(0xFFE0C8A0))
            tri(x + w * 0.1f, y + h * 0.25f, mid, y - h * 0.2f, x + w * 0.9f, y + h * 0.25f, col(0xFF4A2A70))
            val oy = y + h * 0.4f + sin(frame * 0.2f) * 0.05f
            glow(mid + d * w * 0.6f, oy, 0.8f, Color(0xFFD36BFF), 0.4f)
            circ(mid + d * w * 0.6f, oy, 0.15f, Color(0xFFD36BFF))
        }
        else -> {
            val a = 0.65f + 0.2f * sin(frame * 0.2f)
            glow(mid, y + h * 0.5f, max(w, h) * 1.1f, Color(0xFF9CF0FF), 0.25f)
            tri(x, y + h, mid, y, x + w, y + h, (if (flash) Color.White else Color(0xFF9CF0FF)).copy(alpha = a))
            circ(mid, y + h * 0.3f, w * 0.35f, (if (flash) Color.White else Color(0xFFCFFAFF)).copy(alpha = a))
            circ(mid - 0.12f * w, y + h * 0.28f, 0.06f, Color.Black); circ(mid + 0.12f * w, y + h * 0.28f, 0.06f, Color.Black)
        }
    }
    if (f.boss) {
        tri(x + w * 0.2f, y - 0.1f, x + w * 0.3f, y - 0.6f, x + w * 0.4f, y - 0.1f, Color(0xFFFFC83D))
        tri(x + w * 0.4f, y - 0.1f, x + w * 0.5f, y - 0.75f, x + w * 0.6f, y - 0.1f, Color(0xFFFFC83D))
        tri(x + w * 0.6f, y - 0.1f, x + w * 0.7f, y - 0.6f, x + w * 0.8f, y - 0.1f, Color(0xFFFFC83D))
    }
}

private fun KCam.foeFull(f: KFoe, frame: Int) {
    if (f.type == 6 && !f.boss) {
        foe(f, frame)
    } else {
        inked { foe(f, frame) }
    }
    if (f.elite) ringLine(f.x + f.w / 2, f.y + f.h / 2, max(f.w, f.h) * 0.7f, Color(0xFFFF4040).copy(alpha = 0.7f), 3f)
    if (!f.boss && f.hp < f.maxHp) {
        rect(f.x, f.y - 0.25f, f.w, 0.1f, Color.Black.copy(alpha = 0.6f))
        rect(f.x, f.y - 0.25f, f.w * (f.hp / f.maxHp).coerceIn(0f, 1f), 0.1f, Color(0xFFFF5252))
    }
}

// ════════════════════════════════════════════════════════════════
//  Le chevalier (original, entièrement personnalisable)
// ════════════════════════════════════════════════════════════════

/**
 * Dessine le chevalier. (x, y) = coin haut-gauche de sa boîte (0,7 × 1,4), f = +1 droite / -1 gauche,
 * run 0..1 = vitesse de course, swing 0..1 = avancement du coup d'épée (négatif = pas de coup).
 */
internal fun KCam.knightFigure(sk: KSkin, x: Float, y: Float, f: Float, frame: Int, run: Float, air: Boolean, swing: Float, reach: Float) {
    val t = frame.toFloat()
    val m = x + 0.35f
    val armor = Color(sk.col(5))
    val trim = Color(sk.col(6))
    val capeC = Color(sk.col(7))
    val plumeC = Color(sk.col(8))
    val eyes = Color(sk.col(9))
    val blade = Color(sk.col(10))
    val dark = lerp(armor, Color.Black, 0.38f)
    val light = lerp(armor, Color.White, 0.32f)
    val slit = Color(0xFF080810)
    val bob = if (run > 0f) abs(sin(t * 0.3f)) * 0.04f else sin(t * 0.07f) * 0.015f
    val yy = y + bob

    fun rf(d: Float, ry: Float, w: Float, h: Float, c: Color) = rect(if (f > 0f) m + d else m - d - w, ry, w, h, c)
    fun ov(d: Float, ry: Float, w: Float, h: Float, c: Color) = oval(if (f > 0f) m + d else m - d - w, ry, w, h, c)
    fun cf(d: Float, ry: Float, r: Float, c: Color) = circ(m + f * d, ry, r, c)

    // ── cape (derrière)
    val flut = sin(t * 0.22f) * 0.05f
    val back = 0.28f + run * 0.38f + (if (air) 0.15f else 0f)
    if (sk.cape != 0) {
        val tail = if (sk.cape == 1) 0.98f else 1.36f
        val ty = yy + tail - (if (air) 0.12f else 0f)
        val sh = lerp(capeC, Color.Black, 0.4f)
        poly(sh, m - f * 0.1f, yy + 0.52f, m - f * (back + 0.14f + flut), ty + flut, m - f * 0.02f, ty - 0.02f)
        poly(capeC, m - f * 0.08f, yy + 0.52f, m - f * (back + flut), ty - 0.08f + flut * 0.5f, m - f * 0.02f, ty - 0.12f, m + f * 0.02f, yy + 0.62f)
        if (sk.cape == 3) {
            for (i in 0..2) {
                val bx = m - f * (back * (0.25f + 0.3f * i) + 0.04f)
                poly(capeC, bx - f * 0.09f, ty - 0.1f, bx, ty + 0.1f + 0.04f * (i % 2) + flut, bx + f * 0.09f, ty - 0.1f)
            }
        }
    }

    // ── jambes
    val ph = t * 0.35f
    val sw = sin(ph) * 0.17f * run
    fun leg(d: Float, lift: Float, c: Color) {
        rf(d - 0.1f, y + 0.95f, 0.2f, 0.27f, c)
        rf(d - 0.1f, y + 1.18f - lift, 0.2f, 0.12f, lerp(c, Color.Black, 0.1f))
        rf(d - 0.12f, y + 1.29f - lift, 0.32f, 0.11f, lerp(armor, Color.Black, 0.55f))
        rf(d - 0.1f, y + 1.17f - lift, 0.2f, 0.04f, trim)
    }
    if (air) {
        leg(-0.14f, 0.09f, dark)
        leg(0.14f, 0.02f, lerp(dark, armor, 0.4f))
    } else {
        val l1 = max(0f, sin(ph)) * 0.12f * run
        val l2 = max(0f, -sin(ph)) * 0.12f * run
        leg(-0.06f - sw, l1, dark)
        leg(0.06f + sw, l2, lerp(dark, armor, 0.4f))
    }

    // ── torse
    rf(-0.22f, yy + 0.5f, 0.44f, 0.5f, armor)
    rf(-0.22f, yy + 0.5f, 0.1f, 0.5f, dark)
    rf(0.06f, yy + 0.53f, 0.1f, 0.22f, light)
    rf(-0.22f, yy + 0.92f, 0.44f, 0.08f, trim)
    rf(0.02f, yy + 0.9f, 0.1f, 0.12f, lerp(trim, Color.White, 0.3f))
    val sway = run * 0.08f + sin(t * 0.15f) * 0.02f
    poly(capeC, m - f * 0.16f, yy + 0.99f, m + f * 0.2f, yy + 0.99f, m + f * (0.17f + sway), yy + 1.2f, m - f * 0.12f, yy + 1.2f)
    when (sk.emblem) {
        1 -> { rf(0.04f, yy + 0.58f, 0.07f, 0.26f, trim); rf(-0.04f, yy + 0.66f, 0.23f, 0.07f, trim) }
        2 -> poly(trim, m + f * 0.075f, yy + 0.58f, m + f * 0.16f, yy + 0.72f, m + f * 0.075f, yy + 0.86f, m - f * 0.01f, yy + 0.72f)
        3 -> { cf(0.075f, yy + 0.72f, 0.1f, trim); cf(0.075f, yy + 0.72f, 0.05f, capeC) }
    }

    // ── tête
    rf(-0.1f, yy + 0.46f, 0.2f, 0.1f, dark)
    val hy = yy
    when (sk.helm) {
        0 -> {
            rf(-0.23f, hy + 0.06f, 0.46f, 0.46f, armor)
            rf(-0.23f, hy + 0.06f, 0.46f, 0.06f, light)
            rf(-0.23f, hy + 0.06f, 0.1f, 0.46f, dark)
            rf(0.0f, hy + 0.24f, 0.23f, 0.07f, slit)
            rf(0.06f, hy + 0.255f, 0.13f, 0.04f, eyes)
            rf(0.13f, hy + 0.34f, 0.03f, 0.14f, slit)
            rf(-0.23f, hy + 0.47f, 0.46f, 0.05f, trim)
            cf(-0.1f, hy + 0.2f, 0.025f, trim)
        }
        1 -> {
            ov(-0.22f, hy + 0.1f, 0.44f, 0.44f, armor)
            poly(armor, m - f * 0.2f, hy + 0.24f, m + f * 0.02f, hy - 0.2f, m + f * 0.2f, hy + 0.24f)
            line(m - f * 0.02f, hy + 0.22f, m + f * 0.02f, hy - 0.15f, light, 0.035f)
            rf(0.03f, hy + 0.22f, 0.2f, 0.22f, Color(0xFF14141E))
            cf(0.14f, hy + 0.31f, 0.04f, eyes)
            rf(-0.22f, hy + 0.46f, 0.44f, 0.06f, trim)
        }
        2 -> {
            ov(-0.23f, hy + 0.06f, 0.46f, 0.48f, armor)
            rf(0.0f, hy + 0.25f, 0.23f, 0.06f, slit)
            rf(0.07f, hy + 0.262f, 0.12f, 0.035f, eyes)
            poly(trim, m - f * 0.24f, hy + 0.2f, m - f * 0.1f, hy - 0.08f, m + f * 0.1f, hy - 0.08f, m + f * 0.22f, hy + 0.14f, m, hy + 0.14f)
            rf(-0.23f, hy + 0.47f, 0.46f, 0.05f, trim)
        }
        3 -> {
            rf(-0.18f, hy + 0.3f, 0.36f, 0.26f, Color(0xFFE8BE9A))
            rf(-0.18f, hy + 0.3f, 0.1f, 0.2f, Color(0xFF3A2A22))
            cf(0.1f, hy + 0.38f, 0.04f, eyes)
            ov(-0.22f, hy + 0.06f, 0.44f, 0.34f, armor)
            ov(-0.22f, hy + 0.06f, 0.44f, 0.1f, light)
            ov(-0.38f, hy + 0.22f, 0.76f, 0.12f, dark)
            rf(-0.36f, hy + 0.26f, 0.72f, 0.03f, trim)
        }
        else -> {
            cf(0.0f, hy + 0.3f, 0.22f, Color(0xFFE8BE9A))
            rf(-0.22f, hy + 0.1f, 0.2f, 0.32f, Color(0xFF3A2A22))
            cf(0.1f, hy + 0.3f, 0.04f, eyes)
            poly(trim, m - f * 0.2f, hy + 0.1f, m - f * 0.2f, hy - 0.12f, m - f * 0.1f, hy, m, hy - 0.16f, m + f * 0.1f, hy, m + f * 0.2f, hy - 0.12f, m + f * 0.2f, hy + 0.1f)
            cf(0.0f, hy - 0.02f, 0.03f, eyes)
        }
    }
    if (sk.helm <= 2) glow(m + f * 0.14f, hy + 0.27f, 0.32f, eyes, 0.55f)

    // ── panache
    val topY = when (sk.helm) { 4 -> hy - 0.12f; 1 -> hy - 0.2f; else -> hy + 0.06f }
    val fl = sin(t * 0.12f) * 0.05f + run * 0.2f + (if (air) 0.08f else 0f)
    when (sk.plume) {
        1 -> {
            val lt = lerp(plumeC, Color.White, 0.3f)
            poly(plumeC, m - f * 0.05f, topY + 0.03f, m - f * (0.08f + fl * 0.5f), topY - 0.44f, m - f * (0.44f + fl), topY - 0.24f, m + f * 0.02f, topY + 0.02f)
            line(m - f * 0.04f, topY, m - f * (0.14f + fl * 0.5f), topY - 0.36f, lt, 0.03f)
        }
        2 -> {
            for (i in 0..3) {
                val c = if (i % 2 == 0) plumeC else lerp(plumeC, Color.White, 0.25f)
                line(
                    m + f * (0.14f - i * 0.07f), topY + 0.02f + i * 0.03f,
                    m - f * (0.4f + i * 0.1f + fl), topY + 0.12f + i * 0.1f + sin(t * 0.18f + i) * 0.04f, c, 0.1f
                )
            }
        }
        3 -> {
            val flap = sin(t * 0.2f) * 0.05f
            poly(plumeC, m - f * 0.1f, topY + 0.2f, m - f * (0.5f + fl), topY - 0.28f + flap, m - f * 0.28f, topY + 0.04f)
            poly(lerp(plumeC, Color.White, 0.25f), m + f * 0.0f, topY + 0.22f, m + f * 0.3f, topY - 0.18f + flap, m + f * 0.12f, topY + 0.04f)
        }
    }

    // ── épaulière
    when (sk.shoulder) {
        0 -> { ov(-0.17f, yy + 0.48f, 0.34f, 0.22f, light); rf(-0.15f, yy + 0.62f, 0.3f, 0.04f, trim) }
        1 -> {
            ov(-0.17f, yy + 0.5f, 0.34f, 0.2f, light)
            poly(light, m - f * 0.14f, yy + 0.54f, m - f * 0.02f, yy + 0.2f, m + f * 0.12f, yy + 0.54f)
            poly(light, m + f * 0.02f, yy + 0.52f, m + f * 0.18f, yy + 0.3f, m + f * 0.18f, yy + 0.56f)
        }
        else -> { cf(0.0f, yy + 0.56f, 0.21f, light); ringLine(m, yy + 0.56f, 0.2f, trim, 3f) }
    }

    // ── bras + épée
    val shY = yy + 0.62f
    val theta = when {
        swing >= 0f -> 1.9f - 2.5f * (1f - (1f - swing) * (1f - swing))
        air -> 0.6f
        run > 0f -> 1.0f + sin(ph * 2f) * 0.05f
        else -> 1.15f + sin(t * 0.06f) * 0.03f
    }
    val a = theta * 0.55f - 1.0f
    val hx = m + f * 0.38f * cos(a)
    val hyy = shY - 0.38f * sin(a)
    line(m, shY, hx, hyy, dark, 0.16f)
    line(m, shY, hx, hyy, armor, 0.11f)
    val dx = f * cos(theta)
    val dy = -sin(theta)
    val nx = -dy
    val ny = dx
    val len = reach * 0.7f + 0.25f
    val bx0 = hx + dx * 0.12f
    val by0 = hyy + dy * 0.12f
    val tx = hx + dx * len
    val ty2 = hyy + dy * len
    glow((bx0 + tx) / 2f, (by0 + ty2) / 2f, len * 0.7f, blade, if (swing >= 0f) 0.3f else 0.16f)
    line(hx - dx * 0.1f, hyy - dy * 0.1f, hx + dx * 0.1f, hyy + dy * 0.1f, Color(0xFF3A2A22), 0.06f)
    poly(blade, bx0 + nx * 0.065f, by0 + ny * 0.065f, tx, ty2, bx0 - nx * 0.065f, by0 - ny * 0.065f)
    line(bx0, by0, tx - dx * 0.05f, ty2 - dy * 0.05f, lerp(blade, Color.White, 0.65f), 0.025f)
    line(hx + dx * 0.1f + nx * 0.14f, hyy + dy * 0.1f + ny * 0.14f, hx + dx * 0.1f - nx * 0.14f, hyy + dy * 0.1f - ny * 0.14f, trim, 0.055f)
    circ(hx - dx * 0.11f, hyy - dy * 0.11f, 0.05f, trim)
    circ(hx, hyy, 0.08f, trim)
}

private fun KCam.player(g: KnightGame, frame: Int) {
    val p = g.p
    val f = g.face.toFloat()
    val sk = g.skin
    val mid = p.x + 0.35f
    val run = if (abs(p.vx) > 1f && p.ground) min(1f, abs(p.vx) / 6f) else 0f
    val air = !p.ground
    val swingP = if (g.swingT > 0f) (1f - g.swingT / 0.16f).coerceIn(0f, 1f) else -1f
    val reach = g.st.reach
    if (g.dashT > 0f) {
        for (k in 1..3) shifted(-f * k * 0.4f, 0f, Color(0x55BFE8FF)).knightFigure(sk, p.x, p.y, f, frame, 1f, air, -1f, reach)
    }
    if (g.inv > 0f && (frame / 3) % 2 == 0 && g.dashT <= 0f) return
    if (p.ground) oval(mid - 0.38f, p.y + PH_FEET - 0.05f, 0.76f, 0.12f, Color.Black.copy(alpha = 0.35f))
    glow(mid, p.y + 0.7f, 4.2f, Color(sk.col(9)), 0.14f)
    inked { knightFigure(sk, p.x, p.y, f, frame, run, air, swingP, reach) }
    knightFigure(sk, p.x, p.y, f, frame, run, air, swingP, reach)
    if (g.swingT > 0f) {
        val r = reach * 0.95f + 0.25f
        val prog = min(1f, swingP * 1.6f + 0.15f)
        val bc = Color(sk.col(10))
        val col = lerp(bc, Color.White, 0.5f).copy(alpha = 0.8f)
        val tl = Offset((mid - r - cx) * s, (p.y + 0.7f - r - cy) * s)
        val sz = Size(2 * r * s, 2 * r * s)
        val start = if (f > 0f) -80f else 260f
        val sweep = if (f > 0f) 120f * prog else -120f * prog
        ds.drawArc(col, start, sweep, false, tl, sz, style = Stroke(width = 0.28f * s, cap = StrokeCap.Round))
        ds.drawArc(bc.copy(alpha = 0.25f), start, sweep, false, tl, sz, style = Stroke(width = 0.6f * s, cap = StrokeCap.Round))
    }
    if (g.shield > 0f) ringLine(mid, p.y + 0.7f, 1.1f, Color(0xFF6FE3FF).copy(alpha = 0.8f), 4f)
    if (g.rage > 0f) ringLine(mid, p.y + 0.7f, 0.9f + 0.1f * sin(frame * 0.4f), Color(0xFFFF4040).copy(alpha = 0.7f), 3f)
}

private const val PH_FEET = 1.4f

// ════════════════════════════════════════════════════════════════
//  Point d'entrée du dessin
// ════════════════════════════════════════════════════════════════

internal fun DrawScope.drawKnight(g: KnightGame, frame: Int) {
    val viewH = 9.5f
    val s = size.height / viewH
    val viewW = size.width / s
    val cx = (g.p.x + 0.35f - viewW / 2f).coerceIn(0f, max(0f, g.W - viewW))
    val cy = (g.p.y - 5.2f).coerceIn(0f, KnightGame.H - viewH)
    val c = KCam(this, s, cx, cy)
    val w = g.world
    val wi = KN.worldOf(g.lv)

    drawBackdrop(wi, w, cx, cy, s, viewW, frame)
    drawTerrain(g, c, w, wi, cx, cy, viewW, viewH, frame)
    c.gate(g, frame)
    for (ch in g.chests) c.inked { chest(ch, frame) }
    for (f in g.foes) c.foeFull(f, frame)

    for (p in g.projs) {
        val col = Color(p.color)
        c.glow(p.x, p.y, 1.1f, col, 0.4f)
        c.circ(p.x, p.y, 0.3f, col.copy(alpha = 0.35f))
        c.circ(p.x, p.y, 0.17f, col)
        c.circ(p.x, p.y, 0.08f, Color.White.copy(alpha = 0.8f))
    }

    c.player(g, frame)

    for (e in g.fx) {
        val k = e.t / e.max
        c.ringLine(e.x, e.y, e.ring * (0.3f + 0.7f * k), Color(e.color).copy(alpha = 1f - k), 5f)
    }

    drawAtmosphere(wi, w, cx, s, viewW, viewH, frame)
}

/** Aperçu du chevalier pour le menu de personnalisation. pose : 0 repos, 1 course, 2 attaque. */
internal fun DrawScope.drawKnightPreview(sk: KSkin, frame: Int, pose: Int) {
    val s = size.height / 2.9f
    val cx = 0.35f - size.width / s / 2f
    val cy = 1.4f - 0.82f * (size.height / s)
    val gy = (1.4f - cy) * s
    drawBackdrop(11, KN.worlds[11], 30f, 11.5f - gy / s, s, size.width / s, frame)
    drawRect(Color(0xFF14141F), Offset(0f, gy), Size(size.width, max(0f, size.height - gy)))
    drawRect(Color(0xFF3A3A55), Offset(0f, gy), Size(size.width, 0.07f * s))
    val c = KCam(this, s, cx, cy)
    c.glow(0.35f, 0.7f, 2.6f, Color(sk.col(9)), 0.2f)
    c.oval(-0.05f, 1.34f, 0.8f, 0.12f, Color.Black.copy(alpha = 0.4f))
    val run = if (pose == 1) 1f else 0f
    val swing = if (pose == 2) ((frame % 45) / 45f) else -1f
    c.inked { knightFigure(sk, 0f, 0f, 1f, frame, run, false, swing, 1.5f) }
    c.knightFigure(sk, 0f, 0f, 1f, frame, run, false, swing, 1.5f)
    if (pose == 2) {
        val r = 1.5f * 0.95f + 0.25f
        val prog = min(1f, swing * 1.6f + 0.15f)
        val bc = Color(sk.col(10))
        drawArc(
            lerp(bc, Color.White, 0.5f).copy(alpha = 0.8f), -80f, 120f * prog, false,
            Offset((0.35f - r - cx) * s, (0.7f - r - cy) * s), Size(2 * r * s, 2 * r * s),
            style = Stroke(width = 0.28f * s, cap = StrokeCap.Round)
        )
    }
    drawMotes(0f, s, size.width / s, size.height / s, frame, Color(0xFFCFC8FF))
    val diag = sqrt(size.width * size.width + size.height * size.height)
    drawRect(
        Brush.radialGradient(
            0f to Color.Transparent, 0.55f to Color.Transparent, 1f to Color(0xFF02020A).copy(alpha = 0.65f),
            center = Offset(size.width / 2f, size.height / 2f), radius = diag * 0.55f
        ),
        Offset.Zero, size
    )
}
