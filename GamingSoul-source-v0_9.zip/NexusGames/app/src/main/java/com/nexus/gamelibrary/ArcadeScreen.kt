package com.nexus.gamelibrary

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.delay

private val Gold = Color(0xFFFFC83D)

private fun stars(n: Int) = "★".repeat(n) + "☆".repeat(3 - n)

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ════════════════════════════════════════════════════════════════
//  Menu : 3 carrières séparées (foot, volley, basket)
// ════════════════════════════════════════════════════════════════

@Composable
fun ArcadeScreen(theme: GameTheme, store: Store, version: Int, onPlay: (Level) -> Unit) {
    var selected by remember { mutableStateOf<Sport?>(null) }
    var resetTick by remember { mutableIntStateOf(0) }
    val st = remember(version, resetTick) { store.arcadeStars() }
    val sp = selected
    if (sp == null) {
        ArcadeHub(theme, st) { selected = it }
    } else {
        BackHandler { selected = null }
        SportCareer(
            theme = theme,
            sport = sp,
            st = st,
            onPlay = onPlay,
            onBack = { selected = null },
            onReset = { store.resetArcade(sp); resetTick++ }
        )
    }
}

@Composable
private fun ArcadeHub(theme: GameTheme, st: IntArray, onPick: (Sport) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Arcade", color = theme.onBg, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text(
                "Trois carrières séparées, en équipe avec des bots, vue du dessus. Aide à la visée activée, aucun wifi nécessaire.",
                color = theme.onBg.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        items(Sport.values().size) { k ->
            val sport = Sport.values()[k]
            val lvls = Career.of(sport)
            val total = lvls.sumOf { st[it.index] }
            val done = lvls.count { st[it.index] > 0 }
            GlassCard(theme, Modifier.clickable { onPick(sport) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(sport.icon, fontSize = 40.sp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Carrière ${sport.label}",
                            color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 19.sp
                        )
                        Text(sport.blurb, color = theme.onBg.copy(alpha = 0.7f), fontSize = 13.sp)
                        Text(
                            "$done / ${lvls.size} matchs gagnés · $total / ${lvls.size * 3} ★",
                            color = theme.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    Text("›", color = theme.onBg.copy(alpha = 0.6f), fontSize = 28.sp)
                }
            }
        }
    }
}

@Composable
private fun SportCareer(
    theme: GameTheme,
    sport: Sport,
    st: IntArray,
    onPlay: (Level) -> Unit,
    onBack: () -> Unit,
    onReset: () -> Unit
) {
    var confirmReset by remember { mutableStateOf(false) }
    val lvls = Career.of(sport)
    val total = lvls.sumOf { st[it.index] }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TextButton(onClick = onBack) { Text("‹ Arcade", color = theme.accent, fontSize = 16.sp) }
            Text(
                "${sport.icon} Carrière ${sport.label}",
                color = theme.onBg, fontSize = 28.sp, fontWeight = FontWeight.Bold
            )
            Text(
                sport.help,
                color = theme.onBg.copy(alpha = 0.7f),
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        item {
            GlassCard(theme) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⭐", fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Progression", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "$total / ${lvls.size * 3} étoiles",
                            color = theme.onBg.copy(alpha = 0.7f),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        Career.divisions.forEachIndexed { d, name ->
            item {
                Text(
                    "Division ${d + 1} · $name",
                    color = theme.accent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            val inDiv = lvls.filter { it.division == d }
            items(inDiv.size) { k ->
                val lv = inDiv[k]
                val unlocked = lv.number == 1 || st[lv.index - 1] >= 1
                val shape = RoundedCornerShape(20.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(theme.tile)
                        .border(1.dp, theme.onBg.copy(alpha = 0.08f), shape)
                        .then(if (unlocked) Modifier.clickable { onPlay(lv) } else Modifier)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (unlocked) sport.icon else "🔒",
                        fontSize = 30.sp,
                        modifier = Modifier.width(44.dp)
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Match ${lv.number} · vs ${lv.opponent}",
                            color = theme.onBg.copy(alpha = if (unlocked) 1f else 0.45f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            lv.rule,
                            color = theme.onBg.copy(alpha = if (unlocked) 0.7f else 0.35f),
                            fontSize = 13.sp
                        )
                    }
                    Text(
                        stars(st[lv.index]),
                        color = if (st[lv.index] > 0) Gold else theme.onBg.copy(alpha = 0.3f),
                        fontSize = 20.sp
                    )
                }
            }
        }

        item {
            Spacer(Modifier.height(8.dp))
            Text(
                "Étoiles : 1 = victoire · 2 = victoire nette · 3 = victoire écrasante",
                color = theme.onBg.copy(alpha = 0.55f),
                fontSize = 12.sp
            )
            TextButton(onClick = { confirmReset = true }) {
                Text("Réinitialiser la carrière ${sport.label}", color = theme.onBg.copy(alpha = 0.6f))
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Réinitialiser ?") },
            text = { Text("Les étoiles de la carrière ${sport.label} seront effacées (les autres carrières ne changent pas).") },
            confirmButton = {
                TextButton(onClick = {
                    onReset()
                    confirmReset = false
                }) { Text("Effacer") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Annuler") } }
        )
    }
}

// ════════════════════════════════════════════════════════════════
//  Écran de match
// ════════════════════════════════════════════════════════════════

@Composable
fun MatchScreen(level: Level, store: Store, hasNext: Boolean, onExit: () -> Unit, onNext: () -> Unit) {
    val context = LocalContext.current
    var attempt by remember(level.index) { mutableIntStateOf(0) }
    val match = remember(level.index, attempt) { Match(level) }
    var paused by remember(level.index, attempt) { mutableStateOf(false) }
    var hud by remember(match) { mutableStateOf(match.hud()) }
    var frame by remember(match) { mutableIntStateOf(0) }
    var showHelp by remember(match) { mutableStateOf(true) }
    var sound by remember { mutableStateOf(store.arcadeSound) }
    val soundOn = rememberUpdatedState(sound)

    LaunchedEffect(match) {
        delay(7000)
        showHelp = false
    }

    // Écran en paysage + plein écran pendant le match
    DisposableEffect(Unit) {
        val act = context.findActivity()
        val window = act?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Petits bips (aucun fichier son, tout est généré par le téléphone)
    val tone = remember {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 55) } catch (e: Throwable) { null }
    }
    DisposableEffect(tone) { onDispose { try { tone?.release() } catch (e: Throwable) { } } }

    fun beep(code: Int) {
        if (!soundOn.value) return
        try {
            when (code) {
                1 -> tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
                2 -> tone?.startTone(ToneGenerator.TONE_PROP_ACK, 200)
                3 -> tone?.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 400)
                else -> tone?.startTone(ToneGenerator.TONE_PROP_NACK, 400)
            }
        } catch (e: Throwable) { }
    }

    // Boucle de jeu à pas fixe (60 pas par seconde)
    LaunchedEffect(match, paused) {
        if (paused) return@LaunchedEffect
        var last = 0L
        var acc = 0f
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) {
                    acc += min(0.05f, (now - last) / 1_000_000_000f)
                    while (acc >= STEP) {
                        match.step(STEP)
                        acc -= STEP
                    }
                }
                last = now
                while (match.sfx.isNotEmpty()) beep(match.sfx.removeFirst())
                val h = match.hud()
                if (h != hud) hud = h
                frame++
            }
        }
    }

    // Sauvegarde des étoiles à la fin du match
    LaunchedEffect(hud.over) {
        if (hud.over && match.won) store.setArcadeStars(level.index, match.stars())
    }

    BackHandler { if (!hud.over) paused = !paused else onExit() }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
            .background(Color.Black)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            frame // lecture : redessine à chaque image
            drawMatch(match, frame)
        }

        // ── Score + chrono
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("TOI", color = Color(0xFF7FB0FF), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Text("${hud.scoreA}", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                Text(
                    if (hud.seconds >= 0) {
                        "  " + (if (hud.overtime) "+" else "%d:%02d".format(hud.seconds / 60, hud.seconds % 60)) + "  "
                    } else "  –  ",
                    color = Gold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Text("${hud.scoreB}", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                Spacer(Modifier.width(8.dp))
                Text(level.opponent.uppercase(), color = Color(0xFFFF8A80), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            if (hud.touches >= 0) {
                val tc = hud.touches.coerceIn(0, 3)
                Text(
                    "TOUCHES " + "●".repeat(tc) + "○".repeat(3 - tc),
                    color = if (hud.touchSide == 0) Color(0xFF7FB0FF) else Color(0xFFFF8A80),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            if (hud.message.isNotEmpty()) {
                Text(
                    hud.message,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(top = 18.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }

        // ── Aide affichée au début du match
        if (showHelp && !hud.over) {
            Text(
                level.sport.help,
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .safeDrawingPadding()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }

        // ── Bouton pause
        Box(
            Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(8.dp)
                .size(40.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable { if (!hud.over) paused = true },
            contentAlignment = Alignment.Center
        ) { Text("II", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        // ── Commandes : joystick à gauche, boutons à droite
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .safeDrawingPadding()
                .padding(start = 20.dp, bottom = 18.dp)
        ) {
            Joystick { x, y ->
                val l = kotlin.math.sqrt(x * x + y * y)
                if (l < 0.12f) {
                    match.input.mx = 0f
                    match.input.my = 0f
                } else {
                    match.input.mx = x
                    match.input.my = y
                }
            }
        }
        Row(
            Modifier
                .align(Alignment.BottomEnd)
                .safeDrawingPadding()
                .padding(end = 20.dp, bottom = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            val third = level.sport.thirdLabel
            if (third != null) {
                PadButton(third, 62.dp, Color(0xFFFF8A80), onPress = { match.input.thirdLatch = true }) { down -> match.input.third = down }
            }
            val second = level.sport.secondLabel
            if (second != null) {
                PadButton(second, 64.dp, Color.White, onPress = { match.input.passLatch = true }) { down -> match.input.pass = down }
            }
            PadButton(level.sport.actionLabel, 84.dp, Gold, onPress = { match.input.actionLatch = true }) { down -> match.input.action = down }
        }

        // ── Pause
        if (paused && !hud.over) {
            OverlayCard {
                Text("PAUSE", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                Spacer(Modifier.height(14.dp))
                OverlayButton("Continuer", Gold) { paused = false }
                OverlayButton("Recommencer", Color.White) { attempt++ }
                OverlayButton(if (sound) "Son : oui" else "Son : non", Color.White) {
                    sound = !sound
                    store.arcadeSound = sound
                }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { onExit() }
            }
        }

        // ── Fin de match
        if (hud.over) {
            OverlayCard {
                Text(
                    if (match.won) "VICTOIRE !" else "DÉFAITE",
                    color = if (match.won) Gold else Color(0xFFFF8A80),
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 28.sp
                )
                Text(
                    "${hud.scoreA} - ${hud.scoreB}",
                    color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 22.sp
                )
                if (match.won) {
                    Text(stars(match.stars()), color = Gold, fontSize = 34.sp)
                } else {
                    Text("Retente ta chance !", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
                }
                Spacer(Modifier.height(10.dp))
                if (match.won && hasNext) OverlayButton("Match suivant", Gold) { onNext() }
                OverlayButton("Rejouer", Color.White) { attempt++ }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { onExit() }
            }
        }
    }
}

private const val STEP = 1f / 60f

@Composable
private fun OverlayCard(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF1B1B26))
                .border(2.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                .padding(horizontal = 28.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) { content() }
    }
}

@Composable
private fun OverlayButton(text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(vertical = 4.dp)
            .width(200.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.18f))
            .border(1.5.dp, color.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** Joystick tactile : renvoie (x, y) entre -1 et 1, (0, 0) quand on relâche. */
@Composable
private fun Joystick(onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    val cb = rememberUpdatedState(onMove)
    Box(
        Modifier
            .size(150.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(2.dp, Color.White.copy(alpha = 0.35f), CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val rad = size.width / 2f
                    var px = down.position.x
                    var py = down.position.y
                    while (true) {
                        var vx = (px - cx) / rad
                        var vy = (py - cy) / rad
                        val l = kotlin.math.sqrt(vx * vx + vy * vy)
                        if (l > 1f) { vx /= l; vy /= l }
                        knob = Offset(vx * rad * 0.55f, vy * rad * 0.55f)
                        cb.value(vx, vy)
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        px = ch.position.x
                        py = ch.position.y
                        ch.consume()
                    }
                    knob = Offset.Zero
                    cb.value(0f, 0f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .offset { IntOffset(knob.x.roundToInt(), knob.y.roundToInt()) }
                .size(58.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.45f))
        )
    }
}

/** Bouton tactile à appui maintenu (plusieurs doigts en même temps possibles). */
@Composable
private fun PadButton(
    label: String,
    size: Dp,
    color: Color,
    onPress: () -> Unit = {},
    onHold: (Boolean) -> Unit
) {
    var down by remember { mutableStateOf(false) }
    val hold = rememberUpdatedState(onHold)
    val press = rememberUpdatedState(onPress)
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (down) color.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.16f))
            .border(2.dp, color.copy(alpha = 0.75f), CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    down = true
                    hold.value(true)
                    press.value()
                    waitForUpOrCancellation()
                    down = false
                    hold.value(false)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = if (label.length > 2) 13.sp else 24.sp
        )
    }
}

// ════════════════════════════════════════════════════════════════
//  Dessin pixel art (vue du dessus)
// ════════════════════════════════════════════════════════════════

private class Px(val ds: DrawScope, val s: Float, val ox: Float, val oy: Float) {
    fun r(x: Float, y: Float, w: Float, h: Float, c: Color) {
        val x0 = floor(ox + x * s)
        val y0 = floor(oy + y * s)
        val x1 = floor(ox + (x + w) * s)
        val y1 = floor(oy + (y + h) * s)
        ds.drawRect(c, Offset(x0, y0), Size(max(1f, x1 - x0), max(1f, y1 - y0)))
    }

    fun r(x: Int, y: Int, w: Int, h: Int, c: Color) = r(x.toFloat(), y.toFloat(), w.toFloat(), h.toFloat(), c)

    /** Dessine un sprite : une chaîne par ligne, une lettre par couleur, '.' = transparent. */
    fun sprite(rows: List<String>, x: Int, y: Int, flip: Boolean, pal: (Char) -> Color?) {
        for ((j, row) in rows.withIndex()) {
            val n = row.length
            var i = 0
            while (i < n) {
                val ch = row[if (flip) n - 1 - i else i]
                val c = pal(ch)
                if (c == null) { i++; continue }
                var k = i + 1
                while (k < n && row[if (flip) n - 1 - k else k] == ch) k++
                r(x + i, y + j, k - i, 1, c)
                i = k
            }
        }
    }

    /** Cercle (contour) fait de petits points. */
    fun ring(cx: Float, cy: Float, rad: Float, c: Color, from: Float = 0f, to: Float = 6.2832f) {
        val steps = max(12, (rad * 7f).toInt())
        for (i in 0 until steps) {
            val a = from + (to - from) * i / steps
            r((cx + cos(a) * rad).roundToInt(), (cy + sin(a) * rad).roundToInt(), 1, 1, c)
        }
    }

    fun line(x0: Float, y0: Float, x1: Float, y1: Float, c: Color, step: Float = 1f) {
        val dx = x1 - x0
        val dy = y1 - y0
        val len = kotlin.math.sqrt(dx * dx + dy * dy)
        val n = max(1, (len / step).toInt())
        for (i in 0..n) {
            val t = i.toFloat() / n
            r((x0 + dx * t).roundToInt(), (y0 + dy * t).roundToInt(), 1, 1, c)
        }
    }
}

private fun lcg(seed: Int): Int = (seed * 1103515245 + 12345) and 0x7fffffff

private val LineWhite = Color(0xE6FFFFFF)

// ---- tribunes (autour du terrain) ----

private fun Px.drawStands(tick: Int, division: Int) {
    val dark = listOf(0xFF1D2233, 0xFF22262F, 0xFF2A2036, 0xFF16262B, 0xFF2B2619)[division.coerceIn(0, 4)]
    r(0, 0, 320, 180, Color(dark))
    val shirts = listOf(0xFFE74C3C, 0xFF3498DB, 0xFFF1C40F, 0xFF2ECC71, 0xFF9B59B6, 0xFFECF0F1, 0xFFE67E22)
    val skins = listOf(0xFFF2C79A, 0xFFD9A074, 0xFF8D5A3B, 0xFFFAD7B0)
    fun fan(x: Int, y: Int, seed: Int) {
        val h = lcg(seed)
        val bob = if (((tick / 18) + h) % 3 == 0) 1 else 0
        r(x, y + 2 - bob, 3, 2, Color(shirts[h % shirts.size]))
        r(x, y - bob, 3, 2, Color(skins[(h / 7) % skins.size]))
    }
    var x = 1
    while (x < 319) {
        fan(x, 3, x * 7 + 1)
        fan(x + 2, 8, x * 13 + 5)
        fan(x, 169, x * 11 + 3)
        fan(x + 2, 174, x * 5 + 9)
        x += 4
    }
    var y = 14
    while (y < 166) {
        fan(2, y, y * 17 + 2)
        fan(314, y, y * 19 + 4)
        y += 5
    }
}

// ---- football ----

private fun Px.drawFootField(division: Int) {
    val g1 = Color(listOf(0xFF2E8B3A, 0xFF2A8A44, 0xFF278048, 0xFF2D7A3A, 0xFF23703A)[division.coerceIn(0, 4)])
    val g2 = Color(listOf(0xFF37A046, 0xFF33A04F, 0xFF2F9054, 0xFF358846, 0xFF2B8044)[division.coerceIn(0, 4)])
    r(16, 16, 288, 148, g1)
    for (i in 0 until 12) if (i % 2 == 0) r(16 + i * 24, 16, 24, 148, g2)
    val w = LineWhite
    // contour
    r(16, 16, 288, 1, w); r(16, 163, 288, 1, w); r(16, 16, 1, 148, w); r(303, 16, 1, 148, w)
    // ligne médiane + rond central
    r(160, 16, 1, 148, w)
    ring(160.5f, 90.5f, 26f, w)
    r(159, 89, 3, 3, w)
    // surfaces de réparation
    r(16, 50, 44, 1, w); r(16, 130, 44, 1, w); r(60, 50, 1, 81, w)
    r(260, 50, 44, 1, w); r(260, 130, 44, 1, w); r(260, 50, 1, 81, w)
    r(16, 62, 20, 1, w); r(16, 118, 20, 1, w); r(36, 62, 1, 57, w)
    r(284, 62, 20, 1, w); r(284, 118, 20, 1, w); r(284, 62, 1, 57, w)
    // buts : filets + poteaux
    val net = Color(0x55FFFFFF)
    val gy0 = Court.GOAL_Y0.toInt()
    val gh = (Court.GOAL_Y1 - Court.GOAL_Y0).toInt()
    r(4, gy0, 12, gh, Color(0x33000000))
    r(304, gy0, 12, gh, Color(0x33000000))
    var i = 4
    while (i < 16) { r(i, gy0, 1, gh, net); r(i + 300, gy0, 1, gh, net); i += 3 }
    var j = gy0
    while (j < gy0 + gh) { r(4, j, 12, 1, net); r(304, j, 12, 1, net); j += 3 }
    r(4, gy0 - 1, 13, 2, Color.White); r(4, gy0 + gh - 1, 13, 2, Color.White); r(4, gy0 - 1, 2, gh + 2, Color.White)
    r(303, gy0 - 1, 13, 2, Color.White); r(303, gy0 + gh - 1, 13, 2, Color.White); r(314, gy0 - 1, 2, gh + 2, Color.White)
}

// ---- basket ----

private fun Px.drawBasketCourt(division: Int) {
    val w1 = Color(listOf(0xFFC98E4B, 0xFFC4894A, 0xFFBE8447, 0xFFB57A3F, 0xFFAA7038)[division.coerceIn(0, 4)])
    val w2 = Color(0x22000000)
    r(16, 16, 288, 148, w1)
    var y = 16
    while (y < 164) { r(16, y, 288, 1, w2); y += 6 }
    var x = 16
    var k = 0
    while (x < 304) { r(x, 16 + (k % 3) * 2, 1, 4, w2); x += 17; k++ }
    val paint = Color(listOf(0xFF3B6FD4, 0xFFC0392B, 0xFF8E44AD, 0xFF16A085, 0xFFD4A017)[division.coerceIn(0, 4)]).copy(alpha = 0.55f)
    r(16, 65, 58, 50, paint)
    r(246, 65, 58, 50, paint)
    val w = LineWhite
    r(16, 16, 288, 1, w); r(16, 163, 288, 1, w); r(16, 16, 1, 148, w); r(303, 16, 1, 148, w)
    r(160, 16, 1, 148, w)
    ring(160.5f, 90.5f, 18f, w)
    // raquettes
    r(16, 65, 58, 1, w); r(16, 114, 58, 1, w); r(74, 65, 1, 50, w)
    r(246, 65, 58, 1, w); r(246, 114, 58, 1, w); r(246, 65, 1, 50, w)
    // lancers francs + arcs à 3 points
    ring(74.5f, 90.5f, 16f, w, -1.5708f, 1.5708f)
    ring(245.5f, 90.5f, 16f, w, 1.5708f, 4.7124f)
    ring(30.5f, 90.5f, Court.ARC, w, -1.45f, 1.45f)
    ring(289.5f, 90.5f, Court.ARC, w, 1.6916f, 4.5916f)
    // paniers
    drawHoop(true)
    drawHoop(false)
}

private fun Px.drawHoop(left: Boolean) {
    val bxp = if (left) 21 else 298
    r(bxp, 82, 2, 17, Color(0xFFE8E8F0))
    r(bxp, 82, 2, 1, Color(0xFF9AA0B0)); r(bxp, 98, 2, 1, Color(0xFF9AA0B0))
    val hx = if (left) 30f else 290f
    ring(hx + 0.5f, 90.5f, 4f, Color(0xFFFF6A1A))
    ring(hx + 0.5f, 90.5f, 3f, Color(0x66FFFFFF))
    r(if (left) 24 else 295, 90, 3, 1, Color(0xFFFF6A1A))
}

// ---- volley ----

private fun Px.drawVolleyCourt(division: Int) {
    val out = Color(listOf(0xFF2C5E8C, 0xFF2B6A6A, 0xFF4A4A7A, 0xFF2F6B52, 0xFF6A4A2B)[division.coerceIn(0, 4)])
    val inn = Color(listOf(0xFFE88B3E, 0xFFE0A24A, 0xFFD9863F, 0xFFD97B4A, 0xFFE5A22E)[division.coerceIn(0, 4)])
    r(16, 16, 288, 148, out)
    var y = 16
    while (y < 164) { r(16, y, 288, 1, Color(0x14000000)); y += 4 }
    r(44, 32, 232, 116, inn)
    var yy = 32
    while (yy < 148) { r(44, yy, 232, 1, Color(0x12000000)); yy += 4 }
    val w = LineWhite
    r(44, 32, 232, 1, w); r(44, 147, 232, 1, w); r(44, 32, 1, 116, w); r(275, 32, 1, 116, w)
    r(121, 32, 1, 116, w); r(199, 32, 1, 116, w) // lignes des 3 m
}

private fun Px.drawVolleyNet() {
    val nx = Court.NET_X.toInt()
    val y0 = Court.VY0.toInt() - 6
    val y1 = Court.VY1.toInt() + 6
    r(nx + 2, y0 + 2, 3, y1 - y0, Color(0x33000000)) // ombre du filet
    var y = y0
    while (y < y1) {
        r(nx - 1, y, 2, 1, Color.White)
        r(nx - 1, y + 1, 2, 1, Color(0xFFB9C0D0))
        y += 2
    }
    r(nx - 2, y0 - 2, 4, 4, Color(0xFF22252E)); r(nx - 2, y1 - 1, 4, 4, Color(0xFF22252E))
    r(nx - 1, y0 - 1, 2, 2, Color(0xFFFF5A4A)); r(nx - 1, y1, 2, 2, Color(0xFFFF5A4A))
}

// ---- ballon ----

private val ballMask = listOf("..ooo..", ".ooooo.", "ooooooo", "ooooooo", "ooooooo", ".ooooo.", "..ooo..")

private fun ballPixel(sport: Sport, i: Int, j: Int, ph: Int): Color {
    val shade = (i + j) >= 9
    return when (sport) {
        Sport.FOOT -> {
            val patch = (i == 3 && j == 3) ||
                ((ph and 1) == 0 && ((i == 1 && j == 2) || (i == 5 && j == 2) || (i == 3 && j == 5))) ||
                ((ph and 1) == 1 && ((i == 2 && j == 1) || (i == 5 && j == 3) || (i == 2 && j == 5)))
            if (patch) Color(0xFF1B1B22) else if (shade) Color(0xFFC9CED8) else Color(0xFFF7F7FA)
        }
        Sport.VOLLEY -> {
            val row = (j + ph) % 4
            when {
                row == 1 -> Color(0xFFF2C230)
                row == 3 -> Color(0xFF2F6BFF)
                shade -> Color(0xFFC9CED8)
                else -> Color(0xFFF7F7FA)
            }
        }
        Sport.BASKET -> {
            val seam = (i == 3) || (j == 3) || ((ph and 1) == 0 && (i == j)) || ((ph and 1) == 1 && (i + j == 6))
            if (seam) Color(0xFF3B1E0C) else if (shade) Color(0xFFC95E10) else Color(0xFFEE7A1F)
        }
    }
}

private fun Px.drawBall(sport: Sport, bx: Float, by: Float, bz: Float, spin: Float) {
    val sh = Color.Black.copy(alpha = 0.3f)
    val shw = max(3, 7 - (bz / 10f).toInt())
    r(bx.roundToInt() - shw / 2, by.roundToInt() + 1, shw, 2, sh)
    val x0 = bx.roundToInt() - 3
    val y0 = (by - bz * 0.6f).roundToInt() - 3
    val ph = floor(abs(spin)).toInt() and 3
    for (j in 0 until 7) {
        for (i in 0 until 7) {
            if (ballMask[j][i] != 'o') continue
            r(x0 + i, y0 + j, 1, 1, ballPixel(sport, i, j, ph))
        }
    }
}

// ---- joueurs ----

private val sprFrontTop = listOf(
        "...kkkkkk...",
        "..khhHhhhk..",
        ".khhhhhhhhk.",
        ".khsssssshk.",
        ".ksessssesk.",
        ".kssSmmSssk.",
        "..kksSSskk..",
        ".aaJjjjjJaa.",
        "kaajjttjjaak",
        "kSajjjjjjaSk",
        ".kSjjjjjjSk.",
        "..kppppppk..",
        "..kppkkppk.."
    )

private val sprBackTop = listOf(
        "...kkkkkk...",
        "..khhhhhhk..",
        ".khhhHhhhhk.",
        ".khhhhhhhhk.",
        ".khhhhhhhhk.",
        ".kShhhhhhSk.",
        "..kkhSShkk..",
        ".aaJjjjjJaa.",
        "kaajjttjjaak",
        "kSajjjjjjaSk",
        ".kSjjjjjjSk.",
        "..kppppppk..",
        "..kppkkppk.."
    )

private val sprSideTop = listOf(
        "....kkkkk...",
        "...khhhhhk..",
        "..khhhHhhhk.",
        "..khhhssssk.",
        "..khhssesSk.",
        "..khssssmsk.",
        "...kksssSk..",
        "...kjjjjjk..",
        "..kajjttjjk.",
        "..kaajjjjjk.",
        "..kSajjjjjk.",
        "...kpppppk..",
        "...kppppk..."
    )

private val sprFrontLegs = listOf(
        listOf(
        "...ll..ll...",
        "...ll..ll...",
        "..wwk..kww.."
    ),
        listOf(
        "...ll..ll...",
        "...ll...ll..",
        "..wwk...kww."
    ),
        listOf(
        "...ll..ll...",
        "..ll....ll..",
        ".wwk....kww."
    )
    )

private val sprSideLegs = listOf(
        listOf(
        "....llll....",
        "....llll....",
        "...wwwwww..."
    ),
        listOf(
        "....ll.ll...",
        "...ll...ll..",
        "..wwk...wwk."
    ),
        listOf(
        "....llll....",
        "....ll.ll...",
        "...wwk.wwk.."
    )
    )


private val hairCols = listOf(0xFF3A2A1A, 0xFF1E1E1E, 0xFFD2A93C, 0xFF7A3B1E)
private val hairLight = listOf(0xFF5A432B, 0xFF3A3A44, 0xFFF0D27A, 0xFF9C5430)
private val skinCols = listOf(0xFFF2C79A, 0xFFD9A074, 0xFF9A6A45, 0xFFFAD7B0)
private val skinShade = listOf(0xFFD9A878, 0xFFB8825A, 0xFF7A4F2F, 0xFFE0B88C)
private val oppKits = listOf(0xFFE23B3B, 0xFFFF8A00, 0xFF9A3BE2, 0xFF16A085, 0xFFD4AF37)
private val oppKitsDark = listOf(0xFFA82424, 0xFFC26A00, 0xFF7026A8, 0xFF0E7A64, 0xFFA88A1E)

private fun Px.drawPlayer(m: Match, p: Player, tick: Int, isCtrl: Boolean) {
    val sport = m.sport
    val lv = m.level
    val px = p.x.roundToInt()
    val py = p.y.roundToInt()

    // ombre (reste au sol même quand le joueur saute)
    r(px - 5, py - 1, 10, 3, Color.Black.copy(alpha = 0.28f))
    if (isCtrl) {
        val ringCol = Gold.copy(alpha = 0.9f)
        r(px - 6, py, 12, 1, ringCol)
        r(px - 5, py + 1, 10, 1, ringCol)
        r(px - 5, py - 1, 1, 1, ringCol); r(px + 4, py - 1, 1, 1, ringCol)
    }

    val lift = if (p.jumpT > 0f) (sin(min(1f, p.jumpT / 0.45f) * 3.14159f) * 7f).roundToInt() else 0
    val step = if (p.runT > 0f) 1 + (p.runT.toInt() and 1) else 0

    // gardien (foot) : maillot et gants à part, plongeon ; tacle : glissade avec poussière
    val keeper = sport == Sport.FOOT && p.slot == 0
    val sliding = p.tackT > 0f
    var dvy = 0
    var gloveY = 0
    if (keeper && p.diveT > 0f) {
        val k = sin(min(1f, p.diveT / 0.45f) * 3.14159f)
        dvy = (p.diveDir * k * 7f).roundToInt()
        gloveY = (-p.diveDir * k * 6f).roundToInt()
    }
    val oyOff = dvy + (if (sliding) 4 else 0)

    val rows: List<String>
    var flip = false
    if (abs(p.fy) > abs(p.fx) + 0.05f) {
        rows = (if (p.fy > 0f) sprFrontTop else sprBackTop) + sprFrontLegs[step]
    } else {
        rows = sprSideTop + sprSideLegs[step]
        flip = p.fx < 0f
    }

    val jersey: Color
    val jerseyDark: Color
    if (keeper) {
        if (p.team == 0) { jersey = Color(0xFFFFB300); jerseyDark = Color(0xFFC98400) }
        else { jersey = Color(0xFF3DDC84); jerseyDark = Color(0xFF22A35E) }
    } else if (p.team == 0) {
        jersey = Color(0xFF2F6BFF); jerseyDark = Color(0xFF1F4FC4)
    } else {
        val d = lv.division.coerceIn(0, 4)
        jersey = Color(oppKits[d]); jerseyDark = Color(oppKitsDark[d])
    }
    val hi = (p.slot + p.team * 2) % hairCols.size
    val sk = (p.slot * 2 + p.team) % skinCols.size
    val hair = Color(hairCols[hi])
    val hairHi = Color(hairLight[hi])
    val skin = Color(skinCols[sk])
    val skinSh = Color(skinShade[sk])
    val shorts = if (keeper) Color(0xFF1B1B22) else if (p.team == 0) Color(0xFF14286E) else Color(0xFF2B2B33)
    val sock = if (sport == Sport.BASKET) Color(0xFFF2F2F2) else jersey
    val sleeve = if (keeper) Color(0xFFFFFFFF) else if (sport == Sport.BASKET) skin else jersey

    sprite(rows, px - 6, py - 15 - lift + oyOff, flip) { ch ->
        when (ch) {
            'k' -> Color(0xFF14141C)
            'h' -> hair
            'H' -> hairHi
            's' -> skin
            'S' -> skinSh
            'e' -> Color(0xFF111111)
            'm' -> Color(0xFF9A4A3A)
            'j' -> jersey
            'J' -> jerseyDark
            't' -> Color(0xFFF4F4F8)
            'a' -> sleeve
            'p' -> shorts
            'l' -> sock
            'w' -> Color(0xFFF2F2F2)
            else -> null
        }
    }

    // gants tendus du gardien qui plonge
    if (keeper && p.diveT > 0f) {
        r(px - 9, py - 13 + dvy + gloveY, 3, 3, Color.White)
        r(px + 7, py - 13 + dvy + gloveY, 3, 3, Color.White)
    }
    // poussière derrière un tacle glissé
    if (sliding) {
        val ddx = -(p.tdx * 7f).roundToInt()
        val ddy = -(p.tdy * 5f).roundToInt()
        r(px + ddx - 2, py + ddy - 2, 3, 2, Color(0xAAE8D9B0))
        r(px + ddx * 2 - 1, py + ddy * 2 - 1, 2, 2, Color(0x88E8D9B0))
    }
    // petit éclair quand le joueur frappe / tire
    if (p.actT > 0f) {
        r(px + (p.fx * 9f).roundToInt() - 1, py - 7 + (p.fy * 6f).roundToInt() - lift, 3, 3, Color.White.copy(alpha = 0.75f))
    }
    // flèche au-dessus du joueur piloté
    if (isCtrl) {
        val bob = if ((tick / 10) % 2 == 0) 0 else 1
        val ay = py - 24 - lift + bob
        r(px - 2, ay, 5, 1, Gold)
        r(px - 1, ay + 1, 3, 1, Gold)
        r(px, ay + 2, 1, 1, Gold)
    }
}

// ---- scène complète ----

private fun DrawScope.drawMatch(m: Match, tick: Int) {
    val s = min(size.width / Court.W, size.height / Court.H)
    val ox = floor((size.width - Court.W * s) / 2f)
    val oy = floor((size.height - Court.H * s) / 2f)
    val p = Px(this, s, ox, oy)
    val lv = m.level

    p.drawStands(tick, lv.division)
    when (m.sport) {
        Sport.FOOT -> p.drawFootField(lv.division)
        Sport.BASKET -> p.drawBasketCourt(lv.division)
        Sport.VOLLEY -> p.drawVolleyCourt(lv.division)
    }

    // aide à la visée : ligne pointillée + cible
    val hint = m.aimHint()
    if (hint != null) {
        val me = m.ps[m.ctrl]
        val gold = Gold.copy(alpha = 0.85f)
        p.line(me.x, me.y - 6f, hint[0], hint[1], Gold.copy(alpha = 0.45f), 5f)
        if (m.sport == Sport.BASKET) {
            // jauge de chance de marquer au-dessus du joueur
            val w = 20
            val x0 = me.x.roundToInt() - w / 2
            val y0 = me.y.roundToInt() - 31
            p.r(x0 - 1, y0 - 1, w + 2, 4, Color.Black.copy(alpha = 0.6f))
            val ch = hint[2]
            val col = if (ch > 0.6f) Color(0xFF4CD964) else if (ch > 0.35f) Color(0xFFFFC83D) else Color(0xFFFF5A4A)
            p.r(x0, y0, max(1, (w * ch).roundToInt()), 2, col)
        } else {
            val tx = hint[0].roundToInt()
            val ty = hint[1].roundToInt()
            if (hint[2] > 0.5f || m.sport == Sport.VOLLEY) {
                p.ring(tx + 0.5f, ty + 0.5f, 4f, gold)
                p.r(tx, ty, 1, 1, gold)
            }
        }
    }

    if (m.sport == Sport.VOLLEY) {
        p.drawVolleyNet()
    }

    // joueurs et ballon triés par profondeur (y) pour un rendu 2,5D propre
    val order = m.ps.sortedBy { it.y }
    var ballDone = false
    val ballY = m.by
    for (pl in order) {
        if (!ballDone && ballY < pl.y) {
            p.drawBall(m.sport, m.bx, m.by, m.bz, m.ballSpin)
            ballDone = true
        }
        p.drawPlayer(m, pl, tick, pl === m.ps[m.ctrl])
    }
    if (!ballDone) p.drawBall(m.sport, m.bx, m.by, m.bz, m.ballSpin)

    // cercle de timing du smash (volley) : frappe quand il touche l'anneau doré
    val sr = m.smashRing()
    if (sr != null) {
        val q = sr[3]
        val col = if (q >= 1f) Color(0xFF4CD964) else if (q >= 0.6f) Gold else Color.White
        p.ring(sr[0] + 0.5f, sr[1] + 0.5f, 5f, Gold.copy(alpha = 0.9f))
        p.ring(sr[0] + 0.5f, sr[1] + 0.5f, sr[2], col)
        p.ring(sr[0] + 0.5f, sr[1] + 0.5f, sr[2] + 1f, col.copy(alpha = 0.5f))
    }
}
