package com.nexus.gamelibrary

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableIntStateOf
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    // Incrémenté à chaque retour dans l'appli : sert à recharger la liste (nouveaux jeux installés, derniers lancés)
    private val resume = mutableIntStateOf(0)

    // Incrémenté quand le bouton flottant demande d'ouvrir les réglages du viseur
    private val openCrosshair = mutableIntStateOf(0)

    private var pendingPkg: String? = null
    private var pendingLabel: String = ""

    // Retour de l'écran Android "Afficher par-dessus les autres applis"
    private val overlayPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val pkg = pendingPkg ?: return@registerForActivityResult
        pendingPkg = null
        if (Settings.canDrawOverlays(this)) startAssistant(pendingLabel)
        startGame(pkg)
    }

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        handleIntent(intent)
        setContent { NexusGamesApp(resume.intValue, openCrosshair.intValue, ::launchGame) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.getStringExtra("open") == "crosshair") {
            i.removeExtra("open")
            openCrosshair.intValue++
        }
    }

    override fun onResume() {
        super.onResume()
        resume.intValue++
    }

    /** Appelé quand on touche un jeu dans la bibliothèque. */
    private fun launchGame(pkg: String, label: String) {
        val store = Store(this)
        if (!store.assistant && !store.crosshairOn) {
            startGame(pkg)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            pendingPkg = pkg
            pendingLabel = label
            Toast.makeText(
                this,
                "Autorise « Afficher par-dessus les autres applis » pour Gaming Soul, puis reviens.",
                Toast.LENGTH_LONG
            ).show()
            overlayPermission.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startAssistant(label)
        startGame(pkg)
    }

    private fun startAssistant(label: String) {
        ContextCompat.startForegroundService(
            this,
            Intent(this, OverlayService::class.java)
                .putExtra("game", label)
                .putExtra("bubble", Store(this).assistant)
        )
    }

    private fun startGame(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        Store(this).markLaunched(pkg)
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
