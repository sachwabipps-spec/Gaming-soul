package com.nexus.gamelibrary

import androidx.compose.ui.graphics.Color

/** Une option de personnalisation : verrouillée tant que le nombre d'étoiles n'est pas atteint. */
data class Opt(val name: String, val stars: Int = 0, val color: Long = 0L, val color2: Long = 0L)

/** Apparence du joueur (indices dans les listes de [Cosmetics]). */
data class Skin(
    val hairStyle: Int = 0,
    val hairColor: Int = 0,
    val skinTone: Int = 0,
    val kitColor: Int = 0,
    val kitPattern: Int = 0,
    val kit2Color: Int = 5,
    val shortsColor: Int = 6,
    val accessory: Int = 0,
    val number: Int = 10,
    val ball: Int = 0,
    val marker: Int = 0,
    val trail: Int = 0
) {
    fun encode() = listOf(hairStyle, hairColor, skinTone, kitColor, kitPattern, kit2Color, shortsColor, accessory, number, ball, marker, trail)
        .joinToString(",")

    companion object {
        fun decode(s: String?): Skin {
            val a = (s ?: "").split(",").map { it.toIntOrNull() }
            val d = Skin()
            fun g(i: Int, def: Int) = a.getOrNull(i) ?: def
            return Skin(
                g(0, d.hairStyle), g(1, d.hairColor), g(2, d.skinTone), g(3, d.kitColor), g(4, d.kitPattern),
                g(5, d.kit2Color), g(6, d.shortsColor), g(7, d.accessory), g(8, d.number), g(9, d.ball),
                g(10, d.marker), g(11, d.trail)
            ).sanitized()
        }
    }

    fun sanitized() = copy(
        hairStyle = hairStyle.coerceIn(0, Cosmetics.hairStyles.lastIndex),
        hairColor = hairColor.coerceIn(0, Cosmetics.hairColors.lastIndex),
        skinTone = skinTone.coerceIn(0, Cosmetics.skinTones.lastIndex),
        kitColor = kitColor.coerceIn(0, Cosmetics.kitColors.lastIndex),
        kitPattern = kitPattern.coerceIn(0, Cosmetics.patterns.lastIndex),
        kit2Color = kit2Color.coerceIn(0, Cosmetics.kitColors.lastIndex),
        shortsColor = shortsColor.coerceIn(0, Cosmetics.kitColors.lastIndex),
        accessory = accessory.coerceIn(0, Cosmetics.accessories.lastIndex),
        number = number.coerceIn(0, 99),
        ball = ball.coerceIn(0, Cosmetics.balls.lastIndex),
        marker = marker.coerceIn(0, Cosmetics.markers.lastIndex),
        trail = trail.coerceIn(0, Cosmetics.trails.lastIndex)
    )
}

object Cosmetics {
    val hairStyles = listOf(
        Opt("Courts"), Opt("Longs"), Opt("Rasé"), Opt("Queue", 3), Opt("Crête", 8), Opt("Afro", 15)
    )
    val hairColors = listOf(
        Opt("Brun", 0, 0xFF3A2A1A, 0xFF5A432B), Opt("Noir", 0, 0xFF1E1E1E, 0xFF3A3A44),
        Opt("Blond", 0, 0xFFD2A93C, 0xFFF0D27A), Opt("Roux", 0, 0xFF9C3B1E, 0xFFC95A30),
        Opt("Bleu", 6, 0xFF2F6BFF, 0xFF7FA6FF), Opt("Rose", 11, 0xFFFF5FB0, 0xFFFFA0D6),
        Opt("Blanc", 18, 0xFFE8E8F0, 0xFFFFFFFF), Opt("Vert", 24, 0xFF2ECC71, 0xFF7FE8A8)
    )
    val skinTones = listOf(
        Opt("Clair", 0, 0xFFFAD7B0, 0xFFE0B88C), Opt("Beige", 0, 0xFFF2C79A, 0xFFD9A878),
        Opt("Mat", 0, 0xFFD9A074, 0xFFB8825A), Opt("Brun", 0, 0xFF9A6A45, 0xFF7A4F2F),
        Opt("Foncé", 0, 0xFF6B4429, 0xFF4F3019)
    )
    val kitColors = listOf(
        Opt("Bleu", 0, 0xFF2F6BFF, 0xFF1F4FC4), Opt("Rouge", 0, 0xFFE23B3B, 0xFFA82424),
        Opt("Vert", 0, 0xFF2ECC71, 0xFF1E9A55), Opt("Jaune", 0, 0xFFFFC83D, 0xFFC99A1E),
        Opt("Orange", 0, 0xFFFF8A00, 0xFFC26A00), Opt("Blanc", 0, 0xFFF4F4F8, 0xFFC9CED8),
        Opt("Noir", 0, 0xFF2B2B33, 0xFF14141C), Opt("Violet", 0, 0xFF9A3BE2, 0xFF7026A8),
        Opt("Rose", 12, 0xFFFF5FB0, 0xFFC93C86), Opt("Turquoise", 18, 0xFF1ED6C8, 0xFF12988E),
        Opt("Argent", 25, 0xFFB8C0D0, 0xFF8890A0), Opt("Or", 40, 0xFFFFD24A, 0xFFC99A1E)
    )
    val patterns = listOf(Opt("Uni"), Opt("Rayures", 5), Opt("Bande", 10), Opt("Moitié", 20), Opt("Damier", 32))
    val accessories = listOf(Opt("Aucun"), Opt("Bandeau", 2), Opt("Lunettes", 7), Opt("Brassard", 12), Opt("Casquette", 22), Opt("Couronne", 60))
    val balls = listOf(
        Opt("Classique"), Opt("Néon", 6, 0xFF35F0FF, 0xFFFF3DCB), Opt("Feu", 14, 0xFFFF7A1A, 0xFFFFE04A),
        Opt("Galaxie", 28, 0xFF3B2A8F, 0xFFC08CFF), Opt("Or", 45, 0xFFFFD24A, 0xFFFFF2B0), Opt("Arc-en-ciel", 70)
    )
    val markers = listOf(Opt("Flèche or"), Opt("Flèche cyan", 4, 0xFF35F0FF), Opt("Flèche rose", 9, 0xFFFF5FB0),
        Opt("Diamant", 16, 0xFF7FE8FF), Opt("Étoile", 30, 0xFFFFE04A), Opt("Couronne", 50, 0xFFFFD24A))
    val trails = listOf(Opt("Aucune"), Opt("Blanche", 8), Opt("Étincelles", 22), Opt("Feu", 38), Opt("Arc-en-ciel", 55))

    /** Toutes les options, pour compter et annoncer les déblocages. */
    private fun all(): List<Opt> =
        hairStyles + hairColors + skinTones + kitColors + patterns + accessories + balls + markers + trails

    val totalCount: Int get() = all().size

    fun unlockedCount(stars: Int) = all().count { it.stars <= stars }

    /** Noms des options débloquées en passant de [before] à [after] étoiles. */
    fun newlyUnlocked(before: Int, after: Int): List<String> =
        all().filter { it.stars in (before + 1)..after }.map { it.name }

    fun nextUnlock(stars: Int): Opt? = all().filter { it.stars > stars }.minByOrNull { it.stars }

    fun col(v: Long) = Color(v)
}
