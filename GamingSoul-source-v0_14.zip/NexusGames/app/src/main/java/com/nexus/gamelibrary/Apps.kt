package com.nexus.gamelibrary

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap,
    /** Android a classé cette appli comme "jeu" (selon les infos du Play Store). */
    val autoGame: Boolean,
    /** Couleur dominante de l'icône : sert de fond à la carte du jeu. */
    val color: Color
)

private fun dominantColor(bmp: Bitmap): Color {
    val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(px, hsv)
    if (hsv[1] < 0.12f) hsv[0] = 260f // icône grise/blanche : on part sur du violet
    hsv[1] = hsv[1].coerceIn(0.45f, 0.9f)
    hsv[2] = hsv[2].coerceIn(0.5f, 0.85f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** Liste toutes les applis lançables du téléphone (sauf celle-ci). À appeler hors du thread principal. */
fun loadApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { it.activityInfo.applicationInfo }
        .distinctBy { it.packageName }
        .filter { it.packageName != context.packageName }
        .map { ai ->
            val bmp = pm.getApplicationIcon(ai).toBitmap(192, 192)
            AppEntry(
                label = pm.getApplicationLabel(ai).toString(),
                packageName = ai.packageName,
                icon = bmp.asImageBitmap(),
                autoGame = ai.category == ApplicationInfo.CATEGORY_GAME,
                color = dominantColor(bmp)
            )
        }
        .sortedBy { it.label.lowercase() }
}
