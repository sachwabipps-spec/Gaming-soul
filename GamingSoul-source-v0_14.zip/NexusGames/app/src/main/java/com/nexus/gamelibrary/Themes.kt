package com.nexus.gamelibrary

import androidx.compose.ui.graphics.Color

data class GameTheme(
    val name: String,
    val bgTop: Color,
    val bgBottom: Color,
    val accent: Color,
    val tile: Color,
    val light: Boolean = false
) {
    val onBg: Color get() = if (light) Color(0xFF111111) else Color.White
}

val themes = listOf(
    GameTheme("Soul", Color(0xFF12121C), Color(0xFF08080E), Color(0xFF7C5CFF), Color(0xFF1D1D2B)),
    GameTheme("Vert console", Color(0xFF0E1A10), Color(0xFF050805), Color(0xFF3DDC4A), Color(0xFF1B2A1D)),
    GameTheme("Nuit", Color(0xFF0F1220), Color(0xFF05060C), Color(0xFF6C8CFF), Color(0xFF1A1F36)),
    GameTheme("Néon", Color(0xFF1A0B2E), Color(0xFF07030F), Color(0xFFFF3DCB), Color(0xFF2A1647)),
    GameTheme("Arcade", Color(0xFF2B0A0A), Color(0xFF0A0303), Color(0xFFFF5A36), Color(0xFF3F1515)),
    GameTheme("Océan", Color(0xFF062433), Color(0xFF02080D), Color(0xFF2FD1E0), Color(0xFF0E3A4F)),
    GameTheme("Clair", Color(0xFFF4F6FA), Color(0xFFDDE3EE), Color(0xFF2B6BFF), Color(0xFFFFFFFF), light = true)
)
