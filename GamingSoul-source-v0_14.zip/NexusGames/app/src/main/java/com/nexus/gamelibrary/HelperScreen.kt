package com.nexus.gamelibrary

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Onglet Helper : 1) tu écris ta question, elle part vers l'appli ChatGPT
 * 2) tu reviens et tu colles la réponse ici pour la garder.
 */
@Composable
fun HelperScreen(theme: GameTheme, store: Store) {
    val context = LocalContext.current
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var log by remember { mutableStateOf(store.helperLog) }

    fun toast(t: String) = Toast.makeText(context, t, Toast.LENGTH_SHORT).show()

    LazyColumn(
        modifier = Modifier.imePadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Helper", color = theme.onBg, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text(
                "Écris ta question, envoie-la à ChatGPT, puis colle sa réponse ici.",
                color = theme.onBg.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        item {
            GlassCard(theme) {
                Text("1 · Ta question", color = theme.onBg, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                InputBox(question, { question = it }, "ex : comment battre ce boss ?", theme, minLines = 3)
                Spacer(Modifier.height(10.dp))
                ActionButton("Envoyer à ChatGPT", theme, Modifier.fillMaxWidth()) {
                    val q = question.trim()
                    if (q.isEmpty()) {
                        toast("Écris d'abord ta question")
                    } else if (sendToChatGpt(context, q)) {
                        toast("Question copiée et envoyée. Reviens ici pour coller la réponse.")
                    } else {
                        toast("Impossible d'ouvrir ChatGPT")
                    }
                }
            }
        }

        item {
            GlassCard(theme) {
                Text("2 · La réponse de ChatGPT", color = theme.onBg, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                InputBox(answer, { answer = it }, "Colle la réponse ici", theme, minLines = 4, maxLines = 10)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionButton("Coller", theme, Modifier.weight(1f), primary = false) {
                        val t = readClipboard(context)
                        if (t.isBlank()) toast("Le presse-papiers est vide") else answer = t
                    }
                    ActionButton("Enregistrer", theme, Modifier.weight(1f)) {
                        if (answer.isBlank()) {
                            toast("Colle d'abord la réponse")
                        } else {
                            val e = HelperEntry(question.trim(), answer.trim(), System.currentTimeMillis())
                            log = listOf(e) + log
                            store.helperLog = log
                            answer = ""
                            toast("Réponse enregistrée")
                        }
                    }
                }
            }
        }

        if (log.isNotEmpty()) {
            item {
                Text("Historique", color = theme.onBg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        items(log, key = { it.t }) { e ->
            GlassCard(theme) {
                if (e.q.isNotBlank()) {
                    Text(e.q, color = theme.accent, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                }
                Text(e.a, color = theme.onBg, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionButton("Copier", theme, Modifier.weight(1f), primary = false) {
                        copyToClipboard(context, e.a)
                        toast("Réponse copiée")
                    }
                    ActionButton("Supprimer", theme, Modifier.weight(1f), primary = false) {
                        log = log.filter { it.t != e.t }
                        store.helperLog = log
                    }
                }
            }
        }
    }
}
