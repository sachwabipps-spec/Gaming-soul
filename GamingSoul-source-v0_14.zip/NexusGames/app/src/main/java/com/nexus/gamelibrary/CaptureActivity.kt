package com.nexus.gamelibrary

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/** Activité invisible : affiche la demande d'autorisation de capture d'écran d'Android, puis renvoie le résultat au service. */
class CaptureActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val i = Intent(this, OverlayService::class.java)
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            i.action = OverlayService.ACTION_PROJECTION
            i.putExtra("code", res.resultCode)
            i.putExtra("data", data)
        } else {
            i.action = OverlayService.ACTION_CANCELLED
        }
        ContextCompat.startForegroundService(this, i)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            launcher.launch(mpm.createScreenCaptureIntent())
        }
    }
}
