package com.nexus.gamelibrary

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.delay

internal val Gold = Color(0xFFFFC83D)

internal fun stars(n: Int) = "★".repeat(n) + "☆".repeat(3 - n)

internal fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ════════════════════════════════════════════════════════════════
//  Écran de match
// ════════════════════════════════════════════════════════════════

@Composable
fun MatchScreen(level: Level, store: Store, hasNext: Boolean, onExit: () -> Unit, onNext: () -> Unit) {
    val context = LocalContext.current
    var attempt by remember(level.index) { mutableIntStateOf(0) }
    val match = remember(level.index, attempt) { Match(level) }
    var paused by remember(level.index, attempt) { mutableStateOf(false) }
    var hud by remember(match) { mutableStateOf(match.hud()) }
    var frame by remember(match) { mutableIntStateOf(0) }
    var showHelp by remember(match) { mutableStateOf(true) }
    var sound by remember { mutableStateOf(store.arcadeSound) }
    val soundOn = rememberUpdatedState(sound)
    val skin = remember { store.skin }
    val startStars = remember(match) { store.totalStars() }
    var unlockedNames by remember(match) { mutableStateOf(emptyList<String>()) }

    LaunchedEffect(match) {
        delay(7000)
        showHelp = false
    }

    // Écran en paysage + plein écran pendant le match
    DisposableEffect(Unit) {
        val act = context.findActivity()
        val window = act?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Petits bips (aucun fichier son, tout est généré par le téléphone)
    val tone = remember {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 55) } catch (e: Throwable) { null }
    }
    DisposableEffect(tone) { onDispose { try { tone?.release() } catch (e: Throwable) { } } }

    fun beep(code: Int) {
        if (!soundOn.value) return
        try {
            when (code) {
                1 -> tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
                2 -> tone?.startTone(ToneGenerator.TONE_PROP_ACK, 200)
                3 -> tone?.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 400)
                else -> tone?.startTone(ToneGenerator.TONE_PROP_NACK, 400)
            }
        } catch (e: Throwable) { }
    }

    // Boucle de jeu à pas fixe (60 pas par seconde)
    LaunchedEffect(match, paused) {
        if (paused) return@LaunchedEffect
        var last = 0L
        var acc = 0f
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) {
                    acc += min(0.05f, (now - last) / 1_000_000_000f)
                    while (acc >= STEP) {
                        match.step(STEP)
                        acc -= STEP
                    }
                }
                last = now
                while (match.sfx.isNotEmpty()) beep(match.sfx.removeFirst())
                val h = match.hud()
                if (h != hud) hud = h
                frame++
            }
        }
    }

    // Sauvegarde des étoiles à la fin du match
    LaunchedEffect(hud.over) {
        if (hud.over && match.won && !level.quick) {
            store.setArcadeStars(level.index, match.stars())
            unlockedNames = Cosmetics.newlyUnlocked(startStars, store.totalStars())
        }
    }

    BackHandler { if (!hud.over) paused = !paused else onExit() }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
            .background(Color.Black)
    ) {
        val scene = remember(level, attempt) { SceneCache() }
        Canvas(Modifier.fillMaxSize()) {
            frame // lecture : redessine à chaque image
            drawMatch(match, frame, skin, scene)
        }

        // ── Score + chrono
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("TOI", color = Color(0xFF7FB0FF), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Text("${hud.scoreA}", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                Text(
                    if (hud.seconds >= 0) {
                        "  " + (if (hud.overtime) "+" else "%d:%02d".format(hud.seconds / 60, hud.seconds % 60)) + "  "
                    } else "  –  ",
                    color = Gold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Text("${hud.scoreB}", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                Spacer(Modifier.width(8.dp))
                Text(level.opponent.uppercase(), color = Color(0xFFFF8A80), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            if (hud.touches >= 0) {
                val tc = hud.touches.coerceIn(0, 3)
                Text(
                    "TOUCHES " + "●".repeat(tc) + "○".repeat(3 - tc),
                    color = if (hud.touchSide == 0) Color(0xFF7FB0FF) else Color(0xFFFF8A80),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            val coach = if (hud.serveWait >= 0) "SERVICE · appuie sur FRAPPE (auto dans ${hud.serveWait}s)" else match.coach()
            if (coach != null && !hud.over) {
                Text(
                    coach,
                    color = Color(0xFF9CFFB0),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                )
            }
            if (hud.message.isNotEmpty()) {
                Text(
                    hud.message,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(top = 18.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }

        // ── Aide affichée au début du match
        if (showHelp && !hud.over) {
            Text(
                level.sport.help,
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .safeDrawingPadding()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }

        // ── Bouton pause
        Box(
            Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(8.dp)
                .size(40.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable { if (!hud.over) paused = true },
            contentAlignment = Alignment.Center
        ) { Text("II", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        // ── Commandes : joystick à gauche, boutons à droite
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .safeDrawingPadding()
                .padding(start = 20.dp, bottom = 18.dp)
        ) {
            Joystick { x, y ->
                val l = kotlin.math.sqrt(x * x + y * y)
                if (l < 0.12f) {
                    match.input.mx = 0f
                    match.input.my = 0f
                } else {
                    match.input.mx = x
                    match.input.my = y
                }
            }
        }
        Row(
            Modifier
                .align(Alignment.BottomEnd)
                .safeDrawingPadding()
                .padding(end = 20.dp, bottom = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            if (level.sport == Sport.FOOT) {
                PadButton("⇄", 52.dp, Color(0xFF80D8FF), onPress = { match.input.switchLatch = true }) { }
            }
            val third = level.sport.thirdLabel
            if (third != null) {
                PadButton(third, 62.dp, Color(0xFFFF8A80), onPress = { match.input.thirdLatch = true }) { down -> match.input.third = down }
            }
            val second = level.sport.secondLabel
            if (second != null) {
                PadButton(second, 64.dp, Color.White, onPress = { match.input.passLatch = true }) { down -> match.input.pass = down }
            }
            PadButton(level.sport.actionLabel, 84.dp, Gold, onPress = { match.input.actionLatch = true }) { down -> match.input.action = down }
        }

        // ── Pause
        if (paused && !hud.over) {
            OverlayCard {
                Text("PAUSE", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                Spacer(Modifier.height(14.dp))
                OverlayButton("Continuer", Gold) { paused = false }
                OverlayButton("Recommencer", Color.White) { attempt++ }
                OverlayButton(if (sound) "Son : oui" else "Son : non", Color.White) {
                    sound = !sound
                    store.arcadeSound = sound
                }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { onExit() }
            }
        }

        // ── Fin de match
        if (hud.over) {
            OverlayCard {
                Text(
                    if (match.won) "VICTOIRE !" else "DÉFAITE",
                    color = if (match.won) Gold else Color(0xFFFF8A80),
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 28.sp
                )
                Text(
                    "${hud.scoreA} - ${hud.scoreB}",
                    color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 22.sp
                )
                if (match.won && !level.quick) {
                    Text(stars(match.stars()), color = Gold, fontSize = 34.sp)
                    val unlocked = unlockedNames
                    if (unlocked.isNotEmpty()) {
                        Text(
                            "🎁 Débloqué : " + unlocked.take(4).joinToString(", ") + if (unlocked.size > 4) "…" else "",
                            color = Color(0xFF9CFFB0), fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                            textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                } else if (match.won) {
                    Text(if (level.training) "Bien joué !" else "Match rapide : pas d'étoiles", color = Gold, fontSize = 14.sp)
                } else {
                    Text("Retente ta chance !", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
                }
                Spacer(Modifier.height(10.dp))
                if (match.won && hasNext) OverlayButton("Match suivant", Gold) { onNext() }
                OverlayButton("Rejouer", Color.White) { attempt++ }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { onExit() }
            }
        }
    }
}

private const val STEP = 1f / 60f

@Composable
private fun OverlayCard(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF1B1B26))
                .border(2.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                .padding(horizontal = 28.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) { content() }
    }
}

@Composable
private fun OverlayButton(text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(vertical = 4.dp)
            .width(200.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.18f))
            .border(1.5.dp, color.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** Joystick tactile : renvoie (x, y) entre -1 et 1, (0, 0) quand on relâche. */
@Composable
private fun Joystick(onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    val cb = rememberUpdatedState(onMove)
    Box(
        Modifier
            .size(150.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(2.dp, Color.White.copy(alpha = 0.35f), CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val rad = size.width / 2f
                    var px = down.position.x
                    var py = down.position.y
                    while (true) {
                        var vx = (px - cx) / rad
                        var vy = (py - cy) / rad
                        val l = kotlin.math.sqrt(vx * vx + vy * vy)
                        if (l > 1f) { vx /= l; vy /= l }
                        knob = Offset(vx * rad * 0.55f, vy * rad * 0.55f)
                        cb.value(vx, vy)
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        px = ch.position.x
                        py = ch.position.y
                        ch.consume()
                    }
                    knob = Offset.Zero
                    cb.value(0f, 0f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .offset { IntOffset(knob.x.roundToInt(), knob.y.roundToInt()) }
                .size(58.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.45f))
        )
    }
}

/** Bouton tactile à appui maintenu (plusieurs doigts en même temps possibles). */
@Composable
private fun PadButton(
    label: String,
    size: Dp,
    color: Color,
    onPress: () -> Unit = {},
    onHold: (Boolean) -> Unit
) {
    var down by remember { mutableStateOf(false) }
    val hold = rememberUpdatedState(onHold)
    val press = rememberUpdatedState(onPress)
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (down) color.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.16f))
            .border(2.dp, color.copy(alpha = 0.75f), CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    down = true
                    hold.value(true)
                    press.value()
                    waitForUpOrCancellation()
                    down = false
                    hold.value(false)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = if (label.length > 2) 13.sp else 24.sp
        )
    }
}

// ════════════════════════════════════════════════════════════════
//  Dessin pixel art (vue du dessus)
// ════════════════════════════════════════════════════════════════

internal class Px(val ds: DrawScope, val s: Float, val ox: Float, val oy: Float) {
    fun r(x: Float, y: Float, w: Float, h: Float, c: Color) {
        val x0 = floor(ox + x * s)
        val y0 = floor(oy + y * s)
        val x1 = floor(ox + (x + w) * s)
        val y1 = floor(oy + (y + h) * s)
        ds.drawRect(c, Offset(x0, y0), Size(max(1f, x1 - x0), max(1f, y1 - y0)))
    }

    fun r(x: Int, y: Int, w: Int, h: Int, c: Color) = r(x.toFloat(), y.toFloat(), w.toFloat(), h.toFloat(), c)

    /** Dessine un sprite : une chaîne par ligne, une lettre par couleur, '.' = transparent. */
    fun sprite(rows: List<String>, x: Int, y: Int, flip: Boolean, pal: (Char) -> Color?) {
        for ((j, row) in rows.withIndex()) {
            val n = row.length
            var i = 0
            while (i < n) {
                val ch = row[if (flip) n - 1 - i else i]
                val c = pal(ch)
                if (c == null) { i++; continue }
                var k = i + 1
                while (k < n && row[if (flip) n - 1 - k else k] == ch) k++
                r(x + i, y + j, k - i, 1, c)
                i = k
            }
        }
    }

    /** Cercle (contour) fait de petits points. */
    fun ring(cx: Float, cy: Float, rad: Float, c: Color, from: Float = 0f, to: Float = 6.2832f) {
        val steps = max(24, (rad * 14f).toInt())
        for (i in 0 until steps) {
            val a = from + (to - from) * i / steps
            r(floor((cx + cos(a) * rad) * 2f) / 2f, floor((cy + sin(a) * rad) * 2f) / 2f, 0.5f, 0.5f, c)
        }
    }

    fun line(x0: Float, y0: Float, x1: Float, y1: Float, c: Color, step: Float = 1f) {
        val dx = x1 - x0
        val dy = y1 - y0
        val len = kotlin.math.sqrt(dx * dx + dy * dy)
        val n = max(1, (len / step).toInt())
        for (i in 0..n) {
            val t = i.toFloat() / n
            r(floor((x0 + dx * t) * 2f) / 2f, floor((y0 + dy * t) * 2f) / 2f, 1f, 1f, c)
        }
    }
}

internal fun lcg(seed: Int): Int = (seed * 1103515245 + 12345) and 0x7fffffff

private val LineWhite = Color(0xE6FFFFFF)

// ---- filet de volley (les décors et terrains sont dans ArcadeScenery.kt) ----

private fun Px.drawVolleyNet() {
    val nx = Court.NET_X.toInt()
    val y0 = Court.VY0.toInt() - 6
    val y1 = Court.VY1.toInt() + 6
    r(nx + 2, y0 + 2, 3, y1 - y0, Color(0x33000000)) // ombre du filet
    var y = y0
    while (y < y1) {
        r(nx - 1, y, 2, 1, Color.White)
        r(nx - 1, y + 1, 2, 1, Color(0xFFB9C0D0))
        y += 2
    }
    r(nx - 2, y0 - 2, 4, 4, Color(0xFF22252E)); r(nx - 2, y1 - 1, 4, 4, Color(0xFF22252E))
    r(nx - 1, y0 - 1, 2, 2, Color(0xFFFF5A4A)); r(nx - 1, y1, 2, 2, Color(0xFFFF5A4A))
}

// ---- scène complète ----

private fun DrawScope.drawMatch(m: Match, tick: Int, skin: Skin, scene: SceneCache) {
    val s = min(size.width / Court.W, size.height / Court.H)
    val ox = floor((size.width - Court.W * s) / 2f)
    val oy = floor((size.height - Court.H * s) / 2f)
    val p = Px(this, s, ox, oy)
    val lv = m.level

    scene.draw(this, m, s, ox, oy)
    p.drawLive(m, tick)

    // aide à la visée : ligne pointillée + cible
    val hint = m.aimHint()
    if (hint != null) {
        val me = m.ps[m.ctrl]
        val gold = Gold.copy(alpha = 0.85f)
        p.line(me.x, me.y - 6f, hint[0], hint[1], Gold.copy(alpha = 0.45f), 5f)
        if (m.sport == Sport.BASKET) {
            // jauge de chance de marquer au-dessus du joueur
            val w = 20
            val x0 = me.x.roundToInt() - w / 2
            val y0 = me.y.roundToInt() - 31
            p.r(x0 - 1, y0 - 1, w + 2, 4, Color.Black.copy(alpha = 0.6f))
            val ch = hint[2]
            val col = if (ch > 0.6f) Color(0xFF4CD964) else if (ch > 0.35f) Color(0xFFFFC83D) else Color(0xFFFF5A4A)
            p.r(x0, y0, max(1, (w * ch).roundToInt()), 2, col)
        } else {
            val tx = hint[0].roundToInt()
            val ty = hint[1].roundToInt()
            if (hint[2] > 0.5f || m.sport == Sport.VOLLEY) {
                p.ring(tx + 0.5f, ty + 0.5f, 4f, gold)
                p.r(tx, ty, 1, 1, gold)
            }
        }
    }

    // guidage de passe : anneau sous le coéquipier visé
    val ph = m.passHint()
    if (ph != null) {
        p.ring(ph.x + 0.5f, ph.y + 0.5f, 7f, Color.White.copy(alpha = 0.9f))
        p.ring(ph.x + 0.5f, ph.y + 0.5f, 8f, Gold.copy(alpha = 0.5f))
    }

    if (m.sport == Sport.VOLLEY) {
        p.drawVolleyNet()
    }

    p.drawLanding(m, tick)
    p.drawTrail(m, skin)
    // joueurs et ballon triés par profondeur (y) pour un rendu 2,5D propre
    val order = m.ps.sortedBy { it.y }
    var ballDone = false
    val ballY = m.by
    for (pl in order) {
        if (!ballDone && ballY < pl.y) {
            p.drawBallHi(m, skin)
            ballDone = true
        }
        p.drawPlayerHi(m, pl, tick, pl === m.ps[m.ctrl], skin)
    }
    if (!ballDone) p.drawBallHi(m, skin)

    // cercle de timing du smash (volley) : frappe quand il touche l'anneau doré
    val sr = m.smashRing()
    if (sr != null) {
        val q = sr[3]
        val col = if (q >= 1f) Color(0xFF4CD964) else if (q >= 0.6f) Gold else Color.White
        p.ring(sr[0] + 0.5f, sr[1] + 0.5f, 5f, Gold.copy(alpha = 0.9f))
        p.ring(sr[0] + 0.5f, sr[1] + 0.5f, sr[2], col)
        p.ring(sr[0] + 0.5f, sr[1] + 0.5f, sr[2] + 1f, col.copy(alpha = 0.5f))
    }
    p.drawConfetti(m)
}
