package com.nexus.gamelibrary

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent

/** Une question envoyée à ChatGPT et la réponse collée ensuite dans l'appli. */
data class HelperEntry(val q: String, val a: String, val t: Long)

const val CHATGPT_PACKAGE = "com.openai.chatgpt"

fun copyToClipboard(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("gaming-soul", text))
}

fun readClipboard(context: Context): String {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = cm.primaryClip ?: return ""
    if (clip.itemCount == 0) return ""
    return clip.getItemAt(0).coerceToText(context)?.toString().orEmpty()
}

/**
 * Copie la question puis l'envoie à l'appli ChatGPT (sinon à une autre appli au choix).
 * Aucune clé API : tout passe par l'appli ChatGPT installée sur le téléphone.
 */
fun sendToChatGpt(context: Context, question: String): Boolean {
    copyToClipboard(context, question)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, question)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    return try {
        context.startActivity(Intent(send).setPackage(CHATGPT_PACKAGE))
        true
    } catch (e: Exception) {
        try {
            context.startActivity(
                Intent.createChooser(send, "Envoyer la question à…").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (e2: Exception) {
            false
        }
    }
}
