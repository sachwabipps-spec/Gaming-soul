package com.nexus.gamelibrary

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.media.ExifInterface
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import java.io.FileOutputStream

private fun bgFile(context: Context) = File(context.filesDir, "background.jpg")

fun hasBackground(context: Context) = bgFile(context).exists()

fun removeBackground(context: Context) {
    bgFile(context).delete()
}

/** Copie la photo choisie dans le stockage de l'appli (réduite à ~2000 px) pour ne plus dépendre de la galerie. */
fun saveBackground(context: Context, uri: Uri): Boolean {
    return try {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        FileOutputStream(bgFile(context)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        true
    } catch (e: Exception) {
        false
    }
}

/**
 * Charge la photo de fond déjà floutée. blur = 0..100.
 * Le flou est obtenu en réduisant l'image puis en la ré-agrandissant (fonctionne sur tous les Android).
 */
fun loadBackground(context: Context, blur: Int): ImageBitmap? {
    val f = bgFile(context)
    if (!f.exists()) return null
    return try {
        val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
        val src = BitmapFactory.decodeFile(f.absolutePath, opts) ?: return null
        val target = maxOf(16, (src.width / (1f + blur.coerceIn(0, 100) * 0.3f)).toInt())
        var b = src
        while (b.width / 2 >= target) {
            b = Bitmap.createScaledBitmap(b, b.width / 2, maxOf(1, b.height / 2), true)
        }
        if (b.width > target) {
            b = Bitmap.createScaledBitmap(b, target, maxOf(1, b.height * target / b.width), true)
        }
        b.asImageBitmap()
    } catch (e: Exception) {
        null
    }
}
