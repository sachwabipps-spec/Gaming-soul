package com.nexus.gamelibrary

import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas as GfxCanvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * Décors et terrains détaillés (demi-pixels). 15 décors : 3 sports × 5 difficultés.
 *  - La partie fixe est dessinée UNE fois dans une image (SceneCache) puis simplement recopiée.
 *  - La partie animée (flashs, vagues, feux d'artifice, bandeau LED) est dessinée par drawLive().
 * Les coordonnées « hp » sont en demi-pixels (le terrain fait 640 x 360 hp).
 */

private val LW = Color(0xE6FFFFFF)

internal class SceneCache {
    private var bmp: ImageBitmap? = null
    private var key = ""

    fun draw(ds: DrawScope, m: Match, s: Float, ox: Float, oy: Float) {
        val w = ds.size.width.toInt().coerceAtLeast(1)
        val hgt = ds.size.height.toInt().coerceAtLeast(1)
        val k = "${w}x$hgt/${m.sport.ordinal}/${m.level.division}"
        val cur = bmp
        val img: ImageBitmap
        if (cur == null || key != k) {
            val nb = ImageBitmap(w, hgt)
            val cv = CanvasDrawScope()
            cv.draw(Density(1f), LayoutDirection.Ltr, GfxCanvas(nb), Size(w.toFloat(), hgt.toFloat())) {
                Px(this, s, ox, oy).paintStatic(m.sport, m.level.division)
            }
            bmp = nb
            key = k
            img = nb
        } else {
            img = cur
        }
        ds.drawImage(img)
    }
}

// ───────────────────────── outils ─────────────────────────

private fun nz(a: Int, b: Int, s: Int): Int = lcg(a * 73856093 xor b * 19349663 xor s * 83492791)

private fun mixC(a: Color, b: Color, t: Float) =
    Color(a.red + (b.red - a.red) * t, a.green + (b.green - a.green) * t, a.blue + (b.blue - a.blue) * t, 1f)

private fun dkC(c: Color, f: Float) = Color((c.red * f).coerceIn(0f, 1f), (c.green * f).coerceIn(0f, 1f), (c.blue * f).coerceIn(0f, 1f), 1f)

private val shirtsC = listOf(0xFFE74C3C, 0xFF3498DB, 0xFFF1C40F, 0xFF2ECC71, 0xFF9B59B6, 0xFFECF0F1, 0xFFE67E22).map { Color(it) }
private val goldC = listOf(0xFFFFC83D, 0xFFFFE08A, 0xFFE0A21B, 0xFFFFFFFF, 0xFFFFC83D).map { Color(it) }
private val skinsC = listOf(0xFFF2C79A, 0xFFD9A074, 0xFF8D5A3B, 0xFFFAD7B0).map { Color(it) }
private val hairsC = listOf(0xFF2B1B12, 0xFF6B4423, 0xFFD9B35A, 0xFF1A1A1A).map { Color(it) }

private fun Px.speckle(x0: Int, y0: Int, x1: Int, y1: Int, n: Int, seed: Int, cols: List<Color>) {
    var s = seed
    for (i in 0 until n) {
        s = lcg(s); val x = x0 + s % max(1, x1 - x0)
        s = lcg(s); val y = y0 + (s / 7) % max(1, y1 - y0)
        s = lcg(s)
        h(x, y, 1 + s % 2, 1, cols[(s / 5) % cols.size])
    }
}

private fun Px.disc(cx: Int, cy: Int, rad: Int, c: Color) {
    for (dy in -rad..rad) {
        val w = sqrt((rad * rad - dy * dy).toFloat()).toInt()
        h(cx - w, cy + dy, w * 2 + 1, 1, c)
    }
}

/** Cercle / arc fait de points au demi-pixel (plus lisse que ring()). Coordonnées en unités du terrain. */
private fun Px.ringH(cx: Float, cy: Float, rad: Float, c: Color, from: Float = 0f, to: Float = 6.2832f, dash: Int = 0) {
    val steps = max(24, (rad * 16f).toInt())
    for (i in 0 until steps) {
        if (dash > 0 && (i / dash) % 2 == 1) continue
        val a = from + (to - from) * i / steps
        r(floor((cx + cos(a) * rad) * 2f) / 2f, floor((cy + sin(a) * rad) * 2f) / 2f, 1f, 1f, c)
    }
}

private fun Px.fan(x: Int, y: Int, s: Int, pal: List<Color>) {
    val sh = pal[s % pal.size]
    h(x - 2, y + 3, 5, 4, sh)
    h(x - 2, y + 3, 5, 1, mixC(sh, Color.White, 0.3f))
    h(x - 2, y + 6, 5, 1, dkC(sh, 0.7f))
    h(x - 1, y, 3, 3, skinsC[(s / 7) % 4])
    h(x - 1, y, 3, 1, hairsC[(s / 3) % 4])
}

private fun Px.crowdH(x0: Int, x1: Int, y: Int, seed: Int, dens: Int, pal: List<Color>) {
    var x = x0
    while (x < x1) {
        val s = nz(x, y, seed)
        if (s % 100 < dens) fan(x, y, s, pal)
        x += 5
    }
}

private fun Px.crowdV(x: Int, y0: Int, y1: Int, seed: Int, dens: Int, pal: List<Color>) {
    var y = y0
    while (y < y1) {
        val s = nz(x, y, seed)
        if (s % 100 < dens) fan(x, y, s, pal)
        y += 8
    }
}

private fun Px.boardH(x0: Int, x1: Int, y: Int, t: Int, a: Long, b: Long, seed: Int) {
    h(x0, y, x1 - x0, t, Color(0xFF10141C))
    var x = x0 + 2
    var k = 0
    while (x < x1 - 22) {
        val s = nz(k, seed, 5)
        val w = 16 + s % 10
        h(x, y + 1, w, t - 2, Color(if (s % 3 == 0) b else a))
        var g = x + 2
        while (g < x + w - 3) { h(g, y + 2, 2, t - 4, Color(0xCCFFFFFF)); g += 3 + (s / (g + 1)) % 2 }
        x += w + 2
        k++
    }
}

private fun Px.boardV(x: Int, y0: Int, y1: Int, t: Int, a: Long, b: Long, seed: Int) {
    h(x, y0, t, y1 - y0, Color(0xFF10141C))
    var y = y0 + 2
    var k = 0
    while (y < y1 - 22) {
        val s = nz(k, seed, 6)
        val w = 16 + s % 10
        h(x + 1, y, t - 2, w, Color(if (s % 3 == 0) b else a))
        var g = y + 2
        while (g < y + w - 3) { h(x + 2, g, t - 4, 2, Color(0xCCFFFFFF)); g += 3 + (s / (g + 1)) % 2 }
        y += w + 2
        k++
    }
}

private fun Px.mast(x: Int, y: Int) {
    h(x - 1, y, 3, 12, Color(0xFF5A6070))
    h(x - 5, y - 3, 11, 4, Color(0xFFFFF6D0))
    h(x - 5, y + 1, 11, 1, Color(0xFFB8B09A))
    h(x - 9, y - 6, 19, 10, Color(0x18FFF6D0))
}

private fun Px.tree(cx: Int, cy: Int, rad: Int, seed: Int) {
    h(cx - 1, cy + rad - 2, 3, 6, Color(0xFF5B3A22))
    disc(cx + 1, cy + 2, rad, Color(0x33000000))
    disc(cx, cy, rad, Color(0xFF2F6B2F))
    disc(cx - rad / 3, cy - rad / 3, rad * 2 / 3, Color(0xFF3F8A3A))
    speckle(cx - rad, cy - rad, cx + rad, cy + rad, rad * 2, seed, listOf(Color(0xFF58A650), Color(0xFF245A28)))
}

private fun Px.palm(x: Int, y: Int) {
    for (i in 0 until 5) h(x + (i / 2), y + i * 4, 3, 4, Color(0xFF8A6238))
    val g = Color(0xFF2E8B3A)
    val g2 = Color(0xFF47B04F)
    val tx = x + 2
    h(tx - 12, y - 3, 12, 3, g); h(tx - 8, y - 6, 8, 3, g2); h(tx + 1, y - 3, 12, 3, g); h(tx + 1, y - 7, 9, 3, g2)
    h(tx - 3, y - 10, 6, 4, g2); h(tx - 10, y + 1, 8, 2, g); h(tx + 2, y + 1, 8, 2, g)
    h(tx - 1, y - 1, 3, 3, Color(0xFF6B4A28))
}

private fun Px.parasol(cx: Int, cy: Int, a: Color) {
    disc(cx + 2, cy + 3, 9, Color(0x22000000))
    disc(cx, cy, 9, a)
    h(cx - 3, cy - 8, 2, 17, Color.White); h(cx + 2, cy - 8, 2, 17, Color.White)
    h(cx - 1, cy - 1, 3, 3, Color(0xFFEEEEEE))
}

private fun Px.lamp(x: Int, y: Int) {
    h(x, y, 2, 14, Color(0xFF6C7380))
    h(x - 3, y - 2, 8, 3, Color(0xFFFFE9A0))
    h(x - 7, y - 5, 16, 9, Color(0x22FFE9A0))
}

private fun Px.scoreboard(x: Int, y: Int, w: Int) {
    h(x, y, w, 16, Color(0xFF0B0D12))
    h(x + 1, y + 1, w - 2, 1, Color(0xFF3A4150))
    var i = x + 6
    while (i < x + w - 10) { h(i, y + 5, 4, 7, Color(0xFFFFB02E)); h(i + 1, y + 6, 2, 5, Color(0xFF0B0D12)); i += 7 }
    h(x + w / 2 - 1, y + 6, 2, 2, Color(0xFFFFB02E)); h(x + w / 2 - 1, y + 9, 2, 2, Color(0xFFFFB02E))
}

private fun Px.bigScreen(x: Int, w: Int, tone: Long) {
    h(x - 2, 0, w + 4, 25, Color(0xFF0A0A10))
    h(x, 2, w, 21, Color(tone))
    for (i in 0 until 8) h(x, 2 + i * 2, w, 1, Color(0x18FFFFFF))
    h(x + 10, 7, 30, 3, Color(0xFFFFFFFF)); h(x + 10, 12, 52, 2, Color(0x99FFFFFF)); h(x + 10, 16, 40, 2, Color(0x66FFFFFF))
    h(x + w - 46, 6, 36, 14, Color(0x55FFFFFF)); h(x + w - 42, 9, 28, 8, Color(0x44000000))
}

private class Arena(val bg: Long, val step: Long, val seat: Long, val boardA: Long, val boardB: Long, val dens: Int, val pal: List<Color>)

private fun Px.arena(a: Arena, seed: Int) {
    h(0, 0, 640, 360, Color(a.bg))
    val step = Color(a.step)
    val seat = Color(a.seat)
    val seatDk = dkC(seat, 0.75f)
    for (rw in 0 until 3) {
        val yt = 2 + rw * 7
        h(0, yt + 3, 640, 4, if (rw % 2 == 0) seat else seatDk)
        h(0, yt + 7, 640, 1, step)
        val yb = 338 + rw * 7
        h(0, yb + 3, 640, 4, if (rw % 2 == 0) seat else seatDk)
        h(0, yb + 7, 640, 1, step)
    }
    for (cx in intArrayOf(4, 12, 20)) { h(cx - 3, 32, 7, 296, seatDk); h(cx + 4, 32, 1, 296, step) }
    for (cx in intArrayOf(620, 628, 636)) { h(cx - 3, 32, 7, 296, seatDk); h(cx - 4, 32, 1, 296, step) }
    for (rw in 0 until 3) {
        crowdH(0, 640, 2 + rw * 7, seed + rw, a.dens, a.pal)
        crowdH(0, 640, 338 + rw * 7, seed + 9 + rw, a.dens, a.pal)
    }
    for (cx in intArrayOf(4, 12, 20)) crowdV(cx, 34, 322, seed + cx, a.dens, a.pal)
    for (cx in intArrayOf(620, 628, 636)) crowdV(cx, 34, 322, seed + cx, a.dens, a.pal)
    boardH(0, 640, 24, 8, a.boardA, a.boardB, seed)
    boardH(0, 640, 328, 8, a.boardA, a.boardB, seed + 3)
    boardV(24, 32, 328, 8, a.boardA, a.boardB, seed + 5)
    boardV(608, 32, 328, 8, a.boardA, a.boardB, seed + 7)
}

private fun Px.confetti(seed: Int) {
    val cols = listOf(0xFFFFC83D, 0xFFFF5A8A, 0xFF4CD9FF, 0xFF8CFF6A, 0xFFFFFFFF).map { Color(it) }
    speckle(0, 0, 640, 24, 90, seed, cols)
    speckle(0, 336, 640, 360, 90, seed + 1, cols)
    speckle(0, 24, 24, 336, 60, seed + 2, cols)
    speckle(616, 24, 640, 336, 60, seed + 3, cols)
}

private fun Px.beams(x: Int) {
    for (i in 0 until 10) h(x - i * 2, i * 3, 14 + i * 4, 3, Color(0x12FFFFFF))
}

// ───────────────────────── décors urbains / plage / parc / gymnase ─────────────────────────

private fun Px.urban(bg: Long, seed: Int) {
    h(0, 0, 640, 360, Color(bg))
    var x = 0
    var k = 0
    val cols = listOf(0xFF5A4B50, 0xFF4A5568, 0xFF6B5B4B, 0xFF3F4E5E, 0xFF65505A)
    while (x < 640) {
        val s = nz(k, seed, 3)
        val bw = 34 + s % 22
        val bh = 16 + (s / 7) % 12
        val col = Color(cols[s % 5])
        h(x, 28 - bh, bw, bh, col)
        h(x, 28 - bh, bw, 2, dkC(col, 0.7f))
        var wy = 28 - bh + 4
        while (wy < 24) {
            var wx = x + 3
            while (wx < x + bw - 4) {
                val lit = nz(wx, wy, seed) % 3 == 0
                h(wx, wy, 3, 3, if (lit) Color(0xFFFFD98A) else Color(0xFF1B2230))
                wx += 6
            }
            wy += 6
        }
        x += bw + 2
        k++
    }
    // grillages
    val mesh = Color(0xFF8A919E)
    h(0, 28, 640, 1, mesh); h(0, 31, 640, 1, mesh)
    var fx = 0
    while (fx < 640) { h(fx, 26, 2, 6, mesh); var q = 0; while (q < 20) { h(fx + q, 29 + (q / 2) % 2, 1, 1, mesh); q += 2 }; fx += 20 }
    h(24, 32, 1, 296, mesh); h(615, 32, 1, 296, mesh)
    var fy = 32
    while (fy < 328) { h(22, fy, 3, 2, mesh); h(615, fy, 3, 2, mesh); fy += 20 }
    // mur en briques + graffitis (bas)
    h(0, 330, 640, 30, Color(0xFF7A4A3A))
    var by = 330
    var row = 0
    while (by < 360) {
        h(0, by, 640, 1, Color(0xFF5A3428))
        var bx = if (row % 2 == 0) 0 else 6
        while (bx < 640) { h(bx, by, 1, 4, Color(0xFF5A3428)); bx += 12 }
        by += 4; row++
    }
    for (i in 0 until 6) {
        val gx = 30 + i * 100
        val c1 = Color(listOf(0xFFFFC83D, 0xFF4CD9FF, 0xFFFF5A8A, 0xFF8CFF6A, 0xFFB46CFF, 0xFFFF8A3D)[i])
        h(gx, 342, 30, 12, Color(0xFF14141C)); h(gx + 1, 343, 28, 10, c1)
        h(gx + 4, 346, 6, 4, Color(0xFF14141C)); h(gx + 13, 345, 4, 6, Color(0xFF14141C)); h(gx + 20, 346, 6, 4, Color(0xFFFFFFFF))
    }
    crowdH(8, 632, 332, seed + 4, 30, shirtsC)
    // côtés : arbres + lampadaires
    tree(10, 80, 9, seed); tree(628, 120, 10, seed + 1); tree(10, 230, 10, seed + 2); tree(628, 270, 9, seed + 3)
    lamp(40, 8); lamp(600, 8); lamp(40, 332); lamp(600, 332)
}

private fun Px.beach(seed: Int) {
    val sand = Color(0xFFE2C98A)
    h(0, 0, 640, 360, sand)
    speckle(0, 30, 640, 360, 5200, seed, listOf(Color(0x22FFFFFF), Color(0x1A8A6A2A), Color(0x14000000)))
    for (i in 0 until 7) h(0, i * 4, 640, 4, mixC(Color(0xFF1B78C2), Color(0xFF63C6EE), i / 6f))
    var x = 0
    while (x < 640) { h(x, 24 + (x / 16) % 2, 10, 1, Color(0xCCFFFFFF)); x += 16 }
    h(0, 28, 640, 4, Color(0xFFC9B27A))
    h(0, 30, 640, 1, Color(0x55FFFFFF))
    palm(20, 44); palm(612, 46); palm(24, 300); palm(606, 298)
    parasol(90, 340, Color(0xFFE74C3C)); parasol(250, 342, Color(0xFF3498DB)); parasol(420, 340, Color(0xFFF1C40F)); parasol(560, 342, Color(0xFF2ECC71))
    val towel = listOf(0xFFFF8A9B, 0xFF4CD9FF, 0xFFFFD24A, 0xFF9CFF8A)
    for (i in 0 until 4) { val tx = 150 + i * 110; h(tx, 336, 22, 8, Color(towel[i])); h(tx, 338, 22, 1, Color.White); h(tx, 341, 22, 1, Color.White) }
    crowdH(40, 620, 338, seed + 2, 25, shirtsC)
}

private fun Px.park(seed: Int) {
    h(0, 0, 640, 360, Color(0xFF4B8A44))
    speckle(0, 0, 640, 360, 4200, seed, listOf(Color(0x22FFFFFF), Color(0x22000000), Color(0x30A8E060)))
    h(0, 26, 640, 3, Color(0xFFD8D2C0)); h(0, 331, 640, 3, Color(0xFFD8D2C0))
    var tx = 14
    var k = 0
    while (tx < 640) { tree(tx, 10 + (k % 2) * 3, 9 + k % 3, seed + k); tx += 46; k++ }
    for (i in 0 until 5) {
        val px = 40 + i * 120
        h(px, 340, 28, 7, Color(0xFF8A5A32)); h(px, 340, 28, 2, Color(0xFFB07A48)); h(px + 2, 347, 2, 6, Color(0xFF5B3A22)); h(px + 24, 347, 2, 6, Color(0xFF5B3A22))
    }
    crowdH(20, 620, 330, seed + 4, 45, shirtsC)
    for (i in 0 until 4) { val by = 70 + i * 62; h(4, by, 7, 22, Color(0xFF8A5A32)); h(628, by, 7, 22, Color(0xFF8A5A32)) }
    speckle(0, 36, 22, 324, 40, seed + 6, listOf(Color(0xFFFFE04A), Color(0xFFFF8AB0), Color(0xFFFFFFFF)))
    speckle(618, 36, 640, 324, 40, seed + 7, listOf(Color(0xFFFFE04A), Color(0xFFFF8AB0), Color(0xFFFFFFFF)))
}

private fun Px.gymWalls(seed: Int, wall: Long, floorEdge: Long) {
    h(0, 0, 640, 360, Color(wall))
    // espaliers (haut)
    h(0, 0, 640, 26, Color(0xFFB88B55))
    var x = 2
    while (x < 640) { h(x, 0, 2, 26, Color(0xFF8A6238)); h(x, 0, 1, 26, Color(0xFFD1A672)); x += 7 }
    for (y in intArrayOf(5, 12, 19)) h(0, y, 640, 1, Color(0x55000000))
    h(0, 26, 640, 3, Color(0xFF6B4A28))
    // tapis pliés + bancs (bas)
    h(0, 330, 640, 30, Color(floorEdge))
    for (i in 0 until 8) {
        val mx = 20 + i * 76
        h(mx, 334, 60, 9, Color(0xFF2E6FD4)); h(mx, 334, 60, 2, Color(0xFF5B95EA)); h(mx, 341, 60, 2, Color(0xFF1E4F9A))
        h(mx + 28, 334, 2, 9, Color(0xFF14346A))
    }
    h(0, 346, 640, 3, Color(0xFF8A5A32)); h(0, 349, 640, 1, Color(0xFF5B3A22))
    crowdH(20, 620, 340, seed + 3, 40, shirtsC)
    // côtés : murs avec bannières
    for (i in 0 until 4) {
        val by = 50 + i * 66
        h(2, by, 16, 26, Color(listOf(0xFFE74C3C, 0xFF3498DB, 0xFFF1C40F, 0xFF2ECC71)[i])); h(2, by, 16, 2, Color(0x44FFFFFF)); h(7, by + 8, 6, 10, Color(0x66FFFFFF))
        h(622, by, 16, 26, Color(listOf(0xFF3498DB, 0xFFF1C40F, 0xFF2ECC71, 0xFFE74C3C)[i])); h(622, by, 16, 2, Color(0x44FFFFFF)); h(627, by + 8, 6, 10, Color(0x66FFFFFF))
    }
    // horloge
    disc(320, 12, 8, Color(0xFF222222)); disc(320, 12, 7, Color(0xFFF4F0E0)); h(320, 6, 1, 6, Color(0xFF222222)); h(320, 12, 4, 1, Color(0xFF222222))
}

// ───────────────────────── foot ─────────────────────────

private fun footArena(d: Int): Arena = when (d) {
    1 -> Arena(0xFF1E252E, 0xFF3B4350, 0xFF59606E, 0xFFD9A441, 0xFF2E7DD1, 60, shirtsC)
    2 -> Arena(0xFF14213D, 0xFF26365C, 0xFF2D5BA8, 0xFF35D0E8, 0xFFFFFFFF, 78, shirtsC)
    3 -> Arena(0xFF0F1218, 0xFF262B36, 0xFF8C1D2B, 0xFFE23B3B, 0xFFFFFFFF, 90, shirtsC)
    else -> Arena(0xFF070A1F, 0xFF1B2145, 0xFF4A2F8A, 0xFFFFC83D, 0xFFFFFFFF, 98, goldC)
}

private fun Px.footDecor(d: Int) {
    if (d == 0) { urban(0xFF2B2F36, 11); return }
    arena(footArena(d), 20 + d)
    mast(6, 6); mast(634, 6); mast(6, 340); mast(634, 340)
    when (d) {
        1 -> { for (i in 0 until 6) { h(60 + i * 100, 0, 1, 6, Color(0xFFDDDDDD)); h(61 + i * 100, 0, 8, 4, shirtsC[i % 7]) } }
        2 -> scoreboard(240, 2, 160)
        3 -> {
            h(0, 0, 640, 6, Color(0x55000000)); h(0, 354, 640, 6, Color(0x55000000))
            for (cx in intArrayOf(40, 600)) { h(cx - 5, 322, 10, 6, Color(0xFF15151C)); h(cx - 3, 319, 6, 4, Color(0xFF3A3F4C)); h(cx + 1, 320, 2, 2, Color(0xFF7FD6FF)) }
            speckle(0, 0, 640, 24, 30, 5, listOf(Color(0x55FF5A4A), Color(0x55FFFFFF)))
        }
        else -> { bigScreen(200, 240, 0xFF1B3A8A); beams(70); beams(540); confetti(8) }
    }
}

private fun Px.footField(d: Int) {
    val g1 = Color(listOf(0xFF4F8A3A, 0xFF2A8A44, 0xFF278048, 0xFF2D7A3A, 0xFF23703A)[d])
    val g2 = Color(listOf(0xFF5E9A44, 0xFF37A046, 0xFF2F9054, 0xFF358846, 0xFF2B8044)[d])
    r(16, 16, 288, 148, g1)
    when (d) {
        0 -> {}
        1 -> for (i in 0 until 12) if (i % 2 == 0) r(16 + i * 24, 16, 24, 148, g2)
        2 -> { for (i in 0 until 24) if (i % 2 == 0) r(16 + i * 12, 16, 12, 148, g2); r(16, 16, 288, 4, Color(0x14000000)); r(16, 160, 288, 4, Color(0x14000000)) }
        else -> for (gx in 0 until 12) for (gy in 0 until 7) if ((gx + gy) % 2 == 0) r(16 + gx * 24, 16 + gy * 24, 24, min(24, 148 - gy * 24), g2)
    }
    if (d == 4) { var y = 16; while (y < 164) { r(16, y, 288, 1, Color(0x0DFFFFFF)); y += 3 } }
    speckle(32, 32, 608, 328, 3400, 41 + d, listOf(Color(0x14FFFFFF), Color(0x1A000000), Color(0x0FFFF0A0)))
    if (d == 0) {
        // terrain abîmé : zones de terre nue
        val dirt = Color(0xFF8A6B3E)
        val dirt2 = Color(0xFF9A7A4A)
        for (cx in intArrayOf(40, 160, 280)) { r(cx - 14, 80, 28, 20, dirt); r(cx - 10, 76, 20, 28, dirt); r(cx - 8, 82, 12, 8, dirt2) }
        speckle(40, 40, 600, 320, 260, 77, listOf(dirt, dirt2))
    }
    val w = LW
    r(16, 16, 288, 1, w); r(16, 163, 288, 1, w); r(16, 16, 1, 148, w); r(303, 16, 1, 148, w)
    r(160, 16, 1, 148, w)
    ringH(160.5f, 90.5f, 26f, w)
    r(159, 89, 3, 3, w)
    r(16, 50, 44, 1, w); r(16, 130, 44, 1, w); r(60, 50, 1, 81, w)
    r(260, 50, 44, 1, w); r(260, 130, 44, 1, w); r(260, 50, 1, 81, w)
    r(16, 62, 20, 1, w); r(16, 118, 20, 1, w); r(36, 62, 1, 57, w)
    r(284, 62, 20, 1, w); r(284, 118, 20, 1, w); r(284, 62, 1, 57, w)
    // points de penalty + arcs
    r(47, 90, 2, 2, w); r(272, 90, 2, 2, w)
    ringH(48.5f, 90.5f, 20f, w, -0.927f, 0.927f)
    ringH(272.5f, 90.5f, 20f, w, 3.1416f - 0.927f, 3.1416f + 0.927f)
    // arcs de corner
    ringH(16.5f, 16.5f, 4f, w, 0f, 1.5708f); ringH(303.5f, 16.5f, 4f, w, 1.5708f, 3.1416f)
    ringH(16.5f, 163.5f, 4f, w, -1.5708f, 0f); ringH(303.5f, 163.5f, 4f, w, 3.1416f, 4.7124f)
    goalNet(true, d); goalNet(false, d)
    for (cx in intArrayOf(32, 608)) for (cy in intArrayOf(32, 328)) {
        val top = if (cy < 100) cy - 9 else cy - 9
        h(cx, top, 1, 10, Color.White); h(cx + 1, top, 5, 3, Color(0xFFFF4A4A)); h(cx + 1, top, 5, 1, Color(0xFFFF8A8A))
    }
}

private fun Px.goalNet(left: Boolean, d: Int) {
    val gy0 = Court.GOAL_Y0.toInt()
    val gh = (Court.GOAL_Y1 - Court.GOAL_Y0).toInt()
    val x0 = if (left) 8 else 608
    h(x0, gy0 * 2, 24, gh * 2, Color(0x44000000))
    val net = Color(0x77FFFFFF)
    var i = 0
    while (i < 24) { h(x0 + i, gy0 * 2, 1, gh * 2, net); i += 3 }
    var j = 0
    while (j < gh * 2) { h(x0, gy0 * 2 + j, 24, 1, net); j += 3 }
    val post = if (d == 0) Color(0xFFB9B2A8) else Color.White
    val shade = Color(0xFF9AA0B0)
    val bx = if (left) 8 else 606
    h(bx, gy0 * 2 - 2, 26, 4, post); h(bx, (gy0 + gh) * 2 - 2, 26, 4, post)
    h(bx, gy0 * 2 + 1, 26, 1, shade); h(bx, (gy0 + gh) * 2 + 1, 26, 1, shade)
    val back = if (left) 8 else 628
    h(back, gy0 * 2 - 2, 4, gh * 2 + 4, post); h(back + (if (left) 3 else 0), gy0 * 2 - 2, 1, gh * 2 + 4, shade)
}

// ───────────────────────── basket ─────────────────────────

private fun basketArena(d: Int): Arena = when (d) {
    2 -> Arena(0xFF222B38, 0xFF3A4556, 0xFFB04A2A, 0xFF2E7DD1, 0xFFFFFFFF, 70, shirtsC)
    3 -> Arena(0xFF0B0D14, 0xFF222633, 0xFF2B2B4A, 0xFFE23B3B, 0xFFFFFFFF, 90, shirtsC)
    else -> Arena(0xFF120A04, 0xFF3A2A10, 0xFF8A6414, 0xFFFFC83D, 0xFF1A1A1A, 98, goldC)
}

private fun Px.basketDecor(d: Int) {
    when (d) {
        0 -> { urban(0xFF3A3D44, 31); h(0, 332, 640, 2, Color(0x33000000)) }
        1 -> gymWalls(33, 0xFFD8CBB0, 0xFF9A9486)
        else -> {
            arena(basketArena(d), 40 + d)
            when (d) {
                2 -> { scoreboard(250, 2, 140); h(250, 18, 2, 6, Color(0xFF444B58)); h(388, 18, 2, 6, Color(0xFF444B58)) }
                3 -> {
                    bigScreen(210, 220, 0xFF1A2A6A)
                    for (i in 0 until 8) { val bx = 20 + i * 76; h(bx, 26, 1, 3, Color(0xFFAAAAAA)); if (i % 2 == 0) h(bx - 4, 0, 10, 22, Color(0xCC8C1D2B)) }
                    beams(60); beams(560)
                }
                else -> {
                    for (i in 0 until 9) { val bx = 14 + i * 70; h(bx, 0, 12, 22, Color(0xFFFFC83D)); h(bx + 1, 1, 10, 20, Color(0xFF1A1A1A)); h(bx + 3, 6, 6, 6, Color(0xFFFFC83D)) }
                    beams(80); beams(540); confetti(12)
                }
            }
        }
    }
}

private fun Px.basketCourt(d: Int) {
    val base = Color(listOf(0xFF5B5F66, 0xFFD9B27A, 0xFFC98E4B, 0xFF9A6630, 0xFFB8782E)[d])
    r(16, 16, 288, 148, base)
    if (d == 0) {
        speckle(32, 32, 608, 328, 3600, 51, listOf(Color(0x18FFFFFF), Color(0x22000000), Color(0x14FFD080)))
        for (i in 0 until 9) { val sx = 50 + i * 30; val sy = 24 + (i * 37) % 120; r(sx, sy, 14, 1, Color(0x44000000)); r(sx + 14, sy + 1, 6, 1, Color(0x44000000)); r(sx + 19, sy + 2, 1, 5, Color(0x44000000)) }
    } else {
        var x = 16
        var k = 0
        while (x < 304) {
            r(x, 16, 1, 148, Color(0x1F000000))
            var q = 0
            while (q < 3) { r(x, 16 + (k * 37 + q * 53) % 140, 5, 1, Color(0x26000000)); q++ }
            x += 5; k++
        }
        speckle(32, 32, 608, 328, 2600, 52, listOf(Color(0x14FFFFFF), Color(0x1A3A1A00), Color(0x10FFE0A0)))
        if (d == 3) { var s = 0; while (s < 288) { r(16 + s, 16, 8, 148, Color(0x0CFFFFFF)); s += 34 } }
        if (d == 4) { r(16, 16, 288, 3, Color(0x66FFD24A)); r(16, 161, 288, 3, Color(0x66FFD24A)); disc(320, 181, 28, Color(0x33FFD24A)); disc(320, 181, 14, Color(0x44FFD24A)) }
    }
    val paint = Color(listOf(0xFF3B6FD4, 0xFF2E7D6B, 0xFFC0392B, 0xFF8E44AD, 0xFFD4A017)[d]).copy(alpha = if (d == 0) 0.45f else 0.55f)
    r(16, 65, 58, 50, paint); r(246, 65, 58, 50, paint)
    val w = LW
    r(16, 16, 288, 1, w); r(16, 163, 288, 1, w); r(16, 16, 1, 148, w); r(303, 16, 1, 148, w)
    r(160, 16, 1, 148, w)
    ringH(160.5f, 90.5f, 18f, w); ringH(160.5f, 90.5f, 6f, w)
    r(16, 65, 58, 1, w); r(16, 114, 58, 1, w); r(74, 65, 1, 50, w)
    r(246, 65, 58, 1, w); r(246, 114, 58, 1, w); r(246, 65, 1, 50, w)
    ringH(74.5f, 90.5f, 16f, w, -1.5708f, 1.5708f); ringH(74.5f, 90.5f, 16f, w, 1.5708f, 4.7124f, 4)
    ringH(245.5f, 90.5f, 16f, w, 1.5708f, 4.7124f); ringH(245.5f, 90.5f, 16f, w, -1.5708f, 1.5708f, 4)
    ringH(30.5f, 90.5f, Court.ARC, w, -1.45f, 1.45f); ringH(289.5f, 90.5f, Court.ARC, w, 1.6916f, 4.5916f)
    ringH(30.5f, 90.5f, 6f, w, -1.5708f, 1.5708f); ringH(289.5f, 90.5f, 6f, w, 1.5708f, 4.7124f)
    for (k in 0 until 4) { r(30 + k * 10, 62, 1, 3, w); r(30 + k * 10, 115, 1, 3, w); r(262 + k * 10, 62, 1, 3, w); r(262 + k * 10, 115, 1, 3, w) }
    hoop(true); hoop(false)
}

private fun Px.hoop(left: Boolean) {
    val bx = if (left) 21 else 298
    h(bx * 2 + (if (left) 3 else -3), 166, 4, 36, Color(0x33000000))
    h(bx * 2, 164, 4, 36, Color(0xE6E8E8F0))
    h(bx * 2, 164, 4, 2, Color(0xFF9AA0B0)); h(bx * 2, 198, 4, 2, Color(0xFF9AA0B0))
    h(bx * 2 + 1, 176, 2, 12, Color(0xFFFF6A1A))
    val hx = if (left) 30f else 290f
    ringH(hx + 0.5f, 90.5f, 4f, Color(0xFFFF6A1A))
    ringH(hx + 0.5f, 90.5f, 3.5f, Color(0xFFFF8A3D))
    ringH(hx + 0.5f, 90.5f, 2.5f, Color(0x88FFFFFF))
    val cx = (hx * 2f).toInt() + 1
    h(cx - 4, 181, 9, 1, Color(0x66FFFFFF)); h(cx, 177, 1, 9, Color(0x66FFFFFF))
    h(if (left) 48 else 590, 180, 6, 2, Color(0xFF8A8F9C))
}

// ───────────────────────── volley ─────────────────────────

private fun volleyArena(d: Int): Arena = when (d) {
    3 -> Arena(0xFF0E1A2E, 0xFF22324F, 0xFF1E5AA8, 0xFFFF8A00, 0xFFFFFFFF, 85, shirtsC)
    else -> Arena(0xFF0A1022, 0xFF1A2444, 0xFF7A5CC8, 0xFFFFD24A, 0xFFFFFFFF, 98, goldC)
}

private fun Px.volleyDecor(d: Int) {
    when (d) {
        0 -> beach(61)
        1 -> park(62)
        2 -> gymWalls(63, 0xFFCDD8C8, 0xFF8A9A8A)
        3 -> {
            arena(volleyArena(3), 70)
            scoreboard(240, 2, 160)
            h(176, 30, 3, 8, Color(0xFF9AA0B0)); h(172, 22, 11, 7, Color(0xFFF1C40F)); h(174, 18, 7, 5, Color(0xFFFFD6A8)); h(173, 17, 9, 2, Color(0xFF2B1B12))
            beams(70); beams(540)
        }
        else -> {
            arena(volleyArena(4), 80)
            bigScreen(200, 240, 0xFF2A1E6A)
            for (i in 0 until 12) { val fx = 30 + i * 50; h(fx, 24, 1, 5, Color(0xFFDDDDDD)); h(fx + 1, 24, 7, 4, Color(shirtsC[i % 7])) }
            beams(70); beams(540); confetti(18)
        }
    }
}

private fun Px.volleyCourt(d: Int) {
    val out = Color(listOf(0xFFE2C98A, 0xFF4B8A44, 0xFFC9A064, 0xFF1F4E8C, 0xFF14284A)[d])
    val inn = Color(listOf(0xFFEBD79E, 0xFF3A6EA5, 0xFF3E8E6E, 0xFF3A74C0, 0xFFD9A441)[d])
    r(16, 16, 288, 148, out)
    r(44, 32, 232, 116, inn)
    when (d) {
        0 -> {
            speckle(32, 32, 608, 328, 3000, 91, listOf(Color(0x22FFFFFF), Color(0x1A8A6A2A)))
            var y = 40; while (y < 148) { r(48, y, 224, 1, Color(0x0F8A6A2A)); y += 6 }
        }
        1 -> {
            speckle(32, 32, 608, 328, 2200, 92, listOf(Color(0x22FFFFFF), Color(0x22000000), Color(0x30A8E060)))
            var y = 16; while (y < 164) { r(16, y, 288, 1, Color(0x14000000)); y += 4 }
            speckle(88, 64, 552, 296, 900, 93, listOf(Color(0x14FFFFFF), Color(0x14000000)))
        }
        2 -> {
            var x = 16; while (x < 304) { r(x, 16, 1, 148, Color(0x1F000000)); x += 6 }
            speckle(32, 32, 608, 328, 1800, 94, listOf(Color(0x14FFFFFF), Color(0x1A3A1A00)))
        }
        3 -> {
            var y = 16; while (y < 164) { r(16, y, 288, 1, Color(0x14000000)); y += 4 }
            disc(160, 55, 14, Color(0x22FFFFFF)); disc(160, 305, 14, Color(0x22FFFFFF))
        }
        else -> {
            r(16, 16, 288, 2, Color(0x88FFD24A)); r(16, 162, 288, 2, Color(0x88FFD24A))
            var x = 44; while (x < 276) { r(x, 32, 1, 116, Color(0x14000000)); x += 6 }
            disc(160, 90, 12, Color(0x33FFFFFF))
        }
    }
    val w = if (d == 0) Color(0xFF2E7DD1) else LW
    r(44, 32, 232, 1, w); r(44, 147, 232, 1, w); r(44, 32, 1, 116, w); r(275, 32, 1, 116, w)
    r(121, 32, 1, 116, w); r(199, 32, 1, 116, w)
    r(38, 32, 6, 1, w); r(38, 147, 6, 1, w); r(276, 32, 6, 1, w); r(276, 147, 6, 1, w)
}

// ───────────────────────── points d'entrée ─────────────────────────

internal fun Px.paintStatic(sport: Sport, division: Int) {
    val d = division.coerceIn(0, 4)
    when (sport) {
        Sport.FOOT -> { footDecor(d); footField(d) }
        Sport.BASKET -> { basketDecor(d); basketCourt(d) }
        Sport.VOLLEY -> { volleyDecor(d); volleyCourt(d) }
    }
}

/** Partie animée du décor : flashs d'appareils photo, vagues, feux d'artifice, bandeau LED. */
internal fun Px.drawLive(m: Match, tick: Int) {
    val d = m.level.division.coerceIn(0, 4)
    val sp = m.sport
    val arenaLike = (sp == Sport.FOOT && d >= 1) || (sp == Sport.BASKET && d >= 2) || (sp == Sport.VOLLEY && d >= 3)
    if (arenaLike) {
        for (i in 0 until 7) {
            val s = nz(tick / 5, i, 9)
            if (s % 4 == 0) {
                val top = s % 2 == 0
                h(6 + (s / 3) % 628, if (top) 3 + (s / 11) % 18 else 340 + (s / 11) % 16, 2, 2, Color(0xE6FFFFFF))
            }
        }
        val bx = 34 + (tick * 2) % 560
        h(bx, 25, 16, 6, Color(0x38FFFFFF))
        h(34 + (tick * 2 + 280) % 560, 329, 16, 6, Color(0x38FFFFFF))
    }
    if (sp == Sport.VOLLEY && d == 0) {
        for (i in 0 until 40) {
            val x = ((i * 16 + tick / 2) % 640)
            h(x, 22 + (i + tick / 12) % 3, 8, 1, Color(0x99FFFFFF))
        }
    }
    if (sp == Sport.FOOT && d == 4) {
        val cols = listOf(0xFFFFC83D, 0xFFFF5A8A, 0xFF4CD9FF)
        for (b in 0 until 2) {
            val t = (tick + b * 47) % 94
            if (t < 56) {
                val rad = t / 4f
                val cx = if (b == 0) 70f else 250f
                val a = (1f - t / 56f)
                ring(cx, 9f, rad, Color(cols[b]).copy(alpha = a))
                if (rad > 4f) ring(cx, 9f, rad - 3f, Color(cols[b + 1]).copy(alpha = a * 0.7f))
            }
        }
    }
    if (sp == Sport.BASKET && d == 4) {
        for (i in 0 until 10) {
            val s = nz(i, tick / 20, 13)
            h(10 + s % 620, 2 + ((s / 5 + tick) % 20), 2, 2, Color(listOf(0xFFFFC83D, 0xFFFFFFFF, 0xFFFF5A8A)[s % 3]))
        }
    }
}
