package com.nexus.gamelibrary

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * Rendu haute définition : les joueurs, ballons et effets sont dessinés sur une grille
 * 2 fois plus fine que le terrain (demi-pixels), soit 4 fois plus de pixels par sprite.
 */

internal fun Px.h(x: Int, y: Int, w: Int, hh: Int, c: Color) = r(x / 2f, y / 2f, w / 2f, hh / 2f, c)

internal class Look(
    val skin: Color, val skinSh: Color, val hair: Color, val hairHi: Color, val hairStyle: Int,
    val jersey: Color, val jerseyDark: Color, val stripe: Color, val pattern: Int,
    val shorts: Color, val sock: Color, val sleeve: Color, val number: Int, val accessory: Int
)

private val oppKitsHd = listOf(0xFFE23B3B, 0xFFFF8A00, 0xFF9A3BE2, 0xFF16A085, 0xFFD4AF37)
private val oppKitsDarkHd = listOf(0xFFA82424, 0xFFC26A00, 0xFF7026A8, 0xFF0E7A64, 0xFFA88A1E)
private val Ink = Color(0xFF14141C)

internal fun skinLook(s: Skin): Look {
    val k = Cosmetics.kitColors[s.kitColor]
    val k2 = Cosmetics.kitColors[s.kit2Color]
    val sh = Cosmetics.kitColors[s.shortsColor]
    val hc = Cosmetics.hairColors[s.hairColor]
    val st = Cosmetics.skinTones[s.skinTone]
    return Look(
        Color(st.color), Color(st.color2), Color(hc.color), Color(hc.color2), s.hairStyle,
        Color(k.color), Color(k.color2), Color(k2.color), s.kitPattern,
        Color(sh.color), Color(k.color), Color(k.color), s.number, s.accessory
    )
}

/** Apparence d'un joueur du match (toi : ton skin ; coéquipiers : même maillot ; adversaires : couleurs de la division). */
private fun lookOf(m: Match, p: Player, skin: Skin): Look {
    val keeper = m.sport == Sport.FOOT && p.slot == 0
    val mateHair = Cosmetics.hairColors
    if (p.team == 0) {
        val base = skinLook(skin)
        val me = p.slot == 1
        val hs = if (me) skin.hairStyle else (p.slot + 1) % 3
        val hcI = if (me) skin.hairColor else (p.slot * 2 + 1) % 4
        val skI = if (me) skin.skinTone else (p.slot * 2 + 1) % 4
        val sk = Cosmetics.skinTones[skI]
        val hc = mateHair[hcI]
        val jersey = if (keeper) Color(0xFFFFB300) else base.jersey
        val dark = if (keeper) Color(0xFFC98400) else base.jerseyDark
        return Look(
            Color(sk.color), Color(sk.color2), Color(hc.color), Color(hc.color2), hs,
            jersey, dark, if (keeper) Color(0xFFFFD66B) else base.stripe, if (keeper) 0 else skin.kitPattern,
            if (keeper) Ink else base.shorts, if (m.sport == Sport.BASKET) Color(0xFFF2F2F2) else jersey,
            if (keeper) Color.White else if (m.sport == Sport.BASKET) Color(sk.color) else jersey,
            if (me) skin.number else (p.slot * 7 + 3) % 99, if (me) skin.accessory else 0
        )
    }
    val d = m.level.division.coerceIn(0, 4)
    val sk = Cosmetics.skinTones[(p.slot * 2 + 3) % 4]
    val hc = mateHair[(p.slot + 2) % 4]
    val jersey = if (keeper) Color(0xFF3DDC84) else Color(oppKitsHd[d])
    val dark = if (keeper) Color(0xFF22A35E) else Color(oppKitsDarkHd[d])
    return Look(
        Color(sk.color), Color(sk.color2), Color(hc.color), Color(hc.color2), (p.slot + 2) % 3,
        jersey, dark, Color(0xFFF4F4F8), 0, if (keeper) Ink else Color(0xFF2B2B33),
        if (m.sport == Sport.BASKET) Color(0xFFF2F2F2) else jersey,
        if (keeper) Color.White else if (m.sport == Sport.BASKET) Color(sk.color) else jersey, (p.slot * 5 + 4) % 99, 0
    )
}

private val digits = listOf(
    "111101101101111", "010110010010111", "111001111100111", "111001111001111", "101101111001001",
    "111100111001111", "111100111101111", "111001001001001", "111101111101111", "111101111001111"
)

private fun lum(c: Color) = 0.3f * c.red + 0.59f * c.green + 0.11f * c.blue

private fun dk(c: Color, f: Float) = Color((c.red * f).coerceIn(0f, 1f), (c.green * f).coerceIn(0f, 1f), (c.blue * f).coerceIn(0f, 1f), 1f)

private fun mix(a: Color, b: Color, t: Float) =
    Color(a.red + (b.red - a.red) * t, a.green + (b.green - a.green) * t, a.blue + (b.blue - a.blue) * t, 1f)

// Tampon du sprite (demi-pixels) : on dessine tout dedans, puis contour + ombrage automatiques.
private const val BW = 40
private const val BH = 62
private const val BCX = 20
private const val BBASE = 56
private val buf = IntArray(BW * BH)

private class Spr(val sg: Int) {
    fun box(dx: Int, y: Int, w: Int, hh: Int, c: Color) {
        val ci = c.toArgb() or (0xFF shl 24)
        val x0 = if (sg > 0) BCX + dx else BCX - dx - w
        for (j in 0 until hh) for (i in 0 until w) {
            val xx = x0 + i
            val yy = BBASE + y + j
            if (xx in 0 until BW && yy in 0 until BH) buf[yy * BW + xx] = ci
        }
    }

    fun number(n: Int, y: Int, c: Color) {
        val s = n.coerceIn(0, 99).toString()
        var x0 = -(s.length * 4 - 1) / 2
        for (ch in s) {
            val g = digits[ch - '0']
            for (j in 0 until 5) for (i in 0 until 3) if (g[j * 3 + i] == '1') box(x0 + i, y + j, 1, 1, c)
            x0 += 4
        }
    }
}

private fun shadeInt(v: Int, f: Float): Int {
    val r = (((v shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
    val g = (((v shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
    val b = ((v and 0xFF) * f).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
}

/** Envoie le tampon à l'écran : contour noir, lumière en haut à gauche, ombre en bas à droite. */
private fun Px.flush(cx: Int, base: Int) {
    val ox = cx - BCX
    val oy = base - BBASE
    fun at(i: Int, j: Int) = if (i in 0 until BW && j in 0 until BH) buf[j * BW + i] else 0
    val outline = Color(0xE6101018)
    for (j in 0 until BH) for (i in 0 until BW) {
        if (buf[j * BW + i] != 0) continue
        if (at(i - 1, j) != 0 || at(i + 1, j) != 0 || at(i, j - 1) != 0 || at(i, j + 1) != 0) h(ox + i, oy + j, 1, 1, outline)
    }
    for (j in 0 until BH) {
        var i = 0
        while (i < BW) {
            val v = buf[j * BW + i]
            if (v == 0) { i++; continue }
            fun sh(k: Int): Int {
                val c = buf[j * BW + k]
                return when {
                    at(k, j - 1) == 0 || at(k - 1, j) == 0 -> shadeInt(c, 1.14f)
                    at(k + 1, j) == 0 || at(k, j + 1) == 0 -> shadeInt(c, 0.8f)
                    else -> c
                }
            }
            val c0 = sh(i)
            var k = i + 1
            while (k < BW && buf[j * BW + k] != 0 && sh(k) == c0) k++
            h(ox + i, oy + j, k - i, 1, Color(c0))
            i = k
        }
    }
}

/** Dessine un joueur en haute définition (style « chibi » détaillé). (px, py) = pieds en unités du terrain. */
internal fun Px.drawLook(
    px: Float, py: Float, lk: Look, fx: Float, fy: Float, step: Int, lift: Int, armsUp: Boolean = false, kind: Int = 0, keeper: Boolean = false
) {
    java.util.Arrays.fill(buf, 0)
    val cx = (px * 2f).roundToInt()
    val base = (py * 2f).roundToInt() - lift * 2
    val side = abs(fy) <= abs(fx) + 0.05f
    val back = !side && fy < 0f
    val sg = if (side && fx < 0f) -1 else 1
    val s = Spr(sg)
    val shoe = Color(0xFFF4F4F8)
    val sole = Color(0xFF3A3A46)
    val gold = Color(0xFFFFD24A)
    val mouth = Color(0xFF9A3A3A)
    val white = Color.White
    val hairD = dk(lk.hair, 0.7f)
    val blush = mix(lk.skin, Color(0xFFFF6A6A), 0.35f)
    with(s) {
        val lo = if (step == 1) 2 else 0
        val ro = if (step == 2) 2 else 0

        // ── jambes, chaussettes, chaussures
        if (!side) {
            box(-4, -10, 3, 1, lk.skin); box(1, -10, 3, 1, lk.skin)
            box(-4, -9, 3, 6 - lo, lk.sock); box(1, -9, 3, 6 - ro, lk.sock)
            box(-4, -9, 3, 1, lk.stripe); box(1, -9, 3, 1, lk.stripe)
            box(-5, -3 - lo, 4, 3, shoe); box(1, -3 - ro, 4, 3, shoe)
            box(-5, -1 - lo, 4, 1, sole); box(1, -1 - ro, 4, 1, sole)
            box(-4, -3 - lo, 2, 1, lk.stripe); box(2, -3 - ro, 2, 1, lk.stripe)
        } else {
            val a = if (step == 1) -4 else if (step == 2) 1 else -2
            val b = if (step == 1) 1 else if (step == 2) -4 else -1
            for (x in intArrayOf(a, b)) {
                box(x, -10, 3, 1, lk.skin); box(x, -9, 3, 6, lk.sock); box(x, -9, 3, 1, lk.stripe)
                box(x, -3, 5, 3, shoe); box(x, -1, 5, 1, sole); box(x + 2, -3, 2, 1, lk.stripe)
            }
        }

        // ── cheveux placés derrière la tête
        when (lk.hairStyle) {
            1 -> if (!side) { box(-6, -41, 2, 13, lk.hair); box(4, -41, 2, 13, lk.hair) } else box(-6, -41, 4, 13, lk.hair)
            3 -> if (!side) { box(5, -40, 2, 8, lk.hair); box(6, -33, 1, 3, lk.hair) } else box(-8, -40, 3, 8, lk.hair)
            5 -> box(-8, -50, 16, 13, lk.hair)
        }

        // ── short + maillot
        val wS = if (side) 8 else 12
        val left = -wS / 2
        box(if (side) -4 else -6, -17, if (side) 8 else 12, 7, lk.shorts)
        box(if (side) -4 else -6, -17, if (side) 8 else 12, 1, dk(lk.shorts, 0.8f))
        if (!side) {
            box(-6, -17, 1, 7, lk.stripe); box(5, -17, 1, 7, lk.stripe); box(0, -12, 1, 2, dk(lk.shorts, 0.6f))
        } else box(-1, -17, 2, 7, dk(lk.shorts, 0.9f))
        box(left, -29, wS, 12, lk.jersey)
        box(left, -18, wS, 1, lk.jerseyDark)
        when (lk.pattern) {
            1 -> { var x = left + 2; while (x < left + wS - 1) { box(x, -29, 2, 11, lk.stripe); x += 4 } }
            2 -> box(left, -24, wS, 3, lk.stripe)
            3 -> box(left, -29, wS / 2, 11, lk.stripe)
            4 -> for (yy in 0 until 5) for (xx in 0 until wS / 2) if ((xx + yy) % 2 == 0) box(left + xx * 2, -29 + yy * 2, 2, 2, lk.stripe)
        }
        // col
        if (back) box(-2, -29, 4, 1, dk(lk.jersey, 0.8f))
        else if (!side) { box(-2, -29, 4, 1, lk.skin); box(-1, -28, 2, 1, lk.skin); box(-3, -29, 1, 1, lk.stripe); box(2, -29, 1, 1, lk.stripe) }
        else box(-1, -29, 3, 1, lk.skin)
        // écusson / numéro
        if (back) number(lk.number, -26, if (lum(lk.jersey) > 0.6f) Ink else white)
        else if (!side) { box(left + 2, -25, 2, 2, lk.stripe); box(left + 2, -25, 1, 1, white) }

        // ── bras
        if (!side) {
            val la = if (step == 1) 2 else 0
            val ra = if (step == 2) 2 else 0
            if (armsUp) {
                box(-8, -29, 2, 3, lk.sleeve); box(6, -29, 2, 3, lk.sleeve)
                box(-9, -37, 2, 9, lk.skin); box(7, -37, 2, 9, lk.skin)
                box(-9, -39, 2, 2, lk.skin); box(7, -39, 2, 2, lk.skin)
            } else {
                box(-8, -29, 2, 6, lk.sleeve); box(6, -29, 2, 6, lk.sleeve)
                box(-8, -23 + la, 2, 5, lk.skin); box(6, -23 + ra, 2, 5, lk.skin)
                box(-8, -19 + la, 2, 2, lk.skinSh); box(6, -19 + ra, 2, 2, lk.skinSh)
                if (lk.accessory == 3) box(-8, -26, 2, 2, gold)
            }
        } else {
            val sw = if (step == 1) -2 else if (step == 2) 2 else 0
            if (armsUp) {
                box(0, -29, 3, 3, lk.sleeve); box(1, -37, 2, 9, lk.skin); box(1, -39, 2, 2, lk.skin)
            } else {
                box(-1 + sw, -29, 3, 6, lk.sleeve); box(-1 + sw, -23, 2, 5, lk.skin); box(-1 + sw, -19, 2, 2, lk.skinSh)
                if (lk.accessory == 3) box(-1 + sw, -26, 3, 2, gold)
            }
        }

        // ── cou + tête
        box(-2, -31, 4, 2, lk.skinSh)
        box(-5, -42, 10, 11, lk.skin)
        if (!side) { box(-6, -38, 1, 3, lk.skinSh); box(5, -38, 1, 3, lk.skinSh) }
        else { box(-5, -38, 2, 3, lk.skinSh); box(5, -37, 1, 2, lk.skinSh) }

        // ── cheveux dessus / devant
        if (back) {
            if (lk.hairStyle == 2) box(-5, -43, 10, 3, hairD)
            else { box(-5, -44, 10, 13, lk.hair); box(-3, -43, 4, 1, lk.hairHi); box(0, -40, 1, 6, hairD) }
            if (lk.hairStyle == 4) { box(-1, -49, 2, 6, lk.hair); box(-1, -49, 1, 3, lk.hairHi) }
        } else {
            when (lk.hairStyle) {
                2 -> { box(-4, -43, 8, 1, hairD); box(-2, -43, 2, 1, white) }
                4 -> { box(-5, -43, 10, 2, hairD); box(-1, -49, 2, 7, lk.hair); box(-1, -49, 1, 4, lk.hairHi) }
                else -> {
                    box(-5, -44, 10, 4, lk.hair)
                    if (!side) { box(-5, -40, 1, 3, lk.hair); box(4, -40, 1, 3, lk.hair); box(0, -43, 1, 2, hairD) }
                    else box(-5, -40, 3, 6, lk.hair)
                    box(-3, -44, 4, 1, lk.hairHi); box(1, -43, 2, 1, lk.hairHi)
                    if (lk.hairStyle == 5) { box(-5, -48, 2, 1, lk.hairHi); box(2, -47, 2, 1, lk.hairHi); box(-1, -46, 2, 1, lk.hairHi) }
                    if (lk.hairStyle == 3) box(if (side) -8 else 5, -40, 2, 1, lk.stripe)
                }
            }
            // visage
            if (!side) {
                box(-4, -40, 3, 1, hairD); box(1, -40, 3, 1, hairD)
                box(-4, -38, 3, 2, white); box(1, -38, 3, 2, white)
                box(-3, -38, 2, 2, Ink); box(2, -38, 2, 2, Ink)
                box(-3, -38, 1, 1, Color(0xFF8FB8FF)); box(2, -38, 1, 1, Color(0xFF8FB8FF))
                box(0, -36, 1, 1, lk.skinSh)
                box(-4, -35, 1, 1, blush); box(3, -35, 1, 1, blush)
                box(-1, -33, 3, 1, mouth); box(-2, -34, 1, 1, mouth); box(2, -34, 1, 1, mouth)
            } else {
                box(1, -40, 4, 1, hairD)
                box(2, -38, 3, 2, white); box(3, -38, 2, 2, Ink); box(3, -38, 1, 1, Color(0xFF8FB8FF))
                box(5, -37, 1, 2, lk.skinSh)
                box(0, -35, 1, 1, blush)
                box(3, -33, 3, 1, mouth)
            }
        }

        // ── accessoires
        when (lk.accessory) {
            1 -> { box(-5, -42, 10, 2, lk.stripe); box(-5, -42, 10, 1, dk(lk.stripe, 0.8f)); if (side) box(-7, -42, 2, 3, lk.stripe) }
            2 -> if (!back) {
                if (!side) { box(-5, -38, 10, 3, Ink); box(-4, -38, 3, 1, Color(0xFF7FD6FF)); box(1, -38, 3, 1, Color(0xFF7FD6FF)) }
                else { box(-5, -38, 11, 1, Ink); box(1, -38, 5, 3, Ink); box(2, -38, 3, 1, Color(0xFF7FD6FF)) }
            }
            4 -> {
                box(-6, -47, 12, 5, lk.jersey); box(-6, -43, 12, 1, lk.jerseyDark); box(-5, -47, 6, 1, dk(lk.jersey, 1.2f))
                if (!back) { if (side) box(5, -42, 5, 2, lk.jerseyDark) else box(-6, -42, 12, 2, lk.jerseyDark) }
            }
            5 -> {
                box(-5, -48, 10, 3, gold); box(-5, -51, 2, 3, gold); box(-1, -52, 2, 4, gold); box(3, -51, 2, 3, gold)
                box(-5, -48, 10, 1, Color(0xFFFFF2B0)); box(-1, -47, 2, 1, Color(0xFFFF4A6A))
            }
        }

        // ── détails supplémentaires : plis, poignets, marque, oreilles, dents, protections, crampons, gants
        val fold = dk(lk.jersey, 0.86f)
        box(left + 1, -23, 1, 4, fold); box(left + wS - 3, -27, 1, 5, fold)
        if (!back) {
            box(left + wS - 4, -26, 2, 1, white)
            if (!side) {
                box(-8, -24, 2, 1, lk.stripe); box(6, -24, 2, 1, lk.stripe)
                box(-6, -37, 1, 1, dk(lk.skin, 0.8f)); box(5, -37, 1, 1, dk(lk.skin, 0.8f))
                box(0, -37, 1, 1, mix(lk.skin, white, 0.4f))
                box(0, -33, 1, 1, white)
                box(-1, -16, 2, 1, white)
                box(-4, -39, 3, 1, dk(lk.skin, 0.85f)); box(1, -39, 3, 1, dk(lk.skin, 0.85f))
            }
        }
        if (!side) { box(-4, -7, 3, 1, lk.stripe); box(1, -7, 3, 1, lk.stripe) }
        when (kind) {
            0 -> if (!keeper && !side) {
                box(-4, -6, 3, 3, Color(0xFFE6E6EE)); box(1, -6, 3, 3, Color(0xFFE6E6EE))
                box(-4, -lo, 1, 1, sole); box(-1, -lo, 1, 1, sole); box(2, -ro, 1, 1, sole); box(4, -ro, 1, 1, sole)
            }
            1 -> if (!side) {
                box(-4, -4 - lo, 3, 1, lk.stripe); box(1, -4 - ro, 3, 1, lk.stripe)
                box(-8, -21, 2, 1, white); box(6, -21, 2, 1, white)
            }
            2 -> if (!side) { box(-4, -6, 3, 2, Color(0xFF2E2E3A)); box(1, -6, 3, 2, Color(0xFF2E2E3A)) }
        }
        if (keeper) {
            val gl = Color(0xFFFF8A3D)
            val gl2 = Color(0xFFFFB27A)
            if (armsUp) {
                if (!side) { box(-10, -41, 3, 3, gl); box(7, -41, 3, 3, gl) } else box(1, -41, 3, 3, gl)
            } else if (!side) {
                box(-9, -22, 3, 4, gl); box(6, -22, 3, 4, gl); box(-9, -22, 3, 1, gl2); box(6, -22, 3, 1, gl2)
            } else box(-1, -22, 3, 4, gl)
        }
    }
    flush(cx, base)
}

internal fun Px.drawPlayerHi(m: Match, p: Player, tick: Int, isCtrl: Boolean, skin: Skin) {
    val lk = lookOf(m, p, skin)
    val px = p.x.roundToInt()
    val py = p.y.roundToInt()
    r(px - 5, py - 1, 10, 3, Color.Black.copy(alpha = 0.28f))
    if (isCtrl) {
        val ringCol = Gold.copy(alpha = 0.9f)
        r(px - 6, py, 12, 1, ringCol)
        r(px - 5, py + 1, 10, 1, ringCol)
        r(px - 5, py - 1, 1, 1, ringCol); r(px + 4, py - 1, 1, 1, ringCol)
    }
    val lift = if (p.jumpT > 0f) (sin(min(1f, p.jumpT / 0.45f) * 3.14159f) * 7f).roundToInt() else 0
    val step = if (p.runT > 0f) 1 + (p.runT.toInt() and 1) else 0
    val keeper = m.sport == Sport.FOOT && p.slot == 0
    val sliding = p.tackT > 0f
    var dvy = 0
    if (keeper && p.diveT > 0f) {
        val k = sin(min(1f, p.diveT / 0.45f) * 3.14159f)
        dvy = (p.diveDir * k * 7f).roundToInt()
    }
    val oy = dvy + (if (sliding) 4 else 0)
    drawLook(p.x, p.y + oy, lk, p.fx, p.fy, step, lift, (keeper && p.diveT > 0f) || p.jumpT > 0f || p.windT > 0f,
        when (m.sport) { Sport.FOOT -> 0; Sport.BASKET -> 1; Sport.VOLLEY -> 2 }, keeper)
    if (sliding) {
        val ddx = -(p.tdx * 7f).roundToInt()
        val ddy = -(p.tdy * 5f).roundToInt()
        r(px + ddx - 2, py + ddy - 2, 3, 2, Color(0xAAE8D9B0))
        r(px + ddx * 2 - 1, py + ddy * 2 - 1, 2, 2, Color(0x88E8D9B0))
    }
    if (p.actT > 0f) {
        r(px + (p.fx * 9f).roundToInt() - 1, py - 7 + (p.fy * 6f).roundToInt() - lift, 3, 3, Color.White.copy(alpha = 0.75f))
    }
    if (isCtrl) drawMarker(px, py - 28 - lift - (if (lk.accessory == 5) 4 else if (lk.hairStyle == 5 || lk.hairStyle == 4) 3 else 0), tick, skin.marker)
}

/** Marqueur au-dessus du joueur piloté (cosmétique). */
internal fun Px.drawMarker(px: Int, y: Int, tick: Int, type: Int) {
    val bob = if ((tick / 10) % 2 == 0) 0 else 1
    val cx = px * 2
    val by = (y + bob) * 2
    val col = when (type) {
        1 -> Color(0xFF35F0FF); 2 -> Color(0xFFFF5FB0); 3 -> Color(0xFF7FE8FF); 4 -> Color(0xFFFFE04A)
        5 -> Color(0xFFFFD24A); else -> Gold
    }
    when (type) {
        3 -> { h(cx - 1, by, 2, 2, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 1, by + 4, 2, 2, col) }
        4 -> { h(cx - 1, by, 2, 6, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 2, by + 1, 4, 4, col.copy(alpha = 0.6f)) }
        5 -> { h(cx - 4, by + 2, 8, 3, col); h(cx - 4, by, 2, 2, col); h(cx - 1, by - 1, 2, 3, col); h(cx + 2, by, 2, 2, col) }
        else -> { h(cx - 4, by, 8, 2, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 1, by + 4, 2, 2, col); h(cx - 2, by + 2, 4, 1, Color.White.copy(alpha = 0.4f)) }
    }
}

private fun hash(i: Int, j: Int, s: Int): Int = lcg(i * 73856093 xor j * 19349663 xor s * 83492791)

private fun ballColor(sport: Sport, skinIdx: Int, i: Int, j: Int, spin: Float): Color {
    val dx = i - 6.5f
    val dy = j - 6.5f
    val t = (dx + dy) / 13.6f // -0.5 (clair) .. +0.5 (ombre)
    val shade = when { t > 0.28f -> 2; t > -0.05f -> 1; else -> 0 }
    val skinOpt = Cosmetics.balls[skinIdx]
    val a = spin * 0.5f
    val ph = floor(abs(spin)).toInt() and 3
    // motif : true = zone d'accent (taches, bandes, coutures)
    val accent: Boolean = when (sport) {
        Sport.FOOT -> (0 until 3).any { k ->
            val ang = a + k * 2.0944f
            val cx = 6.5f + cos(ang) * 3.6f
            val cy = 6.5f + sin(ang) * 3.6f
            (i - cx) * (i - cx) + (j - cy) * (j - cy) < 3.4f
        } || (dx * dx + dy * dy < 2.2f && (ph and 1) == 0)
        Sport.VOLLEY -> ((j + (a * 2f).toInt() + 40) / 3) % 3 == 1
        Sport.BASKET -> (i == 6 || i == 7 || j == 6 || j == 7) || (((ph and 1) == 0) && abs(i - j) <= 0) || (((ph and 1) == 1) && abs(i + j - 13) <= 0)
    }
    if (skinIdx == 0) {
        return when (sport) {
            Sport.FOOT -> if (accent) Color(0xFF1B1B22) else listOf(Color(0xFFFFFFFF), Color(0xFFE4E7EE), Color(0xFFB9BFCC))[shade]
            Sport.VOLLEY -> {
                val band = ((j + (a * 2f).toInt() + 40) / 3) % 3
                when (band) {
                    1 -> listOf(Color(0xFFFFDC4A), Color(0xFFF2C230), Color(0xFFC49A1A))[shade]
                    2 -> listOf(Color(0xFF5A8CFF), Color(0xFF2F6BFF), Color(0xFF1E4ACF))[shade]
                    else -> listOf(Color(0xFFFFFFFF), Color(0xFFE4E7EE), Color(0xFFB9BFCC))[shade]
                }
            }
            Sport.BASKET -> if (accent) Color(0xFF3B1E0C) else listOf(Color(0xFFFF9140), Color(0xFFEE7A1F), Color(0xFFC95E10))[shade]
        }
    }
    if (skinIdx == 5) { // arc-en-ciel
        val hue = ((i + j) * 14f + spin * 25f) % 360f
        return Color.hsv(if (hue < 0) hue + 360f else hue, if (shade == 2) 0.9f else 0.7f, if (shade == 2) 0.75f else 1f)
    }
    val b = Color(skinOpt.color)
    val c = Color(skinOpt.color2)
    if (skinIdx == 3 && hash(i, j, 3) % 6 == 0) return c // galaxie : étoiles
    val lit = when (shade) { 0 -> 1.15f; 1 -> 1f; else -> 0.72f }
    val base = if (accent) c else b
    return Color(min(1f, base.red * lit), min(1f, base.green * lit), min(1f, base.blue * lit), 1f)
}

internal fun Px.drawBallHi(m: Match, skin: Skin) {
    val bz = m.bz
    val shw = max(6, 14 - (bz / 5f).toInt())
    val cx = (m.bx * 2f).roundToInt()
    r(cx / 2f - shw / 4f, m.by + 1f, shw / 2f, 1.5f, Color.Black.copy(alpha = 0.3f))
    val x0 = cx - 7
    val y0 = ((m.by - bz * 0.6f) * 2f).roundToInt() - 7
    for (j in 0 until 14) {
        for (i in 0 until 14) {
            val dx = i - 6.5f
            val dy = j - 6.5f
            if (dx * dx + dy * dy > 45f) continue
            val edge = dx * dx + dy * dy > 36f
            val c = ballColor(m.sport, skin.ball, i, j, m.ballSpin)
            h(x0 + i, y0 + j, 1, 1, if (edge) Color(c.red * 0.7f, c.green * 0.7f, c.blue * 0.7f, 1f) else c)
        }
    }
}

internal fun Px.drawTrail(m: Match, skin: Skin) {
    if (skin.trail == 0 || m.phase != Phase.PLAY) return
    for (i in 2 until m.trailX.size) {
        val tx = m.trailX[i]
        val ty = m.trailY[i] - m.trailZ[i] * 0.6f
        if (tx == 0f && ty == 0f) continue
        val d = abs(tx - m.bx) + abs(ty - (m.by - m.bz * 0.6f))
        if (d < 3f || d > 90f) continue
        val f = 1f - i / m.trailX.size.toFloat()
        val sz = max(2, (9 * f).roundToInt())
        val x = (tx * 2f).roundToInt()
        val y = (ty * 2f).roundToInt()
        when (skin.trail) {
            1 -> h(x - sz / 2, y - sz / 2, sz, sz, Color.White.copy(alpha = 0.55f * f))
            2 -> {
                val c = if (i % 2 == 0) Color(0xFFFFE04A) else Color.White
                h(x + ((hash(i, 1, tick(m)) % 9) - 4), y + ((hash(i, 2, tick(m)) % 9) - 4), 2, 2, c.copy(alpha = f))
            }
            3 -> h(x - sz / 2, y - sz / 2, sz, sz, Color(1f, 0.25f + 0.55f * f, 0.05f, 0.85f * f))
            else -> h(x - sz / 2, y - sz / 2, sz, sz, Color.hsv((i * 32f) % 360f, 0.85f, 1f).copy(alpha = 0.85f * f))
        }
    }
}

private fun tick(m: Match) = (m.simTime * 30f).toInt()

internal fun Px.drawConfetti(m: Match) {
    if (m.phase != Phase.SCORED) return
    val age = m.scoredAge
    val cols = listOf(0xFFFFC83D, 0xFF3DDC84, 0xFF2F6BFF, 0xFFFF5A4A, 0xFFFF5FB0, 0xFFFFFFFF)
    for (i in 0 until 46) {
        val hh = hash(i, 7, 5)
        val x = (hh % 320) + sin(age * 3f + i) * 6f
        val y = -8f + age * (50f + (hh / 7) % 70) - ((hh / 13) % 30)
        if (y < 0f || y > 180f) continue
        h((x * 2f).roundToInt(), (y * 2f).roundToInt(), 3, 3, Color(cols[hh % cols.size]))
    }
}

/** Repère au sol de l'endroit où le ballon va tomber (volley). */
internal fun Px.drawLanding(m: Match, tick: Int) {
    if (m.sport != Sport.VOLLEY || m.phase != Phase.PLAY || m.serveHeld() || m.bz < 4f) return
    val l = m.landing()
    if (l[0] < Court.VX0 - 10f || l[0] > Court.NET_X + 2f) return
    val pulse = 5f + (tick / 6 % 3)
    ring(l[0], l[1], pulse, Color(0xCCFFFFFF))
    ring(l[0], l[1], pulse - 2f, Color(0x88FFC83D))
    h((l[0] * 2f).roundToInt() - 1, (l[1] * 2f).roundToInt() - 1, 2, 2, Color(0xFFFFC83D))
}

/** Ballon dessiné seul (aperçu du skin) : (cx, cy) = centre en unités du terrain. */
internal fun Px.drawBallRaw(cx: Float, cy: Float, sport: Sport, skinIdx: Int, spin: Float) {
    val x0 = (cx * 2f).roundToInt() - 7
    val y0 = (cy * 2f).roundToInt() - 7
    for (j in 0 until 14) for (i in 0 until 14) {
        val dx = i - 6.5f
        val dy = j - 6.5f
        if (dx * dx + dy * dy > 45f) continue
        val c = ballColor(sport, skinIdx, i, j, spin)
        h(x0 + i, y0 + j, 1, 1, if (dx * dx + dy * dy > 36f) Color(c.red * 0.7f, c.green * 0.7f, c.blue * 0.7f, 1f) else c)
    }
}

/** Aperçu de la traînée : le ballon va vers la droite. */
internal fun Px.drawTrailPreview(cx: Float, cy: Float, trail: Int, tick: Int) {
    if (trail == 0) return
    for (i in 2 until 12) {
        val f = 1f - i / 12f
        val sz = max(2, (9 * f).roundToInt())
        val x = ((cx - i * 2.2f) * 2f).roundToInt()
        val y = (cy * 2f).roundToInt()
        when (trail) {
            1 -> h(x - sz / 2, y - sz / 2, sz, sz, Color.White.copy(alpha = 0.55f * f))
            2 -> h(x + ((hash(i, 1, tick / 4) % 7) - 3), y + ((hash(i, 2, tick / 4) % 9) - 4), 2, 2,
                (if (i % 2 == 0) Color(0xFFFFE04A) else Color.White).copy(alpha = f))
            3 -> h(x - sz / 2, y - sz / 2, sz, sz, Color(1f, 0.25f + 0.55f * f, 0.05f, 0.85f * f))
            else -> h(x - sz / 2, y - sz / 2, sz, sz, Color.hsv((i * 32f) % 360f, 0.85f, 1f).copy(alpha = 0.85f * f))
        }
    }
}
