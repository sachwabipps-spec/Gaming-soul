package com.nexus.gamelibrary

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/*
 * Moteur du mini-jeu « Arcade » (volley / foot / basket en pixel art).
 * Kotlin pur : aucune dépendance Android, tout fonctionne hors ligne.
 * Le monde fait 160 x 90 « pixels » ; l'écran les agrandit.
 */

enum class Sport(val label: String, val icon: String, val actionLabel: String) {
    VOLLEY("Volley", "🏐", "SMASH"),
    FOOT("Foot", "⚽", "TIR"),
    BASKET("Basket", "🏀", "TIR")
}

data class Level(
    val index: Int,
    val division: Int,
    val divisionName: String,
    val sport: Sport,
    val opponent: String,
    val ai: Float,
    /** volley : points à atteindre ; foot / basket : durée du match en secondes */
    val target: Int,
    val margin2: Int,
    val margin3: Int
) {
    val title: String get() = "${sport.label} · vs $opponent"
    val rule: String
        get() = when (sport) {
            Sport.VOLLEY -> "Premier à $target points"
            Sport.FOOT -> "$target s · plus de buts"
            Sport.BASKET -> "$target s · plus de points"
        }
}

object Career {
    val divisions = listOf("Quartier", "Ville", "Région", "Pro", "Légende")

    private val opponents = listOf(
        "Rookie", "Titou", "Léa",
        "Maxou", "Inès", "Dragon",
        "Sam", "Nova", "Bastien",
        "Zoé", "Titan", "Kenji",
        "Mia", "Atlas", "Le Roi Pixel"
    )

    private val baseAi = floatArrayOf(0.12f, 0.30f, 0.48f, 0.66f, 0.82f)
    private val sports = Sport.values()

    val levels: List<Level> = List(15) { i ->
        val div = i / 3
        val k = i % 3
        val sport = sports[(div + k) % 3]
        val ai = min(0.95f, baseAi[div] + 0.05f * k)
        val (target, m2, m3) = when (sport) {
            Sport.VOLLEY -> Triple(if (div < 3) 5 else 7, 2, 4)
            Sport.FOOT -> Triple(60, 2, 3)
            Sport.BASKET -> Triple(60, 6, 14)
        }
        Level(i, div, divisions[div], sport, opponents[i], ai, target, m2, m3)
    }
}

/** Touches du joueur : le moteur lit ces valeurs à chaque pas. */
class ArcadeInput {
    @Volatile var move = 0f
    @Volatile var jump = false
    @Volatile var action = false
    @Volatile var jumpLatch = false
    @Volatile var actionLatch = false
}

class Cmd {
    var move = 0f
    var jump = false
    var action = false
}

object Court {
    const val W = 160f
    const val H = 90f
    const val GROUND = 76f
    const val NET_X = 80f
    const val NET_TOP = 50f
    const val GOAL_H = 26f
    const val GOAL_D = 9f
    const val HOOP_F = 18f
    const val RIM_Y = 38f
    const val BALL_R = 3.5f
    const val PW = 9f
    const val PH = 15f
}

class Body(val side: Int) {
    var x = 0f
    var y = Court.GROUND
    var vx = 0f
    var vy = 0f
    var onGround = true
    var face = 1
    var cool = 0f
    var hitT = 0f
    var runT = 0f
    val atk: Int get() = if (side == 0) 1 else -1
    val cmd = Cmd()
    var aiT = 0f
    var aiHit = false
    var tx = 0f
}

enum class Phase { INTRO, PLAY, SCORED, OVER }

data class Hud(
    val scoreA: Int,
    val scoreB: Int,
    val seconds: Int,
    val message: String,
    val overtime: Boolean,
    val over: Boolean
)

class Match(
    val level: Level,
    /** Si non nul, le joueur de gauche est piloté par l'IA (tests). */
    private val autoLeft: Float? = null,
    seed: Long = System.nanoTime()
) {
    val sport = level.sport
    private val rnd = Random(seed)
    val b = arrayOf(Body(0), Body(1))
    val input = ArcadeInput()

    var ballX = 80f
    var ballY = 30f
    var ballVx = 0f
    var ballVy = 0f
    var ballSpin = 0f
    private var prevY = 30f

    val score = intArrayOf(0, 0)
    var timeLeft = level.target.toFloat()
    var overtime = false
    var phase = Phase.INTRO
    private var phaseT = 1.8f
    private var pendingOver = false
    var message = ""
    private var messageT = 0f
    var won = false
    var simTime = 0f
    private var shotBy = -1
    private var shotDist = 0f

    /** Sons à jouer : 1 = frappe, 2 = point, 3 = victoire, 4 = défaite. */
    val sfx = ArrayDeque<Int>()

    init {
        setMessage("${level.sport.label} · vs ${level.opponent}", 1.8f)
        resetPositions(0)
    }

    fun hud(): Hud = Hud(
        score[0], score[1],
        if (sport == Sport.VOLLEY) -1 else max(0, timeLeft.toInt() + if (timeLeft > timeLeft.toInt()) 1 else 0),
        message, overtime, phase == Phase.OVER
    )

    fun stars(): Int {
        if (!won) return 0
        val diff = score[0] - score[1]
        return 1 + (if (diff >= level.margin2) 1 else 0) + (if (diff >= level.margin3) 1 else 0)
    }

    private fun setMessage(m: String, t: Float) {
        message = m
        messageT = t
    }

    private fun aiLevel(i: Int): Float = if (i == 0) (autoLeft ?: -1f) else level.ai
    private fun isAi(i: Int) = i == 1 || autoLeft != null

    private fun resetPositions(serve: Int) {
        val off = if (sport == Sport.VOLLEY) 38f else 48f
        b[0].x = Court.NET_X - off
        b[1].x = Court.NET_X + off
        for (p in b) {
            p.y = Court.GROUND; p.vx = 0f; p.vy = 0f; p.onGround = true; p.cool = 0f; p.hitT = 0f
            p.face = p.atk
            p.aiT = 0f; p.aiHit = false
            p.cmd.move = 0f; p.cmd.jump = false; p.cmd.action = false
        }
        if (sport == Sport.VOLLEY) {
            ballX = if (serve == 0) Court.NET_X - 38f else Court.NET_X + 38f
            ballY = 28f
        } else {
            // le ballon retombe côté de l'équipe qui vient d'encaisser
            ballX = Court.W / 2f + (if (serve == 0) -1f else 1f) * 20f
            ballY = 26f
        }
        ballVx = 0f; ballVy = 0f
        prevY = ballY
        shotBy = -1
    }

    // ───────────────────────── pas de simulation ─────────────────────────

    fun step(dt: Float) {
        if (phase == Phase.OVER) return
        simTime += dt
        messageT -= dt
        if (messageT <= 0f) message = ""
        ballSpin += ballVx * dt * 0.15f

        when (phase) {
            Phase.INTRO -> {
                phaseT -= dt
                for (i in 0..1) { b[i].cmd.move = 0f; b[i].cmd.jump = false; b[i].cmd.action = false; movePlayer(b[i], dt, 0f) }
                clearLatches()
                if (phaseT <= 0f) {
                    phase = Phase.PLAY
                    if (message.isNotEmpty() && messageT < 0.6f) message = ""
                }
            }
            Phase.SCORED -> {
                phaseT -= dt
                for (i in 0..1) { b[i].cmd.move = 0f; b[i].cmd.jump = false; b[i].cmd.action = false; movePlayer(b[i], dt, 0f) }
                clearLatches()
                moveBall(dt, scoring = false)
                if (phaseT <= 0f) {
                    if (pendingOver) finish() else nextPoint()
                }
            }
            Phase.PLAY -> {
                for (i in 0..1) readCmd(i, dt)
                for (i in 0..1) {
                    val spd = if (isAi(i)) 52f + 28f * aiLevel(i).coerceIn(0f, 1f) else 72f
                    movePlayer(b[i], dt, spd)
                }
                clearLatches()
                moveBall(dt, scoring = true)
                if (sport != Sport.VOLLEY && phase == Phase.PLAY) {
                    if (!overtime) {
                        timeLeft -= dt
                        if (timeLeft <= 0f) {
                            timeLeft = 0f
                            if (score[0] != score[1]) {
                                pendingOver = true
                                phase = Phase.SCORED
                                phaseT = 1.3f
                                setMessage("FIN DU MATCH", 2f)
                            } else {
                                overtime = true
                                setMessage("PROLONGATION · prochain point gagne", 2.5f)
                            }
                        }
                    }
                }
            }
            Phase.OVER -> {}
        }
    }

    private fun clearLatches() {
        input.jumpLatch = false
        input.actionLatch = false
    }

    private fun nextPoint() {
        val serve = if (sport == Sport.VOLLEY) lastScorer else 1 - lastScorer
        resetPositions(serve)
        phase = Phase.INTRO
        phaseT = 0.9f
    }

    private var lastScorer = 0

    private fun finish() {
        phase = Phase.OVER
        won = score[0] > score[1]
        sfx.addLast(if (won) 3 else 4)
        message = ""
    }

    private fun scoreFor(side: Int, pts: Int) {
        if (phase != Phase.PLAY) return
        score[side] += pts
        lastScorer = side
        phase = Phase.SCORED
        phaseT = 1.4f
        sfx.addLast(2)
        val who = if (side == 0) "TOI" else level.opponent.uppercase()
        when (sport) {
            Sport.FOOT -> setMessage("BUT ! · $who", 1.4f)
            Sport.BASKET -> setMessage("PANIER +$pts · $who", 1.4f)
            Sport.VOLLEY -> setMessage("POINT · $who", 1.4f)
        }
        pendingOver = when (sport) {
            Sport.VOLLEY -> score[side] >= level.target
            else -> overtime
        }
        if (pendingOver) setMessage(message, 1.4f)
    }

    // ───────────────────────── commandes (joueur / IA) ─────────────────────────

    private fun readCmd(i: Int, dt: Float) {
        val p = b[i]
        val c = p.cmd
        if (!isAi(i)) {
            c.move = input.move.coerceIn(-1f, 1f)
            c.jump = input.jump || input.jumpLatch
            c.action = input.action || input.actionLatch
        } else {
            think(i, aiLevel(i).coerceIn(0f, 1f), dt)
        }
    }

    // ───────────────────────── joueurs ─────────────────────────

    private fun movePlayer(p: Body, dt: Float, speed: Float) {
        val c = p.cmd
        p.vx = c.move * speed
        if (c.jump && p.onGround) {
            p.vy = -125f
            p.onGround = false
        }
        if (isAi(p.side)) c.jump = false
        p.vy += 300f * dt
        p.x += p.vx * dt
        p.y += p.vy * dt
        if (p.y >= Court.GROUND) {
            p.y = Court.GROUND; p.vy = 0f; p.onGround = true
        } else p.onGround = false

        val half = Court.PW / 2f
        var lo = 4f + half
        var hi = Court.W - 4f - half
        if (sport == Sport.VOLLEY) {
            if (p.side == 0) hi = Court.NET_X - 2f - half else lo = Court.NET_X + 2f + half
        }
        p.x = p.x.coerceIn(lo, hi)

        if (c.move > 0.1f) p.face = 1 else if (c.move < -0.1f) p.face = -1
        if (p.onGround && abs(p.vx) > 5f) p.runT += dt * 9f else p.runT = 0f
        p.cool -= dt
        p.hitT -= dt
        if (c.action && p.cool <= 0f && phase == Phase.PLAY) {
            p.hitT = 0.18f
            if (tryHit(p, c)) p.cool = 0.28f else p.cool = 0.12f
        }
    }

    private fun inReach(p: Body): Boolean {
        val dx = (ballX - p.x) / 16.5f
        val dy = (ballY - (p.y - 8f)) / 19f
        if (dx * dx + dy * dy > 1f) return false
        if (sport == Sport.VOLLEY && (ballX < Court.NET_X) != (p.side == 0)) return false
        return true
    }

    private fun tryHit(p: Body, c: Cmd): Boolean {
        if (!inReach(p)) return false
        val d = p.atk
        val ai = isAi(p.side)
        val a = if (ai) aiLevel(p.side).coerceIn(0f, 1f) else 1f
        val dx = ballX - p.x
        val dy = ballY - (p.y - 8f)
        when (sport) {
            Sport.FOOT -> {
                val behind = dx * d < -2f
                if (behind) {
                    ballVx = d * 70f; ballVy = -95f
                } else if (dy < -8f) {
                    ballVx = d * (95f + rnd.nextFloat() * 20f); ballVy = -25f - rnd.nextFloat() * 25f
                } else {
                    ballVx = d * (125f + abs(p.vx) * 0.4f + rnd.nextFloat() * 15f)
                    ballVy = -(25f + rnd.nextFloat() * 45f)
                }
                if (ai) ballVy += (rnd.nextFloat() - 0.5f) * (1f - a) * 40f
            }
            Sport.VOLLEY -> {
                val smash = !p.onGround && ballY < Court.GROUND - 30f
                val lo = if (p.side == 0) Court.NET_X + 10f else 8f
                val hi = if (p.side == 0) Court.W - 8f else Court.NET_X - 10f
                var tx = (lo + hi) / 2f
                if (ai) {
                    val opp = b[1 - p.side]
                    if (rnd.nextFloat() < a) {
                        tx = if (abs(opp.x - lo) > abs(opp.x - hi)) lo + (hi - lo) * 0.12f else hi - (hi - lo) * 0.12f
                    }
                    tx += (rnd.nextFloat() * 2f - 1f) * (1f - a) * 24f
                } else {
                    tx += c.move * 22f + (rnd.nextFloat() * 2f - 1f) * 3f
                }
                tx = tx.coerceIn(lo, hi)
                if (!aimVolley(tx, if (smash) 0.55f else 1.0f)) {
                    ballVx = d * 70f; ballVy = -190f
                }
            }
            Sport.BASKET -> {
                val hx = if (p.side == 0) Court.W - 10f else 10f
                val dist = abs(ballX - hx)
                var err = (1.5f + dist * 0.065f) * (if (p.onGround) 1f else 0.7f)
                if (ai) err *= (1.7f - 1.0f * a)
                val tx = hx + (rnd.nextFloat() * 2f - 1f) * err
                if (!aimBasket(tx)) {
                    ballVx = d * 60f; ballVy = -170f
                }
                shotBy = p.side
                shotDist = abs(p.x - hx)
            }
        }
        sfx.addLast(1)
        return true
    }

    /** Lob / smash vers (tx, sol) qui passe au-dessus du filet. */
    private fun aimVolley(tx: Float, t0: Float): Boolean {
        val g = GB
        var t = t0
        for (k in 0..16) {
            val vx = (tx - ballX) / t
            val vy = (Court.GROUND - Court.BALL_R - ballY - 0.5f * g * t * t) / t
            val tn = (Court.NET_X - ballX) / vx
            var ok = abs(vy) < 235f && abs(vx) < 200f
            if (ok && tn > 0f && tn < t) {
                val yn = ballY + vy * tn + 0.5f * g * tn * tn
                ok = yn < Court.NET_TOP - Court.BALL_R - 3f
            }
            if (ok) {
                ballVx = vx; ballVy = vy
                return true
            }
            t += 0.07f
        }
        return false
    }

    /** Tir en cloche : le ballon arrive en descendant sur l'anneau en (tx, RIM_Y). */
    private fun aimBasket(tx: Float): Boolean {
        val g = GB
        var t = 0.7f
        while (t < 1.7f) {
            val vx = (tx - ballX) / t
            val vy = (Court.RIM_Y - ballY - 0.5f * g * t * t) / t
            val arrival = vy + g * t
            val apex = if (vy < 0f) ballY - vy * vy / (2f * g) else ballY
            if (arrival > 35f && apex > 6f && abs(vx) < 190f && vy > -215f) {
                ballVx = vx; ballVy = vy
                return true
            }
            t += 0.05f
        }
        return false
    }

    // ───────────────────────── ballon ─────────────────────────

    private val GB = 190f

    private fun ballVsRect(x0: Float, y0: Float, x1: Float, y1: Float, bvx: Float, bvy: Float, e: Float): Boolean {
        val r = Court.BALL_R
        val cx = ballX.coerceIn(x0, x1)
        val cy = ballY.coerceIn(y0, y1)
        var nx = ballX - cx
        var ny = ballY - cy
        val d2 = nx * nx + ny * ny
        if (d2 >= r * r) return false
        if (d2 < 1e-6f) {
            val l = ballX - x0
            val rr = x1 - ballX
            val t = ballY - y0
            val bt = y1 - ballY
            val m = min(min(l, rr), min(t, bt))
            when (m) {
                t -> { nx = 0f; ny = -1f; ballY = y0 - r }
                bt -> { nx = 0f; ny = 1f; ballY = y1 + r }
                l -> { nx = -1f; ny = 0f; ballX = x0 - r }
                else -> { nx = 1f; ny = 0f; ballX = x1 + r }
            }
        } else {
            val d = sqrt(d2)
            nx /= d; ny /= d
            ballX = cx + nx * r
            ballY = cy + ny * r
        }
        val vn = (ballVx - bvx) * nx + (ballVy - bvy) * ny
        if (vn < 0f) {
            ballVx -= (1f + e) * vn * nx
            ballVy -= (1f + e) * vn * ny
        }
        return true
    }

    private fun moveBall(dt: Float, scoring: Boolean) {
        val r = Court.BALL_R
        prevY = ballY
        ballVy += GB * dt
        ballX += ballVx * dt
        ballY += ballVy * dt

        // sol
        var groundContact = false
        if (ballY + r >= Court.GROUND) {
            groundContact = true
            ballY = Court.GROUND - r
            if (ballVy > 30f) ballVy = -ballVy * 0.74f else ballVy = 0f
            ballVx -= ballVx * 1.0f * dt
        }
        // plafond
        if (ballY < r) { ballY = r; ballVy = abs(ballVy) * 0.5f }
        // murs
        if (ballX < r) { ballX = r; ballVx = abs(ballVx) * 0.8f }
        if (ballX > Court.W - r) { ballX = Court.W - r; ballVx = -abs(ballVx) * 0.8f }

        // joueurs
        for (p in b) {
            ballVsRect(p.x - Court.PW / 2f, p.y - Court.PH, p.x + Court.PW / 2f, p.y, p.vx, p.vy, 0.55f)
        }
        when (sport) {
            Sport.VOLLEY -> {
                ballVsRect(Court.NET_X - 1f, Court.NET_TOP, Court.NET_X + 1f, Court.GROUND, 0f, 0f, 0.45f)
                // ballon posé en équilibre sur le haut du filet : on le pousse
                if (abs(ballX - Court.NET_X) < 2.5f && abs(ballY - (Court.NET_TOP - r)) < 1f && abs(ballVx) < 4f) {
                    ballVx = if (rnd.nextBoolean()) 18f else -18f
                }
            }
            Sport.FOOT -> {
                val barY = Court.GROUND - Court.GOAL_H
                ballVsRect(0f, barY, Court.GOAL_D + 1f, barY + 2f, 0f, 0f, 0.6f)
                ballVsRect(Court.W - Court.GOAL_D - 1f, barY, Court.W, barY + 2f, 0f, 0f, 0.6f)
            }
            Sport.BASKET -> {
                ballVsRect(Court.HOOP_F - 1.2f, Court.RIM_Y - 1.2f, Court.HOOP_F + 1.2f, Court.RIM_Y + 1.2f, 0f, 0f, 0.55f)
                val rx = Court.W - Court.HOOP_F
                ballVsRect(rx - 1.2f, Court.RIM_Y - 1.2f, rx + 1.2f, Court.RIM_Y + 1.2f, 0f, 0f, 0.55f)
            }
        }
        // ballon coincé entre un joueur et un mur : on le fait sauter par-dessus la tête du joueur
        if (ballX <= r + 0.05f || ballX >= Court.W - r - 0.05f) {
            for (p in b) {
                if (ballVsRect(p.x - Court.PW / 2f, p.y - Court.PH, p.x + Court.PW / 2f, p.y, p.vx, p.vy, 0.55f) ||
                    abs(ballX - p.x) < Court.PW / 2f + r && ballY > p.y - Court.PH - r && ballY < p.y + r
                ) {
                    ballX = ballX.coerceIn(r + 0.1f, Court.W - r - 0.1f)
                    ballY = p.y - Court.PH - r - 1f
                    ballVy = -120f
                    ballVx = if (ballX < Court.W / 2f) 55f else -55f
                }
            }
        }
        // vitesse maximale
        val sp = sqrt(ballVx * ballVx + ballVy * ballVy)
        if (sp > 240f) { ballVx *= 240f / sp; ballVy *= 240f / sp }

        if (!scoring) return
        when (sport) {
            Sport.VOLLEY -> if (groundContact) scoreFor(if (ballX < Court.NET_X) 1 else 0, 1)
            Sport.FOOT -> {
                if (ballY > Court.GROUND - Court.GOAL_H + 2f) {
                    if (ballX < Court.GOAL_D) scoreFor(1, 1)
                    else if (ballX > Court.W - Court.GOAL_D) scoreFor(0, 1)
                }
            }
            Sport.BASKET -> {
                if (prevY < Court.RIM_Y && ballY >= Court.RIM_Y && ballVy > 0f) {
                    if (ballX < Court.HOOP_F - 1.5f) {
                        scoreFor(1, if (shotBy == 1 && shotDist > 70f) 3 else 2)
                    } else if (ballX > Court.W - Court.HOOP_F + 1.5f) {
                        scoreFor(0, if (shotBy == 0 && shotDist > 70f) 3 else 2)
                    }
                }
            }
        }
    }

    // ───────────────────────── IA ─────────────────────────

    private fun predictLandX(): Float {
        val r = Court.BALL_R
        val floorY = Court.GROUND - r
        val disc = ballVy * ballVy + 2f * GB * (floorY - ballY)
        if (disc < 0f) return ballX
        val t = (-ballVy + sqrt(disc)) / GB
        var x = ballX + ballVx * t
        var guard = 0
        while ((x < r || x > Court.W - r) && guard < 4) {
            if (x < r) x = 2f * r - x
            if (x > Court.W - r) x = 2f * (Court.W - r) - x
            guard++
        }
        return x
    }

    private fun steer(p: Body, tx: Float) {
        val dx = tx - p.x
        p.cmd.move = if (abs(dx) < 1.5f) 0f else (dx / 7f).coerceIn(-1f, 1f)
    }

    private fun think(i: Int, a: Float, dt: Float) {
        val me = b[i]
        val c = me.cmd
        me.aiT -= dt
        if (me.aiT <= 0f) {
            me.aiT = 0.06f + (1f - a) * 0.22f
            me.aiHit = rnd.nextFloat() < 0.55f + 0.45f * a
            when (sport) {
                Sport.VOLLEY -> thinkVolley(i, a)
                Sport.FOOT -> thinkFoot(i, a)
                Sport.BASKET -> thinkBasket(i, a)
            }
        }
        steer(me, me.tx)
        c.action = me.aiHit && inReach(me) && (sport != Sport.VOLLEY || ballVy > -70f) && shootOk(me, a)
    }

    private fun shootOk(me: Body, a: Float): Boolean {
        if (sport != Sport.BASKET) return true
        val hx = if (me.side == 0) Court.W - 10f else 10f
        val range = 36f + 52f * a
        return abs(me.x - hx) < range
    }

    private fun thinkVolley(i: Int, a: Float) {
        val me = b[i]
        val d = me.atk
        val home = Court.NET_X - d * 38f
        val mySide = (ballX < Court.NET_X) == (i == 0)
        if (!mySide) {
            me.tx = home
            return
        }
        val noise = (rnd.nextFloat() * 2f - 1f) * (1f - a) * 12f
        val land = predictLandX() + noise
        me.tx = land - d * 5f
        val dx = ballX - me.x
        if (me.onGround && abs(dx) < 16f && ballVy > 0f && ballY < me.y - 24f && ballY > me.y - 50f &&
            rnd.nextFloat() < 0.4f + 0.6f * a
        ) me.cmd.jump = true
    }

    private fun thinkFoot(i: Int, a: Float) {
        val me = b[i]
        val d = me.atk
        val ownGoal = if (i == 0) 0f else Court.W
        val home = ownGoal + d * 38f
        val chase = a >= 0.4f || abs(ballX - ownGoal) < 95f
        if (!chase) {
            me.tx = home
            return
        }
        val front = (ballX - me.x) * d > 0f
        val target = if (ballY < Court.GROUND - 30f && ballVy > 0f) predictLandX() else ballX
        me.tx = if (front) target - d * 4f else ballX - d * 16f
        val dx = ballX - me.x
        if (me.onGround && abs(dx) < 14f && ballY < me.y - 22f && ballY > me.y - 50f &&
            rnd.nextFloat() < 0.3f + 0.6f * a
        ) me.cmd.jump = true
    }

    private fun thinkBasket(i: Int, a: Float) {
        val me = b[i]
        val d = me.atk
        val ownHoop = if (i == 0) 10f else Court.W - 10f
        val front = (ballX - me.x) * d > 0f
        val target = if (ballY < Court.GROUND - 30f && ballVy > 0f) predictLandX() else ballX
        // défense : les faibles IA restent près de leur panier quand le ballon est loin
        if (a < 0.45f && abs(ballX - ownHoop) > 100f) {
            me.tx = ownHoop + d * 30f
            return
        }
        me.tx = if (front) target - d * 4f else ballX - d * 16f
        val dx = ballX - me.x
        val hx = if (i == 0) Court.W - 10f else 10f
        val inRange = abs(me.x - hx) < 36f + 52f * a
        if (me.onGround && inRange && abs(dx) < 12f && ballY > me.y - 26f && rnd.nextFloat() < 0.6f * a) {
            me.cmd.jump = true
        }
        if (me.onGround && abs(dx) < 14f && ballY < me.y - 22f && ballY > me.y - 50f && rnd.nextFloat() < 0.3f + 0.5f * a) {
            me.cmd.jump = true
        }
    }
}
