package com.nexus.gamelibrary

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val Gold = Color(0xFFFFC83D)

private fun stars(n: Int) = "★".repeat(n) + "☆".repeat(3 - n)

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ════════════════════════════════════════════════════════════════
//  Menu : carrière
// ════════════════════════════════════════════════════════════════

@Composable
fun ArcadeScreen(theme: GameTheme, store: Store, version: Int, onPlay: (Level) -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }
    var resetTick by remember { mutableIntStateOf(0) }
    val st = remember(version, resetTick) { store.arcadeStars() }
    val total = st.sum()

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Arcade", color = theme.onBg, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text(
                "Volley, foot et basket en pixel art. Gagne chaque match pour débloquer le suivant. Aucun wifi nécessaire.",
                color = theme.onBg.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        item {
            GlassCard(theme) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⭐", fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Carrière", color = theme.onBg, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "$total / ${Career.levels.size * 3} étoiles",
                            color = theme.onBg.copy(alpha = 0.7f),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        Career.divisions.forEachIndexed { d, name ->
            item {
                Text(
                    "Division ${d + 1} · $name",
                    color = theme.accent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            val lvls = Career.levels.filter { it.division == d }
            items(lvls.size) { k ->
                val lv = lvls[k]
                val unlocked = lv.index == 0 || st[lv.index - 1] >= 1
                val shape = RoundedCornerShape(20.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(theme.tile)
                        .border(1.dp, theme.onBg.copy(alpha = 0.08f), shape)
                        .then(if (unlocked) Modifier.clickable { onPlay(lv) } else Modifier)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (unlocked) lv.sport.icon else "🔒",
                        fontSize = 30.sp,
                        modifier = Modifier.width(44.dp)
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Niveau ${lv.index + 1} · ${lv.sport.label}",
                            color = theme.onBg.copy(alpha = if (unlocked) 1f else 0.45f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            "vs ${lv.opponent} · ${lv.rule}",
                            color = theme.onBg.copy(alpha = if (unlocked) 0.7f else 0.35f),
                            fontSize = 13.sp
                        )
                    }
                    Text(
                        stars(st[lv.index]),
                        color = if (st[lv.index] > 0) Gold else theme.onBg.copy(alpha = 0.3f),
                        fontSize = 20.sp
                    )
                }
            }
        }

        item {
            Spacer(Modifier.height(8.dp))
            Text(
                "Étoiles : 1 = victoire · 2 = victoire nette · 3 = victoire écrasante",
                color = theme.onBg.copy(alpha = 0.55f),
                fontSize = 12.sp
            )
            TextButton(onClick = { confirmReset = true }) {
                Text("Réinitialiser la carrière", color = theme.onBg.copy(alpha = 0.6f))
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Réinitialiser ?") },
            text = { Text("Toutes les étoiles seront effacées.") },
            confirmButton = {
                TextButton(onClick = {
                    store.resetArcade()
                    resetTick++
                    confirmReset = false
                }) { Text("Effacer") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Annuler") } }
        )
    }
}

// ════════════════════════════════════════════════════════════════
//  Écran de match
// ════════════════════════════════════════════════════════════════

@Composable
fun MatchScreen(level: Level, store: Store, hasNext: Boolean, onExit: () -> Unit, onNext: () -> Unit) {
    val context = LocalContext.current
    var attempt by remember(level.index) { mutableIntStateOf(0) }
    val match = remember(level.index, attempt) { Match(level) }
    var paused by remember(level.index, attempt) { mutableStateOf(false) }
    var hud by remember(match) { mutableStateOf(match.hud()) }
    var frame by remember(match) { mutableIntStateOf(0) }
    var sound by remember { mutableStateOf(store.arcadeSound) }
    val soundOn = rememberUpdatedState(sound)

    // Écran en paysage + plein écran pendant le match
    DisposableEffect(Unit) {
        val act = context.findActivity()
        val window = act?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Petits bips (aucun fichier son, tout est généré par le téléphone)
    val tone = remember {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 55) } catch (e: Throwable) { null }
    }
    DisposableEffect(tone) { onDispose { try { tone?.release() } catch (e: Throwable) { } } }

    fun beep(code: Int) {
        if (!soundOn.value) return
        try {
            when (code) {
                1 -> tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
                2 -> tone?.startTone(ToneGenerator.TONE_PROP_ACK, 200)
                3 -> tone?.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 400)
                else -> tone?.startTone(ToneGenerator.TONE_PROP_NACK, 400)
            }
        } catch (e: Throwable) { }
    }

    // Boucle de jeu à pas fixe (60 pas par seconde)
    LaunchedEffect(match, paused) {
        if (paused) return@LaunchedEffect
        var last = 0L
        var acc = 0f
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) {
                    acc += min(0.05f, (now - last) / 1_000_000_000f)
                    while (acc >= STEP) {
                        match.step(STEP)
                        acc -= STEP
                    }
                }
                last = now
                while (match.sfx.isNotEmpty()) beep(match.sfx.removeFirst())
                val h = match.hud()
                if (h != hud) hud = h
                frame++
            }
        }
    }

    // Sauvegarde des étoiles à la fin du match
    LaunchedEffect(hud.over) {
        if (hud.over && match.won) store.setArcadeStars(level.index, match.stars())
    }

    BackHandler { if (!hud.over) paused = !paused else onExit() }

    // Touches
    val held = remember(match) { booleanArrayOf(false, false) }
    fun updateMove() {
        match.input.move = (if (held[1]) 1f else 0f) - (if (held[0]) 1f else 0f)
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
            .background(Color.Black)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            frame // lecture : redessine à chaque image
            drawMatch(match, frame)
        }

        // ── Score + chrono
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("TOI", color = Color(0xFF7FB0FF), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Text("${hud.scoreA}", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                Text(
                    if (hud.seconds >= 0) {
                        "  " + (if (hud.overtime) "+" else "%d:%02d".format(hud.seconds / 60, hud.seconds % 60)) + "  "
                    } else "  –  ",
                    color = Gold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Text("${hud.scoreB}", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                Spacer(Modifier.width(8.dp))
                Text(level.opponent.uppercase(), color = Color(0xFFFF8A80), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            if (hud.message.isNotEmpty()) {
                Text(
                    hud.message,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(top = 18.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }

        // ── Bouton pause
        Box(
            Modifier
                .align(Alignment.TopStart)
                .safeDrawingPadding()
                .padding(8.dp)
                .size(40.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable { if (!hud.over) paused = true },
            contentAlignment = Alignment.Center
        ) { Text("II", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        // ── Commandes
        Row(
            Modifier
                .align(Alignment.BottomStart)
                .safeDrawingPadding()
                .padding(start = 16.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PadButton("◀", 64.dp, Color.White) { down -> held[0] = down; updateMove() }
            PadButton("▶", 64.dp, Color.White) { down -> held[1] = down; updateMove() }
        }
        Row(
            Modifier
                .align(Alignment.BottomEnd)
                .safeDrawingPadding()
                .padding(end = 16.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            PadButton("▲", 60.dp, Color.White, onPress = { match.input.jumpLatch = true }) { down -> match.input.jump = down }
            PadButton(level.sport.actionLabel, 76.dp, Gold, onPress = { match.input.actionLatch = true }) { down -> match.input.action = down }
        }

        // ── Pause
        if (paused && !hud.over) {
            OverlayCard {
                Text("PAUSE", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                Spacer(Modifier.height(14.dp))
                OverlayButton("Continuer", Gold) { paused = false }
                OverlayButton("Recommencer", Color.White) { attempt++ }
                OverlayButton(if (sound) "Son : oui" else "Son : non", Color.White) {
                    sound = !sound
                    store.arcadeSound = sound
                }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { onExit() }
            }
        }

        // ── Fin de match
        if (hud.over) {
            OverlayCard {
                Text(
                    if (match.won) "VICTOIRE !" else "DÉFAITE",
                    color = if (match.won) Gold else Color(0xFFFF8A80),
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 28.sp
                )
                Text(
                    "${hud.scoreA} - ${hud.scoreB}",
                    color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 22.sp
                )
                if (match.won) {
                    Text(stars(match.stars()), color = Gold, fontSize = 34.sp)
                } else {
                    Text("Retente ta chance !", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
                }
                Spacer(Modifier.height(10.dp))
                if (match.won && hasNext) OverlayButton("Niveau suivant", Gold) { onNext() }
                OverlayButton("Rejouer", Color.White) { attempt++ }
                OverlayButton("Quitter", Color(0xFFFF8A80)) { onExit() }
            }
        }
    }
}

private const val STEP = 1f / 60f

@Composable
private fun OverlayCard(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF1B1B26))
                .border(2.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                .padding(horizontal = 28.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) { content() }
    }
}

@Composable
private fun OverlayButton(text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(vertical = 4.dp)
            .width(200.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.18f))
            .border(1.5.dp, color.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** Bouton tactile à appui maintenu (plusieurs doigts en même temps possibles). */
@Composable
private fun PadButton(
    label: String,
    size: Dp,
    color: Color,
    onPress: () -> Unit = {},
    onHold: (Boolean) -> Unit
) {
    var down by remember { mutableStateOf(false) }
    val hold = rememberUpdatedState(onHold)
    val press = rememberUpdatedState(onPress)
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (down) color.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.16f))
            .border(2.dp, color.copy(alpha = 0.75f), CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    down = true
                    hold.value(true)
                    press.value()
                    waitForUpOrCancellation()
                    down = false
                    hold.value(false)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = if (label.length > 2) 14.sp else 24.sp
        )
    }
}

// ════════════════════════════════════════════════════════════════
//  Dessin pixel art
// ════════════════════════════════════════════════════════════════

private class Px(val ds: DrawScope, val s: Float, val ox: Float, val oy: Float) {
    fun r(x: Float, y: Float, w: Float, h: Float, c: Color) {
        val x0 = floor(ox + x * s)
        val y0 = floor(oy + y * s)
        val x1 = floor(ox + (x + w) * s)
        val y1 = floor(oy + (y + h) * s)
        ds.drawRect(c, Offset(x0, y0), Size(x1 - x0, y1 - y0))
    }

    fun r(x: Int, y: Int, w: Int, h: Int, c: Color) = r(x.toFloat(), y.toFloat(), w.toFloat(), h.toFloat(), c)

    /** Dessine un sprite : une chaîne par ligne, une lettre par couleur, '.' = transparent. */
    fun sprite(rows: List<String>, x: Int, y: Int, flip: Boolean, pal: (Char) -> Color?) {
        for ((j, row) in rows.withIndex()) {
            val n = row.length
            var i = 0
            while (i < n) {
                val ch = row[if (flip) n - 1 - i else i]
                val c = pal(ch)
                if (c == null) { i++; continue }
                var k = i + 1
                while (k < n && row[if (flip) n - 1 - k else k] == ch) k++
                r(x + i, y + j, k - i, 1, c)
                i = k
            }
        }
    }
}

private class SkyPal(val bands: List<Color>, val bldg: Color, val bldg2: Color, val stars: Int, val neon: Boolean)

private val skyPals = listOf(
    SkyPal(listOf(Color(0xFF6EC6FF), Color(0xFF8AD3FF), Color(0xFFA9DEFF), Color(0xFFC8EBFF)), Color(0xFF8FB3D6), Color(0xFF6C94BB), 0, false),
    SkyPal(listOf(Color(0xFFFF8A5C), Color(0xFFFFA766), Color(0xFFFFC27A), Color(0xFFFFDB94)), Color(0xFF9A5A74), Color(0xFF7A3F5C), 0, false),
    SkyPal(listOf(Color(0xFF1B1F4B), Color(0xFF2B2D6B), Color(0xFF3F3A86), Color(0xFF5A4A9A)), Color(0xFF1C1B3F), Color(0xFF141331), 14, false),
    SkyPal(listOf(Color(0xFF2A0B4F), Color(0xFF4B1A7A), Color(0xFF7A2A96), Color(0xFFB23DA8)), Color(0xFF26113F), Color(0xFF1B0A2E), 10, true),
    SkyPal(listOf(Color(0xFF05070F), Color(0xFF0A1024), Color(0xFF101A38), Color(0xFF182850)), Color(0xFF0B1226), Color(0xFF070C1B), 30, true)
)

private fun lcg(seed: Int): Int = (seed * 1103515245 + 12345) and 0x7fffffff

private fun Px.drawBackground(sport: Sport, division: Int, tick: Int) {
    val pal = skyPals[division.coerceIn(0, skyPals.lastIndex)]
    // ciel en bandes
    for (i in 0 until 4) r(0, i * 13, 160, 14, pal.bands[i])
    // étoiles
    var sd = 7
    for (i in 0 until pal.stars) {
        sd = lcg(sd); val x = sd % 160
        sd = lcg(sd); val y = (sd % 30)
        if ((tick / 30 + i) % 7 != 0) r(x, y, 1, 1, Color.White.copy(alpha = 0.8f))
    }
    // soleil / lune
    when (division) {
        0 -> { r(128, 8, 10, 10, Color(0xFFFFE680)); r(126, 10, 14, 6, Color(0xFFFFE680)); r(130, 6, 6, 14, Color(0xFFFFE680)) }
        1 -> { r(20, 28, 14, 8, Color(0xFFFFE08A)); r(22, 26, 10, 12, Color(0xFFFFE08A)) }
        2 -> { r(130, 8, 8, 8, Color(0xFFF2F2D0)); r(132, 6, 4, 12, Color(0xFFF2F2D0)) }
        else -> {}
    }
    // immeuble
    sd = 11 + division * 13
    var x = 0
    while (x < 160) {
        sd = lcg(sd)
        val w = 7 + sd % 9
        sd = lcg(sd)
        val h = 12 + sd % 22
        val top = 56 - h
        r(x, top, w, h + 8, if ((x / 8) % 2 == 0) pal.bldg else pal.bldg2)
        if (division >= 2) {
            var wy = top + 3
            while (wy < 52) {
                var wx = x + 2
                while (wx < x + w - 2) {
                    sd = lcg(sd)
                    if (sd % 3 == 0) {
                        val col = if (pal.neon) (if (sd % 2 == 0) Color(0xFFFF4FD8) else Color(0xFF4FF3FF)) else Color(0xFFFFE07A)
                        r(wx, wy, 1, 2, col)
                    }
                    wx += 3
                }
                wy += 4
            }
        }
        x += w + 1
    }

    when (sport) {
        Sport.VOLLEY -> {
            // mer + plage
            r(0, 52, 160, 8, Color(0xFF2F86D6))
            r(0, 52, 160, 1, Color(0xFF7CC0F5))
            for (i in 0 until 14) {
                val wx = (i * 13 + tick / 6) % 160
                r(wx, 54 + (i % 3) * 2, 4, 1, Color(0xFFBFE3FF))
            }
            r(0, 60, 160, 16, Color(0xFFF4D894))
            r(0, 76, 160, 14, Color(0xFFE6C47A))
            sd = 5
            for (i in 0 until 120) {
                sd = lcg(sd); val px = sd % 160
                sd = lcg(sd); val py = 61 + sd % 29
                r(px, py, 1, 1, Color(0xFFD1AC62))
            }
            r(0, 76, 160, 1, Color(0xFFC9A55C))
        }
        Sport.FOOT -> {
            drawCrowd(tick, 48, 62)
            for (i in 0 until 16) {
                val c = if (i % 2 == 0) Color(0xFF3FAE52) else Color(0xFF379F49)
                r(i * 10, 62, 10, 14, c)
                r(i * 10, 76, 10, 14, if (i % 2 == 0) Color(0xFF2E8E40) else Color(0xFF29813A))
            }
            r(0, 76, 160, 1, Color.White.copy(alpha = 0.85f))
            r(79, 62, 1, 28, Color.White.copy(alpha = 0.6f))
            // surfaces de réparation
            r(0, 62, 22, 1, Color.White.copy(alpha = 0.5f)); r(22, 62, 1, 14, Color.White.copy(alpha = 0.5f))
            r(138, 62, 22, 1, Color.White.copy(alpha = 0.5f)); r(138, 62, 1, 14, Color.White.copy(alpha = 0.5f))
            drawGoal(left = true)
            drawGoal(left = false)
        }
        Sport.BASKET -> {
            drawCrowd(tick, 44, 62)
            r(0, 62, 160, 14, Color(0xFFD39A58))
            r(0, 76, 160, 14, Color(0xFFBD8447))
            for (i in 0 until 16) r(i * 10, 62, 1, 28, Color(0xFFB07A40))
            r(0, 76, 160, 1, Color.White.copy(alpha = 0.8f))
            r(79, 62, 1, 28, Color.White.copy(alpha = 0.55f))
            r(60, 62, 40, 1, Color.White.copy(alpha = 0.4f))
            drawHoop(left = true)
            drawHoop(left = false)
        }
    }
}

private fun Px.drawCrowd(tick: Int, y0: Int, y1: Int) {
    r(0, y0, 160, y1 - y0, Color(0xFF1C2230))
    val heads = listOf(
        Color(0xFFE0A070), Color(0xFFF2C79A), Color(0xFF8D5A3B), Color(0xFFCC4455),
        Color(0xFF4466CC), Color(0xFFEEDD55), Color(0xFF55BB77), Color(0xFFFFFFFF)
    )
    var sd = 3
    var y = y0 + 2
    var row = 0
    while (y < y1 - 2) {
        var x = (row % 2) * 2
        while (x < 160) {
            sd = lcg(sd)
            val bob = if ((sd % 5 == 0) && ((tick / 12 + x) % 2 == 0)) -1 else 0
            r(x, y + bob, 2, 2, heads[sd % heads.size])
            x += 4
        }
        y += 4
        row++
    }
    r(0, y1 - 1, 160, 1, Color(0xFF0E121C))
}

private fun Px.drawGoal(left: Boolean) {
    val top = (Court.GROUND - Court.GOAL_H).toInt()
    val h = Court.GOAL_H.toInt()
    val x0 = if (left) 0 else 160 - Court.GOAL_D.toInt() - 1
    val w = Court.GOAL_D.toInt() + 1
    r(x0, top, w, h, Color(0xFF1B1B1B).copy(alpha = 0.35f))
    for (j in 0 until h step 2) for (i in 0 until w step 2) r(x0 + i, top + j, 1, 1, Color.White.copy(alpha = 0.55f))
    r(x0, top, w, 2, Color.White)
    val postX = if (left) Court.GOAL_D.toInt() else 160 - Court.GOAL_D.toInt() - 1
    r(postX, top, 1, h, Color.White)
}

private fun Px.drawHoop(left: Boolean) {
    val rimY = Court.RIM_Y.toInt()
    val f = Court.HOOP_F.toInt()
    val bx = if (left) 0 else 158
    // poteau + panneau
    r(bx, rimY - 14, 2, 18, Color.White)
    r(if (left) 2 else 157, rimY - 9, 1, 8, Color(0xFFE23B3B))
    // anneau
    val rx0 = if (left) 2 else 160 - f
    r(rx0, rimY, f - 2, 1, Color(0xFFFF6A1A))
    r(if (left) f - 1 else 160 - f, rimY - 1, 1, 3, Color(0xFFFF6A1A))
    // filet
    for (j in 1..7) {
        val inset = j / 2
        val a = rx0 + inset
        val len = (f - 2) - inset * 2
        for (i in 0 until len step 2) r(a + i + (j % 2), rimY + j, 1, 1, Color.White.copy(alpha = 0.85f))
    }
}

private fun Px.drawNet() {
    val nx = Court.NET_X.toInt()
    val top = Court.NET_TOP.toInt()
    val bottom = Court.GROUND.toInt()
    r(nx - 1, top, 2, bottom - top, Color(0xFFEDEDED))
    for (j in 2 until bottom - top step 2) {
        r(nx - 3, top + j, 6, 1, Color.White.copy(alpha = 0.55f))
    }
    for (i in -3..2 step 2) r(nx + i, top + 2, 1, bottom - top - 3, Color.White.copy(alpha = 0.4f))
    r(nx - 4, top, 8, 2, Color.White)
}

private val spriteStand = listOf(
    "..hhhhh..", ".hhhhhhh.", ".hssssss.", ".hsssess.", "..sssss..", "...sss...",
    ".aaaaaaa.", "saaaaaaas", "saaaaaaas", "s.aaaaa.s",
    "..ppppp..", "..pp.pp..", "..ll.ll..", "..ll.ll..", ".ww..ww.."
)
private val spriteRunA = spriteStand.take(10) + listOf("..ppppp..", ".pp...pp.", ".ll...ll.", "ll.....ll", "ww.....ww")
private val spriteRunB = spriteStand.take(10) + listOf("..ppppp..", "..ppppp..", "..lllll..", "...lll...", "..wwwww..")
private val spriteJump = spriteStand.take(10) + listOf("..ppppp..", ".pp...pp.", ".ll...ll.", ".ww...ww.", ".........")
private val armsUp = listOf("s.sssss.s", "s..sss..s", "saaaaaaas", ".aaaaaaa.", ".aaaaaaa.", ".aaaaaaa.")

private fun playerFrame(runT: Float, onGround: Boolean, hitting: Boolean): List<String> {
    val base = when {
        !onGround -> spriteJump
        runT > 0f -> if ((runT.toInt() and 1) == 0) spriteRunA else spriteRunB
        else -> spriteStand
    }
    return if (hitting) base.take(4) + armsUp + base.drop(10) else base
}

private val ballMask = listOf("..ooo..", ".ooooo.", "ooooooo", "ooooooo", "ooooooo", ".ooooo.", "..ooo..")

private fun Px.drawBall(sport: Sport, bx: Float, by: Float, spin: Float) {
    val x0 = bx.roundToInt() - 3
    val y0 = by.roundToInt() - 3
    val base: Color
    val mark: Color
    val marks: List<Pair<Int, Int>>
    val v = (abs(spin).toInt()) % 3
    when (sport) {
        Sport.FOOT -> {
            base = Color(0xFFF5F5F5); mark = Color(0xFF222222)
            marks = when (v) { 0 -> listOf(3 to 3, 1 to 2, 5 to 2, 2 to 5, 4 to 5); 1 -> listOf(3 to 2, 1 to 4, 5 to 4, 3 to 6); else -> listOf(2 to 3, 4 to 3, 3 to 1, 3 to 5) }
        }
        Sport.BASKET -> {
            base = Color(0xFFF07B1C); mark = Color(0xFF6B3208)
            marks = when (v) { 0 -> listOf(3 to 0, 3 to 1, 3 to 2, 3 to 3, 3 to 4, 3 to 5, 3 to 6, 0 to 3, 1 to 3, 2 to 3, 4 to 3, 5 to 3, 6 to 3); 1 -> listOf(2 to 0, 2 to 1, 2 to 2, 2 to 3, 2 to 4, 2 to 5, 2 to 6, 0 to 3, 1 to 3, 3 to 3, 4 to 3, 5 to 3, 6 to 3); else -> listOf(4 to 0, 4 to 1, 4 to 2, 4 to 3, 4 to 4, 4 to 5, 4 to 6, 0 to 3, 1 to 3, 2 to 3, 3 to 3, 5 to 3, 6 to 3) }
        }
        Sport.VOLLEY -> {
            base = Color(0xFFFFF3C4); mark = Color(0xFF2F6BFF)
            marks = when (v) { 0 -> listOf(1 to 2, 2 to 3, 3 to 4, 4 to 3, 5 to 2); 1 -> listOf(2 to 1, 3 to 2, 4 to 3, 3 to 4, 2 to 5); else -> listOf(1 to 4, 2 to 3, 3 to 2, 4 to 3, 5 to 4) }
        }
    }
    for ((j, row) in ballMask.withIndex()) for ((i, ch) in row.withIndex()) if (ch == 'o') r(x0 + i, y0 + j, 1, 1, base)
    for ((i, j) in marks) if (ballMask[j][i] == 'o') r(x0 + i, y0 + j, 1, 1, mark)
}

private fun DrawScope.drawMatch(m: Match, tick: Int) {
    val s = max(1f, floor(min(size.width / Court.W, size.height / Court.H)))
    val ox = floor((size.width - Court.W * s) / 2f)
    val oy = floor((size.height - Court.H * s) / 2f)
    val p = Px(this, s, ox, oy)
    val lv = m.level

    p.drawBackground(m.sport, lv.division, tick)

    // ombres
    val shadow = Color.Black.copy(alpha = 0.28f)
    for (b in m.b) p.r(b.x.roundToInt() - 4, Court.GROUND.toInt() + 1, 9, 1, shadow)
    val hgt = (Court.GROUND - m.ballY)
    val sw = max(2, 7 - (hgt / 12f).toInt())
    p.r(m.ballX.roundToInt() - sw / 2, Court.GROUND.toInt() + 1, sw, 1, shadow)

    if (m.sport == Sport.VOLLEY) p.drawNet()

    // joueurs
    val shirtMe = Color(0xFF2F6BFF)
    val shirtOpp = listOf(Color(0xFFE23B3B), Color(0xFFFF8A00), Color(0xFF9A3BE2), Color(0xFF16A085), Color(0xFFD4AF37))[lv.division.coerceIn(0, 4)]
    for ((i, b) in m.b.withIndex()) {
        val shirt = if (i == 0) shirtMe else shirtOpp
        val hair = if (i == 0) Color(0xFF3A2A1A) else Color(0xFF1E1E1E)
        val shorts = if (i == 0) Color(0xFF1F3FA8) else Color(0xFF3A3A3A)
        val skin = if (i == 0) Color(0xFFF2C79A) else Color(0xFFD9A074)
        val frame = playerFrame(b.runT, b.onGround, b.hitT > 0f)
        p.sprite(frame, b.x.roundToInt() - 4, b.y.roundToInt() - 15, b.face < 0) { ch ->
            when (ch) {
                'h' -> hair
                's', 'l' -> skin
                'e' -> Color(0xFF111111)
                'a' -> shirt
                'p' -> shorts
                'w' -> Color(0xFFF0F0F0)
                else -> null
            }
        }
        // petit repère au-dessus du joueur
        if (i == 0) p.r(b.x.roundToInt() - 1, b.y.roundToInt() - 19, 3, 1, Color(0xFFFFC83D))
    }

    p.drawBall(m.sport, m.ballX, m.ballY, m.ballSpin)
}
