# Gaming Soul (v0.6)

Bibliothèque de jeux pour Android + bouton flottant, viseur et Helper ChatGPT.
Package inchangé (`com.nexus.gamelibrary`) : la mise à jour s'installe par-dessus l'ancienne version.

## Nouveautés v0.6
- **Onglet Arcade** : mini-jeux en pixel art, 100 % hors ligne (aucun wifi, aucune permission).
  - 3 sports : **volley**, **foot**, **basket** (1 contre 1 contre l'ordinateur).
  - **Carrière** : 5 divisions (Quartier → Légende), 15 niveaux, l'IA devient de plus en plus forte.
  - 1 à 3 étoiles par niveau selon l'écart de score ; un niveau se débloque quand le précédent est gagné.
  - Commandes tactiles : ◀ ▶ pour bouger, ▲ pour sauter, bouton d'action pour frapper / smasher / tirer.
  - La progression est sauvegardée sur le téléphone.
- La barre du bas a un 6ᵉ onglet (« Bibliothèque » y est abrégé en « Biblio », « Paramètres » en « Réglages »).

## Nouveautés v0.5
- **Position du viseur** : décalage horizontal + vertical (curseurs) et croix de flèches ↑ ← ◎ → ↓ (aussi dans le bouton flottant, onglet Viseur ; maintenir = défilement, ◎ = recentrer).

## Nouveautés v0.4
- **Viseur façon Valorant** : couleur (8 couleurs + #RRGGBB), contours, point central, lignes intérieures et extérieures, décalage vertical. Écran *Paramètres → Viseur* avec aperçu en direct.
- **Photo de fond floue** (*Paramètres → Photo de fond*) : boutons et cartes deviennent translucides. Réglage du flou.
- **Onglet Helper** : tu écris ta question, elle part vers l'appli ChatGPT, puis tu colles la réponse dans Gaming Soul (historique enregistré). Aucune clé API.
- **« Boutique » renommé « Applis »**.
- **Bouton flottant à 3 onglets** : Capture (texte proposé + suggestions), Helper, Viseur (afficher / masquer).
- **Nouveau logo** (anneau + flamme) et nom **Gaming Soul**.
- L'APK s'appelle **gaming-soul.apk**.

## Compiler
GitHub : onglet Actions → *Build APK* → télécharger l'artefact `gaming-soul`.
Android Studio : *Build → Build APK(s)* (fichier `gaming-soul-debug.apk`).

## Premier lancement
1. Autorise « Afficher par-dessus les autres applis » (bulle + viseur).
2. À chaque capture, Android demande « Commencer l'enregistrement ou la diffusion ? » : appuie sur Commencer.
