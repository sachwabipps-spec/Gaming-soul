package com.nexus.gamelibrary

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/*
 * Moteur du mini-jeu « Arcade » v2 : vue du dessus, équipes avec bots.
 *  - Football 3 contre 3, Volley 2 contre 2, Basket 3 contre 3
 *  - Tu pilotes un joueur (celui qui est le plus proche de l'action), les bots font le reste.
 *  - Aide à la visée : tirs, passes et frappes sont corrigés automatiquement vers la bonne cible.
 * Kotlin pur : aucune dépendance Android, tout fonctionne hors ligne.
 * Le monde fait 320 x 180 « pixels » ; l'écran les agrandit.
 */

enum class Sport(
    val label: String,
    val icon: String,
    val actionLabel: String,
    val secondLabel: String?,
    val teamSize: Int,
    val blurb: String,
    val help: String
) {
    FOOT(
        "Football", "⚽", "TIR", "PASSE", 3,
        "3 contre 3 · tirs et passes avec aide à la visée",
        "Joystick : bouger · TIR : vise le but tout seul · PASSE : cherche un coéquipier"
    ),
    VOLLEY(
        "Volley", "🏐", "FRAPPE", null, 2,
        "2 contre 2 · la frappe vise toute seule",
        "Joystick : bouger · FRAPPE près du ballon · pousse le joystick pour viser court/long"
    ),
    BASKET(
        "Basket", "🏀", "TIR", "PASSE", 3,
        "3 contre 3 · tirs assistés, passes, interceptions",
        "Joystick : bouger · TIR : panier (ou vol de balle en défense) · PASSE : coéquipier"
    )
}

data class Level(
    val index: Int,
    val number: Int,
    val division: Int,
    val divisionName: String,
    val sport: Sport,
    val opponent: String,
    val ai: Float,
    /** volley : points à atteindre ; foot / basket : durée du match en secondes */
    val target: Int,
    val margin2: Int,
    val margin3: Int
) {
    val title: String get() = "${sport.label} · vs $opponent"
    val rule: String
        get() = when (sport) {
            Sport.VOLLEY -> "Premier à $target points"
            Sport.FOOT -> "$target s · plus de buts"
            Sport.BASKET -> "$target s · plus de points"
        }
}

object Career {
    val divisions = listOf("Quartier", "Ville", "Région", "Pro", "Légende")

    private val teams: Map<Sport, List<String>> = mapOf(
        Sport.FOOT to listOf(
            "Les Pitchous", "FC Quartier", "Les Rapides",
            "Union Ville", "AS Béton", "Étoile Sud",
            "Racing Pixel", "Olympique Nord", "Real Régio",
            "Atlético Néon", "Dragons FC", "Titans United",
            "Pixel City", "Les Galactiques", "Légende FC"
        ),
        Sport.VOLLEY to listOf(
            "Les Smasheurs", "Volley Club", "Les Sablés",
            "Filet Express", "Team Plage", "Les Bloqueurs",
            "Ace Ville", "Smash Nord", "Les Faucons",
            "Tempête", "Les Spikers", "Volcan VB",
            "Néon Spike", "Les Titans", "Légende VB"
        ),
        Sport.BASKET to listOf(
            "Les Dunkers", "Street Ball", "Les Paniers",
            "Ville Hoops", "Les Rebonds", "Bitume BC",
            "Pro Hoops", "Les Meneurs", "Blocs Nord",
            "Les Aigles", "Skyline", "Triple Double",
            "Pixel Hoops", "Les Légendes", "Dream Team"
        )
    )

    private val baseAi = floatArrayOf(0.12f, 0.30f, 0.48f, 0.66f, 0.82f)

    val levels: List<Level> = Sport.values().toList().flatMapIndexed { si, sport ->
        List(15) { i ->
            val div = i / 3
            val k = i % 3
            val ai = min(0.95f, baseAi[div] + 0.05f * k)
            val t = when (sport) {
                Sport.VOLLEY -> Triple(if (div < 3) 5 else 7, 2, 4)
                Sport.FOOT -> Triple(75, 2, 3)
                Sport.BASKET -> Triple(75, 8, 16)
            }
            Level(si * 15 + i, i + 1, div, divisions[div], sport, teams.getValue(sport)[i], ai, t.first, t.second, t.third)
        }
    }

    fun of(sport: Sport): List<Level> = levels.filter { it.sport == sport }

    fun next(lv: Level): Level? = levels.getOrNull(lv.index + 1)?.takeIf { it.sport == lv.sport }
}

/** Touches du joueur : le moteur lit ces valeurs à chaque pas. */
class ArcadeInput {
    @Volatile var mx = 0f
    @Volatile var my = 0f
    @Volatile var action = false
    @Volatile var actionLatch = false
    @Volatile var pass = false
    @Volatile var passLatch = false
}

object Court {
    const val W = 320f
    const val H = 180f

    // aire de jeu (foot et basket)
    const val X0 = 16f
    const val X1 = 304f
    const val Y0 = 16f
    const val Y1 = 164f
    const val CY = 90f

    // foot
    const val GOAL_Y0 = 68f
    const val GOAL_Y1 = 112f
    const val GOAL_D = 12f

    // basket
    const val HOOP_X = 30f
    const val ARC = 74f

    // volley
    const val VX0 = 44f
    const val VX1 = 276f
    const val VY0 = 32f
    const val VY1 = 148f
    const val NET_X = 160f
    const val NET_H = 20f

    const val BALL_R = 3f
}

class Player(val team: Int, val slot: Int) {
    var x = 0f
    var y = 0f
    var vx = 0f
    var vy = 0f
    var fx = 1f
    var fy = 0f
    var runT = 0f
    var cool = 0f
    var actT = 0f
    var jumpT = 0f
    var tx = 0f
    var ty = 0f
    var aiT = 0f
    var aiGo = false
    var aiGo2 = false
    var mx = 0f
    var my = 0f
    var act = false
    var pass = false
}

enum class Phase { INTRO, PLAY, SCORED, OVER }

data class Hud(
    val scoreA: Int,
    val scoreB: Int,
    val seconds: Int,
    val message: String,
    val overtime: Boolean,
    val over: Boolean
)

private fun hyp(a: Float, b: Float): Float = sqrt(a * a + b * b)

class Match(
    val level: Level,
    seed: Long = System.nanoTime()
) {
    val sport = level.sport
    private val n = sport.teamSize
    private val rnd = Random(seed)
    val ps: List<Player> = List(n * 2) { Player(it / n, it % n) }
    val input = ArcadeInput()

    /** Indice (dans ps) du joueur que tu pilotes. */
    var ctrl = 1
    private var switchT = 0f

    // ballon
    var bx = 160f
    var by = 90f
    var bz = 0f
    var bvx = 0f
    var bvy = 0f
    var bvz = 0f
    var ballSpin = 0f

    // basket : qui tient le ballon, et vol (passe / tir)
    var holder: Player? = null
    var flKind = 0 // 0 aucun, 1 passe, 2 tir
    private var flT = 0f
    private var flDur = 0.5f
    private var fsx = 0f
    private var fsy = 0f
    private var fex = 0f
    private var fey = 0f
    private var flTarget: Player? = null
    private var flGood = false
    private var flPts = 2
    private var flTeam = 0

    // volley
    var lastTouch = 0

    val score = intArrayOf(0, 0)
    var timeLeft = level.target.toFloat()
    var overtime = false
    var phase = Phase.INTRO
    private var phaseT = 1.8f
    private var pendingOver = false
    var message = ""
    private var messageT = 0f
    var won = false
    var simTime = 0f
    private var lastScorer = 0

    /** Sons à jouer : 1 = frappe, 2 = point, 3 = victoire, 4 = défaite. */
    val sfx = ArrayDeque<Int>()

    init {
        setMessage("${level.sport.label} · vs ${level.opponent}", 1.8f)
        resetPositions(0)
    }

    fun hud(): Hud = Hud(
        score[0], score[1],
        if (sport == Sport.VOLLEY) -1 else max(0, timeLeft.toInt() + if (timeLeft > timeLeft.toInt()) 1 else 0),
        message, overtime, phase == Phase.OVER
    )

    fun stars(): Int {
        if (!won) return 0
        val diff = score[0] - score[1]
        return 1 + (if (diff >= level.margin2) 1 else 0) + (if (diff >= level.margin3) 1 else 0)
    }

    private fun setMessage(m: String, t: Float) {
        message = m
        messageT = t
    }

    private fun aiOf(p: Player): Float = if (p.team == 1) level.ai else 0.7f

    private fun isHuman(p: Player) = p === ps[ctrl]

    private fun dir(team: Int): Float = if (team == 0) 1f else -1f

    /** Panier que vise cette équipe (x). L'équipe 0 attaque à droite. */
    private fun hoopX(team: Int): Float = if (team == 0) Court.W - Court.HOOP_X else Court.HOOP_X

    private fun goalLineX(team: Int): Float = if (team == 0) Court.X1 else Court.X0

    // ───────────────────────── mise en place ─────────────────────────

    private fun resetPositions(serve: Int) {
        for (p in ps) {
            p.vx = 0f; p.vy = 0f; p.cool = 0f; p.actT = 0f; p.jumpT = 0f
            p.aiT = 0f; p.aiGo = false; p.aiGo2 = false
            p.mx = 0f; p.my = 0f; p.act = false; p.pass = false
            p.fx = dir(p.team); p.fy = 0f
        }
        holder = null
        flKind = 0
        bz = 0f; bvx = 0f; bvy = 0f; bvz = 0f
        switchT = 0f

        when (sport) {
            Sport.FOOT -> {
                for (p in ps) {
                    val d = dir(p.team)
                    when (p.slot) {
                        0 -> { p.x = 160f - d * 112f; p.y = Court.CY }
                        1 -> { p.x = 160f - d * (if (p.team == serve) 14f else 46f); p.y = Court.CY - 30f }
                        else -> { p.x = 160f - d * 46f; p.y = Court.CY + 34f }
                    }
                }
                bx = 160f; by = 90f
                ctrl = 1
            }
            Sport.BASKET -> {
                val d = dir(serve)
                for (p in ps) {
                    if (p.team == serve) {
                        p.x = 160f - d * (if (p.slot == 1) 52f else 74f)
                        p.y = Court.CY + (p.slot - 1) * 34f
                    } else {
                        p.x = 160f - d * (if (p.slot == 1) 30f else 42f)
                        p.y = Court.CY + (p.slot - 1) * 30f
                    }
                }
                holder = ps[serve * n + 1]
                val h = holder
                if (h != null) { bx = h.x; by = h.y }
                ctrl = 1
            }
            Sport.VOLLEY -> {
                for (p in ps) {
                    val d = dir(p.team)
                    if (p.slot == 0) { p.x = Court.NET_X - d * 54f; p.y = Court.CY - 28f }
                    else { p.x = Court.NET_X - d * 104f; p.y = Court.CY + 28f }
                }
                val server = ps[serve * n + 1]
                bx = server.x + dir(serve) * 6f
                by = server.y
                bz = 14f
                bvz = 70f
                lastTouch = serve
                ctrl = 1
            }
        }
    }

    // ───────────────────────── pas de simulation ─────────────────────────

    fun step(dt: Float) {
        if (phase == Phase.OVER) return
        simTime += dt
        messageT -= dt
        if (messageT <= 0f) message = ""
        ballSpin += (bvx + bvy) * dt * 0.1f

        when (phase) {
            Phase.INTRO -> {
                phaseT -= dt
                idle(dt)
                clearLatches()
                if (phaseT <= 0f) {
                    phase = Phase.PLAY
                    if (message.isNotEmpty() && messageT < 0.6f) message = ""
                }
            }
            Phase.SCORED -> {
                phaseT -= dt
                idle(dt)
                clearLatches()
                moveBall(dt, false)
                if (phaseT <= 0f) {
                    if (pendingOver) finish() else nextPoint()
                }
            }
            Phase.PLAY -> {
                chooseControlled(dt)
                for (p in ps) control(p, dt)
                for (p in ps) movePlayer(p, dt, speedOf(p))
                separate()
                for (p in ps) doAction(p)
                clearLatches()
                moveBall(dt, true)
                if (sport != Sport.VOLLEY && phase == Phase.PLAY && !overtime && flKind == 0) {
                    timeLeft -= dt
                    if (timeLeft <= 0f) {
                        timeLeft = 0f
                        if (score[0] != score[1]) {
                            pendingOver = true
                            phase = Phase.SCORED
                            phaseT = 1.3f
                            setMessage("FIN DU MATCH", 2f)
                        } else {
                            overtime = true
                            setMessage("PROLONGATION · prochain point gagne", 2.5f)
                        }
                    }
                }
            }
            Phase.OVER -> {}
        }
    }

    private fun idle(dt: Float) {
        for (p in ps) {
            p.mx = 0f; p.my = 0f; p.act = false; p.pass = false
            movePlayer(p, dt, 0f)
        }
    }

    private fun clearLatches() {
        input.actionLatch = false
        input.passLatch = false
    }

    private fun nextPoint() {
        val serve = if (sport == Sport.VOLLEY) lastScorer else 1 - lastScorer
        resetPositions(serve)
        phase = Phase.INTRO
        phaseT = 0.9f
    }

    private fun finish() {
        phase = Phase.OVER
        won = score[0] > score[1]
        sfx.addLast(if (won) 3 else 4)
        message = ""
    }

    private fun scoreFor(side: Int, pts: Int) {
        if (phase != Phase.PLAY) return
        score[side] += pts
        lastScorer = side
        phase = Phase.SCORED
        phaseT = 1.5f
        sfx.addLast(2)
        val who = if (side == 0) "TOI" else level.opponent.uppercase()
        when (sport) {
            Sport.FOOT -> setMessage("BUT ! · $who", 1.5f)
            Sport.BASKET -> setMessage("PANIER +$pts · $who", 1.5f)
            Sport.VOLLEY -> setMessage("POINT · $who", 1.5f)
        }
        pendingOver = when (sport) {
            Sport.VOLLEY -> score[side] >= level.target
            else -> overtime
        }
        flKind = 0
    }

    // ───────────────────────── joueur piloté ─────────────────────────

    private fun dist2(p: Player, x: Float, y: Float): Float {
        val dx = p.x - x
        val dy = p.y - y
        return dx * dx + dy * dy
    }

    private fun chooseControlled(dt: Float) {
        switchT -= dt
        if (switchT > 0f) return
        val h = holder
        if (sport == Sport.BASKET && h != null && h.team == 0) {
            val idx = ps.indexOf(h)
            if (idx != ctrl) { ctrl = idx; switchT = 0.2f }
            return
        }
        var rx = bx
        var ry = by
        if (sport == Sport.BASKET && h != null) { rx = h.x; ry = h.y }
        if (sport == Sport.VOLLEY) {
            val l = landing()
            if (l[0] >= Court.NET_X) return
            rx = l[0]; ry = l[1]
        }
        var best = ctrl
        var bd = dist2(ps[ctrl], rx, ry) - 80f
        for (i in 0 until n) {
            val d = dist2(ps[i], rx, ry)
            if (d < bd) { bd = d; best = i }
        }
        if (best != ctrl) { ctrl = best; switchT = 0.3f }
    }

    private fun speedOf(p: Player): Float {
        if (isHuman(p)) {
            return if (sport == Sport.BASKET && holder === p) 92f else 100f
        }
        return if (p.team == 0) 86f else 64f + 32f * level.ai
    }

    // ───────────────────────── commandes (joueur / IA) ─────────────────────────

    private fun control(p: Player, dt: Float) {
        p.act = false
        p.pass = false
        if (isHuman(p)) {
            p.mx = input.mx.coerceIn(-1f, 1f)
            p.my = input.my.coerceIn(-1f, 1f)
            p.act = input.action || input.actionLatch
            p.pass = input.pass || input.passLatch
            return
        }
        val a = aiOf(p)
        p.aiT -= dt
        if (p.aiT <= 0f) {
            p.aiT = 0.05f + (1f - a) * 0.2f
            p.aiGo = rnd.nextFloat() < 0.5f + 0.5f * a
            p.aiGo2 = rnd.nextFloat() < 0.10f + 0.20f * a
            when (sport) {
                Sport.FOOT -> thinkFoot(p, a)
                Sport.BASKET -> thinkBasket(p, a)
                Sport.VOLLEY -> thinkVolley(p, a)
            }
        }
        steer(p)
        when (sport) {
            Sport.FOOT -> actFootAi(p, a)
            Sport.BASKET -> actBasketAi(p, a)
            Sport.VOLLEY -> actVolleyAi(p)
        }
    }

    private fun steer(p: Player) {
        val dx = p.tx - p.x
        val dy = p.ty - p.y
        val d = hyp(dx, dy)
        if (d < 2f) {
            p.mx = 0f; p.my = 0f
        } else {
            val k = min(1f, d / 10f)
            p.mx = dx / d * k
            p.my = dy / d * k
        }
    }

    private fun movePlayer(p: Player, dt: Float, speed: Float) {
        var mx = p.mx
        var my = p.my
        val len = hyp(mx, my)
        if (len > 1f) { mx /= len; my /= len }
        val k = min(1f, 14f * dt)
        p.vx += (mx * speed - p.vx) * k
        p.vy += (my * speed - p.vy) * k
        p.x += p.vx * dt
        p.y += p.vy * dt
        clampPlayer(p)
        if (len > 0.15f) {
            val l = max(len, 0.001f)
            p.fx = p.mx / l
            p.fy = p.my / l
        }
        val sp = hyp(p.vx, p.vy)
        if (sp > 8f) p.runT += dt * 9f else p.runT = 0f
        p.cool -= dt
        p.actT -= dt
        p.jumpT -= dt
    }

    private fun clampPlayer(p: Player) {
        if (sport == Sport.VOLLEY) {
            val lo = if (p.team == 0) Court.VX0 - 16f else Court.NET_X + 8f
            val hi = if (p.team == 0) Court.NET_X - 8f else Court.VX1 + 16f
            p.x = p.x.coerceIn(lo, hi)
            p.y = p.y.coerceIn(Court.VY0 - 14f, Court.VY1 + 14f)
        } else {
            p.x = p.x.coerceIn(Court.X0 + 4f, Court.X1 - 4f)
            p.y = p.y.coerceIn(Court.Y0 + 4f, Court.Y1 - 4f)
        }
    }

    private fun separate() {
        for (i in ps.indices) {
            for (j in i + 1 until ps.size) {
                val a = ps[i]
                val b = ps[j]
                val dx = b.x - a.x
                val dy = b.y - a.y
                val d2 = dx * dx + dy * dy
                if (d2 < 64f && d2 > 0.0001f) {
                    val d = sqrt(d2)
                    val push = (8f - d) / 2f
                    val nx = dx / d
                    val ny = dy / d
                    a.x -= nx * push; a.y -= ny * push
                    b.x += nx * push; b.y += ny * push
                }
            }
        }
    }

    private fun doAction(p: Player) {
        if (p.cool > 0f) return
        if (!p.act && !p.pass) return
        when (sport) {
            Sport.FOOT -> {
                p.actT = 0.2f
                if (hyp(bx - p.x, by - p.y) < 11f) kickFoot(p, p.act) else p.cool = 0.12f
            }
            Sport.BASKET -> actBasket(p)
            Sport.VOLLEY -> {
                p.actT = 0.25f
                if (volleyReach(p)) hitVolley(p) else { p.cool = 0.2f; p.jumpT = 0.3f }
            }
        }
    }

    /** Choisit un coéquipier pour la passe : le plus aligné avec la direction (ou le plus avancé pour un bot). */
    private fun passTarget(p: Player, human: Boolean): Player? {
        var best: Player? = null
        var bs = -9f
        val d = dir(p.team)
        for (q in ps) {
            if (q.team != p.team || q === p) continue
            val ex = q.x - p.x
            val ey = q.y - p.y
            val dl = hyp(ex, ey)
            if (dl < 18f) continue
            val score = if (human) (p.fx * ex + p.fy * ey) / dl - dl * 0.0012f
            else (q.x - p.x) * d / 100f - dl * 0.004f + rnd.nextFloat() * 0.2f
            if (score > bs) { bs = score; best = q }
        }
        if (human && bs < 0.15f) return null
        return best
    }

    // ───────────────────────── FOOT ─────────────────────────

    /** Cible d'un tir : [x, y, assisté (1) ou non (0)]. */
    fun footShotTarget(p: Player, human: Boolean): FloatArray {
        val a = if (human) 1f else aiOf(p)
        val goalX = if (p.team == 0) Court.X1 + 4f else Court.X0 - 4f
        val tgx = goalX - bx
        val tgy = Court.CY - by
        val gl = max(1f, hyp(tgx, tgy))
        val cosA = (p.fx * tgx + p.fy * tgy) / gl
        if (cosA > 0.6f && gl < 190f) {
            val keeper = ps[(1 - p.team) * n]
            var ty = if (keeper.y < Court.CY) Court.GOAL_Y1 - 9f else Court.GOAL_Y0 + 9f
            if (!human) ty += (rnd.nextFloat() - 0.5f) * 2f * (1f - a) * 34f
            return floatArrayOf(goalX, ty, 1f)
        }
        return floatArrayOf(bx + p.fx * 60f, by + p.fy * 60f, 0f)
    }

    private fun kickFoot(p: Player, shot: Boolean) {
        val human = isHuman(p)
        var dx = p.fx
        var dy = p.fy
        var speed: Float
        if (shot) {
            val t = footShotTarget(p, human)
            dx = t[0] - bx
            dy = t[1] - by
            speed = 255f
        } else {
            val q = passTarget(p, human)
            if (q != null) {
                dx = q.x + q.vx * 0.35f - bx
                dy = q.y + q.vy * 0.35f - by
                val dl = hyp(dx, dy)
                speed = min(235f, 95f + dl * 1.25f)
            } else {
                speed = 175f
            }
        }
        val l = max(0.001f, hyp(dx, dy))
        bvx = dx / l * speed
        bvy = dy / l * speed
        p.cool = 0.35f
        sfx.addLast(1)
    }

    private fun thinkFoot(p: Player, a: Float) {
        val d = dir(p.team)
        val ownX = goalLineX(1 - p.team)
        val oppX = goalLineX(p.team)
        var chaser: Player? = null
        var cd = 1e9f
        for (q in ps) {
            if (q.team != p.team || isHuman(q)) continue
            val dd = dist2(q, bx, by)
            if (dd < cd) { cd = dd; chaser = q }
        }
        if (p === chaser) {
            if (sqrt(cd) < 12f) {
                p.tx = oppX
                p.ty = Court.CY + (by - Court.CY) * 0.35f
            } else {
                p.tx = bx + bvx * 0.25f
                p.ty = by + bvy * 0.25f
            }
        } else {
            when (p.slot) {
                0 -> {
                    p.tx = ownX + d * 56f
                    p.ty = (by * 0.5f + Court.CY * 0.5f).coerceIn(62f, 118f)
                }
                1 -> {
                    p.tx = (bx + d * 44f).coerceIn(52f, 268f)
                    p.ty = Court.CY - 42f + (by - Court.CY) * 0.3f
                }
                else -> {
                    p.tx = (bx + d * 30f).coerceIn(52f, 268f)
                    p.ty = Court.CY + 42f + (by - Court.CY) * 0.3f
                }
            }
        }
    }

    private fun actFootAi(p: Player, a: Float) {
        if (p.cool > 0f) return
        if (hyp(bx - p.x, by - p.y) > 10f) return
        val d = dir(p.team)
        val dg = abs(p.x - goalLineX(p.team))
        if (dg < 105f && p.aiGo && p.fx * d > 0.3f) {
            p.act = true
        } else if (p.slot == 0 && abs(p.x - goalLineX(1 - p.team)) < 80f && p.aiGo) {
            p.pass = true
        } else if (p.aiGo2) {
            var near = 999f
            for (q in ps) if (q.team != p.team) near = min(near, hyp(q.x - p.x, q.y - p.y))
            if (near < 24f) p.pass = true
        }
    }

    private fun moveBallFoot(dt: Float, scoring: Boolean) {
        val r = Court.BALL_R
        val f = max(0f, 1f - 1.15f * dt)
        bvx *= f
        bvy *= f
        bx += bvx * dt
        by += bvy * dt

        // joueurs : poussent et conduisent le ballon
        for (p in ps) {
            val dx = bx - p.x
            val dy = by - p.y
            val d = hyp(dx, dy)
            if (d < 8f && d > 0.01f) {
                val nx = dx / d
                val ny = dy / d
                bx = p.x + nx * 8f
                by = p.y + ny * 8f
                val rel = (bvx - p.vx) * nx + (bvy - p.vy) * ny
                if (rel < 0f) {
                    bvx -= rel * nx * 1.45f
                    bvy -= rel * ny * 1.45f
                }
                bvx += p.vx * 0.1f
                bvy += p.vy * 0.1f
            }
        }

        // murs et filets
        val inMouth = by > Court.GOAL_Y0 && by < Court.GOAL_Y1
        if (by < Court.Y0 + r) { by = Court.Y0 + r; bvy = abs(bvy) * 0.8f }
        if (by > Court.Y1 - r) { by = Court.Y1 - r; bvy = -abs(bvy) * 0.8f }
        if (!inMouth) {
            if (bx < Court.X0 + r) { bx = Court.X0 + r; bvx = abs(bvx) * 0.8f }
            if (bx > Court.X1 - r) { bx = Court.X1 - r; bvx = -abs(bvx) * 0.8f }
        } else {
            if (bx < Court.X0 - Court.GOAL_D + r) { bx = Court.X0 - Court.GOAL_D + r; bvx = abs(bvx) * 0.2f }
            if (bx > Court.X1 + Court.GOAL_D - r) { bx = Court.X1 + Court.GOAL_D - r; bvx = -abs(bvx) * 0.2f }
        }
        if (bx < Court.X0 || bx > Court.X1) by = by.coerceIn(Court.GOAL_Y0 + r, Court.GOAL_Y1 - r)

        val sp = hyp(bvx, bvy)
        if (sp > 300f) { bvx *= 300f / sp; bvy *= 300f / sp }

        if (!scoring) return
        if (bx < Court.X0 - r) scoreFor(1, 1)
        else if (bx > Court.X1 + r) scoreFor(0, 1)
    }

    // ───────────────────────── BASKET ─────────────────────────

    private fun grab(q: Player) {
        holder = q
        flKind = 0
        q.cool = 0.3f
        sfx.addLast(1)
    }

    private fun actBasket(p: Player) {
        val h = holder
        p.actT = 0.25f
        if (p.pass) {
            if (h === p) passBasket(p) else p.cool = 0.12f
            return
        }
        if (h === p) {
            shootBasket(p)
        } else if (h != null && h.team != p.team && hyp(p.x - h.x, p.y - h.y) < 11f) {
            val chance = if (isHuman(p)) 0.5f else 0.12f + 0.3f * aiOf(p)
            p.cool = 0.5f
            if (rnd.nextFloat() < chance) grab(p)
        } else {
            p.cool = 0.15f
        }
    }

    /** Chance de marquer si p tire maintenant (0..1). */
    fun shotChance(p: Player): Float {
        val human = isHuman(p)
        val hx = hoopX(p.team)
        val dist = hyp(hx - p.x, Court.CY - p.y)
        var chance = 0.95f - 0.0058f * dist
        if (human) chance += 0.12f else chance *= 0.72f + 0.35f * aiOf(p)
        var near = 999f
        for (q in ps) if (q.team != p.team) near = min(near, hyp(q.x - p.x, q.y - p.y))
        if (near < 12f) chance -= 0.22f else if (near < 20f) chance -= 0.10f
        return chance.coerceIn(0.06f, 0.95f)
    }

    private fun shootBasket(p: Player) {
        val hx = hoopX(p.team)
        val dist = hyp(hx - p.x, Court.CY - p.y)
        val chance = shotChance(p)
        holder = null
        flKind = 2
        flT = 0f
        flDur = 0.5f + dist / 360f
        fsx = p.x; fsy = p.y
        fex = hx; fey = Court.CY
        flGood = rnd.nextFloat() < chance
        flPts = if (dist > Court.ARC) 3 else 2
        flTeam = p.team
        flTarget = null
        p.cool = 0.5f
        sfx.addLast(1)
    }

    private fun passBasket(p: Player) {
        val q = passTarget(p, isHuman(p))
        p.cool = 0.4f
        if (q == null) return
        val tx = q.x + q.vx * 0.2f
        val ty = q.y + q.vy * 0.2f
        val dl = hyp(tx - p.x, ty - p.y)
        holder = null
        flKind = 1
        flT = 0f
        flDur = 0.22f + dl / 520f
        fsx = p.x; fsy = p.y
        fex = tx; fey = ty
        flTarget = q
        flTeam = p.team
        sfx.addLast(1)
    }

    private fun thinkBasket(p: Player, a: Float) {
        val h = holder
        val d = dir(p.team)
        val atkX = hoopX(p.team)
        val ownX = hoopX(1 - p.team)
        if (h == null) {
            var chaser: Player? = null
            var cd = 1e9f
            for (q in ps) {
                if (q.team != p.team || isHuman(q)) continue
                val dd = dist2(q, bx, by)
                if (dd < cd) { cd = dd; chaser = q }
            }
            if (p === chaser) {
                p.tx = bx; p.ty = by
            } else {
                p.tx = atkX - d * 90f
                p.ty = Court.CY + (p.slot - 1) * 44f
            }
        } else if (h.team == p.team) {
            if (p === h) {
                p.tx = atkX - d * 30f
                p.ty = Court.CY + (by - Court.CY) * 0.2f
            } else {
                p.tx = atkX - d * (50f + (if (p.slot == 1) 0f else 20f))
                p.ty = Court.CY + (p.slot - 1) * 52f
            }
        } else {
            var presser: Player? = null
            var pd = 1e9f
            for (q in ps) {
                if (q.team != p.team || isHuman(q)) continue
                val dd = dist2(q, h.x, h.y)
                if (dd < pd) { pd = dd; presser = q }
            }
            if (p === presser) {
                p.tx = h.x + (ownX - h.x) * 0.12f
                p.ty = h.y + (Court.CY - h.y) * 0.12f
            } else {
                var opp = ps[(1 - p.team) * n + p.slot]
                if (opp === h) opp = ps[(1 - p.team) * n + (p.slot + 1) % n]
                p.tx = opp.x + (ownX - opp.x) * 0.2f
                p.ty = opp.y + (Court.CY - opp.y) * 0.2f
            }
        }
    }

    private fun actBasketAi(p: Player, a: Float) {
        if (p.cool > 0f) return
        val h = holder
        if (h === p) {
            val dist = hyp(hoopX(p.team) - p.x, Court.CY - p.y)
            var near = 999f
            for (q in ps) if (q.team != p.team) near = min(near, hyp(q.x - p.x, q.y - p.y))
            if (dist < 48f + 40f * a && p.aiGo) p.act = true
            else if (near < 15f && p.aiGo2) p.pass = true
        } else if (h != null && h.team != p.team && hyp(p.x - h.x, p.y - h.y) < 10f && p.aiGo2) {
            p.act = true
        }
    }

    private fun moveBallBasket(dt: Float, scoring: Boolean) {
        val h = holder
        if (h != null) {
            bx = h.x + h.fx * 6f
            by = h.y + h.fy * 6f
            bz = 3f + abs(sin(simTime * 9f)) * 7f
            bvx = 0f; bvy = 0f; bvz = 0f
            return
        }
        if (flKind != 0) {
            flT += dt
            val t = min(1f, flT / flDur)
            bx = fsx + (fex - fsx) * t
            by = fsy + (fey - fsy) * t
            bz = (if (flKind == 2) 30f else 7f) * sin(t * 3.14159f) + 6f
            if (flKind == 1 && scoring) {
                for (q in ps) {
                    if (q.team == flTeam) continue
                    if (t > 0.15f && t < 0.9f && hyp(q.x - bx, q.y - by) < 7f) {
                        grab(q)
                        return
                    }
                }
            }
            if (t >= 1f) arrive(scoring)
            return
        }
        // ballon libre
        val f = max(0f, 1f - 2.2f * dt)
        bvx *= f
        bvy *= f
        bx += bvx * dt
        by += bvy * dt
        bz = max(0f, bz - 30f * dt)
        val r = Court.BALL_R
        if (bx < Court.X0 + r) { bx = Court.X0 + r; bvx = abs(bvx) * 0.6f }
        if (bx > Court.X1 - r) { bx = Court.X1 - r; bvx = -abs(bvx) * 0.6f }
        if (by < Court.Y0 + r) { by = Court.Y0 + r; bvy = abs(bvy) * 0.6f }
        if (by > Court.Y1 - r) { by = Court.Y1 - r; bvy = -abs(bvy) * 0.6f }
        if (scoring) {
            var best: Player? = null
            var bd = 49f
            for (q in ps) {
                val dd = dist2(q, bx, by)
                if (dd < bd) { bd = dd; best = q }
            }
            if (best != null) grab(best)
        }
    }

    private fun arrive(scoring: Boolean) {
        val kind = flKind
        flKind = 0
        if (kind == 1) {
            val q = flTarget
            if (q != null && hyp(q.x - bx, q.y - by) < 16f) {
                grab(q)
            } else {
                bvx = 0f; bvy = 0f
            }
            return
        }
        // tir
        if (flGood && scoring) {
            scoreFor(flTeam, flPts)
            bz = 0f
        } else {
            val away = if (fex < 160f) 1f else -1f
            bvx = away * (40f + rnd.nextFloat() * 50f)
            bvy = (rnd.nextFloat() - 0.5f) * 90f
            bz = 6f
            sfx.addLast(1)
        }
    }

    // ───────────────────────── VOLLEY ─────────────────────────

    /** Point d'atterrissage prévu du ballon : [x, y]. */
    fun landing(): FloatArray {
        val g = 150f
        val disc = bvz * bvz + 2f * g * max(0f, bz)
        val t = (bvz + sqrt(disc)) / g
        return floatArrayOf(bx + bvx * max(0f, t), by + bvy * max(0f, t))
    }

    private fun volleyReach(p: Player): Boolean {
        if ((bx < Court.NET_X) != (p.team == 0)) return false
        return hyp(bx - p.x, by - p.y) < 15f && bz < 28f
    }

    /** Cible conseillée d'une frappe de volley : [x, y]. Le joystick oriente (côté, court / long). */
    fun volleyTarget(p: Player): FloatArray {
        val d = dir(p.team)
        val x0 = if (p.team == 0) Court.NET_X + 22f else Court.VX0 + 8f
        val x1 = if (p.team == 0) Court.VX1 - 8f else Court.NET_X - 22f
        val y0 = Court.VY0 + 8f
        val y1 = Court.VY1 - 8f
        val human = isHuman(p)
        var tx = (x0 + x1) / 2f
        var ty = Court.CY
        var bs = -1e9f
        for (a in 0..5) {
            for (b in 0..5) {
                val cx = x0 + (x1 - x0) * a / 5f
                val cy = y0 + (y1 - y0) * b / 5f
                var sc = 1e9f
                for (q in ps) if (q.team != p.team) sc = min(sc, hyp(q.x - cx, q.y - cy))
                if (human) {
                    if (hyp(p.mx, p.my) > 0.3f) sc -= abs(cy - (Court.CY + p.my * 50f)) * 1.2f
                    if (p.mx * d > 0.5f) sc -= abs(cx - (Court.NET_X + d * 32f)) * 0.9f
                    else if (p.mx * d < -0.5f) sc -= abs(cx - (if (p.team == 0) x1 else x0)) * 0.9f
                }
                if (sc > bs) { bs = sc; tx = cx; ty = cy }
            }
        }
        return floatArrayOf(tx, ty)
    }

    private fun hitVolley(p: Player) {
        val human = isHuman(p)
        val a = if (human) 1f else aiOf(p)
        val tg = volleyTarget(p)
        var tx = tg[0]
        var ty = tg[1]
        val err = if (human) 3f else 4f + (1f - a) * 30f
        tx += (rnd.nextFloat() - 0.5f) * 2f * err
        ty += (rnd.nextFloat() - 0.5f) * 2f * err

        val g = 150f
        val smash = bz > 12f
        var t = if (smash) 0.62f else 1.0f
        var guard = 0
        while (true) {
            val vx = (tx - bx) / t
            val vy = (ty - by) / t
            val vz = (0.5f * g * t * t - bz) / t
            var ok = true
            if (abs(vx) > 1f) {
                val tn = (Court.NET_X - bx) / vx
                if (tn > 0f && tn < t) {
                    val zn = bz + vz * tn - 0.5f * g * tn * tn
                    ok = zn > Court.NET_H + 5f
                }
            }
            guard++
            if (ok || guard > 24) {
                bvx = vx; bvy = vy; bvz = vz
                break
            }
            t += 0.07f
        }
        lastTouch = p.team
        p.cool = 0.3f
        p.jumpT = if (smash) 0.45f else 0.25f
        sfx.addLast(1)
    }

    private fun voHome(p: Player): FloatArray {
        val d = dir(p.team)
        return if (p.slot == 0) floatArrayOf(Court.NET_X - d * 54f, Court.CY - 28f)
        else floatArrayOf(Court.NET_X - d * 104f, Court.CY + 28f)
    }

    private fun thinkVolley(p: Player, a: Float) {
        val home = voHome(p)
        val l = landing()
        val onMine = (l[0] < Court.NET_X) == (p.team == 0)
        if (!onMine) {
            p.tx = home[0]
            p.ty = home[1] + (by - Court.CY) * 0.2f
            return
        }
        var chaser: Player? = null
        var cd = 1e9f
        for (q in ps) {
            if (q.team != p.team || isHuman(q)) continue
            val dd = dist2(q, l[0], l[1])
            if (dd < cd) { cd = dd; chaser = q }
        }
        if (p === chaser) {
            p.tx = l[0] + (rnd.nextFloat() - 0.5f) * (1f - a) * 24f
            p.ty = l[1] + (rnd.nextFloat() - 0.5f) * (1f - a) * 24f
        } else {
            p.tx = home[0]
            p.ty = home[1]
        }
    }

    private fun actVolleyAi(p: Player) {
        if (p.cool > 0f) return
        if (p.aiGo && volleyReach(p) && bvz < 40f) p.act = true
    }

    private fun moveBallVolley(dt: Float, scoring: Boolean) {
        val g = 150f
        val px = bx
        bvz -= g * dt
        bx += bvx * dt
        by += bvy * dt
        bz += bvz * dt

        // filet
        if ((px - Court.NET_X) * (bx - Court.NET_X) < 0f && by > Court.VY0 - 10f && by < Court.VY1 + 10f && bz < Court.NET_H) {
            bx = if (px < Court.NET_X) Court.NET_X - 2f else Court.NET_X + 2f
            bvx = -bvx * 0.25f
            bvy *= 0.5f
            bvz = min(bvz, 0f)
            if (scoring) {
                setMessage("FILET !", 1.2f)
                scoreFor(1 - lastTouch, 1)
            }
        }
        if (bz <= 0f) {
            bz = 0f
            if (scoring) {
                val inb = bx >= Court.VX0 && bx <= Court.VX1 && by >= Court.VY0 && by <= Court.VY1
                val winner = if (inb) (if (bx < Court.NET_X) 1 else 0) else 1 - lastTouch
                scoreFor(winner, 1)
            }
            if (bvz < -25f) bvz = -bvz * 0.35f else bvz = 0f
            bvx *= 0.7f
            bvy *= 0.7f
        }
        if (bx < 4f) { bx = 4f; bvx = abs(bvx) * 0.5f }
        if (bx > Court.W - 4f) { bx = Court.W - 4f; bvx = -abs(bvx) * 0.5f }
        if (by < 4f) { by = 4f; bvy = abs(bvy) * 0.5f }
        if (by > Court.H - 4f) { by = Court.H - 4f; bvy = -abs(bvy) * 0.5f }
    }

    // ───────────────────────── ballon ─────────────────────────

    private fun moveBall(dt: Float, scoring: Boolean) {
        when (sport) {
            Sport.FOOT -> moveBallFoot(dt, scoring)
            Sport.BASKET -> moveBallBasket(dt, scoring)
            Sport.VOLLEY -> moveBallVolley(dt, scoring)
        }
    }

    // ───────────────────────── aide à la visée (affichage) ─────────────────────────

    /** Cible conseillée pour le joueur piloté : [x, y, force 0..1] ou null s'il n'y a rien à viser. */
    fun aimHint(): FloatArray? {
        if (phase != Phase.PLAY) return null
        val p = ps[ctrl]
        return when (sport) {
            Sport.FOOT ->
                if (hyp(bx - p.x, by - p.y) > 14f) null else footShotTarget(p, true)
            Sport.BASKET ->
                if (holder !== p) null else floatArrayOf(hoopX(0), Court.CY, shotChance(p))
            Sport.VOLLEY ->
                if (!volleyReach(p)) null
                else volleyTarget(p).let { floatArrayOf(it[0], it[1], 1f) }
        }
    }
}
