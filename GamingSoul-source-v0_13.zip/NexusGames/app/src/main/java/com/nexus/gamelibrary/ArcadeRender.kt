package com.nexus.gamelibrary

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * Rendu très haute définition : les joueurs et les ballons sont dessinés sur une grille
 * 4 fois plus fine que le terrain (quarts de pixel), soit 16 fois plus de pixels par sprite.
 * Le dessin reste décrit en « unités de dessin » (1/2 pixel) ; chaque unité est échantillonnée
 * en SS x SS cellules, ce qui permet des contours fins, des coins arrondis et des membres
 * inclinés (poses d'action : tir, passe, tacle, smash, contre, etc.).
 */

internal fun Px.h(x: Int, y: Int, w: Int, hh: Int, c: Color) = r(x / 2f, y / 2f, w / 2f, hh / 2f, c)

internal class Look(
    val skin: Color, val skinSh: Color, val hair: Color, val hairHi: Color, val hairStyle: Int,
    val jersey: Color, val jerseyDark: Color, val stripe: Color, val pattern: Int,
    val shorts: Color, val sock: Color, val sleeve: Color, val number: Int, val accessory: Int
)

private val oppKitsHd = listOf(0xFFE23B3B, 0xFFFF8A00, 0xFF9A3BE2, 0xFF16A085, 0xFFD4AF37)
private val oppKitsDarkHd = listOf(0xFFA82424, 0xFFC26A00, 0xFF7026A8, 0xFF0E7A64, 0xFFA88A1E)
private val Ink = Color(0xFF14141C)

internal fun skinLook(s: Skin): Look {
    val k = Cosmetics.kitColors[s.kitColor]
    val k2 = Cosmetics.kitColors[s.kit2Color]
    val sh = Cosmetics.kitColors[s.shortsColor]
    val hc = Cosmetics.hairColors[s.hairColor]
    val st = Cosmetics.skinTones[s.skinTone]
    return Look(
        Color(st.color), Color(st.color2), Color(hc.color), Color(hc.color2), s.hairStyle,
        Color(k.color), Color(k.color2), Color(k2.color), s.kitPattern,
        Color(sh.color), Color(k.color), Color(k.color), s.number, s.accessory
    )
}

/** Apparence d'un joueur du match (toi : ton skin ; coéquipiers : même maillot ; adversaires : couleurs de la division). */
private fun lookOf(m: Match, p: Player, skin: Skin): Look {
    val keeper = m.sport == Sport.FOOT && p.slot == 0
    val mateHair = Cosmetics.hairColors
    if (p.team == 0) {
        val base = skinLook(skin)
        val me = p.slot == 1
        val hs = if (me) skin.hairStyle else (p.slot + 1) % 3
        val hcI = if (me) skin.hairColor else (p.slot * 2 + 1) % 4
        val skI = if (me) skin.skinTone else (p.slot * 2 + 1) % 4
        val sk = Cosmetics.skinTones[skI]
        val hc = mateHair[hcI]
        val jersey = if (keeper) Color(0xFFFFB300) else base.jersey
        val dark = if (keeper) Color(0xFFC98400) else base.jerseyDark
        return Look(
            Color(sk.color), Color(sk.color2), Color(hc.color), Color(hc.color2), hs,
            jersey, dark, if (keeper) Color(0xFFFFD66B) else base.stripe, if (keeper) 0 else skin.kitPattern,
            if (keeper) Ink else base.shorts, if (m.sport == Sport.BASKET) Color(0xFFF2F2F2) else jersey,
            if (keeper) Color.White else if (m.sport == Sport.BASKET) Color(sk.color) else jersey,
            if (me) skin.number else (p.slot * 7 + 3) % 99, if (me) skin.accessory else 0
        )
    }
    val d = m.level.division.coerceIn(0, 4)
    val sk = Cosmetics.skinTones[(p.slot * 2 + 3) % 4]
    val hc = mateHair[(p.slot + 2) % 4]
    val jersey = if (keeper) Color(0xFF3DDC84) else Color(oppKitsHd[d])
    val dark = if (keeper) Color(0xFF22A35E) else Color(oppKitsDarkHd[d])
    return Look(
        Color(sk.color), Color(sk.color2), Color(hc.color), Color(hc.color2), (p.slot + 2) % 3,
        jersey, dark, Color(0xFFF4F4F8), 0, if (keeper) Ink else Color(0xFF2B2B33),
        if (m.sport == Sport.BASKET) Color(0xFFF2F2F2) else jersey,
        if (keeper) Color.White else if (m.sport == Sport.BASKET) Color(sk.color) else jersey, (p.slot * 5 + 4) % 99, 0
    )
}

private val digits = listOf(
    "111101101101111", "010110010010111", "111001111100111", "111001111001111", "101101111001001",
    "111100111001111", "111100111101111", "111001001001001", "111101111101111", "111101111001111"
)

private fun lum(c: Color) = 0.3f * c.red + 0.59f * c.green + 0.11f * c.blue

private fun dk(c: Color, f: Float) = Color((c.red * f).coerceIn(0f, 1f), (c.green * f).coerceIn(0f, 1f), (c.blue * f).coerceIn(0f, 1f), 1f)

private fun mix(a: Color, b: Color, t: Float) =
    Color(a.red + (b.red - a.red) * t, a.green + (b.green - a.green) * t, a.blue + (b.blue - a.blue) * t, 1f)

// Tampon du sprite : SS x SS cellules par unité de dessin (1 cellule = 1/4 de pixel du terrain).
private const val SS = 2
private const val BW = 56
private const val BH = 70
private const val BCX = 28
private const val BBASE = 62
private const val CW = BW * SS
private const val CH = BH * SS
private val buf = IntArray(CW * CH)
private val tmp = IntArray(CW * CH)
private val outBuf = IntArray(CW * CH)
private val usedStamp = IntArray(CW * CH)
private var stampNo = 0

// rectangle englobant du sprite en cours (en cellules) : limite le travail de contour / fusion
private var bbX0 = 0
private var bbX1 = -1
private var bbY0 = 0
private var bbY1 = -1

private val ballBuf = IntArray(28 * 28)

/** Pose d'un joueur (calculée à chaque image selon l'action en cours). Unités de dessin, x vers l'avant. */
internal class Pose {
    var lean = 0f        // haut du corps penché vers l'avant (vue de profil)
    var crouch = 0f      // haut du corps abaissé (genoux fléchis)
    var lift = 0f        // saut supplémentaire (pixels du terrain)
    var arms = false     // bras dessinés d'après a1 / a2
    var together = false // les deux mains au même endroit (réception, passe, contre…)
    var a1r = 0f; var a1y = 0f   // bras proche : portée vers l'avant, hauteur relative à l'épaule (négatif = en haut)
    var a2r = 0f; var a2y = 0f   // bras éloigné
    var kick = false     // une jambe libre (frappe, passe, tacle)
    var slide = false
    var kx = 0f; var ky = 0f     // position du pied libre

    fun clear() {
        lean = 0f; crouch = 0f; lift = 0f; arms = false; together = false
        a1r = 0f; a1y = 0f; a2r = 0f; a2y = 0f; kick = false; slide = false; kx = 0f; ky = 0f
    }
}

private val NO_POSE = Pose()
private val poseBuf = Pose()

private class Spr(val sg: Int) {
    /** Décalage du haut du corps (unités de dessin) : penché vers l'avant / accroupi. */
    var shx = 0f
    var shy = 0f

    private fun put(cx: Int, cy: Int, ci: Int) {
        if (cx in 0 until CW && cy in 0 until CH) {
            buf[cy * CW + cx] = ci
            if (cx < bbX0) bbX0 = cx
            if (cx > bbX1) bbX1 = cx
            if (cy < bbY0) bbY0 = cy
            if (cy > bbY1) bbY1 = cy
        }
    }

    fun box(dx: Int, y: Int, w: Int, hh: Int, c: Color) {
        val ci = c.toArgb() or (0xFF shl 24)
        val xd = if (sg > 0) BCX + dx else BCX - dx - w
        val cx0 = xd * SS + (shx * SS).roundToInt() * sg
        val cy0 = (BBASE + y) * SS + (shy * SS).roundToInt()
        for (j in 0 until hh * SS) for (i in 0 until w * SS) put(cx0 + i, cy0 + j, ci)
    }

    /** Segment épais de (x0,y0) à (x1,y1), en deux couleurs : c1 sur la première part (split), puis c2. */
    fun limb(x0: Float, y0: Float, x1: Float, y1: Float, thick: Float, c1: Color, c2: Color, split: Float = 0.5f, follow: Boolean = true) {
        val i1 = c1.toArgb() or (0xFF shl 24)
        val i2 = c2.toArgb() or (0xFF shl 24)
        val offX = if (follow) shx else 0f
        val offY = if (follow) shy else 0f
        val len = sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0))
        val n = max(2, (len * SS * 1.5f).toInt())
        val half = thick / 2f
        for (k in 0..n) {
            val t = k / n.toFloat()
            val x = x0 + (x1 - x0) * t + offX
            val y = y0 + (y1 - y0) * t + offY
            val xc = BCX + sg * x
            val ci = if (t < split) i1 else i2
            val xa = ((xc - half) * SS).roundToInt()
            val xb = ((xc + half) * SS).roundToInt()
            val ya = ((BBASE + y - half) * SS).roundToInt()
            val yb = ((BBASE + y + half) * SS).roundToInt()
            for (yy in ya until yb) for (xx in xa until xb) put(xx, yy, ci)
        }
    }

    fun number(n: Int, y: Int, c: Color) {
        val s = n.coerceIn(0, 99).toString()
        var x0 = -(s.length * 4 - 1) / 2
        for (ch in s) {
            val g = digits[ch - '0']
            for (j in 0 until 5) for (i in 0 until 3) if (g[j * 3 + i] == '1') box(x0 + i, y + j, 1, 1, c)
            x0 += 4
        }
    }
}

private fun shadeInt(v: Int, f: Float): Int {
    val r = (((v shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
    val g = (((v shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
    val b = ((v and 0xFF) * f).toInt().coerceIn(0, 255)
    return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
}

/**
 * Dessine un tableau de cellules (ARGB, 0 = transparent) en fusionnant les cellules voisines de même couleur
 * en grands rectangles (peu d'appels de dessin). (x0, y0) = coin en unités du terrain, unit = taille d'une cellule.
 */
internal fun Px.blitCells(
    a: IntArray, w: Int, hgt: Int, x0: Float, y0: Float, unit: Float,
    ia: Int = 0, ib: Int = w - 1, ja: Int = 0, jb: Int = hgt - 1
) {
    stampNo++
    val st = stampNo
    for (j in ja..jb) {
        var i = ia
        while (i <= ib) {
            val idx = j * w + i
            val v = a[idx]
            if (v == 0 || usedStamp[idx] == st) { i++; continue }
            var k = i + 1
            while (k <= ib && a[j * w + k] == v && usedStamp[j * w + k] != st) k++
            var m = j + 1
            while (m <= jb) {
                var same = true
                for (q in i until k) {
                    if (a[m * w + q] != v || usedStamp[m * w + q] == st) { same = false; break }
                }
                if (!same) break
                m++
            }
            for (jj in j until m) for (q in i until k) usedStamp[jj * w + q] = st
            r(x0 + i * unit, y0 + j * unit, (k - i) * unit, (m - j) * unit, Color(v))
            i = k
        }
    }
}

/** Envoie le tampon à l'écran : coins arrondis, contour noir fin, lumière en haut à gauche, ombre en bas à droite. */
private fun Px.flush(cxC: Int, baseC: Int) {
    if (bbX1 < 0) return
    // position des pieds en quarts de pixel du terrain
    val x0 = cxC * 0.25f - BCX * 0.5f
    val y0 = baseC * 0.25f - BBASE * 0.5f
    val xa = max(0, bbX0 - 2)
    val xb = min(CW - 1, bbX1 + 2)
    val ya = max(0, bbY0 - 2)
    val yb = min(CH - 1, bbY1 + 2)

    // 1. coins de la silhouette légèrement arrondis (sur les formes assez grandes)
    System.arraycopy(buf, 0, tmp, 0, buf.size)
    fun t(i: Int, j: Int) = if (i in 0 until CW && j in 0 until CH) tmp[j * CW + i] else 0
    for (j in ya..yb) for (i in xa..xb) {
        if (tmp[j * CW + i] == 0) continue
        val el = t(i - 1, j) == 0
        val er = t(i + 1, j) == 0
        val eu = t(i, j - 1) == 0
        val ed = t(i, j + 1) == 0
        if (!(el || er || eu || ed)) continue
        var cut = false
        if (eu && el && t(i + 1, j) != 0 && t(i + 2, j) != 0 && t(i, j + 1) != 0 && t(i, j + 2) != 0) cut = true
        if (eu && er && t(i - 1, j) != 0 && t(i - 2, j) != 0 && t(i, j + 1) != 0 && t(i, j + 2) != 0) cut = true
        if (ed && el && t(i + 1, j) != 0 && t(i + 2, j) != 0 && t(i, j - 1) != 0 && t(i, j - 2) != 0) cut = true
        if (ed && er && t(i - 1, j) != 0 && t(i - 2, j) != 0 && t(i, j - 1) != 0 && t(i, j - 2) != 0) cut = true
        if (cut) buf[j * CW + i] = 0
    }

    // 2. contour fin + ombrage (lumière en haut à gauche)
    java.util.Arrays.fill(outBuf, 0)
    fun b(i: Int, j: Int) = if (i in 0 until CW && j in 0 until CH) buf[j * CW + i] else 0
    val outline = 0xE6101018L.toInt()
    for (j in ya..yb) for (i in xa..xb) {
        val v = buf[j * CW + i]
        if (v == 0) {
            if (b(i - 1, j) != 0 || b(i + 1, j) != 0 || b(i, j - 1) != 0 || b(i, j + 1) != 0) outBuf[j * CW + i] = outline
        } else {
            outBuf[j * CW + i] = when {
                b(i, j - SS) == 0 || b(i - SS, j) == 0 -> shadeInt(v, 1.14f)
                b(i + SS, j) == 0 || b(i, j + SS) == 0 -> shadeInt(v, 0.8f)
                else -> v
            }
        }
    }
    blitCells(outBuf, CW, CH, x0, y0, 0.25f, xa, xb, ya, yb)
}

private fun ease(t: Float): Float { val c = t.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }

private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t.coerceIn(0f, 1f)

/**
 * Pose du joueur selon son action : un geste différent par sport et par action.
 *  Foot : frappe, passe du plat du pied, tacle glissé, relevé, arrêt / repousse / lancer du gardien.
 *  Basket : dribble, tir en suspension (poignet), passe à deux mains, vol (balayage), contre (bras tendus).
 *  Volley : réception (bras joints), passe (mains au front), smash (bras armé puis frappe), service, plongeon.
 *  Fin de point : joie (bras levés + sauts) ou déception.
 */
internal fun poseFor(po: Pose, m: Match, p: Player, tick: Int): Pose {
    po.clear()
    val ap = if (p.anim != 0 && p.animT > 0f && p.animDur > 0f) (1f - p.animT / p.animDur).coerceIn(0f, 1f) else 1f
    val e = ease(ap)
    val pi = 3.14159f
    val sn = sin(ap * pi)
    if (p.anim != 0 && p.animT > 0f) {
        when (p.anim) {
            Anim.SHOT -> {
                po.kick = true
                po.kx = lerp(10.5f, -0.5f, e)
                po.ky = lerp(-8f, -2f, e) - 7f * sn
                po.lean = -2f * (1f - ap) + 2.5f * sn
                po.arms = true
                po.a1r = lerp(-7f, 0f, ap); po.a1y = lerp(2f, 10f, ap)
                po.a2r = lerp(7f, 0f, ap); po.a2y = lerp(0f, 10f, ap)
            }
            Anim.PASS_FOOT -> {
                po.kick = true
                po.kx = lerp(7f, -0.5f, e)
                po.ky = lerp(-6f, -2f, e) - 3f * sn
                po.lean = 0.8f * sn
                po.arms = true
                po.a1r = lerp(5f, 0f, ap); po.a1y = lerp(6f, 10f, ap)
                po.a2r = lerp(-4f, 0f, ap); po.a2y = lerp(5f, 10f, ap)
            }
            Anim.TACKLE -> {
                po.slide = true
                po.kick = true
                po.crouch = 12f
                po.lean = -6f
                po.kx = 16f; po.ky = -4f
                po.arms = true
                po.a1r = -9f; po.a1y = -2f
                po.a2r = -6f; po.a2y = 3f
            }
            Anim.K_CATCH -> {
                po.arms = true; po.together = true
                po.a1r = lerp(9f, 3f, e); po.a1y = lerp(-6f, 7f, e)
                po.crouch = lerp(3f, 0f, ap)
            }
            Anim.K_PARRY -> {
                po.arms = true
                po.a1r = lerp(10f, 4f, ap); po.a1y = lerp(-13f, 6f, ap)
                po.a2r = lerp(-3f, 0f, ap); po.a2y = lerp(-8f, 10f, ap)
                po.lean = 2f * (1f - ap)
            }
            Anim.K_THROW -> {
                po.arms = true
                po.a1r = lerp(10f, 2f, ap); po.a1y = lerp(-6f, 10f, ap)
                po.a2r = lerp(-2f, 0f, ap); po.a2y = lerp(-12f, 10f, ap)
                po.lean = lerp(3f, 0f, ap)
            }
            Anim.JUMPSHOT -> {
                po.arms = true
                if (ap < 0.48f) {
                    val tt = ap / 0.48f
                    po.together = true
                    po.a1r = lerp(4f, 7f, ease(tt)); po.a1y = lerp(-5f, -16f, ease(tt))
                    po.lean = tt
                    po.crouch = lerp(3f, 0f, tt)
                } else {
                    val tt = (ap - 0.48f) / 0.52f
                    po.a1r = lerp(9f, 6f, tt); po.a1y = lerp(-17f, -9f, tt)
                    po.a2r = lerp(2f, 0f, tt); po.a2y = lerp(-12f, 10f, tt)
                    po.lean = lerp(1f, 0f, tt)
                }
            }
            Anim.CHEST_PASS -> {
                po.arms = true; po.together = true
                po.a1r = lerp(10f, 3f, e); po.a1y = lerp(-1f, 6f, e)
                po.lean = lerp(2f, 0f, ap)
            }
            Anim.STEAL -> {
                po.arms = true
                po.a1r = lerp(11f, 5f, e); po.a1y = lerp(-3f, 9f, e)
                po.a2r = -3f; po.a2y = 6f
                po.lean = lerp(3f, 0f, ap)
                po.crouch = lerp(2f, 0f, ap)
            }
            Anim.BLOCK -> {
                po.arms = true
                po.a1r = 2f; po.a2r = 2f
                po.a1y = if (ap < 0.65f) -17f else lerp(-17f, 10f, (ap - 0.65f) / 0.35f)
                po.a2y = po.a1y
                po.lean = 1f
                po.lift = 2.5f * sn
            }
            Anim.BUMP -> {
                po.arms = true; po.together = true
                po.a1r = lerp(7f, 1f, ap)
                po.a1y = if (ap < 0.5f) lerp(8f, -1f, ap * 2f) else lerp(-1f, 10f, (ap - 0.5f) * 2f)
                po.crouch = lerp(5f, 0f, ap)
                po.lean = lerp(2f, 0f, ap)
            }
            Anim.SET -> {
                po.arms = true; po.together = true
                po.a1r = 3f
                po.a1y = if (ap < 0.45f) lerp(-13f, -17f, ap / 0.45f) else lerp(-17f, 10f, (ap - 0.45f) / 0.55f)
                po.crouch = lerp(3f, 0f, ap)
            }
            Anim.SMASH -> {
                val s1 = min(1f, ap * 2f)
                val s2 = max(0f, (ap - 0.5f) * 2f)
                po.arms = true
                po.a1r = lerp(lerp(6f, 10f, s1), 0f, s2)
                po.a1y = lerp(lerp(-17f, 4f, s1), 10f, s2)
                po.a2r = lerp(-3f, 0f, ap); po.a2y = lerp(-12f, 10f, ap)
                po.lean = lerp(3.5f, 0f, ap)
                po.lift = 3f * sn
            }
            Anim.SERVE -> {
                val s1 = min(1f, ap * 2f)
                val s2 = max(0f, (ap - 0.5f) * 2f)
                po.arms = true
                po.a1r = lerp(lerp(4f, 9f, s1), 0f, s2)
                po.a1y = lerp(lerp(-17f, 3f, s1), 10f, s2)
                po.a2r = lerp(2f, 0f, ap); po.a2y = lerp(-14f, 10f, ap)
                po.lean = lerp(2f, 0f, ap)
            }
            Anim.LUNGE -> {
                po.arms = true; po.together = true
                po.a1r = lerp(10f, 2f, ap); po.a1y = lerp(5f, 10f, ap)
                po.crouch = lerp(6f, 0f, ap)
                po.lean = lerp(4f, 0f, ap)
            }
            Anim.CELEBRATE -> {
                po.arms = true
                val w = sin(tick * 0.5f) * 2f
                po.a1r = 8f; po.a1y = -15f + w
                po.a2r = 8f; po.a2y = -15f - w
                po.lift = abs(sin(ap * pi * 4f)) * 5f
            }
            Anim.SAD -> {
                po.crouch = 3f
                po.lean = -1.5f
            }
        }
        return po
    }

    // poses sans action en cours
    if (m.sport == Sport.FOOT && p.stunT > 0f) { // au sol après un tacle, puis se relève
        po.crouch = min(9f, p.stunT * 18f)
        po.lean = -1.5f
        return po
    }
    if (m.sport == Sport.BASKET && m.holder === p && p.windT <= 0f) { // dribble : la main suit le rebond
        val k = ((m.bz - 3f) / 7f).coerceIn(0f, 1f)
        po.arms = true
        po.a1r = 6f + 2f * k; po.a1y = 13f - 6f * k
        po.a2r = -2f; po.a2y = 7f
        po.crouch = 1.5f
        po.lean = 1.5f
        return po
    }
    if (p.runT > 0f && m.sport != Sport.VOLLEY) po.lean = 1.2f // course penchée vers l'avant
    return po
}

/** Dessine un joueur en haute définition (style « chibi » détaillé). (px, py) = pieds en unités du terrain. */
internal fun Px.drawLook(
    px: Float, py: Float, lk: Look, fx: Float, fy: Float, step: Int, lift: Float, armsUp: Boolean = false, kind: Int = 0, keeper: Boolean = false,
    pose: Pose? = null
) {
    java.util.Arrays.fill(buf, 0)
    bbX0 = CW; bbX1 = -1; bbY0 = CH; bbY1 = -1
    val po = pose ?: NO_POSE
    val cxC = (px * 4f).roundToInt()
    val baseC = (py * 4f).roundToInt() - (lift * 4f).roundToInt()
    val side = abs(fy) <= abs(fx) + 0.05f
    val back = !side && fy < 0f
    val sg = if (side && fx < 0f) -1 else 1
    val s = Spr(sg)
    val shoe = Color(0xFFF4F4F8)
    val sole = Color(0xFF3A3A46)
    val gold = Color(0xFFFFD24A)
    val mouth = Color(0xFF9A3A3A)
    val white = Color.White
    val hairD = dk(lk.hair, 0.7f)
    val blush = mix(lk.skin, Color(0xFFFF6A6A), 0.35f)
    with(s) {
        val kick = po.kick
        val lo = if (kick && !side) 4 else if (step == 1) 2 else 0
        val ro = if (step == 2) 2 else 0

        // ── jambes, chaussettes, chaussures
        if (kick && side) {
            // frappe / passe / tacle : jambe d'appui + jambe libre (segment incliné)
            val hipY = -11f + po.crouch * 0.7f
            if (po.slide) {
                limb(0f, hipY, -7f, -2f, 3f, lk.sock, shoe, 0.8f, false)
            } else {
                box(-2, -10, 3, 1, lk.skin); box(-2, -9, 3, 6, lk.sock); box(-2, -9, 3, 1, lk.stripe)
                box(-2, -3, 5, 3, shoe); box(-2, -1, 5, 1, sole); box(0, -3, 2, 1, lk.stripe)
            }
            limb(0f, hipY, po.kx, po.ky, 3.2f, lk.sock, shoe, 0.72f, false)
            limb(po.kx, po.ky, po.kx + 0.6f, po.ky + 0.6f, 3.6f, shoe, shoe, 0.5f, false)
        } else if (!side) {
            box(-4, -10, 3, 1, lk.skin); box(1, -10, 3, 1, lk.skin)
            box(-4, -9, 3, 6 - lo, lk.sock); box(1, -9, 3, 6 - ro, lk.sock)
            box(-4, -9, 3, 1, lk.stripe); box(1, -9, 3, 1, lk.stripe)
            box(-5, -3 - lo, 4, 3, shoe); box(1, -3 - ro, 4, 3, shoe)
            box(-5, -1 - lo, 4, 1, sole); box(1, -1 - ro, 4, 1, sole)
            box(-4, -3 - lo, 2, 1, lk.stripe); box(2, -3 - ro, 2, 1, lk.stripe)
        } else {
            val a = if (step == 1) -4 else if (step == 2) 1 else -2
            val b = if (step == 1) 1 else if (step == 2) -4 else -1
            for (x in intArrayOf(a, b)) {
                box(x, -10, 3, 1, lk.skin); box(x, -9, 3, 6, lk.sock); box(x, -9, 3, 1, lk.stripe)
                box(x, -3, 5, 3, shoe); box(x, -1, 5, 1, sole); box(x + 2, -3, 2, 1, lk.stripe)
            }
        }

        // ── à partir d'ici : le haut du corps suit la pose (penché, accroupi)
        shx = if (side) po.lean else 0f
        shy = po.crouch

        // ── cheveux placés derrière la tête
        when (lk.hairStyle) {
            1 -> if (!side) { box(-6, -41, 2, 13, lk.hair); box(4, -41, 2, 13, lk.hair) } else box(-6, -41, 4, 13, lk.hair)
            3 -> if (!side) { box(5, -40, 2, 8, lk.hair); box(6, -33, 1, 3, lk.hair) } else box(-8, -40, 3, 8, lk.hair)
            5 -> box(-8, -50, 16, 13, lk.hair)
        }

        // ── short + maillot
        val wS = if (side) 8 else 12
        val left = -wS / 2
        box(if (side) -4 else -6, -17, if (side) 8 else 12, 7, lk.shorts)
        box(if (side) -4 else -6, -17, if (side) 8 else 12, 1, dk(lk.shorts, 0.8f))
        if (!side) {
            box(-6, -17, 1, 7, lk.stripe); box(5, -17, 1, 7, lk.stripe); box(0, -12, 1, 2, dk(lk.shorts, 0.6f))
        } else box(-1, -17, 2, 7, dk(lk.shorts, 0.9f))
        box(left, -29, wS, 12, lk.jersey)
        box(left, -18, wS, 1, lk.jerseyDark)
        when (lk.pattern) {
            1 -> { var x = left + 2; while (x < left + wS - 1) { box(x, -29, 2, 11, lk.stripe); x += 4 } }
            2 -> box(left, -24, wS, 3, lk.stripe)
            3 -> box(left, -29, wS / 2, 11, lk.stripe)
            4 -> for (yy in 0 until 5) for (xx in 0 until wS / 2) if ((xx + yy) % 2 == 0) box(left + xx * 2, -29 + yy * 2, 2, 2, lk.stripe)
        }
        // col
        if (back) box(-2, -29, 4, 1, dk(lk.jersey, 0.8f))
        else if (!side) { box(-2, -29, 4, 1, lk.skin); box(-1, -28, 2, 1, lk.skin); box(-3, -29, 1, 1, lk.stripe); box(2, -29, 1, 1, lk.stripe) }
        else box(-1, -29, 3, 1, lk.skin)
        // écusson / numéro
        if (back) number(lk.number, -26, if (lum(lk.jersey) > 0.6f) Ink else white)
        else if (!side) { box(left + 2, -25, 2, 2, lk.stripe); box(left + 2, -25, 1, 1, white) }

        // ── bras
        if (po.arms) {
            // bras d'action : dessinés plus bas, par-dessus la tête
        } else if (!side) {
            val la = if (step == 1) 2 else 0
            val ra = if (step == 2) 2 else 0
            if (armsUp) {
                box(-8, -29, 2, 3, lk.sleeve); box(6, -29, 2, 3, lk.sleeve)
                box(-9, -37, 2, 9, lk.skin); box(7, -37, 2, 9, lk.skin)
                box(-9, -39, 2, 2, lk.skin); box(7, -39, 2, 2, lk.skin)
            } else {
                box(-8, -29, 2, 6, lk.sleeve); box(6, -29, 2, 6, lk.sleeve)
                box(-8, -23 + la, 2, 5, lk.skin); box(6, -23 + ra, 2, 5, lk.skin)
                box(-8, -19 + la, 2, 2, lk.skinSh); box(6, -19 + ra, 2, 2, lk.skinSh)
                if (lk.accessory == 3) box(-8, -26, 2, 2, gold)
            }
        } else {
            val sw = if (step == 1) -2 else if (step == 2) 2 else 0
            if (armsUp) {
                box(0, -29, 3, 3, lk.sleeve); box(1, -37, 2, 9, lk.skin); box(1, -39, 2, 2, lk.skin)
            } else {
                box(-1 + sw, -29, 3, 6, lk.sleeve); box(-1 + sw, -23, 2, 5, lk.skin); box(-1 + sw, -19, 2, 2, lk.skinSh)
                if (lk.accessory == 3) box(-1 + sw, -26, 3, 2, gold)
            }
        }

        // ── cou + tête
        box(-2, -31, 4, 2, lk.skinSh)
        box(-5, -42, 10, 11, lk.skin)
        if (!side) { box(-6, -38, 1, 3, lk.skinSh); box(5, -38, 1, 3, lk.skinSh) }
        else { box(-5, -38, 2, 3, lk.skinSh); box(5, -37, 1, 2, lk.skinSh) }

        // ── cheveux dessus / devant
        if (back) {
            if (lk.hairStyle == 2) box(-5, -43, 10, 3, hairD)
            else { box(-5, -44, 10, 13, lk.hair); box(-3, -43, 4, 1, lk.hairHi); box(0, -40, 1, 6, hairD) }
            if (lk.hairStyle == 4) { box(-1, -49, 2, 6, lk.hair); box(-1, -49, 1, 3, lk.hairHi) }
        } else {
            when (lk.hairStyle) {
                2 -> { box(-4, -43, 8, 1, hairD); box(-2, -43, 2, 1, white) }
                4 -> { box(-5, -43, 10, 2, hairD); box(-1, -49, 2, 7, lk.hair); box(-1, -49, 1, 4, lk.hairHi) }
                else -> {
                    box(-5, -44, 10, 4, lk.hair)
                    if (!side) { box(-5, -40, 1, 3, lk.hair); box(4, -40, 1, 3, lk.hair); box(0, -43, 1, 2, hairD) }
                    else box(-5, -40, 3, 6, lk.hair)
                    box(-3, -44, 4, 1, lk.hairHi); box(1, -43, 2, 1, lk.hairHi)
                    if (lk.hairStyle == 5) { box(-5, -48, 2, 1, lk.hairHi); box(2, -47, 2, 1, lk.hairHi); box(-1, -46, 2, 1, lk.hairHi) }
                    if (lk.hairStyle == 3) box(if (side) -8 else 5, -40, 2, 1, lk.stripe)
                }
            }
            // visage
            if (!side) {
                box(-4, -40, 3, 1, hairD); box(1, -40, 3, 1, hairD)
                box(-4, -38, 3, 2, white); box(1, -38, 3, 2, white)
                box(-3, -38, 2, 2, Ink); box(2, -38, 2, 2, Ink)
                box(-3, -38, 1, 1, Color(0xFF8FB8FF)); box(2, -38, 1, 1, Color(0xFF8FB8FF))
                box(0, -36, 1, 1, lk.skinSh)
                box(-4, -35, 1, 1, blush); box(3, -35, 1, 1, blush)
                box(-1, -33, 3, 1, mouth); box(-2, -34, 1, 1, mouth); box(2, -34, 1, 1, mouth)
            } else {
                box(1, -40, 4, 1, hairD)
                box(2, -38, 3, 2, white); box(3, -38, 2, 2, Ink); box(3, -38, 1, 1, Color(0xFF8FB8FF))
                box(5, -37, 1, 2, lk.skinSh)
                box(0, -35, 1, 1, blush)
                box(3, -33, 3, 1, mouth)
            }
        }

        // ── accessoires
        when (lk.accessory) {
            1 -> { box(-5, -42, 10, 2, lk.stripe); box(-5, -42, 10, 1, dk(lk.stripe, 0.8f)); if (side) box(-7, -42, 2, 3, lk.stripe) }
            2 -> if (!back) {
                if (!side) { box(-5, -38, 10, 3, Ink); box(-4, -38, 3, 1, Color(0xFF7FD6FF)); box(1, -38, 3, 1, Color(0xFF7FD6FF)) }
                else { box(-5, -38, 11, 1, Ink); box(1, -38, 5, 3, Ink); box(2, -38, 3, 1, Color(0xFF7FD6FF)) }
            }
            4 -> {
                box(-6, -47, 12, 5, lk.jersey); box(-6, -43, 12, 1, lk.jerseyDark); box(-5, -47, 6, 1, dk(lk.jersey, 1.2f))
                if (!back) { if (side) box(5, -42, 5, 2, lk.jerseyDark) else box(-6, -42, 12, 2, lk.jerseyDark) }
            }
            5 -> {
                box(-5, -48, 10, 3, gold); box(-5, -51, 2, 3, gold); box(-1, -52, 2, 4, gold); box(3, -51, 2, 3, gold)
                box(-5, -48, 10, 1, Color(0xFFFFF2B0)); box(-1, -47, 2, 1, Color(0xFFFF4A6A))
            }
        }

        // ── bras d'action (segments inclinés selon la pose)
        if (po.arms) {
            val sh = -27f
            val cSleeve = lk.sleeve
            val cSkin = lk.skin
            val cDark = dk(lk.sleeve, 0.78f)
            val dSkin = dk(lk.skin, 0.82f)
            val gl = Color(0xFFFF8A3D)
            if (side) {
                val h1x = po.a1r
                val h1y = sh + po.a1y
                val h2x = if (po.together) po.a1r - 0.8f else po.a2r
                val h2y = if (po.together) sh + po.a1y else sh + po.a2y
                limb(0f, sh, h2x, h2y, 2.4f, cDark, dSkin, 0.4f)
                limb(0f, sh, h1x, h1y, 2.6f, cSleeve, cSkin, 0.4f)
                if (keeper) { limb(h2x, h2y, h2x, h2y, 3.4f, gl, gl); limb(h1x, h1y, h1x, h1y, 3.6f, gl, gl) }
            } else {
                val rx = if (po.together) 1.6f else 7.5f + po.a1r * 0.3f
                val lx = if (po.together) -1.6f else -7.5f - po.a2r * 0.3f
                val ry = sh + po.a1y
                val ly = if (po.together) sh + po.a1y else sh + po.a2y
                limb(-6.5f, sh, lx, ly, 2.4f, cDark, dSkin, 0.4f)
                limb(6.5f, sh, rx, ry, 2.6f, cSleeve, cSkin, 0.4f)
                if (keeper) { limb(lx, ly, lx, ly, 3.4f, gl, gl); limb(rx, ry, rx, ry, 3.6f, gl, gl) }
            }
        }

        // ── détails supplémentaires : plis, poignets, marque, oreilles, dents, protections, crampons, gants
        val fold = dk(lk.jersey, 0.86f)
        box(left + 1, -23, 1, 4, fold); box(left + wS - 3, -27, 1, 5, fold)
        if (!back) {
            box(left + wS - 4, -26, 2, 1, white)
            if (!side) {
                if (!po.arms) { box(-8, -24, 2, 1, lk.stripe); box(6, -24, 2, 1, lk.stripe) }
                box(-6, -37, 1, 1, dk(lk.skin, 0.8f)); box(5, -37, 1, 1, dk(lk.skin, 0.8f))
                box(0, -37, 1, 1, mix(lk.skin, white, 0.4f))
                box(0, -33, 1, 1, white)
                box(-1, -16, 2, 1, white)
                box(-4, -39, 3, 1, dk(lk.skin, 0.85f)); box(1, -39, 3, 1, dk(lk.skin, 0.85f))
            }
        }
        shx = 0f
        shy = 0f
        if (!side) { box(-4, -7, 3, 1, lk.stripe); box(1, -7, 3, 1, lk.stripe) }
        when (kind) {
            0 -> if (!keeper && !side) {
                box(-4, -6, 3, 3, Color(0xFFE6E6EE)); box(1, -6, 3, 3, Color(0xFFE6E6EE))
                box(-4, -lo, 1, 1, sole); box(-1, -lo, 1, 1, sole); box(2, -ro, 1, 1, sole); box(4, -ro, 1, 1, sole)
            }
            1 -> if (!side) {
                box(-4, -4 - lo, 3, 1, lk.stripe); box(1, -4 - ro, 3, 1, lk.stripe)
                if (!po.arms) { box(-8, -21, 2, 1, white); box(6, -21, 2, 1, white) }
            }
            2 -> if (!side) { box(-4, -6, 3, 2, Color(0xFF2E2E3A)); box(1, -6, 3, 2, Color(0xFF2E2E3A)) }
        }
        if (keeper && !po.arms) {
            shx = if (side) po.lean else 0f
            shy = po.crouch
            val gl = Color(0xFFFF8A3D)
            val gl2 = Color(0xFFFFB27A)
            if (armsUp) {
                if (!side) { box(-10, -41, 3, 3, gl); box(7, -41, 3, 3, gl) } else box(1, -41, 3, 3, gl)
            } else if (!side) {
                box(-9, -22, 3, 4, gl); box(6, -22, 3, 4, gl); box(-9, -22, 3, 1, gl2); box(6, -22, 3, 1, gl2)
            } else box(-1, -22, 3, 4, gl)
        }
    }
    flush(cxC, baseC)
}

internal fun Px.drawPlayerHi(m: Match, p: Player, tick: Int, isCtrl: Boolean, skin: Skin) {
    val lk = lookOf(m, p, skin)
    val xp = (p.x * 4f).roundToInt() / 4f
    val yp = (p.y * 4f).roundToInt() / 4f
    val po = poseFor(poseBuf, m, p, tick)
    val ap = if (p.anim != 0 && p.animT > 0f && p.animDur > 0f) (1f - p.animT / p.animDur).coerceIn(0f, 1f) else 1f
    var lift = if (p.jumpT > 0f) sin(min(1f, p.jumpT / 0.45f) * 3.14159f) * 7f else 0f
    lift += po.lift
    // ombre douce (3 couches), plus petite quand le joueur saute
    val sk = 1f - min(0.4f, lift * 0.04f)
    r(xp - 5f * sk, yp - 0.5f, 10f * sk, 1.5f, Color.Black.copy(alpha = 0.16f))
    r(xp - 4f * sk, yp - 1f, 8f * sk, 2.5f, Color.Black.copy(alpha = 0.16f))
    r(xp - 2.5f * sk, yp - 1.25f, 5f * sk, 3f, Color.Black.copy(alpha = 0.12f))
    if (isCtrl) {
        val ringCol = Gold.copy(alpha = 0.9f)
        r(xp - 6f, yp, 12f, 1f, ringCol)
        r(xp - 5f, yp + 1f, 10f, 1f, ringCol)
        r(xp - 5f, yp - 1f, 1f, 1f, ringCol); r(xp + 4f, yp - 1f, 1f, 1f, ringCol)
    }
    val step = if (p.runT > 0f) 1 + (p.runT.toInt() and 1) else 0
    val keeper = m.sport == Sport.FOOT && p.slot == 0
    val sliding = p.tackT > 0f
    var dvy = 0f
    if (keeper && p.diveT > 0f) {
        val k = sin(min(1f, p.diveT / 0.45f) * 3.14159f)
        dvy = p.diveDir * k * 7f
    }
    drawLook(xp, yp + dvy, lk, p.fx, p.fy, step, lift, (keeper && p.diveT > 0f) || p.jumpT > 0f || p.windT > 0f,
        when (m.sport) { Sport.FOOT -> 0; Sport.BASKET -> 1; Sport.VOLLEY -> 2 }, keeper, po)
    if (sliding) {
        val ddx = -p.tdx * 7f
        val ddy = -p.tdy * 5f
        r(xp + ddx - 2f, yp + ddy - 2f, 3f, 2f, Color(0xAAE8D9B0))
        r(xp + ddx * 2f - 1f, yp + ddy * 2f - 1f, 2f, 2f, Color(0x88E8D9B0))
        r(xp + ddx * 3f - 0.5f, yp + ddy * 3f - 0.5f, 1.5f, 1.5f, Color(0x55E8D9B0))
    }
    // étincelle d'impact au moment du geste (pied, main)
    if (p.anim != 0 && p.animT > 0f && ap < 0.28f && p.anim != Anim.CELEBRATE && p.anim != Anim.SAD) {
        val al = 0.85f * (1f - ap / 0.28f)
        val ix = xp + p.fx * 9f
        val iy = yp - 7f + p.fy * 5f - lift
        val c = Color.White.copy(alpha = al)
        r(ix - 0.5f, iy - 0.5f, 1f, 1f, c)
        r(ix - 1.75f, iy - 0.25f, 3.5f, 0.5f, c)
        r(ix - 0.25f, iy - 1.75f, 0.5f, 3.5f, c)
    }
    if (isCtrl) drawMarker(xp.roundToInt(), yp.roundToInt() - 28 - lift.roundToInt() - (if (lk.accessory == 5) 4 else if (lk.hairStyle == 5 || lk.hairStyle == 4) 3 else 0), tick, skin.marker)
}

/** Marqueur au-dessus du joueur piloté (cosmétique). */
internal fun Px.drawMarker(px: Int, y: Int, tick: Int, type: Int) {
    val bob = if ((tick / 10) % 2 == 0) 0 else 1
    val cx = px * 2
    val by = (y + bob) * 2
    val col = when (type) {
        1 -> Color(0xFF35F0FF); 2 -> Color(0xFFFF5FB0); 3 -> Color(0xFF7FE8FF); 4 -> Color(0xFFFFE04A)
        5 -> Color(0xFFFFD24A); else -> Gold
    }
    when (type) {
        3 -> { h(cx - 1, by, 2, 2, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 1, by + 4, 2, 2, col) }
        4 -> { h(cx - 1, by, 2, 6, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 2, by + 1, 4, 4, col.copy(alpha = 0.6f)) }
        5 -> { h(cx - 4, by + 2, 8, 3, col); h(cx - 4, by, 2, 2, col); h(cx - 1, by - 1, 2, 3, col); h(cx + 2, by, 2, 2, col) }
        else -> { h(cx - 4, by, 8, 2, col); h(cx - 3, by + 2, 6, 2, col); h(cx - 1, by + 4, 2, 2, col); h(cx - 2, by + 2, 4, 1, Color.White.copy(alpha = 0.4f)) }
    }
}

private fun hash(i: Int, j: Int, s: Int): Int = lcg(i * 73856093 xor j * 19349663 xor s * 83492791)

private val FOOT_W = arrayOf(Color(0xFFFFFFFF), Color(0xFFE4E7EE), Color(0xFFB9BFCC))
private val VOL_Y = arrayOf(Color(0xFFFFDC4A), Color(0xFFF2C230), Color(0xFFC49A1A))
private val VOL_B = arrayOf(Color(0xFF5A8CFF), Color(0xFF2F6BFF), Color(0xFF1E4ACF))
private val BASK_O = arrayOf(Color(0xFFFF9140), Color(0xFFEE7A1F), Color(0xFFC95E10))
private val FOOT_BLACK = Color(0xFF1B1B22)
private val BASK_SEAM = Color(0xFF3B1E0C)

/** Couleur du ballon au point (x, y) exprimé en « demi-pixels » (0..14, centre en 6.5) ; fi / fj : cellule fine (28 x 28). */
private fun ballColor(sport: Sport, skinIdx: Int, x: Float, y: Float, spin: Float, fi: Int, fj: Int): Color {
    val dx = x - 6.5f
    val dy = y - 6.5f
    val t = (dx + dy) / 13.6f // -0.5 (clair) .. +0.5 (ombre)
    val shade = when { t > 0.28f -> 2; t > -0.05f -> 1; else -> 0 }
    val skinOpt = Cosmetics.balls[skinIdx]
    val a = spin * 0.5f
    val ph = floor(abs(spin)).toInt() and 3
    val band = (floor((y + (a * 2f).toInt() + 40f) / 3f).toInt()) % 3
    // motif : true = zone d'accent (taches, bandes, coutures)
    val accent: Boolean = when (sport) {
        Sport.FOOT -> (0 until 3).any { k ->
            val ang = a + k * 2.0944f
            val cx = 6.5f + cos(ang) * 3.6f
            val cy = 6.5f + sin(ang) * 3.6f
            (x - cx) * (x - cx) + (y - cy) * (y - cy) < 3.4f
        } || (dx * dx + dy * dy < 2.2f && (ph and 1) == 0)
        Sport.VOLLEY -> band == 1
        Sport.BASKET -> abs(dx) < 0.62f || abs(dy) < 0.62f ||
            (((ph and 1) == 0) && abs(x - y) < 0.62f) || (((ph and 1) == 1) && abs(x + y - 13f) < 0.62f)
    }
    if (skinIdx == 0) {
        return when (sport) {
            Sport.FOOT -> if (accent) FOOT_BLACK else FOOT_W[shade]
            Sport.VOLLEY -> when (band) {
                1 -> VOL_Y[shade]
                2 -> VOL_B[shade]
                else -> FOOT_W[shade]
            }
            Sport.BASKET -> if (accent) BASK_SEAM else BASK_O[shade]
        }
    }
    if (skinIdx == 5) { // arc-en-ciel
        val hue = ((x + y) * 14f + spin * 25f) % 360f
        return Color.hsv(if (hue < 0) hue + 360f else hue, if (shade == 2) 0.9f else 0.7f, if (shade == 2) 0.75f else 1f)
    }
    val b = Color(skinOpt.color)
    val c = Color(skinOpt.color2)
    if (skinIdx == 3 && hash(fi, fj, 3) % 14 == 0) return c // galaxie : étoiles
    val lit = when (shade) { 0 -> 1.15f; 1 -> 1f; else -> 0.72f }
    val base = if (accent) c else b
    return Color(min(1f, base.red * lit), min(1f, base.green * lit), min(1f, base.blue * lit), 1f)
}

/** Remplit ballBuf (28 x 28 cellules = 7 x 7 pixels du terrain) avec le ballon. */
private fun fillBall(sport: Sport, skinIdx: Int, spin: Float) {
    for (j in 0 until 28) {
        for (i in 0 until 28) {
            val x = (i + 0.5f) / 2f - 0.5f
            val y = (j + 0.5f) / 2f - 0.5f
            val dx = x - 6.5f
            val dy = y - 6.5f
            val d2 = dx * dx + dy * dy
            if (d2 > 45f) { ballBuf[j * 28 + i] = 0; continue }
            val c = ballColor(sport, skinIdx, x, y, spin, i, j)
            val col = if (d2 > 36f) Color(c.red * 0.7f, c.green * 0.7f, c.blue * 0.7f, 1f) else c
            ballBuf[j * 28 + i] = col.toArgb() or (0xFF shl 24)
        }
    }
}

internal fun Px.drawBallHi(m: Match, skin: Skin) {
    val bz = m.bz
    val shw = max(6f, 14f - bz / 5f)
    val sx = (m.bx * 4f).roundToInt() / 4f
    r(sx - shw / 4f, m.by + 1f, shw / 2f, 1.5f, Color.Black.copy(alpha = 0.18f))
    r(sx - shw / 6f, m.by + 0.75f, shw / 3f, 2f, Color.Black.copy(alpha = 0.16f))
    val cxC = (m.bx * 4f).roundToInt()
    val cyC = ((m.by - bz * 0.6f) * 4f).roundToInt()
    fillBall(m.sport, skin.ball, m.ballSpin)
    blitCells(ballBuf, 28, 28, cxC * 0.25f - 3.5f, cyC * 0.25f - 3.5f, 0.25f)
}

internal fun Px.drawTrail(m: Match, skin: Skin) {
    if (skin.trail == 0 || m.phase != Phase.PLAY) return
    for (i in 2 until m.trailX.size) {
        val tx = m.trailX[i]
        val ty = m.trailY[i] - m.trailZ[i] * 0.6f
        if (tx == 0f && ty == 0f) continue
        val d = abs(tx - m.bx) + abs(ty - (m.by - m.bz * 0.6f))
        if (d < 3f || d > 90f) continue
        val f = 1f - i / m.trailX.size.toFloat()
        val sz = max(2, (9 * f).roundToInt())
        val x = (tx * 2f).roundToInt()
        val y = (ty * 2f).roundToInt()
        when (skin.trail) {
            1 -> h(x - sz / 2, y - sz / 2, sz, sz, Color.White.copy(alpha = 0.55f * f))
            2 -> {
                val c = if (i % 2 == 0) Color(0xFFFFE04A) else Color.White
                h(x + ((hash(i, 1, tick(m)) % 9) - 4), y + ((hash(i, 2, tick(m)) % 9) - 4), 2, 2, c.copy(alpha = f))
            }
            3 -> h(x - sz / 2, y - sz / 2, sz, sz, Color(1f, 0.25f + 0.55f * f, 0.05f, 0.85f * f))
            else -> h(x - sz / 2, y - sz / 2, sz, sz, Color.hsv((i * 32f) % 360f, 0.85f, 1f).copy(alpha = 0.85f * f))
        }
    }
}

private fun tick(m: Match) = (m.simTime * 30f).toInt()

internal fun Px.drawConfetti(m: Match) {
    if (m.phase != Phase.SCORED) return
    val age = m.scoredAge
    val cols = listOf(0xFFFFC83D, 0xFF3DDC84, 0xFF2F6BFF, 0xFFFF5A4A, 0xFFFF5FB0, 0xFFFFFFFF)
    for (i in 0 until 46) {
        val hh = hash(i, 7, 5)
        val x = (hh % 320) + sin(age * 3f + i) * 6f
        val y = -8f + age * (50f + (hh / 7) % 70) - ((hh / 13) % 30)
        if (y < 0f || y > 180f) continue
        h((x * 2f).roundToInt(), (y * 2f).roundToInt(), 3, 3, Color(cols[hh % cols.size]))
    }
}

/** Repère au sol de l'endroit où le ballon va tomber (volley). */
internal fun Px.drawLanding(m: Match, tick: Int) {
    if (m.sport != Sport.VOLLEY || m.phase != Phase.PLAY || m.serveHeld() || m.bz < 4f) return
    val l = m.landing()
    if (l[0] < Court.VX0 - 10f || l[0] > Court.NET_X + 2f) return
    val pulse = 5f + (tick / 6 % 3)
    ring(l[0], l[1], pulse, Color(0xCCFFFFFF))
    ring(l[0], l[1], pulse - 2f, Color(0x88FFC83D))
    h((l[0] * 2f).roundToInt() - 1, (l[1] * 2f).roundToInt() - 1, 2, 2, Color(0xFFFFC83D))
}

/** Ballon dessiné seul (aperçu du skin) : (cx, cy) = centre en unités du terrain. */
internal fun Px.drawBallRaw(cx: Float, cy: Float, sport: Sport, skinIdx: Int, spin: Float) {
    fillBall(sport, skinIdx, spin)
    blitCells(ballBuf, 28, 28, (cx * 4f).roundToInt() * 0.25f - 3.5f, (cy * 4f).roundToInt() * 0.25f - 3.5f, 0.25f)
}

/** Aperçu de la traînée : le ballon va vers la droite. */
internal fun Px.drawTrailPreview(cx: Float, cy: Float, trail: Int, tick: Int) {
    if (trail == 0) return
    for (i in 2 until 12) {
        val f = 1f - i / 12f
        val sz = max(2, (9 * f).roundToInt())
        val x = ((cx - i * 2.2f) * 2f).roundToInt()
        val y = (cy * 2f).roundToInt()
        when (trail) {
            1 -> h(x - sz / 2, y - sz / 2, sz, sz, Color.White.copy(alpha = 0.55f * f))
            2 -> h(x + ((hash(i, 1, tick / 4) % 7) - 3), y + ((hash(i, 2, tick / 4) % 9) - 4), 2, 2,
                (if (i % 2 == 0) Color(0xFFFFE04A) else Color.White).copy(alpha = f))
            3 -> h(x - sz / 2, y - sz / 2, sz, sz, Color(1f, 0.25f + 0.55f * f, 0.05f, 0.85f * f))
            else -> h(x - sz / 2, y - sz / 2, sz, sz, Color.hsv((i * 32f) % 360f, 0.85f, 1f).copy(alpha = 0.85f * f))
        }
    }
}
